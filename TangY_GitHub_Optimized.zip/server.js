// server.ts
import express from "express";
import path from "path";
import { fileURLToPath } from "url";
import fs from "fs";
import { GoogleGenAI } from "@google/genai";

// src/data/Viet_Phuc_Master_Research_v1.json
var Viet_Phuc_Master_Research_v1_default = {
  README: {
    title: "VI\u1EC6T PH\u1EE4C \u2014 MASTER RESEARCH v1",
    purpose: "B\u1ED9 d\u1EEF li\u1EC7u n\u1EC1n cho web \u201CVi\u1EC7t ph\u1EE5c Remix\u201D: kh\xE1m ph\xE1, ph\u1ED1i \u0111\u1ED3 v\xE0 c\u1EA3nh b\xE1o ph\u1ED1i kh\xF4ng ph\xF9 h\u1EE3p v\u1EC1 m\u1EB7t l\u1ECBch s\u1EED/v\u0103n h\xF3a.",
    scope: "Kinh ph\u1EE5c / Vi\u1EC7t ph\u1EE5c c\u1EE7a ng\u01B0\u1EDDi Vi\u1EC7t (Kinh), kh\xF4ng m\u1EDF r\u1ED9ng 54 d\xE2n t\u1ED9c trong phi\xEAn b\u1EA3n audition n\xE0y.",
    excluded: "Model ng\u01B0\u1EDDi, \u1EA3nh garment, 3D model \u2014 ng\u01B0\u1EDDi d\xF9ng s\u1EBD t\u1EF1 cung c\u1EA5p.",
    principle: "Kh\xF4ng coi m\u1ED9t outfit l\xE0 \u201C\u0111\xFAng\u201D ch\u1EC9 v\xEC nh\xECn h\u1EE3p m\u1EAFt. M\u1ECDi quan h\u1EC7 ph\u1ED1i ph\u1EA3i x\xE9t th\u1EDDi k\u1EF3, v\xF9ng, \u0111\u1ED1i t\u01B0\u1EE3ng, ng\u1EEF c\u1EA3nh v\xE0 m\u1EE9c \u0111\u1ED9 b\u1EB1ng ch\u1EE9ng.",
    evidenceLevels: {
      VERIFIED: "C\xF3 t\u01B0 li\u1EC7u/hi\u1EC7n v\u1EADt/ngu\u1ED3n m\u1EA1nh t\u1EEB b\u1EA3o t\xE0ng ho\u1EB7c th\u01B0 t\u1ECBch ch\xEDnh th\u1ED1ng.",
      CONSISTENT: "Ph\xF9 h\u1EE3p v\u1EDBi b\u1ED1i c\u1EA3nh nh\u01B0ng kh\xF4ng c\xF3 b\u1EB1ng ch\u1EE9ng tr\u1EF1c ti\u1EBFp cho \u0111\xFAng combo.",
      REMIX: "Ch\u1EE7 \xFD hi\u1EC7n \u0111\u1EA1i h\xF3a / s\xE1ng t\u1EA1o \u0111\u01B0\u01A1ng \u0111\u1EA1i, kh\xF4ng g\u1ECDi l\xE0 ph\u1EE5c d\u1EF1ng nguy\xEAn b\u1EA3n.",
      UNCERTAIN: "Ch\u01B0a \u0111\u1EE7 ngu\u1ED3n t\u01B0 li\u1EC7u ho\u1EB7c c\xF2n ph\xE2n t\xE1n, c\u1EA7n th\u1EADn tr\u1ECDng.",
      CONTESTED: "Thu\u1EADt ng\u1EEF / c\xE1ch hi\u1EC3u c\xF2n tranh lu\u1EADn gi\u1EEFa c\xE1c nh\xE0 nghi\xEAn c\u1EE9u v\xE0 ngu\u1ED3n ph\u1EE5c d\u1EF1ng.",
      MISMATCH: "C\xF3 m\xE2u thu\u1EABn r\xF5 r\u1EC7t v\u1EC1 th\u1EDDi k\u1EF3, ph\u1EA9m c\u1EA5p ho\u1EB7c quy th\u1EE9c v\u0103n h\xF3a."
    },
    prioritySources: "1) B\u1EA3o t\xE0ng/di s\u1EA3n nh\xE0 n\u01B0\u1EDBc; 2) t\u01B0 li\u1EC7u/hi\u1EC7n v\u1EADt v\xE0 s\xE1ch nghi\xEAn c\u1EE9u \u0111\u01B0\u1EE3c c\u01A1 quan v\u0103n h\xF3a d\u1EABn; 3) nghi\xEAn c\u1EE9u h\u1ECDc thu\u1EADt; 4) ngu\u1ED3n ph\u1EE5c d\u1EF1ng chuy\xEAn m\xF4n; ngu\u1ED3n c\u1ED9ng \u0111\u1ED3ng ch\u1EC9 d\xF9ng \u0111\u1EC3 ph\xE1t hi\u1EC7n v\u1EA5n \u0111\u1EC1 v\xE0 kh\xF4ng t\u1EF1 \u0111\u1ED9ng coi l\xE0 b\u1EB1ng ch\u1EE9ng.",
    notes: "C\xE1c m\u1EE5c nh\u01B0 T\u1EE9 \u0110i\xEAn, m\u1ED9t s\u1ED1 thu\u1EADt ng\u1EEF Tr\u1EF1c l\u0129nh/C\u1ED5 th\xECa/B\xE1n t\xED v\xE0 ph\xE2n bi\u1EC7t n\xF3n Ba T\u1EA7m\u2013quai thao c\xF3 tranh lu\u1EADn/kh\xE1c c\xE1ch g\u1ECDi. File gi\u1EEF tr\u1EA1ng th\xE1i b\u1EA5t \u0111\u1ECBnh thay v\xEC \xE9p th\xE0nh m\u1ED9t \u0111\xE1p \xE1n."
  },
  MASTER_GARMENTS: [
    {
      id: "G001",
      name: "\xC1o Giao L\u0129nh",
      aliases: ["Giao l\u0129nh", "Tr\xE0ng v\u1EA1t"],
      category: "\xC1o th\xE2n tr\xEAn",
      period: ["L\xFD", "Tr\u1EA7n", "L\xEA", "Nguy\u1EC5n (nghi l\u1EC5)"],
      audience: ["Nam", "N\u1EEF"],
      region: ["B\u1EAFc B\u1ED9", "Kinh k\u1EF3"],
      context: ["Nghi l\u1EC5", "Tri\u1EC1u ch\xEDnh x\u01B0a", "C\u1ED5 phong"],
      auditStatus: "GI\u1EEE + CHU\u1EA8N H\xD3A",
      evidenceLevel: "CONSISTENT",
      constructionNotes: "C\u1ED5 giao nhau tr\u01B0\u1EDBc ng\u1EF1c (v\u1EA1t tr\xE1i \u0111\xE8 v\u1EA1t ph\u1EA3i); h\xECnh th\u1EE9c v\xE0 \u0111\u1ED9 th\u1EE5ng thay \u0111\u1ED5i theo t\u1EEBng th\u1EDDi k\u1EF3.",
      layerCompatibility: "Ph\u1EA3i x\xE1c \u0111\u1ECBnh period tr\u01B0\u1EDBc khi gh\xE9p ph\u1EE5 ki\u1EC7n.",
      warnings: "Kh\xF4ng gh\xE9p t\xF9y ti\u1EC7n ph\u1EE5 ki\u1EC7n/c\u1EA5u tr\xFAc c\u1EE7a Nguy\u1EC5n v\xE0o set L\xEA/L\xFD\u2013Tr\u1EA7n.",
      researchNotes: "Kh\xF4ng n\xEAn d\xF9ng m\u1ED9t m\xF4 t\u1EA3 duy nh\u1EA5t cho m\u1ECDi th\u1EDDi k\u1EF3.",
      sourceIds: ["S02", "S07"]
    },
    {
      id: "G002",
      name: "\xC1o Tr\u1EF1c L\u0129nh",
      aliases: ["Tr\u1EF1c l\u0129nh"],
      category: "\xC1o th\xE2n tr\xEAn",
      period: ["L\xEA Trung H\u01B0ng"],
      audience: ["Nam", "N\u1EEF"],
      region: ["\u0110\xE0ng Ngo\xE0i", "\u0110\xE0ng Trong"],
      context: ["L\u1ECBch s\u1EED", "C\u1ED5 phong"],
      auditStatus: "TH\xCAM",
      evidenceLevel: "UNCERTAIN",
      constructionNotes: "T\xEAn g\u1ECDi/h\u1EC7 ph\xE2n lo\u1EA1i c\xF3 c\xE1ch hi\u1EC3u kh\xE1c nhau gi\u1EEFa c\xE1c ngu\u1ED3n ph\u1EE5c d\u1EF1ng. C\u1ED5 \xE1o ch\u1EA1y th\u1EB3ng song song tr\u01B0\u1EDBc ng\u1EF1c.",
      layerCompatibility: "C\xF3 quan h\u1EC7 v\u1EDBi Giao l\u0129nh/\u0110\u1ED1i kh\xE2m/C\u1ED5 th\xECa trong m\u1ED9t s\u1ED1 h\u1EC7 ph\xE2n lo\u1EA1i ph\u1EE5c d\u1EF1ng.",
      warnings: "Kh\xF4ng coi s\u01A1 \u0111\u1ED3 ph\xE2n lo\u1EA1i l\xE0 s\u1EF1 th\u1EADt tuy\u1EC7t \u0111\u1ED1i n\u1EBFu ch\u01B0a g\u1EAFn ngu\u1ED3n \u0111\u1ED1i chi\u1EBFu.",
      researchNotes: "C\u1EA7n m\u1ED9t ghi ch\xFA r\xF5 v\u1EC1 thu\u1EADt ng\u1EEF \u0111ang tranh lu\u1EADn.",
      sourceIds: ["S07"]
    },
    {
      id: "G003",
      name: "\xC1o \u0110\u1ED1i Kh\xE2m",
      aliases: ["\u0110\u1ED1i kh\xE2m", "B\xF9 Long"],
      category: "\xC1o kho\xE1c/\xE1o th\xE2n tr\xEAn",
      period: ["L\xEA Trung H\u01B0ng", "Nguy\u1EC5n"],
      audience: ["Nam", "N\u1EEF", "Qu\xFD t\u1ED9c", "Quan l\u1EA1i"],
      region: ["Kinh k\u1EF3", "Cung \u0111\xECnh"],
      context: ["Cung \u0111\xECnh", "Qu\xFD t\u1ED9c", "Nghi l\u1EC5"],
      auditStatus: "S\u1EECA",
      evidenceLevel: "CONSISTENT",
      constructionNotes: "Hai v\u1EA1t tr\u01B0\u1EDBc song song \u0111\u1ED1i x\u1EE9ng nhau; th\u01B0\u1EDDng l\xE0 \xE1o kho\xE1c ngo\xE0i trong c\xE1c m\xF4 t\u1EA3 ph\u1EE5c d\u1EF1ng.",
      layerCompatibility: "C\xF3 th\u1EC3 t\u1EA1o layer ngo\xE0i; c\u1EA7n x\xE1c \u0111\u1ECBnh period/context.",
      warnings: "Kh\xF4ng t\u1EF1 \u0111\u1ED9ng ph\u1ED1i v\u1EDBi m\u1ECDi \xE1o c\u1ED5 truy\u1EC1n. Kh\xF4ng gi\u1EEF \u0111\u1ECBnh ki\u1EBFn 'kh\xF4ng c\xE0i c\xFAc' nh\u01B0 t\xE0i li\u1EC7u c\u0169.",
      researchNotes: "\u0110\xE3 \u0111\xEDnh ch\xEDnh t\u1EEB nh\u1EADn \u0111\u1ECBnh sai trong PDF c\u0169.",
      sourceIds: ["S01", "S07"]
    },
    {
      id: "G004",
      name: "\xC1o C\u1ED5 Th\xECa",
      aliases: ["C\u1ED5 th\xECa"],
      category: "\xC1o th\xE2n tr\xEAn",
      period: ["L\xEA Trung H\u01B0ng"],
      audience: ["C\u1EA7n x\xE1c minh"],
      region: ["B\u1EAFc B\u1ED9"],
      context: ["L\u1ECBch s\u1EED"],
      auditStatus: "TH\xCAM + X\xC1C MINH",
      evidenceLevel: "UNCERTAIN",
      constructionNotes: "C\u1ED5 \xE1o kho\xE9t cong nh\u01B0 h\xECnh chi\u1EBFc th\xECa; t\xEAn \u0111\u01B0\u1EE3c m\u1ED9t s\u1ED1 ngu\u1ED3n ph\u1EE5c d\u1EF1ng x\u1EBFp trong h\u1EC7 Tr\u1EF1c l\u0129nh.",
      layerCompatibility: "Ch\u01B0a \u0111\u1EE7 ngu\u1ED3n m\u1EA1nh \u0111\u1EC3 t\u1EA1o rule ph\u1ED1i c\u1EE5 th\u1EC3.",
      warnings: "Kh\xF4ng cho engine \u0111\xE1nh d\u1EA5u VERIFIED.",
      researchNotes: "C\u1EA7n nghi\xEAn c\u1EE9u ri\xEAng tr\u01B0\u1EDBc khi \u0111\u01B0a v\xE0o UI ch\xEDnh.",
      sourceIds: ["S07"]
    },
    {
      id: "G005",
      name: "\xC1o B\xE1n T\xED",
      aliases: ["Vi\xEAn l\u0129nh b\xE1n t\xED", "Giao l\u0129nh b\xE1n t\xED", "\u0110\u1ED1i kh\xE2m b\xE1n t\xED"],
      category: "\xC1o tay ng\u1EAFn",
      period: ["Nhi\u1EC1u th\u1EDDi k\u1EF3"],
      audience: ["Nam", "N\u1EEF"],
      region: ["Kinh k\u1EF3"],
      context: ["L\u1ECBch s\u1EED"],
      auditStatus: "TH\xCAM + X\xC1C MINH",
      evidenceLevel: "UNCERTAIN",
      constructionNotes: "D\u1EA1ng tay ng\u1EAFn (b\xE1n t\xED = n\u1EEDa c\xE1nh tay); ngu\u1ED3n ph\u1EE5c d\u1EF1ng ghi c\xE1c bi\u1EBFn th\u1EC3 theo ki\u1EC3u c\u1ED5 \xE1o.",
      layerCompatibility: "Ch\u01B0a x\xE2y rule ph\u1ED1i m\u1EB7c \u0111\u1ECBnh.",
      warnings: "Kh\xF4ng suy ra th\u1EDDi k\u1EF3 ch\u1EC9 t\u1EEB t\xEAn g\u1ECDi B\xE1n T\xED.",
      researchNotes: "C\u1EA7n ngu\u1ED3n hi\u1EC7n v\u1EADt ho\u1EB7c tranh \u1EA3nh l\u1ECBch s\u1EED m\u1EA1nh h\u01A1n.",
      sourceIds: ["S07"]
    },
    {
      id: "G006",
      name: "\xC1o Vi\xEAn L\u0129nh",
      aliases: ["\u0110o\xE0n l\u0129nh", "B\xE0n l\u0129nh", "C\u1ED5 ki\u1EC1ng"],
      category: "\xC1o th\xE2n tr\xEAn",
      period: ["L\xFD", "Tr\u1EA7n", "L\xEA", "Nguy\u1EC5n"],
      audience: ["Nam", "N\u1EEF"],
      region: ["Kinh k\u1EF3", "Cung \u0111\xECnh"],
      context: ["C\xF4ng ph\u1EE5c", "L\u1EC5 ph\u1EE5c cung \u0111\xECnh", "Qu\xFD t\u1ED9c"],
      auditStatus: "GI\u1EEE + CHU\u1EA8N H\xD3A",
      evidenceLevel: "CONSISTENT",
      constructionNotes: "C\u1ED5 tr\xF2n \xF4m s\xE1t ho\u1EB7c \u0111\u1EE9ng th\u1EA5p; c\xE0i n\xFAt b\xEAn vai h\u1EEFu trong m\xF4 t\u1EA3 c\u1ED5 ph\u1EE5c; th\u1EDDi Nguy\u1EC5n c\xF3 nhi\u1EC1u d\u1EA1ng b\xE0n l\u0129nh.",
      layerCompatibility: "Ph\u1EA3i g\u1EAFn theo period v\xE0 context c\u1EE5 th\u1EC3.",
      warnings: "Kh\xF4ng d\xF9ng m\u1ED9t m\u1EABu vi\xEAn l\u0129nh l\xE0m \u0111\u1EA1i di\u1EC7n cho m\u1ECDi tri\u1EC1u \u0111\u1EA1i.",
      researchNotes: "T\xEAn g\u1ECDi v\xE0 c\u1EA5u tr\xFAc thay \u0111\u1ED5i r\xF5 r\u1EC7t qua t\u1EEBng th\u1EDDi k\u1EF3.",
      sourceIds: ["S01", "S07"]
    },
    {
      id: "G007",
      name: "\xC1o T\u1EE9 \u0110i\xEAn",
      aliases: ["T\u1EE9 \u0111i\xEAn", "T\u1EE9 \u0111i\u1EC1n"],
      category: "\xC1o b\u1ED1n v\u1EA1t",
      period: ["L\xFD", "Tr\u1EA7n"],
      audience: ["Nam th\u01B0\u1EDDng d\xE2n", "Binh s\u0129"],
      region: ["\u0110\u1EA1i Vi\u1EC7t"],
      context: ["D\xE2n gian", "\u0110\u1EDDi th\u01B0\u1EDDng x\u01B0a"],
      auditStatus: "GI\u1EEE NH\u01AFNG G\u1EAEN C\u1EA2NH B\xC1O",
      evidenceLevel: "UNCERTAIN",
      constructionNotes: "V\u0103n li\u1EC7u th\u01B0 t\u1ECBch c\u1ED5 m\xF4 t\u1EA3 \xE1o m\xE0u \u0111en, c\u1ED5 tr\xF2n, b\u1ED1n v\u1EA1t x\u1EBB; c\u1EA5u tr\xFAc ph\u1EE5c d\u1EF1ng hi\u1EC7n \u0111\u1EA1i c\xF2n nhi\u1EC1u suy \u0111o\xE1n.",
      layerCompatibility: "Kh\xF4ng t\u1EA1o combo VERIFIED ngo\xE0i ph\u1EA7n v\u0103n li\u1EC7u tr\u1EF1c ti\u1EBFp h\u1ED7 tr\u1EE3.",
      warnings: "Kh\xF4ng tr\xECnh b\xE0y model ph\u1EE5c d\u1EF1ng nh\u01B0 hi\u1EC7n v\u1EADt l\u1ECBch s\u1EED nguy\xEAn b\u1EA3n. B\u1EAFt bu\u1ED9c g\u1EAFn nh\xE3n 'Reconstruction / Debated'.",
      researchNotes: "C\u1EA7n ghi r\xF5 ph\u1EE5c d\u1EF1ng d\u1EF1a tr\xEAn v\u0103n li\u1EC7u ng\u1EAFn, ch\u01B0a c\xF3 hi\u1EC7n v\u1EADt m\u1ED9 t\xE1ng \u0111\u1ED1i ch\u1EE9ng.",
      sourceIds: ["S08"]
    },
    {
      id: "G008",
      name: "\xC1o Ng\u0169 Th\xE2n tay ch\u1EBDn",
      aliases: ["\xC1o d\xE0i ng\u0169 th\xE2n", "\xC1o n\u0103m th\xE2n tay ch\u1EBDn", "Ng\u0169 th\xE2n l\u1EADp l\u0129nh"],
      category: "\xC1o th\xE2n tr\xEAn",
      period: ["Nguy\u1EC5n", "C\u1EADn \u0111\u1EA1i", "Th\u1EBF k\u1EF7 18-19"],
      audience: ["Nam", "N\u1EEF"],
      region: ["To\xE0n qu\u1ED1c", "\u0110\xE0ng Trong", "Hu\u1EBF"],
      context: ["\u0110\u1EDDi th\u01B0\u1EDDng", "Nghi l\u1EC5", "Gia t\u1ED9c"],
      auditStatus: "CORE",
      evidenceLevel: "VERIFIED",
      constructionNotes: "May 5 th\xE2n (2 th\xE2n tr\u01B0\u1EDBc, 2 th\xE2n sau n\u1ED1i s\u1ED1ng l\u01B0ng, 1 th\xE2n con l\xF3t b\xEAn trong); c\u1ED5 \u0111\u1EE9ng vu\xF4ng v\u1EAFn; 5 h\u1EA1t c\xFAc; tay may \xF4m v\u1EEBa v\u1EB7n (tay ch\u1EBDn).",
      layerCompatibility: "\xC1o l\xF3t tr\u1EAFng + qu\u1EA7n \u1ED1ng r\u1ED9ng s\xE1ng m\xE0u l\xE0 combo chu\u1EA9n x\xE1c c\xF3 ngu\u1ED3n b\u1EA3o t\xE0ng r\u1EA5t m\u1EA1nh.",
      warnings: "Kh\xF4ng t\u1EF1 \xFD g\u1EAFn ph\u1EE5 ki\u1EC7n cung \u0111\xECnh n\u1EBFu kh\xF4ng c\xF3 b\u1ED1i c\u1EA3nh ph\u1EA9m h\xE0m c\u1EE5 th\u1EC3.",
      researchNotes: "B\u1EA3o t\xE0ng Ph\u1EE5 n\u1EEF Nam B\u1ED9 m\xF4 t\u1EA3 r\xF5 c\u1EA5u tr\xFAc 5 th\xE2n v\xE0 c\xE1ch ph\u1ED1i qu\u1EA7n \u1ED1ng r\u1ED9ng.",
      sourceIds: ["S04", "S05"]
    },
    {
      id: "G009",
      name: "\xC1o T\u1EA5c",
      aliases: ["Ng\u0169 th\xE2n tay th\u1EE5ng", "\xC1o th\u1EE5ng"],
      category: "\xC1o l\u1EC5 / th\xE2n tr\xEAn",
      period: ["Nguy\u1EC5n", "C\u1EADn \u0111\u1EA1i"],
      audience: ["Nam", "N\u1EEF"],
      region: ["To\xE0n qu\u1ED1c", "Hu\u1EBF"],
      context: ["L\u1EC5 ph\u1EE5c", "T\u1EBF l\u1EC5", "C\u01B0\u1EDBi h\u1ECFi", "\u0110\xECnh l\xE0ng"],
      auditStatus: "CORE",
      evidenceLevel: "VERIFIED",
      constructionNotes: "C\xF9ng c\u1EA5u tr\xFAc ng\u0169 th\xE2n l\u1EADp l\u0129nh nh\u01B0ng tay \xE1o may th\u1EE5ng d\xE0i v\xE0 r\u1ED9ng (kho\u1EA3ng m\u1ED9t t\u1EA5c vu\xF4ng v\u1EE9c khi bu\xF4ng th\xF5ng); c\xF3 hi\u1EC7n v\u1EADt b\u1ED5 ph\u1EE5c may theo phom \xE1o t\u1EA5c.",
      layerCompatibility: "\u0110i c\xF9ng qu\u1EA7n s\xE1ng m\xE0u + kh\u0103n \u0111\xF3ng/m\u0169 + h\xE0i t\xF9y context l\u1EC5 nghi.",
      warnings: "Kh\xF4ng m\u1EB7c \u0111\u1ECBnh m\u1ECDi ph\u1EE5 ki\u1EC7n quan l\u1EA1i ph\u1EA9m ph\u1EE5c cho m\u1ECDi \xE1o t\u1EA5c th\u01B0\u1EDDng d\xE2n.",
      researchNotes: "B\u1EA3o t\xE0ng L\u1ECBch s\u1EED Qu\u1ED1c gia c\xF3 nhi\u1EC1u hi\u1EC7n v\u1EADt \xE1o t\u1EA5c v\xE0 b\u1ED5 ph\u1EE5c tri\u1EC1u Nguy\u1EC5n.",
      sourceIds: ["S01", "S02"]
    },
    {
      id: "G010",
      name: "\xC1o T\u1EE9 Th\xE2n",
      aliases: ["T\u1EE9 th\xE2n", "\xC1o b\u1ED1n v\u1EA1t"],
      category: "\xC1o th\xE2n tr\xEAn d\xE2n gian",
      period: ["Th\u1EBF k\u1EF7 19", "\u0110\u1EA7u th\u1EBF k\u1EF7 20", "Truy\u1EC1n th\u1ED1ng"],
      audience: ["N\u1EEF"],
      region: ["B\u1EAFc B\u1ED9", "\u0110\u1ED3ng b\u1EB1ng s\xF4ng H\u1ED3ng", "Kinh B\u1EAFc"],
      context: ["L\u1EC5 h\u1ED9i", "H\u1ED9i l\xE0ng", "Quan h\u1ECD", "\u0110\u1EDDi th\u01B0\u1EDDng d\xE2n gian"],
      auditStatus: "CORE",
      evidenceLevel: "VERIFIED",
      constructionNotes: "G\u1ED3m 4 v\u1EA1t \xE1o: 2 v\u1EA1t sau may li\u1EC1n t\u1EA1o \u0111\u01B0\u1EDDng s\u1ED1ng l\u01B0ng \u1EDF gi\u1EEFa, 2 v\u1EA1t tr\u01B0\u1EDBc \u0111\u1EC3 bu\xF4ng r\u1EE7 ho\u1EB7c bu\u1ED9c ch\xE9o tr\u01B0\u1EDBc b\u1EE5ng; kh\xF4ng c\xE0i khuy c\u1ED1 \u0111\u1ECBnh.",
      layerCompatibility: "Y\u1EBFm + V\xE1y \u0111\u1EE5p + Th\u1EAFt l\u01B0ng d\u1EA3i bao l\xE0 l\xF5i b\u1EAFt bu\u1ED9c (R001, R002, R003); kh\u0103n m\u1ECF qu\u1EA1 ho\u1EB7c n\xF3n t\xF9y context.",
      warnings: "Kh\xF4ng g\u1EAFn ph\u1EE5 ki\u1EC7n cung \u0111\xECnh Nguy\u1EC5n (nh\u01B0 V\xE2n Ki\xEAn) ho\u1EB7c kh\u0103n r\u1EB1n Nam B\u1ED9 ch\u1EC9 v\xEC mu\u1ED1n trang tr\xED.",
      researchNotes: "T\u01B0 li\u1EC7u B\u1EA3o t\xE0ng Ph\u1EE5 n\u1EEF Nam B\u1ED9 v\xE0 c\xE1c b\u1EA3o t\xE0ng d\xE2n t\u1ED9c h\u1ECDc m\xF4 t\u1EA3 chi ti\u1EBFt b\u1ED9 trang ph\u1EE5c t\u1EE9 th\xE2n d\xE2n gian.",
      sourceIds: ["S03", "S04"]
    },
    {
      id: "G011",
      name: "Y\u1EBFm",
      aliases: ["\xC1o y\u1EBFm", "Y\u1EBFm \u0111\xE0o", "Y\u1EBFm hoa hi\xEAn", "Y\u1EBFm c\u1ED5 x\xE2y"],
      category: "N\u1ED9i y / l\u1EDBp trong",
      period: ["Nhi\u1EC1u giai \u0111o\u1EA1n", "L\xEA", "Nguy\u1EC5n", "D\xE2n gian"],
      audience: ["N\u1EEF"],
      region: ["To\xE0n qu\u1ED1c", "B\u1EAFc B\u1ED9"],
      context: ["N\u1ED9i y", "D\xE2n gian", "\u0110\u1EDDi th\u01B0\u1EDDng"],
      auditStatus: "CORE",
      evidenceLevel: "CONSISTENT",
      constructionNotes: "M\u1EA3nh v\u1EA3i vu\xF4ng ho\u1EB7c h\xECnh thoi che ng\u1EF1c, c\xF3 d\xE2y bu\u1ED9c sau g\xE1y v\xE0 sau l\u01B0ng; m\xE9p c\u1ED5 kho\xE9t tr\xF2n ho\u1EB7c x\u1EBB ch\u1EEF V.",
      layerCompatibility: "L\u1EDBp m\u1EB7c l\xF3t b\xEAn trong c\u1EE7a \xC1o T\u1EE9 Th\xE2n ho\u1EB7c trang ph\u1EE5c n\u1EEF d\xE2n gian.",
      warnings: "Tuy\u1EC7t \u0111\u1ED1i kh\xF4ng coi y\u1EBFm l\xE0 ph\u1EE5 ki\u1EC7n trang s\u1EE9c b\xEAn ngo\xE0i.",
      researchNotes: "\u0110\u01B0\u1EE3c ghi nh\u1EADn l\xE0 n\u1ED9i y c\u0103n b\u1EA3n trong trang ph\u1EE5c n\u1EEF truy\u1EC1n th\u1ED1ng.",
      sourceIds: ["S03", "S04"]
    },
    {
      id: "G012",
      name: "V\xE1y",
      aliases: ["V\xE1y \u0111\u1EE5p", "V\xE1y l\u1EE5a \u0111en", "V\xE1y x\xF2e d\xE2n gian"],
      category: "Trang ph\u1EE5c th\xE2n d\u01B0\u1EDBi",
      period: ["D\xE2n gian B\u1EAFc B\u1ED9", "Truy\u1EC1n th\u1ED1ng"],
      audience: ["N\u1EEF"],
      region: ["B\u1EAFc B\u1ED9"],
      context: ["D\xE2n gian", "L\u1EC5 h\u1ED9i", "Lao \u0111\u1ED9ng"],
      auditStatus: "TH\xCAM",
      evidenceLevel: "VERIFIED",
      constructionNotes: "V\xE1y may b\u1EB1ng v\u1EA3i s\u1ED3i, th\xF4 ho\u1EB7c l\u1EE5a nhu\u1ED9m c\u1EE7 n\xE2u/\u0111en b\xF3ng, d\xE1ng x\xF2e r\u1ED9ng, c\u1EA1p v\xE1y lu\u1ED3n d\u1EA3i r\xFAt ho\u1EB7c gi\u1EAFt c\u1EA1p.",
      layerCompatibility: "Trang ph\u1EE5c th\xE2n d\u01B0\u1EDBi c\u1ED1t l\xF5i khi m\u1EB7c c\xF9ng \xC1o T\u1EE9 Th\xE2n theo t\u01B0 li\u1EC7u b\u1EA3o t\xE0ng.",
      warnings: "Kh\xF4ng thay b\u1EB1ng qu\u1EA7n t\xE2y ho\u1EB7c v\xE1y hi\u1EC7n \u0111\u1EA1i ng\u1EAFn n\u1EBFu \u0111ang y\xEAu c\u1EA7u t\xEDnh l\u1ECBch s\u1EED authentic.",
      researchNotes: "B\u1EA3o t\xE0ng Ph\u1EE5 n\u1EEF Nam B\u1ED9 x\xE1c nh\u1EADn ph\u1EE5 n\u1EEF B\u1EAFc B\u1ED9 m\u1EB7c t\u1EE9 th\xE2n c\xF9ng v\xE1y \u0111\u1EE5p \u0111en.",
      sourceIds: ["S03", "S04"]
    },
    {
      id: "G013",
      name: "Qu\u1EA7n \u1ED1ng r\u1ED9ng s\xE1ng m\xE0u",
      aliases: ["Qu\u1EA7n tr\u1EAFng", "Qu\u1EA7n l\u1EE5a tr\u1EAFng", "Qu\u1EA7n s\xE1ng m\xE0u"],
      category: "Trang ph\u1EE5c th\xE2n d\u01B0\u1EDBi",
      period: ["Nguy\u1EC5n", "C\u1EADn \u0111\u1EA1i"],
      audience: ["Nam", "N\u1EEF"],
      region: ["To\xE0n qu\u1ED1c"],
      context: ["Nguy\u1EC5n", "\xC1o d\xE0i ng\u0169 th\xE2n", "Nghi l\u1EC5"],
      auditStatus: "GI\u1EEE",
      evidenceLevel: "VERIFIED",
      constructionNotes: "Qu\u1EA7n may b\u1EB1ng l\u1EE5a ho\u1EB7c v\u1EA3i tr\u1EAFng/ng\xE0, \u0111\u0169ng r\u1ED9ng tho\u1EA3i m\xE1i, \u1ED1ng su\xF4ng r\u1ED9ng, c\u1EA1p c\xF3 d\u1EA3i th\u1EAFt.",
      layerCompatibility: "Th\xE0nh ph\u1EA7n th\xE2n d\u01B0\u1EDBi chu\u1EA9n m\u1EF1c \u0111i c\xF9ng \xC1o Ng\u0169 Th\xE2n tay ch\u1EBDn ho\u1EB7c \xC1o T\u1EA5c.",
      warnings: "Kh\xF4ng bi\u1EBFn m\xE0u tr\u1EAFng th\xE0nh quy t\u1EAFc b\u1EAFt bu\u1ED9c cho m\u1ECDi th\u1EDDi k\u1EF3 (th\u1EDDi k\u1EF3 s\u1EDBm ho\u1EB7c th\u01B0\u1EDDng d\xE2n c\xF3 d\xF9ng m\xE0u s\u1EABm).",
      researchNotes: "B\u1EA3o t\xE0ng Ph\u1EE5 n\u1EEF Nam B\u1ED9 ghi r\xF5 ng\u0169 th\xE2n th\u01B0\u1EDDng m\u1EB7c v\u1EDBi qu\u1EA7n \u1ED1ng r\u1ED9ng s\xE1ng m\xE0u.",
      sourceIds: ["S04", "S05"]
    },
    {
      id: "G014",
      name: "Qu\u1EA7n L\xE1 T\u1ECDa",
      aliases: ["L\xE1 t\u1ECDa", "Qu\u1EA7n \u0111\u0169ng r\u1ED9ng"],
      category: "Trang ph\u1EE5c th\xE2n d\u01B0\u1EDBi",
      period: ["D\xE2n gian truy\u1EC1n th\u1ED1ng"],
      audience: ["Nam"],
      region: ["B\u1EAFc B\u1ED9", "\u0110\u1ED3ng b\u1EB1ng"],
      context: ["Lao \u0111\u1ED9ng", "D\xE2n gian \u0111\u1EDDi th\u01B0\u1EDDng"],
      auditStatus: "GI\u1EEE + X\xC1C MINH",
      evidenceLevel: "CONSISTENT",
      constructionNotes: "Qu\u1EA7n \u0111\u0169ng r\u1EA5t s\xE2u, \u1ED1ng r\u1ED9ng, may b\u1EB1ng v\u1EA3i th\xF4 ho\u1EB7c nhu\u1ED9m n\xE2u s\u1ED3ng, thu\u1EADn ti\u1EC7n cho vi\u1EC7c \u0111\u1ED3ng \xE1ng.",
      layerCompatibility: "\u0110i c\xF9ng \xC1o c\xE1nh ho\u1EB7c \xE1o n\xE2u s\u1ED3ng trong b\u1ED1i c\u1EA3nh lao \u0111\u1ED9ng d\xE2n d\xE3.",
      warnings: "Kh\xF4ng d\xF9ng l\xE0m qu\u1EA7n m\u1EB7c \u0111\u1ECBnh cho \xC1o Ng\u0169 Th\xE2n hay \xC1o T\u1EA5c trang tr\u1ECDng.",
      researchNotes: "Trang ph\u1EE5c lao \u0111\u1ED9ng nam gi\u1EDBi ti\xEAu bi\u1EC3u th\u1EDDi x\u01B0a.",
      sourceIds: ["S03", "S06"]
    },
    {
      id: "G015",
      name: "Kh\u1ED1",
      aliases: ["Kh\u1ED1 v\u1EA3i", "Kh\u1ED1 c\u1ED5 truy\u1EC1n"],
      category: "Trang ph\u1EE5c th\xE2n d\u01B0\u1EDBi",
      period: ["Th\u1EDDi k\u1EF3 c\u1ED5 \u0111\u1EA1i", "\u0110\xF4ng S\u01A1n", "Ti\u1EC1n s\u1EED"],
      audience: ["Nam"],
      region: ["\u0110\u1EA1i Vi\u1EC7t c\u1ED5"],
      context: ["Ti\u1EC1n s\u1EED", "C\u1ED5 truy\u1EC1n"],
      auditStatus: "GI\u1EEE + G\u1EAEN TH\u1EDCI K\u1EF2",
      evidenceLevel: "CONSISTENT",
      constructionNotes: "D\u1EA3i v\u1EA3i qu\u1EA5n quanh h\xF4ng v\xE0 lu\u1ED3n qua \u0111\xF9i; kh\xF4ng c\xF3 m\u1ED9t phom d\xE1ng c\u1ED1 \u0111\u1ECBnh duy nh\u1EA5t cho m\u1ECDi th\u1EDDi k\u1EF3.",
      layerCompatibility: "Ch\u1EC9 ph\u1ED1i trong c\xE1c b\u1ED1i c\u1EA3nh ph\u1EE5c d\u1EF1ng kh\u1EA3o c\u1ED5 th\u1EDDi k\u1EF3 t\u01B0\u01A1ng \u1EE9ng.",
      warnings: "Tuy\u1EC7t \u0111\u1ED1i kh\xF4ng gh\xE9p t\xF9y ti\u1EC7n kh\u1ED1 v\u1EDBi c\xE1c trang ph\u1EE5c tri\u1EC1u Nguy\u1EC5n hay th\u1EDDi H\u1EADu L\xEA.",
      researchNotes: "C\u1EA7n b\u1EB1ng ch\u1EE9ng kh\u1EA3o c\u1ED5 chi ti\u1EBFt theo t\u1EEBng th\u1EDDi k\u1EF3 n\u1EBFu \u0111\u01B0a l\xEAn m\xF4 h\xECnh 3D.",
      sourceIds: ["S01"]
    },
    {
      id: "G016",
      name: "\xC1o B\u1ED5 Ph\u1EE5c",
      aliases: ["B\u1ED5 ph\u1EE5c", "\xC1o c\xF3 B\u1ED5 t\u1EED"],
      category: "Ph\u1EE5c ph\u1EA9m / quan l\u1EA1i",
      period: ["Nguy\u1EC5n"],
      audience: ["Quan l\u1EA1i tri\u1EC1u \u0111\xECnh"],
      region: ["Cung \u0111\xECnh Hu\u1EBF"],
      context: ["Tri\u1EC1u h\u1ED9i", "Nghi l\u1EC5", "Quan ch\u1EE9c"],
      auditStatus: "CORE",
      evidenceLevel: "VERIFIED",
      constructionNotes: "\xC1o may theo d\xE1ng c\u1ED5 b\xE0n l\u0129nh ho\u1EB7c \xE1o t\u1EA5c, ph\xEDa tr\u01B0\u1EDBc ng\u1EF1c v\xE0 sau l\u01B0ng \u0111\xEDnh m\u1EA3nh B\u1ED5 T\u1EED th\xEAu h\xECnh chim mu\xF4ng (quan v\u0103n) ho\u1EB7c th\xFA d\u1EEF (quan v\xF5).",
      layerCompatibility: "Ch\u1EC9 ph\u1ED1i trong h\u1EC7 ph\u1EA9m ph\u1EE5c t\u01B0\u01A1ng \u1EE9ng v\u1EDBi ph\u1EA9m tr\u1EADt quan l\u1EA1i.",
      warnings: "Kh\xF4ng ph\u1ED1i t\u1EF1 do v\u1EDBi n\xF3n l\xE1 hay ph\u1EE5 ki\u1EC7n d\xE2n gian.",
      researchNotes: "B\u1EA3o t\xE0ng L\u1ECBch s\u1EED Qu\u1ED1c gia l\u01B0u gi\u1EEF nhi\u1EC1u hi\u1EC7n v\u1EADt b\u1ED5 ph\u1EE5c c\xE1c ph\u1EA9m c\u1EA5p.",
      sourceIds: ["S01", "S02"]
    },
    {
      id: "G017",
      name: "B\u1ED5 T\u1EED",
      aliases: ["B\u1ED5 t\u1EED", "Ph\xF9 hi\u1EC7u ph\u1EA9m quan"],
      category: "Ph\u1EE5 ki\u1EC7n/chi ti\u1EBFt ph\u1EA9m ph\u1EE5c",
      period: ["Nguy\u1EC5n"],
      audience: ["Quan l\u1EA1i tri\u1EC1u \u0111\xECnh"],
      region: ["Cung \u0111\xECnh"],
      context: ["Ph\u1EA9m h\xE0m", "Nghi th\u1EE9c"],
      auditStatus: "GI\u1EEE NH\u01AF COMPONENT",
      evidenceLevel: "VERIFIED",
      constructionNotes: "M\u1EA3nh v\u1EA3i th\xEAu h\xECnh vu\xF4ng \u0111\xEDnh tr\xEAn \xE1o b\u1ED5 ph\u1EE5c; quan v\u0103n th\xEAu chim (H\u1EA1c, Tr\u0129, Nh\u1EA1n...), quan v\xF5 th\xEAu th\xFA (K\u1EF3 l\xE2n, S\u01B0 t\u1EED, H\u1ED5...).",
      layerCompatibility: "B\u1EAFt bu\u1ED9c g\u1EAFn tr\xEAn \xC1o B\u1ED5 Ph\u1EE5c theo \u0111\xFAng ph\u1EA9m c\u1EA5p quy \u0111\u1ECBnh.",
      warnings: "Kh\xF4ng coi l\xE0 ph\u1EE5 ki\u1EC7n th\u1EDDi trang c\xF3 th\u1EC3 \u0111\xEDnh t\xF9y ti\u1EC7n l\xEAn m\u1ECDi lo\u1EA1i \xE1o.",
      researchNotes: "L\xE0 component \u0111\u1ECBnh danh \u0111\u1ECBa v\u1ECB x\xE3 h\u1ED9i ch\u1EE9 kh\xF4ng ph\u1EA3i trang ph\u1EE5c \u0111\u1ED9c l\u1EADp.",
      sourceIds: ["S01", "S02"]
    },
    {
      id: "G018",
      name: "\xC1o Nh\u1EADt B\xECnh",
      aliases: ["Nh\u1EADt B\xECnh", "\xC1o c\u1ED5 nh\u1EADt b\xECnh"],
      category: "\xC1o cung \u0111\xECnh n\u1EEF",
      period: ["Nguy\u1EC5n"],
      audience: ["Ho\xE0ng th\xE1i h\u1EADu", "Ho\xE0ng h\u1EADu", "C\xF4ng ch\xFAa", "Cung t\u1EA7n", "M\u1EC7nh ph\u1EE5"],
      region: ["Cung \u0111\xECnh Hu\u1EBF"],
      context: ["Cung \u0111\xECnh", "L\u1EC5 th\u01B0\u1EDDng tri\u1EC1u", "H\xF4n l\u1EC5 ho\xE0ng gia"],
      auditStatus: "CORE + S\u1EECA M\xD4 T\u1EA2",
      evidenceLevel: "VERIFIED",
      constructionNotes: "C\u1ED5 \xE1o x\u1EBB gi\u1EEFa h\xECnh ch\u1EEF nh\u1EADt vi\u1EC1n hoa v\u0103n tinh x\u1EA3o; c\u1EEDa tay vi\u1EC1n d\u1EA3i ng\u0169 s\u1EAFc t\u01B0\u01A1ng sinh; hoa v\u0103n d\u1EC7t th\xEAu loan ph\u01B0\u1EE3ng, m\xE2y hoa theo c\u1EA5p b\u1EADc.",
      layerCompatibility: "Ph\u1EA3i gh\xE9p theo c\u1EA5p b\u1EADc v\xE0 nghi l\u1EC5: kh\u0103n v\xE0nh d\xE2y, tr\xE2m c\xE0i, v\xE1y/qu\u1EA7n l\u1EE5a tr\u1EAFng, h\xE0i cung \u0111\xECnh.",
      warnings: "Kh\xF4ng gi\u1EA3n l\u01B0\u1EE3c coi Nh\u1EADt B\xECnh l\xE0 'th\u01B0\u1EDDng ph\u1EE5c c\u1EE7a h\u1EADu phi' n\xF3i chung. Kh\xF4ng ph\u1ED1i nh\u01B0 \xE1o d\xE2n gian.",
      researchNotes: "B\u1EA3o t\xE0ng L\u1ECBch s\u1EED Qu\u1ED1c gia c\xF3 hi\u1EC7n v\u1EADt \xE1o Nh\u1EADt B\xECnh nh\u1EA5t ph\u1EA9m phu nh\xE2n v\xE0 c\xF4ng ch\xFAa tri\u1EC1u Nguy\u1EC5n.",
      sourceIds: ["S01", "S02"]
    },
    {
      id: "G019",
      name: "\xC1o M\u1EC7nh Ph\u1EE5",
      aliases: ["M\u1EC7nh ph\u1EE5 ph\u1EA9m ph\u1EE5c"],
      category: "H\u1EC7 ph\u1EE5c trang/\u0111\u1ECBa v\u1ECB",
      period: ["Nguy\u1EC5n"],
      audience: ["Ph\u1EE5 n\u1EEF \u0111\u01B0\u1EE3c tri\u1EC1u \u0111\xECnh phong ph\u1EA9m tr\u1EADt"],
      region: ["Cung \u0111\xECnh", "Quan l\u1EA1i"],
      context: ["Nghi l\u1EC5", "Tri\u1EC1u h\u1ED9i"],
      auditStatus: "S\u1EECA TAXONOMY",
      evidenceLevel: "UNCERTAIN",
      constructionNotes: "'M\u1EC7nh ph\u1EE5' l\xE0 danh x\u01B0ng \u0111\u1ECBa v\u1ECB ch\u1EE9 kh\xF4ng ph\u1EA3i m\u1ED9t form \xE1o duy nh\u1EA5t; t\xF9y ph\u1EA9m h\xE0m m\xE0 m\u1EC7nh ph\u1EE5 m\u1EB7c Nh\u1EADt B\xECnh ho\u1EB7c \xC1o T\u1EA5c t\u01B0\u01A1ng \u1EE9ng.",
      layerCompatibility: "Li\xEAn h\u1EC7 v\u1EDBi Nh\u1EADt B\xECnh ho\u1EB7c \xC1o T\u1EA5c theo ph\u1EA9m tr\u1EADt quy \u0111\u1ECBnh trong \u0111i\u1EC3n ch\u1EBF.",
      warnings: "Kh\xF4ng t\u1EA1o card '\xC1o M\u1EC7nh Ph\u1EE5' nh\u01B0 m\u1ED9t form \xE1o \u0111\u01A1n l\u1EBB n\u1EBFu ch\u01B0a x\xE1c \u0111\u1ECBnh r\xF5 quy th\u1EE9c c\u1EAFt may.",
      researchNotes: "C\u1EA7n t\xE1ch status/title ra kh\u1ECFi th\u1EF1c th\u1EC3 garment.",
      sourceIds: ["S01", "S02"]
    },
    {
      id: "G020",
      name: "\xC1o M\xE3ng B\xE0o",
      aliases: ["M\xE3ng b\xE0o"],
      category: "\xC1o cung \u0111\xECnh nam",
      period: ["Nguy\u1EC5n"],
      audience: ["Ho\xE0ng th\xE2n", "Quan l\u1EA1i c\u1EA5p cao"],
      region: ["Cung \u0111\xECnh"],
      context: ["\u0110\u1EA1i tri\u1EC1u", "L\u1EC5 ti\u1EBFt"],
      auditStatus: "CORE",
      evidenceLevel: "VERIFIED",
      constructionNotes: "Th\xEAu h\xECnh m\xE3ng (r\u1ED3ng 4 m\xF3ng) u\u1ED1n l\u01B0\u1EE3n; m\xE0u s\u1EAFc v\xE0 hoa v\u0103n tu\xE2n th\u1EE7 nghi\xEAm ng\u1EB7t theo ph\u1EA9m c\u1EA5p tri\u1EC1u \u0111\xECnh.",
      layerCompatibility: "\u0110i c\xF9ng m\u0169 c\xE1nh chu\u1ED3n, \u0111ai, h\u1ED1t, hia trong nghi th\u1EE9c \u0111\u1EA1i tri\u1EC1u.",
      warnings: "Kh\xF4ng g\u1EAFn v\xE0o outfit d\xE2n gian ho\u1EB7c Gen Z remix m\xE0 kh\xF4ng c\u1EA3nh b\xE1o m\u1EA1nh.",
      researchNotes: "B\u1EA3o t\xE0ng L\u1ECBch s\u1EED Qu\u1ED1c gia m\xF4 t\u1EA3 m\xE3ng b\xE0o \u0111\u1EA1i tri\u1EC1u c\u1EE7a quan nh\u1EA5t ph\u1EA9m.",
      sourceIds: ["S01", "S02"]
    },
    {
      id: "G021",
      name: "M\xE3ng Lan",
      aliases: ["M\xE3ng lan"],
      category: "\xC1o cung \u0111\xECnh nam",
      period: ["Nguy\u1EC5n"],
      audience: ["Ho\xE0ng t\u1EED", "Th\xE1i t\u1EED"],
      region: ["Cung \u0111\xECnh"],
      context: ["L\u1EC5 l\u1EA1t quan tr\u1ECDng"],
      auditStatus: "CORE",
      evidenceLevel: "VERIFIED",
      constructionNotes: "D\u1EA1ng \xE1o cung \u0111\xECnh th\xEAu m\xE3ng d\xE0nh cho ho\xE0ng t\u1EED v\xE0o c\xE1c d\u1ECBp l\u1EC5 trang tr\u1ECDng.",
      layerCompatibility: "Ph\u1ED1i theo b\u1ED9 ph\u1EE5c trang cung \u0111\xECnh t\u01B0\u01A1ng \u1EE9ng c\u1EE7a ho\xE0ng t\u1EED.",
      warnings: "Kh\xF4ng \u0111\u1ED3ng nh\u1EA5t m\xE3ng lan v\u1EDBi m\xE3ng b\xE0o c\u1EE7a quan l\u1EA1i.",
      researchNotes: "Ngu\u1ED3n ch\xEDnh th\u1EE9c ph\xE2n bi\u1EC7t r\xF5 M\xE3ng b\xE0o v\xE0 M\xE3ng lan.",
      sourceIds: ["S02"]
    },
    {
      id: "G022",
      name: "Long B\xE0o",
      aliases: ["Long b\xE0o \u0111\u1EA1i tri\u1EC1u"],
      category: "\xC1o cung \u0111\xECnh",
      period: ["Nguy\u1EC5n"],
      audience: ["Ho\xE0ng \u0111\u1EBF (Vua)"],
      region: ["Ho\xE0ng cung"],
      context: ["\u0110\u1EA1i tri\u1EC1u", "\u0110\u0103ng quang", "\u0110\u1EA1i l\u1EC5"],
      auditStatus: "CORE",
      evidenceLevel: "VERIFIED",
      constructionNotes: "M\xE0u v\xE0ng ch\xEDnh s\u1EAFc th\xEAu r\u1ED3ng 5 m\xF3ng tinh x\u1EA3o, c\u1ED5 \xE1o, th\xE2n v\xE0 g\u1EA5u \xE1o d\u1EC7t th\xEAu m\xE2y ng\u0169 s\u1EAFc v\xE0 s\xF3ng n\u01B0\u1EDBc th\u1EE7y ba.",
      layerCompatibility: "Tr\u1ECDn b\u1ED9 \u0111\u1EA1i tri\u1EC1u: M\u0169 C\u1EEDu Long, xi\xEAm, ng\u1ECDc \u0111ai, h\u1ED1t ng\u1ECDc, hia th\xEAu r\u1ED3ng.",
      warnings: "Kh\xF4ng ph\u1ED1i t\xF9y ti\u1EC7n t\u1EEBng m\xF3n l\u1EBB t\u1EBB m\xE0 v\u1EABn g\u1ECDi l\xE0 nguy\xEAn b\u1ED9 long b\xE0o authentic.",
      researchNotes: "B\u1EA3o t\xE0ng L\u1ECBch s\u1EED Qu\u1ED1c gia m\xF4 t\u1EA3 tr\u1ECDn b\u1ED9 ph\u1EE5c trang \u0111\u1EA1i tri\u1EC1u c\u1EE7a vua tri\u1EC1u Nguy\u1EC5n.",
      sourceIds: ["S02"]
    },
    {
      id: "G023",
      name: "Ho\xE0ng B\xE0o",
      aliases: ["Ho\xE0ng b\xE0o th\u01B0\u1EDDng tri\u1EC1u"],
      category: "\xC1o cung \u0111\xECnh",
      period: ["Nguy\u1EC5n"],
      audience: ["Ho\xE0ng \u0111\u1EBF (Vua)"],
      region: ["Ho\xE0ng cung"],
      context: ["Th\u01B0\u1EDDng tri\u1EC1u", "Nghe ch\xEDnh s\u1EF1"],
      auditStatus: "CORE",
      evidenceLevel: "VERIFIED",
      constructionNotes: "\xC1o m\xE0u v\xE0ng c\u1ED5 tr\xF2n ho\u1EB7c \u0111\u1EE9ng th\u1EA5p d\xF9ng trong c\xE1c bu\u1ED5i th\u01B0\u1EDDng tri\u1EC1u b\xE0n vi\u1EC7c n\u01B0\u1EDBc.",
      layerCompatibility: "Ph\u1EA3i \u0111i theo b\u1ED9 th\u01B0\u1EDDng tri\u1EC1u t\u01B0\u01A1ng \u1EE9ng v\u1EDBi m\u0169 b\xECnh thi\xEAn ho\u1EB7c m\u0169 xung thi\xEAn.",
      warnings: "Kh\xF4ng \u0111\u1ED3ng nh\u1EA5t ho\xE0ng b\xE0o th\u01B0\u1EDDng tri\u1EC1u v\u1EDBi long b\xE0o \u0111\u1EA1i tri\u1EC1u.",
      researchNotes: "B\u1EA3o t\xE0ng L\u1ECBch s\u1EED Qu\u1ED1c gia ph\xE2n bi\u1EC7t ho\xE0ng b\xE0o c\u1EE7a vua trong th\u01B0\u1EDDng tri\u1EC1u.",
      sourceIds: ["S02"]
    },
    {
      id: "G024",
      name: "C\u1ED5n Ph\u1EE5c",
      aliases: ["C\u1ED5n ph\u1EE5c", "\xC1o C\u1ED5n"],
      category: "\xC1o l\u1EC5 t\u1ED1i cao/cung \u0111\xECnh",
      period: ["Nguy\u1EC5n"],
      audience: ["Ho\xE0ng \u0111\u1EBF (Vua)"],
      region: ["\u0110\xE0n Nam Giao"],
      context: ["T\u1EBF Nam Giao", "T\u1EBF Giao"],
      auditStatus: "CORE",
      evidenceLevel: "VERIFIED",
      constructionNotes: "M\xE0u \u0111en, tay th\u1EE5ng l\u1EDBn, th\xEAu nh\u1EADt nguy\u1EC7t tinh t\xFA, h\xECnh l\u01B0\u1EE1ng long tri\u1EC1u nh\u1EADt t\xF4n nghi\xEAm.",
      layerCompatibility: "Ch\u1EC9 s\u1EED d\u1EE5ng trong nghi l\u1EC5 t\u1EBF Nam Giao v\u1EDBi m\u0169 C\u1ED5n v\xE0 \u0111ai ng\u1ECDc.",
      warnings: "Tuy\u1EC7t \u0111\u1ED1i kh\xF4ng ph\u1ED1i v\u1EDBi b\u1EA5t k\u1EF3 ph\u1EE5 ki\u1EC7n d\xE2n gian n\xE0o.",
      researchNotes: "Trang ph\u1EE5c t\u1EBF l\u1EC5 t\u1ED1i cao v\xE0 t\xF4n nghi\xEAm nh\u1EA5t c\u1EE7a vua.",
      sourceIds: ["S02"]
    },
    {
      id: "G025",
      name: "Ph\u01B0\u1EE3ng ph\u1EE5c / \xE1o th\xEAu ph\u01B0\u1EE3ng",
      aliases: ["Ph\u01B0\u1EE3ng ph\u1EE5c", "\xC1o th\xEAu ph\u01B0\u1EE3ng"],
      category: "Ph\u1EE5c trang n\u1EEF cung \u0111\xECnh",
      period: ["Nguy\u1EC5n"],
      audience: ["Ho\xE0ng h\u1EADu", "C\xF4ng ch\xFAa"],
      region: ["Cung \u0111\xECnh"],
      context: ["Cung \u0111\xECnh", "L\u1EC5 ti\u1EBFt"],
      auditStatus: "TH\xCAM + X\xC1C MINH",
      evidenceLevel: "VERIFIED",
      constructionNotes: "Trang ph\u1EE5c th\xEAu h\u1ECDa ti\u1EBFt chim ph\u01B0\u1EE3ng ho\xE0ng, hoa l\xE1 qu\xFD ph\xE1i.",
      layerCompatibility: "Ph\u1ED1i theo b\u1ED9 ph\u1EE5c trang cung \u0111\xECnh n\u1EEF t\u01B0\u01A1ng \u1EE9ng v\u1EDBi tr\xE2m ph\u01B0\u1EE3ng, m\u0169 ph\u01B0\u1EE3ng.",
      warnings: "Kh\xF4ng d\xF9ng 'Ph\u01B0\u1EE3ng b\xE0o' nh\u01B0 t\xEAn m\u1EB7c \u0111\u1ECBnh n\u1EBFu ch\u01B0a x\xE1c minh t\xEAn ch\xEDnh x\xE1c theo quy ch\u1EBF \u0111i\u1EC3n ch\u01B0\u01A1ng.",
      researchNotes: "B\u1EA3o t\xE0ng L\u1ECBch s\u1EED Qu\u1ED1c gia x\xE1c nh\u1EADn ho\xE0ng h\u1EADu/c\xF4ng ch\xFAa d\xF9ng ch\u1EE7 \u0111\u1EC1 hoa v\xE0 ph\u01B0\u1EE3ng.",
      sourceIds: ["S02"]
    },
    {
      id: "G026",
      name: "\xC1o Th\xE2m",
      aliases: ["\xC1o th\xE2m", "\xC1o the th\xE2m"],
      category: "\xC1o d\xE2n gian/nh\xE0 Nho",
      period: ["Nhi\u1EC1u th\u1EDDi k\u1EF3", "Nguy\u1EC5n", "C\u1EADn \u0111\u1EA1i"],
      audience: ["Nam", "Nho s\u0129", "Ng\u01B0\u1EDDi cao ni\xEAn"],
      region: ["To\xE0n qu\u1ED1c"],
      context: ["Nho h\u1ECDc", "Gia t\u1ED9c", "H\u01B0\u01A1ng l\u1EC5"],
      auditStatus: "S\u1EECA + X\xC1C MINH",
      evidenceLevel: "UNCERTAIN",
      constructionNotes: "M\xE0u th\xE2m (\u0111en pha n\xE2u s\u1EABm); th\u01B0\u1EDDng may b\u1EB1ng the m\u1ECFng m\u1EB7c ngo\xE0i \xE1o l\xF3t tr\u1EAFng b\xEAn trong.",
      layerCompatibility: "Ch\u1EC9 ph\u1ED1i v\u1EDBi kh\u0103n x\u1EBFp, qu\u1EA7n tr\u1EAFng trong b\u1ED1i c\u1EA3nh Nho s\u0129 t\u01B0\u01A1ng \u1EE9ng.",
      warnings: "Kh\xF4ng g\u1EAFn m\u1EB7c \u0111\u1ECBnh \xE1o th\xE2m v\u1EDBi m\u1ECDi b\u1ED1i c\u1EA3nh y ph\u1EE5c c\u1ED5 phong.",
      researchNotes: "T\xE0i li\u1EC7u m\xF4 t\u1EA3 ng\u1EAFn, c\u1EA7n th\xEAm t\u01B0 li\u1EC7u \u0111\u1ED1i chi\u1EBFu.",
      sourceIds: ["S03"]
    },
    {
      id: "G027",
      name: "\xC1o C\xE1nh",
      aliases: ["\xC1o c\xE1nh", "\xC1o c\xE1nh n\xE2u"],
      category: "\xC1o d\xE2n gian",
      period: ["D\xE2n gian truy\u1EC1n th\u1ED1ng"],
      audience: ["Nam", "N\u1EEF"],
      region: ["B\u1EAFc B\u1ED9", "N\xF4ng th\xF4n"],
      context: ["Lao \u0111\u1ED9ng", "\u0110\u1EDDi th\u01B0\u1EDDng"],
      auditStatus: "GI\u1EEE + X\xC1C MINH",
      evidenceLevel: "CONSISTENT",
      constructionNotes: "\xC1o ng\u1EAFn x\u1EBB ng\u1EF1c, c\xE0i c\xFAc, c\xF3 hai t\xFAi tr\u01B0\u1EDBc b\u1EE5ng, may b\u1EB1ng v\u1EA3i th\xF4 nhu\u1ED9m n\xE2u s\u1ED3ng.",
      layerCompatibility: "\u0110i c\xF9ng qu\u1EA7n L\xE1 T\u1ECDa trong b\u1ED1i c\u1EA3nh sinh ho\u1EA1t v\xE0 lao \u0111\u1ED9ng n\xF4ng th\xF4n.",
      warnings: "Kh\xF4ng d\xF9ng nh\u01B0 t\xEAn g\u1ECDi chung cho m\u1ECDi ki\u1EC3u \xE1o ng\u1EAFn d\xE2n gian.",
      researchNotes: "C\u1EA7n ph\xE2n bi\u1EC7t \xE1o c\xE1nh ng\u01B0\u1EDDi Kinh v\u1EDBi \xE1o c\xE1nh c\u1EE7a c\xE1c d\xE2n t\u1ED9c anh em kh\xE1c.",
      sourceIds: ["S03"]
    },
    {
      id: "G028",
      name: "\xC1o B\xE0 Ba",
      aliases: ["B\xE0 ba", "\xC1o b\xE0 ba Nam B\u1ED9"],
      category: "\xC1o d\xE2n gian",
      period: ["C\u1EADn \u0111\u1EA1i", "Th\u1EBF k\u1EF7 19-20", "Hi\u1EC7n \u0111\u1EA1i"],
      audience: ["Nam", "N\u1EEF"],
      region: ["Nam B\u1ED9"],
      context: ["\u0110\u1EDDi th\u01B0\u1EDDng", "Mi\u1EC7t v\u01B0\u1EDDn", "Lao \u0111\u1ED9ng", "L\u1EC5 h\u1ED9i ph\u01B0\u01A1ng Nam"],
      auditStatus: "GI\u1EEE",
      evidenceLevel: "CONSISTENT",
      constructionNotes: "\xC1o ng\u1EAFn kh\xF4ng c\u1ED5, c\xE0i c\xFAc gi\u1EEFa v\u1EA1t, x\u1EBB t\xE0 hai b\xEAn h\xF4ng tho\xE1ng m\xE1t, c\xF3 2 t\xFAi tr\u01B0\u1EDBc v\u1EA1t \xE1o d\u01B0\u1EDBi.",
      layerCompatibility: "Ph\u1ED1i c\xF9ng qu\u1EA7n \u1ED1ng r\u1ED9ng l\u1EE5a \u0111en/v\u1EA3i \xFA, kh\u0103n r\u1EB1n v\xE0 n\xF3n l\xE1 Nam B\u1ED9.",
      warnings: "Kh\xF4ng \u0111\u01B0a v\xE0o outfit Kinh B\u1EAFc/B\u1EAFc B\u1ED9 truy\u1EC1n th\u1ED1ng ch\u1EC9 v\xEC danh ngh\u0129a chung 'Vi\u1EC7t ph\u1EE5c'.",
      researchNotes: "Trang ph\u1EE5c bi\u1EC3u tr\u01B0ng c\u1EE7a v\xF9ng \u0111\u1EA5t Nam B\u1ED9 tr\xF9 ph\xFA.",
      sourceIds: ["S03"]
    },
    {
      id: "G029",
      name: "\xC1o Ch\xE0m",
      aliases: ["\xC1o ch\xE0m"],
      category: "T\xEAn nh\xF3m / V\xF9ng mi\u1EC1n",
      period: ["Nhi\u1EC1u nh\xF3m d\xE2n t\u1ED9c"],
      audience: ["Nhi\u1EC1u nh\xF3m"],
      region: ["V\xF9ng n\xFAi ph\xEDa B\u1EAFc"],
      context: ["D\xE2n t\u1ED9c h\u1ECDc"],
      auditStatus: "T\u1EA0M LO\u1EA0I KH\u1ECEI CORE",
      evidenceLevel: "UNCERTAIN",
      constructionNotes: "Nhu\u1ED9m t\u1EEB l\xE1 ch\xE0m t\u1EF1 nhi\xEAn; l\xE0 t\xEAn nh\xF3m trang ph\u1EE5c c\u1EE7a nhi\u1EC1u c\u1ED9ng \u0111\u1ED3ng c\xE1c d\xE2n t\u1ED9c mi\u1EC1n n\xFAi ph\xEDa B\u1EAFc.",
      layerCompatibility: "Kh\xF4ng t\u1EA1o rule ph\u1ED1i trong core Kinh ph\u1EE5c v1.",
      warnings: "Nguy c\u01A1 tr\u1ED9n l\u1EABn scope Kinh ph\u1EE5c v\u1EDBi trang ph\u1EE5c c\u1EE7a 53 d\xE2n t\u1ED9c anh em.",
      researchNotes: "Phi\xEAn b\u1EA3n v1 gi\u1EDBi h\u1EA1n trong Kinh ph\u1EE5c theo t\xE0i li\u1EC7u.",
      sourceIds: ["S03"]
    },
    {
      id: "G030",
      name: "\xC1o D\xE0i hi\u1EC7n \u0111\u1EA1i",
      aliases: ["\xC1o d\xE0i t\xE2n th\u1EDDi", "\xC1o d\xE0i Le Mur", "\xC1o d\xE0i L\xEA Ph\u1ED5"],
      category: "\xC1o d\xE0i hi\u1EC7n \u0111\u1EA1i",
      period: ["Th\u1EBF k\u1EF7 20 - nay"],
      audience: ["N\u1EEF", "Nam"],
      region: ["To\xE0n qu\u1ED1c"],
      context: ["H\u1ECDc \u0111\u01B0\u1EDDng", "C\u01B0\u1EDBi h\u1ECFi", "L\u1EC5 T\u1EBFt", "Ngo\u1EA1i giao"],
      auditStatus: "CORE + T\xC1CH TIMELINE",
      evidenceLevel: "VERIFIED",
      constructionNotes: "Hai t\xE0 tr\u01B0\u1EDBc sau d\xE0i ch\u1EA5m g\xF3t, chi\u1EBFt eo t\xF4n d\xE1ng, c\u1ED5 \u0111\u1EE9ng ho\u1EB7c c\u1ED5 tr\xF2n, m\u1EB7c c\xF9ng qu\u1EA7n l\u1EE5a su\xF4ng.",
      layerCompatibility: "Cho ph\xE9p Remix Gen Z nh\u01B0ng ph\u1EA3i g\u1EAFn nh\xE3n 'Modern Remix' n\u1EBFu bi\u1EBFn t\u1EA5u phom d\xE1ng.",
      warnings: "Kh\xF4ng g\u1ECDi \xE1o d\xE0i hi\u1EC7n \u0111\u1EA1i l\xE0 nguy\xEAn m\u1EABu c\u1ED5 x\u01B0a c\u1EE7a \xC1o Ng\u0169 Th\xE2n hay \xC1o T\u1EE9 Th\xE2n.",
      researchNotes: "B\u1EA3o t\xE0ng Ph\u1EE5 n\u1EEF Nam B\u1ED9 c\xF3 chuy\xEAn \u0111\u1EC1 tr\u01B0ng b\xE0y ti\u1EBFn tr\xECnh c\u1EA3i bi\u1EBFn c\u1EE7a \xE1o d\xE0i th\u1EBF k\u1EF7 20.",
      sourceIds: ["S04", "S10"]
    },
    {
      id: "G031",
      name: "Kh\u0103n X\u1EBFp / Kh\u0103n \u0110\xF3ng",
      aliases: ["Kh\u0103n x\u1EBFp", "Kh\u0103n \u0111\xF3ng"],
      category: "Kh\u0103n \u0111\u1ED9i \u0111\u1EA7u",
      period: ["Nguy\u1EC5n", "C\u1EADn \u0111\u1EA1i"],
      audience: ["Nam", "N\u1EEF"],
      region: ["B\u1EAFc B\u1ED9", "Trung B\u1ED9", "Nam B\u1ED9"],
      context: ["Trang tr\u1ECDng", "Nghi l\u1EC5", "C\u01B0\u1EDBi h\u1ECFi"],
      auditStatus: "GI\u1EEE",
      evidenceLevel: "CONSISTENT",
      constructionNotes: "D\u1EA3i v\u1EA3i qu\u1EA5n s\u1EB5n th\xE0nh nhi\u1EC1u n\u1EBFp c\u1ED1 \u0111\u1ECBnh x\u1EBFp ch\u1EEF Nh\xE2n ho\u1EB7c ch\u1EEF Nh\u1EA5t tr\u01B0\u1EDBc tr\xE1n.",
      layerCompatibility: "Ph\u1ED1i h\u1EE3p h\xE0i h\xF2a v\u1EDBi \xC1o Ng\u0169 Th\xE2n ho\u1EB7c \xC1o T\u1EA5c.",
      warnings: "Kh\xF4ng m\u1EB7c \u0111\u1ECBnh l\xE0 ph\u1EE5 ki\u1EC7n b\u1EAFt bu\u1ED9c c\u1EE7a m\u1ECDi \xC1o Ng\u0169 Th\xE2n n\u1EEF.",
      researchNotes: "C\u1EA7n ph\xE2n bi\u1EC7t kh\u0103n x\u1EBFp truy\u1EC1n th\u1ED1ng qu\u1EA5n tay v\xE0 kh\u0103n \u0111\xF3ng khu\xF4n c\u1EE9ng th\u1EDDi hi\u1EC7n \u0111\u1EA1i.",
      sourceIds: ["S05"]
    },
    {
      id: "G032",
      name: "Kh\u0103n V\xE0nh D\xE2y",
      aliases: ["Kh\u0103n v\xE0nh", "V\xE0nh d\xE2y"],
      category: "Kh\u0103n \u0111\u1ED9i \u0111\u1EA7u",
      period: ["Nguy\u1EC5n"],
      audience: ["N\u1EEF cung \u0111\xECnh", "H\u1EADu phi", "M\u1EC7nh ph\u1EE5"],
      region: ["Cung \u0111\xECnh Hu\u1EBF"],
      context: ["\u0110\u1EA1i l\u1EC5 cung \u0111\xECnh", "H\xF4n l\u1EC5 cung \u0111\xECnh"],
      auditStatus: "GI\u1EEE + X\xC1C MINH",
      evidenceLevel: "CONSISTENT",
      constructionNotes: "Kh\u0103n v\u1EA3i l\u1EE5a ho\u1EB7c g\u1EA5m kh\u1ED5 r\u1ED9ng qu\u1EA5n nhi\u1EC1u v\xF2ng quanh \u0111\u1EA7u t\u1EA1o d\xE1ng x\xF2e h\xECnh ch\u1EEF V ng\u01B0\u1EE3c tr\u01B0\u1EDBc tr\xE1n.",
      layerCompatibility: "Ch\u1EC9 ph\u1ED1i c\xF9ng \xC1o Nh\u1EADt B\xECnh ho\u1EB7c l\u1EC5 ph\u1EE5c cung \u0111\xECnh n\u1EEF.",
      warnings: "Tuy\u1EC7t \u0111\u1ED1i kh\xF4ng ph\u1ED1i v\u1EDBi \xC1o T\u1EE9 Th\xE2n d\xE2n gian.",
      researchNotes: "G\u1EAFn li\u1EC1n v\u1EDBi h\xECnh \u1EA3nh trang tr\u1ECDng c\u1EE7a ph\u1EE5 n\u1EEF ho\xE0ng gia tri\u1EC1u Nguy\u1EC5n.",
      sourceIds: ["S01"]
    },
    {
      id: "G033",
      name: "Kh\u0103n M\u1ECF Qu\u1EA1",
      aliases: ["Kh\u0103n m\u1ECF qu\u1EA1", "Kh\u0103n vu\xF4ng"],
      category: "Kh\u0103n d\xE2n gian",
      period: ["B\u1EAFc B\u1ED9 truy\u1EC1n th\u1ED1ng"],
      audience: ["N\u1EEF"],
      region: ["B\u1EAFc B\u1ED9"],
      context: ["D\xE2n gian", "L\u1EC5 h\u1ED9i l\xE0ng"],
      auditStatus: "TH\xCAM",
      evidenceLevel: "CONSISTENT",
      constructionNotes: "Kh\u0103n vu\xF4ng b\u1EB1ng v\u1EA3i s\u1ED3i \u0111en g\u1EA5p ch\xE9o h\xECnh tam gi\xE1c, qu\u1EA5n tr\xF9m quanh \u0111\u1EA7u nh\u1ECDn ch\xFAc xu\u1ED1ng gi\u1EEFa tr\xE1n nh\u01B0 m\u1ECF chim qu\u1EA1.",
      layerCompatibility: "L\xE0 ph\u1EE5 ki\u1EC7n kinh \u0111i\u1EC3n c\u1EE7a \xC1o T\u1EE9 Th\xE2n B\u1EAFc B\u1ED9.",
      warnings: "Kh\xF4ng coi l\xE0 b\u1EAFt bu\u1ED9c cho m\u1ECDi b\u1ED9 \xC1o T\u1EE9 Th\xE2n (c\xF3 th\u1EC3 \u0111\u1EC3 t\xF3c tr\u1EA7n v\u1EA5n kh\u0103n).",
      researchNotes: "Bi\u1EC3u t\u01B0\u1EE3ng duy\xEAn d\xE1ng c\u1EE7a ph\u1EE5 n\u1EEF \u0111\u1ED3ng b\u1EB1ng B\u1EAFc B\u1ED9 x\u01B0a.",
      sourceIds: ["S03"]
    },
    {
      id: "G034",
      name: "Kh\u0103n R\u1EB1n",
      aliases: ["Kh\u0103n r\u1EB1n Nam B\u1ED9"],
      category: "Kh\u0103n v\xF9ng mi\u1EC1n",
      period: ["C\u1EADn \u0111\u1EA1i", "Hi\u1EC7n \u0111\u1EA1i"],
      audience: ["Nam", "N\u1EEF"],
      region: ["Nam B\u1ED9"],
      context: ["\u0110\u1EDDi th\u01B0\u1EDDng", "Mi\u1EC7t v\u01B0\u1EDDn"],
      auditStatus: "GI\u1EEE",
      evidenceLevel: "CONSISTENT",
      constructionNotes: "Kh\u0103n d\u1EC7t s\u1EE3i b\xF4ng k\u1EBB s\u1ECDc ca-r\xF4 tr\u1EAFng \u0111en ho\u1EB7c \u0111\u1ECF tr\u1EAFng, qu\xE0ng c\u1ED5 ho\u1EB7c qu\u1EA5n tr\xE1n th\u1EA5m m\u1ED3 h\xF4i.",
      layerCompatibility: "Ph\u1ED1i c\xF9ng \xC1o B\xE0 Ba trong sinh ho\u1EA1t Nam B\u1ED9.",
      warnings: "Kh\xF4ng d\xF9ng nh\u01B0 ph\u1EE5 ki\u1EC7n trung t\xEDnh cho m\u1ECDi lo\u1EA1i c\u1ED5 ph\u1EE5c.",
      researchNotes: "\u0110\xE3 s\u1EEDa l\u1ED7i ph\xE2n lo\u1EA1i: kh\u0103n r\u1EB1n thu\u1ED9c h\u1EC7 Kh\u0103n, kh\xF4ng thu\u1ED9c h\u1EC7 N\xF3n che.",
      sourceIds: ["S03"]
    },
    {
      id: "G035",
      name: "N\xF3n L\xE1",
      aliases: ["N\xF3n ch\xF3p", "N\xF3n l\xE1 truy\u1EC1n th\u1ED1ng"],
      category: "N\xF3n",
      period: ["Nhi\u1EC1u th\u1EDDi k\u1EF3"],
      audience: ["Nam", "N\u1EEF"],
      region: ["To\xE0n qu\u1ED1c"],
      context: ["\u0110\u1EDDi th\u01B0\u1EDDng", "Lao \u0111\u1ED9ng", "L\u1EC5 h\u1ED9i"],
      auditStatus: "GI\u1EEE + G\u1EAEN CONTEXT",
      evidenceLevel: "CONSISTENT",
      constructionNotes: "N\xF3n ch\xF3p \u0111an b\u1EB1ng l\xE1 c\u1ECD ho\u1EB7c l\xE1 g\u1ED3i, c\xF3 khung nan tre u\u1ED1n tr\xF2n d\u1EA7n t\u1EEB ch\xF3p xu\u1ED1ng v\xE0nh.",
      layerCompatibility: "Ph\u1ED1i t\xF9y b\u1ED1i c\u1EA3nh d\xE2n gian ho\u1EB7c hi\u1EC7n \u0111\u1EA1i.",
      warnings: "Kh\xF4ng coi l\xE0 ph\u1EE5 ki\u1EC7n b\u1EAFt bu\u1ED9c c\u1EE7a m\u1ECDi trang ph\u1EE5c truy\u1EC1n th\u1ED1ng.",
      researchNotes: "H\xECnh d\xE1ng n\xF3n thay \u0111\u1ED5i theo t\u1EEBng v\xF9ng mi\u1EC1n v\xE0 th\u1EDDi k\u1EF3.",
      sourceIds: ["S03"]
    },
    {
      id: "G036",
      name: "N\xF3n Ba T\u1EA7m",
      aliases: ["Ba t\u1EA7m"],
      category: "N\xF3n",
      period: ["B\u1EAFc B\u1ED9 truy\u1EC1n th\u1ED1ng"],
      audience: ["N\u1EEF"],
      region: ["B\u1EAFc B\u1ED9"],
      context: ["D\xE2n gian", "Quan h\u1ECD"],
      auditStatus: "T\xC1CH KH\u1ECEI QUAI THAO",
      evidenceLevel: "CONTESTED",
      constructionNotes: "N\xF3n tr\xF2n d\u1EB9t, \u0111\u01B0\u1EDDng k\xEDnh v\xE0nh r\u1ED9ng (kho\u1EA3ng ba t\u1EA7m), kh\xE2u b\u1EB1ng l\xE1 c\u1ECD.",
      layerCompatibility: "T\xE1ch ri\xEAng v\u1EDBi quai thao theo tranh lu\u1EADn h\u1ECDc thu\u1EADt.",
      warnings: "Kh\xF4ng g\u1ED9p tuy\u1EC7t \u0111\u1ED1i 'Ba T\u1EA7m = Quai thao'.",
      researchNotes: "C\xE1c ngu\u1ED3n nghi\xEAn c\u1EE9u v\xE0 b\xE1o ch\xED ghi nh\u1EADn tranh lu\u1EADn thu\u1EADt ng\u1EEF kh\xF4ng \u0111\u1ED3ng nh\u1EA5t.",
      sourceIds: ["S06", "S09"]
    },
    {
      id: "G037",
      name: "N\xF3n Th\xFAng / Th\xFAng quai thao",
      aliases: ["N\xF3n th\xFAng", "Th\xFAng quai thao", "N\xF3n quai thao"],
      category: "N\xF3n",
      period: ["B\u1EAFc B\u1ED9", "Quan h\u1ECD"],
      audience: ["N\u1EEF"],
      region: ["B\u1EAFc B\u1ED9", "Kinh B\u1EAFc"],
      context: ["H\u1ED9i Lim", "Quan h\u1ECD", "L\u1EC5 h\u1ED9i"],
      auditStatus: "T\xC1CH + GHI CH\xDA THU\u1EACT NG\u1EEE",
      evidenceLevel: "CONTESTED",
      constructionNotes: "N\xF3n l\xF2ng s\xE2u nh\u01B0 c\xE1i th\xFAng, c\xF3 quai thao b\u1EB1ng t\u01A1 t\u1EB1m d\xE0i bu\xF4ng r\u1EE7 hai b\xEAn h\xF4ng.",
      layerCompatibility: "Ph\u1ED1i c\xF9ng \xC1o T\u1EE9 Th\xE2n trong b\u1ED1i c\u1EA3nh d\xE2n ca Quan h\u1ECD B\u1EAFc Ninh.",
      warnings: "Kh\xF4ng tuy\xEAn b\u1ED1 m\u1ED9t h\u1EC7 ph\xE2n lo\u1EA1i duy nh\u1EA5t l\xE0 ch\xE2n l\xFD tuy\u1EC7t \u0111\u1ED1i.",
      researchNotes: "B\xE1o \u0110\xE0 N\u1EB5ng v\xE0 Th\u1EC3 thao & V\u0103n h\xF3a ghi nh\u1EADn tranh lu\u1EADn v\u1EC1 c\xE1ch hi\u1EC3u quai thao.",
      sourceIds: ["S06", "S09"]
    },
    {
      id: "G038",
      name: "N\xF3n B\xE0i Th\u01A1",
      aliases: ["N\xF3n b\xE0i th\u01A1 x\u1EE9 Hu\u1EBF"],
      category: "N\xF3n",
      period: ["C\u1EADn \u0111\u1EA1i", "Hi\u1EC7n \u0111\u1EA1i"],
      audience: ["N\u1EEF"],
      region: ["Hu\u1EBF"],
      context: ["H\u1ECDc \u0111\u01B0\u1EDDng", "Duy\xEAn d\xE1ng c\u1ED1 \u0111\xF4"],
      auditStatus: "GI\u1EEE",
      evidenceLevel: "CONSISTENT",
      constructionNotes: "N\xF3n l\xE1 m\u1ECFng hai l\u1EDBp, gi\u1EEFa ch\xE8n h\xECnh hoa v\u0103n v\xE0 b\xE0i th\u01A1 ch\u1EC9 th\u1EA5y r\xF5 khi soi ra \xE1nh s\xE1ng.",
      layerCompatibility: "Ph\u1ED1i c\xF9ng \xC1o D\xE0i n\u1EEF sinh ho\u1EB7c \xE1o d\xE0i x\u1EE9 Hu\u1EBF.",
      warnings: "Kh\xF4ng d\xF9ng l\xE0m n\xF3n m\u1EB7c \u0111\u1ECBnh cho \xC1o T\u1EE9 Th\xE2n B\u1EAFc B\u1ED9.",
      researchNotes: "N\xE9t v\u0103n h\xF3a \u0111\u1ED9c \u0111\xE1o \u0111\u1EB7c tr\u01B0ng c\u1EE7a v\xF9ng \u0111\u1EA5t c\u1ED1 \u0111\xF4.",
      sourceIds: ["S03"]
    },
    {
      id: "G039",
      name: "M\u0169 C\xE1nh Chu\u1ED3n",
      aliases: ["M\u0169 c\xE1nh chu\u1ED3n", "\xD4 sa m\u1EA1o"],
      category: "M\u0169 ph\u1EA9m ph\u1EE5c",
      period: ["L\xEA", "Nguy\u1EC5n"],
      audience: ["Quan v\u0103n", "Quan l\u1EA1i"],
      region: ["Cung \u0111\xECnh"],
      context: ["Tri\u1EC1u h\u1ED9i", "Ph\u1EA9m h\xE0m"],
      auditStatus: "GI\u1EEE",
      evidenceLevel: "VERIFIED",
      constructionNotes: "M\u0169 m\xE0u \u0111en c\xF3 hai c\xE1nh chu\u1ED3n d\xE0i ch\xECa ngang sang hai b\xEAn; hoa v\u0103n trang tr\xED theo ph\u1EA9m c\u1EA5p.",
      layerCompatibility: "\u0110i tr\u1ECDn b\u1ED9 c\xF9ng \xC1o B\u1ED5 Ph\u1EE5c ho\u1EB7c quan ph\u1EE5c tri\u1EC1u \u0111\xECnh.",
      warnings: "Kh\xF4ng d\xF9ng nh\u01B0 ph\u1EE5 ki\u1EC7n th\u1EDDi trang t\u1EF1 do cho \xE1o d\xE2n gian n\u1EBFu kh\xF4ng g\u1EAFn nh\xE3n Remix.",
      researchNotes: "B\u1EA3o t\xE0ng L\u1ECBch s\u1EED Qu\u1ED1c gia l\u01B0u gi\u1EEF nhi\u1EC1u hi\u1EC7n v\u1EADt m\u0169 quan v\u0103n tri\u1EC1u Nguy\u1EC5n.",
      sourceIds: ["S02", "S04"]
    },
    {
      id: "G040",
      name: "V\xE2n Ki\xEAn",
      aliases: ["V\xE2n ki\xEAn", "D\u1EA3i m\xE2y cho\xE0ng vai"],
      category: "Ph\u1EE5 ki\u1EC7n ph\u1EE5c s\u1EE9c / chi ti\u1EBFt vai",
      period: ["Nguy\u1EC5n"],
      audience: ["Quan l\u1EA1i", "Cung \u0111\xECnh t\xF9y ph\u1EA9m c\u1EA5p"],
      region: ["Cung \u0111\xECnh"],
      context: ["Ph\u1EA9m ph\u1EE5c", "Nghi l\u1EC5"],
      auditStatus: "CORE NH\u01AF ACCESSORY C\xD3 \u0110I\u1EC0U KI\u1EC6N",
      evidenceLevel: "VERIFIED",
      constructionNotes: "M\u1EA3nh cho\xE0ng h\xECnh \u0111\xE1m m\xE2y \xF4m quanh vai, th\xEAu hoa v\u0103n ch\u1EC9 v\xE0ng ch\u1EC9 b\u1EA1c theo \u0111i\u1EC3n ch\u1EBF.",
      layerCompatibility: "Ch\u1EC9 cho ph\xE9p khi garment + period + rank/status + context nghi l\u1EC5 ho\xE0n to\xE0n kh\u1EDBp.",
      warnings: "C\u1EF0C K\u1EF2 QUAN TR\u1ECCNG: Tuy\u1EC7t \u0111\u1ED1i kh\xF4ng cho ph\u1ED1i t\u1EF1 do v\u1EDBi \xC1o T\u1EE9 Th\xE2n hay \xC1o Ng\u0169 Th\xE2n d\xE2n d\xE3.",
      researchNotes: "\u0110\xE2y l\xE0 accessory c\xF3 \u0111i\u1EC1u ki\u1EC7n nghi\xEAm ng\u1EB7t, kh\xF4ng ph\u1EA3i trang s\u1EE9c t\u1EF1 do.",
      sourceIds: ["S01"]
    },
    {
      id: "G041",
      name: "Tr\xE2m",
      aliases: ["Tr\xE2m c\xE0i t\xF3c", "Tr\xE2m ng\u1ECDc", "Tr\xE2m v\xE0ng"],
      category: "Trang s\u1EE9c",
      period: ["Nhi\u1EC1u th\u1EDDi k\u1EF3"],
      audience: ["N\u1EEF"],
      region: ["To\xE0n qu\u1ED1c"],
      context: ["L\u1EC5 ti\u1EBFt", "Q\xFAy t\u1ED9c", "D\xE2n gian"],
      auditStatus: "GI\u1EEE",
      evidenceLevel: "CONSISTENT",
      constructionNotes: "C\xE2y tr\xE2m c\xE0i gi\u1EEF n\u1EBFp t\xF3c; ch\u1EA5t li\u1EC7u t\u1EEB g\u1ED7, b\u1EA1c, ng\u1ECDc b\xEDch \u0111\u1EBFn v\xE0ng ch\u1EA1m kh\u1EAFc tinh x\u1EA3o.",
      layerCompatibility: "Ph\u1ED1i theo ki\u1EC3u t\xF3c v\xE0 t\u1EA7ng l\u1EDBp x\xE3 h\u1ED9i.",
      warnings: "Kh\xF4ng d\xF9ng c\xF9ng m\u1ED9t ki\u1EC3u tr\xE2m cho m\u1ECDi th\u1EDDi k\u1EF3 l\u1ECBch s\u1EED.",
      researchNotes: "T\xE1ch bi\u1EC7t r\xF5 kh\u1ECFi V\xE2n Ki\xEAn; tr\xE2m l\xE0 trang s\u1EE9c t\xF3c.",
      sourceIds: ["S01"]
    },
    {
      id: "G042",
      name: "\u0110ai / Th\u1EAFt l\u01B0ng",
      aliases: ["\u0110ai ph\u1EA9m ph\u1EE5c", "Th\u1EAFt l\u01B0ng l\u1EE5a", "D\u1EA3i bao"],
      category: "Ph\u1EE5 ki\u1EC7n eo",
      period: ["Nhi\u1EC1u th\u1EDDi k\u1EF3"],
      audience: ["Nam", "N\u1EEF"],
      region: ["To\xE0n qu\u1ED1c"],
      context: ["Cung \u0111\xECnh / D\xE2n gian"],
      auditStatus: "CORE",
      evidenceLevel: "VERIFIED",
      constructionNotes: "Th\xE0nh ph\u1EA7n gi\u1EEF v\u1EA1t ho\u1EB7c bi\u1EC3u th\u1ECB ph\u1EA9m c\u1EA5p; \u0111ai cung \u0111\xECnh n\u1EA1m ng\u1ECDc \u0111\u1ED3i m\u1ED3i, th\u1EAFt l\u01B0ng d\xE2n gian may b\u1EB1ng l\u1EE5a m\u1EC1m.",
      layerCompatibility: "T\u1EE9 th\xE2n c\xF3 th\u1EAFt l\u01B0ng d\u1EA3i bao; cung \u0111\xECnh c\xF3 \u0111ai ph\u1EA9m ph\u1EE5c n\u1EA1m ng\u1ECDc.",
      warnings: "Ph\u1EA3i ph\xE2n bi\u1EC7t r\u1EA1ch r\xF2i \u0111ai cung \u0111\xECnh v\u1EDBi th\u1EAFt l\u01B0ng d\xE2n d\xE3.",
      researchNotes: "Th\xE0nh ph\u1EA7n k\u1EBFt n\u1ED1i trang ph\u1EE5c c\u1ED1t l\xF5i.",
      sourceIds: ["S02", "S04"]
    },
    {
      id: "G043",
      name: "D\xE2y Ru\u1ED9t T\u01B0\u1EE3ng",
      aliases: ["Ru\u1ED9t t\u01B0\u1EE3ng", "Th\u1EAFt l\u01B0ng ru\u1ED9t t\u01B0\u1EE3ng"],
      category: "Ph\u1EE5 ki\u1EC7n eo",
      period: ["D\xE2n gian truy\u1EC1n th\u1ED1ng"],
      audience: ["N\u1EEF"],
      region: ["B\u1EAFc B\u1ED9"],
      context: ["D\xE2n gian", "Lao \u0111\u1ED9ng"],
      auditStatus: "GI\u1EEE",
      evidenceLevel: "CONSISTENT",
      constructionNotes: "D\u1EA3i v\u1EA3i may r\u1ED7ng ru\u1ED9t nh\u01B0 h\xECnh ru\u1ED9t t\u01B0\u1EE3ng d\xF9ng \u0111\u1EC3 th\u1EAFt l\u01B0ng v\xE0 \u0111\u1EF1ng ti\u1EC1n \u0111\u1ED3ng ho\u1EB7c \u0111\u1ED3 v\u1EADt qu\xFD.",
      layerCompatibility: "C\xF3 th\u1EC3 l\xE0 ph\u1EE5 ki\u1EC7n c\u1EE7a set \xC1o T\u1EE9 Th\xE2n trong b\u1ED1i c\u1EA3nh th\xF4n d\xE3.",
      warnings: "Kh\xF4ng \xE1p d\u1EE5ng cho m\u1ECDi ki\u1EC3u trang ph\u1EE5c c\u1ED5 phong.",
      researchNotes: "Ph\u1EE5 ki\u1EC7n ti\u1EC7n \xEDch d\xE2n gian truy\u1EC1n th\u1ED1ng.",
      sourceIds: ["S03"]
    },
    {
      id: "G044",
      name: "H\u1ED1t",
      aliases: ["Th\u1EBB h\u1ED1t", "H\u1ED1t ng\xE0", "H\u1ED1t ng\u1ECDc"],
      category: "Ph\u1EE5 ki\u1EC7n nghi l\u1EC5",
      period: ["Nguy\u1EC5n"],
      audience: ["Vua", "Quan l\u1EA1i tri\u1EC1u \u0111\xECnh"],
      region: ["Cung \u0111\xECnh"],
      context: ["\u0110\u1EA1i tri\u1EC1u", "H\xE0nh l\u1EC5"],
      auditStatus: "TH\xCAM",
      evidenceLevel: "VERIFIED",
      constructionNotes: "Phi\u1EBFn b\u1EB1ng ng\xE0 voi, ng\u1ECDc ho\u1EB7c g\u1ED7 qu\xFD c\u1EA7m tr\xEAn tay khi t\xE2u b\xE0y tr\u01B0\u1EDBc ngai v\xE0ng.",
      layerCompatibility: "Ch\u1EC9 ph\u1ED1i trong b\u1ED9 l\u1EC5 ph\u1EE5c tri\u1EC1u \u0111\xECnh (Long b\xE0o ho\u1EB7c B\u1ED5 ph\u1EE5c).",
      warnings: "Tuy\u1EC7t \u0111\u1ED1i kh\xF4ng d\xF9ng trong b\u1ED1i c\u1EA3nh \u0111\u1EDDi th\u01B0\u1EDDng ho\u1EB7c casual.",
      researchNotes: "B\u1EA3o t\xE0ng L\u1ECBch s\u1EED Qu\u1ED1c gia x\xE1c nh\u1EADn h\u1ED1t l\xE0 th\xE0nh ph\u1EA7n nghi l\u1EC5 quan tr\u1ECDng.",
      sourceIds: ["S02"]
    },
    {
      id: "G045",
      name: "Hia",
      aliases: ["Hia nghi l\u1EC5", "Hia th\xEAu"],
      category: "Gi\xE0y/footwear nghi l\u1EC5",
      period: ["Nguy\u1EC5n"],
      audience: ["Vua", "Quan l\u1EA1i tri\u1EC1u \u0111\xECnh"],
      region: ["Cung \u0111\xECnh"],
      context: ["\u0110\u1EA1i tri\u1EC1u", "L\u1EC5 ti\u1EBFt"],
      auditStatus: "TH\xCAM",
      evidenceLevel: "VERIFIED",
      constructionNotes: "Gi\xE0y c\u1ED5 cao qua m\u1EAFt c\xE1 ch\xE2n b\u1EB1ng da ho\u1EB7c v\u1EA3i g\u1EA5m d\xE0y th\xEAu hoa v\u0103n r\u1ED3ng m\xE2y trang tr\u1ECDng.",
      layerCompatibility: "\u0110i c\xF9ng b\u1ED9 ph\u1EA9m ph\u1EE5c tri\u1EC1u \u0111\xECnh.",
      warnings: "Kh\xF4ng ph\u1ED1i c\xF9ng \xC1o T\u1EE9 Th\xE2n hay \xC1o B\xE0 Ba d\xE2n gian.",
      researchNotes: "Th\xE0nh ph\u1EA7n footwear trang tr\u1ECDng h\xE0ng \u0111\u1EA7u c\u1EE7a cung \u0111\xECnh.",
      sourceIds: ["S02"]
    },
    {
      id: "G046",
      name: "H\xE0i",
      aliases: ["H\xE0i m\xF5m nh\xE1i", "H\xE0i v\xE2n \u0111\u1EA7u", "H\xE0i th\xEAu hoa"],
      category: "Gi\xE0y/footwear",
      period: ["Nhi\u1EC1u th\u1EDDi k\u1EF3"],
      audience: ["Nam", "N\u1EEF"],
      region: ["To\xE0n qu\u1ED1c"],
      context: ["Cung \u0111\xECnh / D\xE2n gian trang tr\u1ECDng"],
      auditStatus: "GI\u1EEE + T\xC1CH BI\u1EBEN TH\u1EC2",
      evidenceLevel: "CONSISTENT",
      constructionNotes: "Gi\xE0y m\u0169i cong u\u1ED1n l\u01B0\u1EE3n; h\xE0i cung \u0111\xECnh \u0111\xEDnh ng\u1ECDc th\xEAu kim tuy\u1EBFn, h\xE0i n\u1EEF l\u01B0u th\xEAu hoa trang nh\xE3.",
      layerCompatibility: "G\u1EAFn theo t\u1EEBng bi\u1EBFn th\u1EC3 v\xE0 b\u1ED1i c\u1EA3nh c\u1EE5 th\u1EC3.",
      warnings: "Kh\xF4ng coi m\u1ECDi lo\u1EA1i h\xE0i l\xE0 t\u01B0\u01A1ng \u0111\u01B0\u01A1ng nhau.",
      researchNotes: "Ph\xE2n bi\u1EC7t r\xF5 h\xE0i cung \u0111\xECnh v\xE0 h\xE0i d\xE2n gian.",
      sourceIds: ["S01"]
    },
    {
      id: "G047",
      name: "Gu\u1ED1c M\u1ED9c",
      aliases: ["Gu\u1ED1c m\u1ED9c", "Gu\u1ED1c g\u1ED7"],
      category: "Gi\xE0y/footwear d\xE2n gian",
      period: ["D\xE2n gian", "C\u1EADn \u0111\u1EA1i", "Hi\u1EC7n \u0111\u1EA1i"],
      audience: ["Nam", "N\u1EEF"],
      region: ["To\xE0n qu\u1ED1c"],
      context: ["\u0110\u1EDDi th\u01B0\u1EDDng", "D\xE2n d\xE3"],
      auditStatus: "GI\u1EEE",
      evidenceLevel: "CONSISTENT",
      constructionNotes: "Gu\u1ED1c \u0111\u1EBDo t\u1EEB g\u1ED7 xoan ho\u1EB7c m\xEDt, quai b\u1EB1ng da, v\u1EA3i ho\u1EB7c m\xE2y \u0111an m\u1ED9c m\u1EA1c.",
      layerCompatibility: "D\xF9ng trong sinh ho\u1EA1t d\xE2n gian ho\u1EB7c modern remix c\xF3 \xFD th\u1EE9c b\u1ED1i c\u1EA3nh.",
      warnings: "Kh\xF4ng ph\u1EA3i footwear chu\u1EA9n m\u1EF1c cho \u0111\u1EA1i tri\u1EC1u cung \u0111\xECnh.",
      researchNotes: "G\u1EAFn li\u1EC1n \u0111\u1EDDi s\u1ED1ng b\xECnh d\xE2n ng\u01B0\u1EDDi Vi\u1EC7t qua nhi\u1EC1u th\u1EBF k\u1EF7.",
      sourceIds: ["S03"]
    }
  ],
  OUTFIT_RULES: [
    {
      id: "R001",
      baseGarment: "\xC1o T\u1EE9 Th\xE2n",
      baseGarmentSlug: "ao-tu-than",
      component: "Y\u1EBFm",
      relationship: "CORE_LAYER",
      periodContext: "B\u1EAFc B\u1ED9 / d\xE2n gian",
      evidence: "VERIFIED",
      confidence: "HIGH",
      whyEvidence: "B\u1EA3o t\xE0ng Ph\u1EE5 n\u1EEF Nam B\u1ED9 v\xE0 t\u01B0 li\u1EC7u b\u1EA3o t\xE0ng m\xF4 t\u1EA3 T\u1EE9 th\xE2n m\u1EB7c ngo\xE0i y\u1EBFm.",
      whatToWarnAbout: "Kh\xF4ng coi y\u1EBFm l\xE0 accessory th\u1EDDi trang b\xEAn ngo\xE0i.",
      webBehavior: "Recommend",
      sourceIds: ["S03", "S04"]
    },
    {
      id: "R002",
      baseGarment: "\xC1o T\u1EE9 Th\xE2n",
      baseGarmentSlug: "ao-tu-than",
      component: "V\xE1y",
      relationship: "CORE_LAYER",
      periodContext: "B\u1EAFc B\u1ED9 / d\xE2n gian",
      evidence: "VERIFIED",
      confidence: "HIGH",
      whyEvidence: "B\u1EA3o t\xE0ng Ph\u1EE5 n\u1EEF Nam B\u1ED9 m\xF4 t\u1EA3 ph\u1EE5 n\u1EEF m\u1EB7c T\u1EE9 th\xE2n v\u1EDBi v\xE1y \u0111\u1EE5p \u0111en.",
      whatToWarnAbout: "Kh\xF4ng thay b\u1EB1ng qu\u1EA7n hi\u1EC7n \u0111\u1EA1i n\u1EBFu \u0111ang y\xEAu c\u1EA7u authentic l\u1ECBch s\u1EED.",
      webBehavior: "Recommend",
      sourceIds: ["S03", "S04"]
    },
    {
      id: "R003",
      baseGarment: "\xC1o T\u1EE9 Th\xE2n",
      baseGarmentSlug: "ao-tu-than",
      component: "Th\u1EAFt l\u01B0ng",
      relationship: "CORE_ACCESSORY",
      periodContext: "B\u1EAFc B\u1ED9 / d\xE2n gian",
      evidence: "VERIFIED",
      confidence: "HIGH",
      whyEvidence: "M\xF4 t\u1EA3 b\u1EA3o t\xE0ng ghi th\u1EAFt v\u1EA1t ho\u1EB7c th\u1EAFt l\u01B0ng d\u1EA3i bao l\u1EE5a.",
      whatToWarnAbout: "Ki\u1EC3u th\u1EAFt c\xF3 th\u1EC3 thay \u0111\u1ED5i theo b\u1ED1i c\u1EA3nh.",
      webBehavior: "Recommend",
      sourceIds: ["S03", "S04"]
    },
    {
      id: "R004",
      baseGarment: "\xC1o T\u1EE9 Th\xE2n",
      baseGarmentSlug: "ao-tu-than",
      component: "Kh\u0103n M\u1ECF Qu\u1EA1",
      relationship: "CONTEXTUAL",
      periodContext: "B\u1EAFc B\u1ED9; c\u1EA7n period",
      evidence: "CONSISTENT",
      confidence: "MEDIUM",
      whyEvidence: "H\xECnh \u1EA3nh/t\u01B0 li\u1EC7u ph\u1ED5 bi\u1EBFn li\xEAn h\u1EC7 kh\u0103n m\u1ECF qu\u1EA1 v\u1EDBi n\u1EEF ph\u1EE5c B\u1EAFc B\u1ED9; ch\u01B0a d\xF9ng ngu\u1ED3n b\u1EA3o t\xE0ng m\u1EA1nh trong v1.",
      whatToWarnAbout: "Kh\xF4ng \u0111\xE1nh d\u1EA5u VERIFIED ph\u1ED5 qu\xE1t cho m\u1ECDi T\u1EE9 th\xE2n.",
      webBehavior: "Suggest with note",
      sourceIds: ["S03"]
    },
    {
      id: "R005",
      baseGarment: "\xC1o T\u1EE9 Th\xE2n",
      baseGarmentSlug: "ao-tu-than",
      component: "N\xF3n Th\xFAng/Quai thao",
      relationship: "CONTEXTUAL",
      periodContext: "B\u1EAFc B\u1ED9 / Quan h\u1ECD / d\xE2n gian",
      evidence: "CONSISTENT",
      confidence: "MEDIUM",
      whyEvidence: "B\u1EA3o t\xE0ng Ph\u1EE5 n\u1EEF Nam B\u1ED9 m\xF4 t\u1EA3 T\u1EE9 th\xE2n + n\xF3n th\xFAng quai thao; thu\u1EADt ng\u1EEF n\xF3n c\xF3 tranh lu\u1EADn h\u1ECDc thu\u1EADt.",
      whatToWarnAbout: "Kh\xF4ng g\u1ED9p Ba T\u1EA7m = Quai thao m\u1ED9t c\xE1ch tuy\u1EC7t \u0111\u1ED1i.",
      webBehavior: "Suggest with terminology note",
      sourceIds: ["S03", "S06", "S09"]
    },
    {
      id: "R006",
      baseGarment: "Ng\u0169 Th\xE2n tay ch\u1EBDn",
      baseGarmentSlug: "ao-ngu-than",
      component: "Qu\u1EA7n \u1ED1ng r\u1ED9ng s\xE1ng m\xE0u",
      relationship: "CORE_LAYER",
      periodContext: "Nguy\u1EC5n",
      evidence: "VERIFIED",
      confidence: "HIGH",
      whyEvidence: "B\u1EA3o t\xE0ng Ph\u1EE5 n\u1EEF Nam B\u1ED9 ghi r\xF5 ng\u0169 th\xE2n th\u01B0\u1EDDng m\u1EB7c v\u1EDBi qu\u1EA7n \u1ED1ng r\u1ED9ng, s\xE1ng m\xE0u.",
      whatToWarnAbout: "Kh\xF4ng bi\u1EBFn 'tr\u1EAFng' th\xE0nh quy t\u1EAFc tuy\u1EC7t \u0111\u1ED1i cho m\u1ECDi th\u1EDDi k\u1EF3.",
      webBehavior: "Recommend",
      sourceIds: ["S04", "S05"]
    },
    {
      id: "R007",
      baseGarment: "Ng\u0169 Th\xE2n tay ch\u1EBDn",
      baseGarmentSlug: "ao-ngu-than",
      component: "\xC1o l\xF3t",
      relationship: "CORE_LAYER",
      periodContext: "Nguy\u1EC5n",
      evidence: "VERIFIED",
      confidence: "HIGH",
      whyEvidence: "B\u1EA3o t\xE0ng m\xF4 t\u1EA3 \xE1o l\xF3t tr\u1EAFng m\u1EB7c b\xEAn trong, ch\u1EC9 \u0111i\u1EC3m xuy\u1EBFt \u1EDF vi\u1EC1n c\u1ED5 v\xE0 c\u1ED5 tay \xE1o.",
      whatToWarnAbout: "Kh\xF4ng \u0111\u1EC3 \xE1o l\xF3t th\xE0nh outer layer b\xEAn ngo\xE0i.",
      webBehavior: "Recommend",
      sourceIds: ["S04", "S05"]
    },
    {
      id: "R008",
      baseGarment: "Ng\u0169 Th\xE2n tay ch\u1EBDn",
      baseGarmentSlug: "ao-ngu-than",
      component: "Kh\u0103n x\u1EBFp/\u0111\xF3ng",
      relationship: "CONTEXTUAL",
      periodContext: "Nguy\u1EC5n / c\u1EADn \u0111\u1EA1i",
      evidence: "CONSISTENT",
      confidence: "MEDIUM",
      whyEvidence: "C\xF3 ph\u1ED1i \xE1o ng\u0169 th\xE2n + kh\u0103n x\u1EBFp; c\u1EA7n b\u1ED1i c\u1EA3nh \u0111\u1EC3 \u0111\xE1nh d\u1EA5u ch\xEDnh x\xE1c.",
      whatToWarnAbout: "Kh\xF4ng b\u1EAFt bu\u1ED9c v\u1EDBi m\u1ECDi ng\u0169 th\xE2n n\u1EEF.",
      webBehavior: "Suggest",
      sourceIds: ["S05"]
    },
    {
      id: "R009",
      baseGarment: "\xC1o T\u1EA5c",
      baseGarmentSlug: "ao-ngu-than",
      component: "Qu\u1EA7n",
      relationship: "CORE_LAYER",
      periodContext: "L\u1EC5 ph\u1EE5c Nguy\u1EC5n",
      evidence: "VERIFIED",
      confidence: "HIGH",
      whyEvidence: "Hi\u1EC7n v\u1EADt \xE1o t\u1EA5c/b\u1ED5 ph\u1EE5c t\u1EA1i BTLSQG cho th\u1EA5y h\u1EC7 \xE1o l\u1EC5; b\u1ED9 ho\xE0n ch\u1EC9nh c\u1EA7n theo context.",
      whatToWarnAbout: "Kh\xF4ng d\xF9ng sneaker ho\u1EB7c \u0111\u1ED3 casual n\u1EBFu m\u1EE5c ti\xEAu authentic.",
      webBehavior: "Recommend",
      sourceIds: ["S01", "S02"]
    },
    {
      id: "R010",
      baseGarment: "\xC1o T\u1EA5c",
      baseGarmentSlug: "ao-ngu-than",
      component: "V\xE2n Ki\xEAn",
      relationship: "CONDITIONAL",
      periodContext: "Nguy\u1EC5n / ph\u1EA9m ph\u1EE5c c\u1EE5 th\u1EC3",
      evidence: "VERIFIED",
      confidence: "HIGH",
      whyEvidence: "BTLSQG ghi hi\u1EC7n v\u1EADt b\u1ED5 ph\u1EE5c c\xF3 v\xE2n ki\xEAn bao quanh vai.",
      whatToWarnAbout: "Ch\u1EC9 b\u1EADt khi garment, rank v\xE0 context ph\u1EA9m h\xE0m ph\xF9 h\u1EE3p.",
      webBehavior: "Conditional",
      sourceIds: ["S01"]
    },
    {
      id: "R011",
      baseGarment: "\xC1o B\u1ED5 Ph\u1EE5c",
      baseGarmentSlug: "ao-bo-phuc",
      component: "B\u1ED5 T\u1EED",
      relationship: "CORE_COMPONENT",
      periodContext: "Nguy\u1EC5n / quan ph\u1EE5c",
      evidence: "VERIFIED",
      confidence: "HIGH",
      whyEvidence: "BTLSQG m\xF4 t\u1EA3 nhi\u1EC1u \xE1o b\u1ED5 ph\u1EE5c v\xE0 b\u1ED5 t\u1EED theo c\u1EA5p b\u1EADc r\xF5 r\xE0ng.",
      whatToWarnAbout: "Ph\u1EA9m c\u1EA5p quy\u1EBFt \u0111\u1ECBnh motif, m\xE0u s\u1EAFc v\xE0 \u0111\u1ED1i t\u01B0\u1EE3ng.",
      webBehavior: "Required/conditional",
      sourceIds: ["S01", "S02"]
    },
    {
      id: "R012",
      baseGarment: "Long B\xE0o",
      baseGarmentSlug: "long-bao",
      component: "M\u0169 + xi\xEAm + \u0111ai + h\u1ED1t + hia",
      relationship: "CEREMONIAL_SET",
      periodContext: "Nguy\u1EC5n / \u0110\u1EA1i tri\u1EC1u",
      evidence: "VERIFIED",
      confidence: "HIGH",
      whyEvidence: "BTLSQG m\xF4 t\u1EA3 tr\u1ECDn b\u1ED9 ph\u1EE5c trang \u0111i k\xE8m long b\xE0o c\u1EE7a vua.",
      whatToWarnAbout: "Kh\xF4ng remix t\u1EEBng m\xF3n ri\xEAng l\u1EBB m\xE0 v\u1EABn g\u1ECDi l\xE0 nguy\xEAn b\u1ED9 long b\xE0o authentic.",
      webBehavior: "Bundle",
      sourceIds: ["S02"]
    },
    {
      id: "R013",
      baseGarment: "M\xE3ng B\xE0o",
      baseGarmentSlug: "mang-bao",
      component: "Ph\u1EE5 ki\u1EC7n cung \u0111\xECnh t\u01B0\u01A1ng \u1EE9ng",
      relationship: "CEREMONIAL_SET",
      periodContext: "Nguy\u1EC5n",
      evidence: "VERIFIED",
      confidence: "HIGH",
      whyEvidence: "BTLSQG ph\xE2n bi\u1EC7t m\xE3ng b\xE0o, m\xE3ng lan v\xE0 context nghi l\u1EC5.",
      whatToWarnAbout: "Kh\xF4ng \u0111\u1ED3ng nh\u1EA5t m\xE3ng b\xE0o v\u1EDBi long b\xE0o.",
      webBehavior: "Bundle",
      sourceIds: ["S01", "S02"]
    },
    {
      id: "R014",
      baseGarment: "Nh\u1EADt B\xECnh",
      baseGarmentSlug: "ao-nhat-binh",
      component: "Ph\u1EE5 ki\u1EC7n cung \u0111\xECnh n\u1EEF",
      relationship: "CONDITIONAL",
      periodContext: "Nguy\u1EC5n / c\u1EA5p b\u1EADc",
      evidence: "VERIFIED",
      confidence: "HIGH",
      whyEvidence: "Hi\u1EC7n v\u1EADt c\u1ED5 nh\u1EADt b\xECnh c\xF3 nhi\u1EC1u context: nh\u1EA5t ph\u1EA9m phu nh\xE2n, c\xF4ng ch\xFAa ho\u1EB7c phi t\u1EA7n.",
      whatToWarnAbout: "Kh\xF4ng g\u1ECDi \u0111\u01A1n gi\u1EA3n l\xE0 'th\u01B0\u1EDDng ph\u1EE5c h\u1EADu phi'.",
      webBehavior: "Conditional",
      sourceIds: ["S01", "S02"]
    },
    {
      id: "R015",
      baseGarment: "\xC1o B\xE0 Ba",
      baseGarmentSlug: "ao-ba-ba",
      component: "Kh\u0103n R\u1EB1n",
      relationship: "REGIONAL",
      periodContext: "Nam B\u1ED9 / c\u1EADn \u0111\u1EA1i",
      evidence: "CONSISTENT",
      confidence: "MEDIUM",
      whyEvidence: "Hai y\u1EBFu t\u1ED1 \u0111\u1EC1u g\u1EAFn m\u1EA1nh v\u1EDBi h\xECnh \u1EA3nh Nam B\u1ED9; c\u1EA7n ngu\u1ED3n chuy\xEAn s\xE2u cho combo c\u1EE5 th\u1EC3.",
      whatToWarnAbout: "Kh\xF4ng d\xF9ng l\xE0m combo 'c\u1ED5 ph\u1EE5c' l\u1ECBch s\u1EED s\u1EDBm.",
      webBehavior: "Suggest",
      sourceIds: ["S03"]
    },
    {
      id: "R016",
      baseGarment: "T\u1EE9 \u0110i\xEAn",
      baseGarmentSlug: "ao-tu-dien",
      component: "Th\u01B0\u1EDDng \u0111en",
      relationship: "HISTORICAL_TEXT_SUPPORT",
      periodContext: "L\xFD\u2013Tr\u1EA7n",
      evidence: "CONSISTENT",
      confidence: "MEDIUM",
      whyEvidence: "V\u0103n li\u1EC7u \u0111\u01B0\u1EE3c d\u1EABn t\u1EEB L\u0129nh Ngo\u1EA1i \u0110\u1EA1i \u0110\xE1p/Nguy\xEAn Thi K\u1EF7 S\u1EF1 trong ngu\u1ED3n ph\u1EE5c d\u1EF1ng.",
      whatToWarnAbout: "Kh\xF4ng tr\xECnh b\xE0y reconstructed cut nh\u01B0 hi\u1EC7n v\u1EADt nguy\xEAn b\u1EA3n.",
      webBehavior: "Historical note",
      sourceIds: ["S08"]
    },
    {
      id: "R017",
      baseGarment: "\xC1o C\xE1nh",
      baseGarmentSlug: "ao-canh",
      component: "Qu\u1EA7n L\xE1 T\u1ECDa",
      relationship: "LABOR_DAILY",
      periodContext: "D\xE2n gian; context lao \u0111\u1ED9ng",
      evidence: "CONSISTENT",
      confidence: "MEDIUM",
      whyEvidence: "T\xE0i li\u1EC7u ghi tr\u1EF1c ti\u1EBFp \u0111\xE2y l\xE0 trang ph\u1EE5c lao \u0111\u1ED9ng th\u01B0\u1EDDng ng\xE0y c\u1EE7a ng\u01B0\u1EDDi d\xE2n.",
      whatToWarnAbout: "Kh\xF4ng \xE1p d\u1EE5ng cho b\u1ED1i c\u1EA3nh cung \u0111\xECnh.",
      webBehavior: "Recommend with context",
      sourceIds: ["S03"]
    },
    {
      id: "R018",
      baseGarment: "V\xE2n Ki\xEAn",
      baseGarmentSlug: "van-kien",
      component: "\xC1o T\u1EE9 Th\xE2n",
      relationship: "MISMATCH",
      periodContext: "Kh\xE1c h\u1EC7 ph\u1EE5c trang",
      evidence: "MISMATCH",
      confidence: "HIGH",
      whyEvidence: "V\xE2n ki\xEAn \u0111\u01B0\u1EE3c ngu\u1ED3n ch\xEDnh th\u1EE9c m\xF4 t\u1EA3 tr\xEAn ph\u1EE5c trang/b\u1ED5 ph\u1EE5c cung \u0111\xECnh Nguy\u1EC5n c\u1EE5 th\u1EC3, kh\xF4ng ph\u1EA3i accessory d\xE2n gian t\u1EF1 do.",
      whatToWarnAbout: "C\u1EA3nh b\xE1o cultural mismatch nghi\xEAm tr\u1ECDng gi\u1EEFa ph\u1EA9m ph\u1EE5c cung \u0111\xECnh v\xE0 \xE1o d\xE2n gian.",
      webBehavior: "Block/Warning",
      sourceIds: ["S01"]
    },
    {
      id: "R019",
      baseGarment: "V\xE2n Ki\xEAn",
      baseGarmentSlug: "van-kien",
      component: "\xC1o Ng\u0169 Th\xE2n d\xE2n gian",
      relationship: "MISMATCH",
      periodContext: "Ph\u1EA3i ph\xE2n bi\u1EC7t ph\u1EA9m ph\u1EE5c Nguy\u1EC5n",
      evidence: "UNCERTAIN",
      confidence: "MEDIUM",
      whyEvidence: "C\xF3 v\xE2n ki\xEAn tr\xEAn m\u1ED9t s\u1ED1 \xE1o ph\u1EE5c ph\u1EA9m, nh\u01B0ng kh\xF4ng \u0111\u1EE7 \u0111\u1EC3 cho ph\xE9p m\u1ECDi \xE1o ng\u0169 th\xE2n.",
      whatToWarnAbout: "Kh\xF4ng t\u1EF1 \u0111\u1ED9ng k\xEDch ho\u1EA1t n\u1EBFu kh\xF4ng c\xF3 ch\u1EE9ng minh ph\u1EA9m h\xE0m.",
      webBehavior: "Warning",
      sourceIds: ["S01"]
    },
    {
      id: "R020",
      baseGarment: "Sneaker",
      baseGarmentSlug: "sneaker",
      component: "\xC1o T\u1EE9 Th\xE2n / Ng\u0169 Th\xE2n",
      relationship: "MODERN_REMIX",
      periodContext: "Gen Z / \u0110\u01B0\u01A1ng \u0111\u1EA1i",
      evidence: "REMIX",
      confidence: "HIGH",
      whyEvidence: "Kh\xF4ng ph\u1EA3i ph\u1ED1i truy\u1EC1n th\u1ED1ng; \u0111\u01B0\u1EE3c ph\xE9p n\u1EBFu ng\u01B0\u1EDDi d\xF9ng ch\u1EE7 \xFD ch\u1ECDn phong c\xE1ch Remix.",
      whatToWarnAbout: "Tuy\u1EC7t \u0111\u1ED1i kh\xF4ng g\u1EAFn nh\xE3n authentic.",
      webBehavior: "Allow as Remix",
      sourceIds: ["S03"]
    },
    {
      id: "R021",
      baseGarment: "T\xFAi hi\u1EC7n \u0111\u1EA1i",
      baseGarmentSlug: "tui-hien-dai",
      component: "\xC1o T\u1EE9 Th\xE2n / Ng\u0169 Th\xE2n",
      relationship: "MODERN_REMIX",
      periodContext: "Gen Z / \u0110\u01B0\u01A1ng \u0111\u1EA1i",
      evidence: "REMIX",
      confidence: "HIGH",
      whyEvidence: "Ph\u1EE5 ki\u1EC7n hi\u1EC7n \u0111\u1EA1i; kh\xF4ng ph\u1EA3i historical pairing.",
      whatToWarnAbout: "C\u1EA7n gi\u1EEF identity core n\u1EBFu mu\u1ED1n nh\u1EADn x\xE9t t\u1ED1t.",
      webBehavior: "Allow as Remix",
      sourceIds: ["S03"]
    },
    {
      id: "R022",
      baseGarment: "Item sai th\u1EDDi k\u1EF3",
      baseGarmentSlug: "item-sai-thoi-ky",
      component: "B\u1EA5t k\u1EF3 outfit l\u1ECBch s\u1EED",
      relationship: "CULTURAL_MISMATCH",
      periodContext: "Kh\xE1c tri\u1EC1u \u0111\u1EA1i",
      evidence: "MISMATCH",
      confidence: "HIGH",
      whyEvidence: "V\xED d\u1EE5 d\xF9ng ph\u1EE5 ki\u1EC7n cung \u0111\xECnh Nguy\u1EC5n v\xE0o set L\xFD\u2013Tr\u1EA7n m\xE0 kh\xF4ng c\xF3 c\u01A1 s\u1EDF v\u0103n h\xF3a.",
      whatToWarnAbout: "Hi\u1EC3n th\u1ECB period mismatch r\xF5 r\xE0ng.",
      webBehavior: "Warn/Block",
      sourceIds: ["S01", "S02"]
    }
  ],
  ACCESSORIES: [
    {
      id: "A001",
      name: "V\xE2n Ki\xEAn",
      taxonomy: "Ph\u1EE5 ki\u1EC7n ph\u1EE5c s\u1EE9c / vai",
      status: "CORE CONDITIONAL",
      periodContext: "Nguy\u1EC5n / ph\u1EA9m ph\u1EE5c",
      userRole: "Quan l\u1EA1i / cung \u0111\xECnh t\xF9y b\u1ED9",
      compatibilityLogic: "Ch\u1EC9 cho ph\xE9p khi garment + rank + context kh\u1EDBp",
      evidence: "VERIFIED",
      source: "S01"
    },
    {
      id: "A002",
      name: "B\u1ED5 T\u1EED",
      taxonomy: "Component ph\u1EA9m ph\u1EE5c",
      status: "CORE CONDITIONAL",
      periodContext: "Nguy\u1EC5n",
      userRole: "Quan l\u1EA1i / c\u1EA5p b\u1EADc",
      compatibilityLogic: "Kh\xF4ng ph\u1EA3i accessory th\u1EDDi trang; ph\u1EA3i g\u1EAFn garment/ph\u1EA9m c\u1EA5p",
      evidence: "VERIFIED",
      source: "S01"
    },
    {
      id: "A003",
      name: "\u0110ai",
      taxonomy: "Ph\u1EE5 ki\u1EC7n eo / ph\u1EA9m ph\u1EE5c",
      status: "CORE",
      periodContext: "Nhi\u1EC1u th\u1EDDi k\u1EF3",
      userRole: "T\xF9y context",
      compatibilityLogic: "T\xE1ch \u0111ai cung \u0111\xECnh kh\u1ECFi th\u1EAFt l\u01B0ng d\xE2n gian",
      evidence: "VERIFIED",
      source: "S02"
    },
    {
      id: "A004",
      name: "Th\u1EAFt l\u01B0ng",
      taxonomy: "Ph\u1EE5 ki\u1EC7n eo",
      status: "CORE",
      periodContext: "D\xE2n gian",
      userRole: "T\xF9y context",
      compatibilityLogic: "Core trong T\u1EE9 th\xE2n",
      evidence: "VERIFIED",
      source: "S04"
    },
    {
      id: "A005",
      name: "D\xE2y Ru\u1ED9t T\u01B0\u1EE3ng",
      taxonomy: "Ph\u1EE5 ki\u1EC7n eo",
      status: "CORE CONDITIONAL",
      periodContext: "T\u1EE9 th\xE2n",
      userRole: "N\u1EEF",
      compatibilityLogic: "T\u1EE9 th\xE2n context",
      evidence: "CONSISTENT",
      source: "PDF"
    },
    {
      id: "A006",
      name: "Tr\xE2m",
      taxonomy: "Trang s\u1EE9c t\xF3c",
      status: "CORE",
      periodContext: "Nhi\u1EC1u th\u1EDDi k\u1EF3",
      userRole: "N\u1EEF",
      compatibilityLogic: "Ph\u1EA3i x\xE9t period/style/status",
      evidence: "CONSISTENT",
      source: "PDF"
    },
    {
      id: "A007",
      name: "H\u1ED1t",
      taxonomy: "Nghi l\u1EC5",
      status: "ADD",
      periodContext: "Nguy\u1EC5n",
      userRole: "Vua / quan",
      compatibilityLogic: "Ch\u1EC9 ceremonial set (R012)",
      evidence: "VERIFIED",
      source: "S02"
    },
    {
      id: "A008",
      name: "Hia",
      taxonomy: "Footwear nghi l\u1EC5",
      status: "ADD",
      periodContext: "Nguy\u1EC5n",
      userRole: "Vua / quan",
      compatibilityLogic: "Ceremonial set (R012)",
      evidence: "VERIFIED",
      source: "S02"
    },
    {
      id: "A009",
      name: "H\xE0i",
      taxonomy: "Footwear",
      status: "CORE",
      periodContext: "Nhi\u1EC1u th\u1EDDi k\u1EF3",
      userRole: "T\xF9y context",
      compatibilityLogic: "T\xE1ch subtype theo b\u1ED1i c\u1EA3nh",
      evidence: "CONSISTENT",
      source: "PDF"
    },
    {
      id: "A010",
      name: "Gu\u1ED1c M\u1ED9c",
      taxonomy: "Footwear d\xE2n gian",
      status: "CORE",
      periodContext: "D\xE2n gian",
      userRole: "T\xF9y context",
      compatibilityLogic: "Kh\xF4ng ph\u1EA3i universal historical footwear",
      evidence: "CONSISTENT",
      source: "PDF"
    },
    {
      id: "A011",
      name: "Qu\u1EA1t",
      taxonomy: "Handheld accessory",
      status: "CORE CONTEXTUAL",
      periodContext: "Nho s\u0129 / l\u1EC5 / d\xE2n gian t\xF9y lo\u1EA1i",
      userRole: "T\xF9y context",
      compatibilityLogic: "Kh\xF4ng ph\u1EA3i accessory b\u1EAFt bu\u1ED9c",
      evidence: "CONSISTENT",
      source: "PDF"
    },
    {
      id: "A012",
      name: "Th\u1EBB b\xE0i",
      taxonomy: "Ph\u1EE5c s\u1EE9c / insignia",
      status: "VERIFY",
      periodContext: "Nguy\u1EC5n / quan l\u1EA1i",
      userRole: "Quan l\u1EA1i",
      compatibilityLogic: "C\u1EA7n x\xE1c \u0111\u1ECBnh lo\u1EA1i th\u1EBB c\u1EE5 th\u1EC3 tr\u01B0\u1EDBc khi rule",
      evidence: "UNCERTAIN",
      source: "PDF"
    },
    {
      id: "A013",
      name: "Ng\u1ECDc \u0111ai",
      taxonomy: "Ph\u1EA9m ph\u1EE5c / \u0111ai",
      status: "CORE CONDITIONAL",
      periodContext: "Cung \u0111\xECnh",
      userRole: "Vua / quan",
      compatibilityLogic: "Rank / context required",
      evidence: "VERIFIED",
      source: "PDF; S02"
    }
  ],
  PDF_AUDIT: [
    {
      statement: "\xC1o T\u1EE9 Th\xE2n: g\u1ED3m 4 t\xE0...",
      assessment: "Gi\u1EEF",
      problem: "C\u1EA7n b\u1ED5 sung layer",
      correction: "Y\u1EBFm + v\xE1y + th\u1EAFt l\u01B0ng; context B\u1EAFc B\u1ED9",
      priority: "HIGH",
      source: "S04; S03"
    },
    {
      statement: "\xC1o T\u1EE9 Th\xE2n + Y\u1EBFm + M\u1EDB ba m\u1EDB b\u1EA3y",
      assessment: "Gi\u1EEF nh\u01B0ng kh\xF4ng tuy\u1EC7t \u0111\u1ED1i",
      problem: "M\u1EDB ba m\u1EDB b\u1EA3y l\xE0 c\xE1ch m\u1EB7c nhi\u1EC1u l\u1EDBp, kh\xF4ng ph\u1EA3i m\u1ED9t item \u0111\u01A1n",
      correction: "Model th\xE0nh layering concept",
      priority: "HIGH",
      source: "PDF; S04"
    },
    {
      statement: "\xC1o T\u1EA5c: \u1ED1ng tay r\u1ED9ng, d\xE0i qua kh\u1ECFi tay \xE1o",
      assessment: "S\u1EEDa c\xE2u",
      problem: "Di\u1EC5n \u0111\u1EA1t l\u1ED7i / kh\xF3 hi\u1EC3u",
      correction: "\u0110\u1ED5i th\xE0nh 'tay \xE1o r\u1ED9ng, d\xE0i; th\u01B0\u1EDDng g\u1EAFn l\u1EC5 ph\u1EE5c trong context c\u1EE5 th\u1EC3'",
      priority: "HIGH",
      source: "PDF; S01"
    },
    {
      statement: "Giao L\u0129nh ph\u1ED5 bi\u1EBFn t\u1EEB L\xFD, Tr\u1EA7n, L\xEA cho nhi\u1EC1u t\u1EA7ng l\u1EDBp",
      assessment: "S\u1EEDa",
      problem: "Qu\xE1 r\u1ED9ng n\u1EBFu kh\xF4ng g\u1EAFn context",
      correction: "G\u1EAFn period/context; tr\xE1nh universal claim",
      priority: "HIGH",
      source: "S07"
    },
    {
      statement: "\u0110\u1ED1i Kh\xE2m... kh\xF4ng c\xE0i c\xFAc",
      assessment: "S\u1EEDa",
      problem: "Kh\u1EB3ng \u0111\u1ECBnh qu\xE1 tuy\u1EC7t \u0111\u1ED1i",
      correction: "Kh\xF4ng d\xF9ng c\xE2u n\xE0y; m\xF4 t\u1EA3 form + c\xE1ch m\u1EB7c theo ngu\u1ED3n c\u1EE5 th\u1EC3",
      priority: "HIGH",
      source: "S07"
    },
    {
      statement: "T\u1EE9 \u0110i\xEAn... c\xE1c d\u1EA3i t\xE0 (\u0111i\xEAn/\u0111i\u1EC1n)",
      assessment: "S\u1EEDa / c\u1EA3nh b\xE1o",
      problem: "C\u1EA5u tr\xFAc ph\u1EE5c d\u1EF1ng c\xF3 tranh lu\u1EADn",
      correction: "Ghi reconstruction / debated",
      priority: "HIGH",
      source: "S08"
    },
    {
      statement: "Nh\u1EADt B\xECnh: th\u01B0\u1EDDng ph\u1EE5c c\u1EE7a H\u1EADu phi",
      assessment: "S\u1EEDa",
      problem: "Qu\xE1 h\u1EB9p v\xE0 d\u1EC5 sai context",
      correction: "Ghi h\u1EC7 ph\u1EE5c trang cung \u0111\xECnh n\u1EEF, \u0111\u1ED1i t\u01B0\u1EE3ng/ph\u1EA9m c\u1EA5p/nghi l\u1EC5 theo quy ch\u1EBF",
      priority: "HIGH",
      source: "S01; S02"
    },
    {
      statement: "Long b\xE0o 5 m\xF3ng = vua; M\xE3ng b\xE0o 4 m\xF3ng = v\u01B0\u01A1ng t\xF4n, quan l\u1EA1i",
      assessment: "S\u1EEDa m\u1EA1nh",
      problem: "\u0110\u01A1n gi\u1EA3n h\xF3a quy ch\u1EBF ph\u1EA9m c\u1EA5p",
      correction: "T\xE1ch Long b\xE0o / Ho\xE0ng b\xE0o / M\xE3ng b\xE0o / M\xE3ng lan v\xE0 ghi \u0111\u1ED1i t\u01B0\u1EE3ng/context",
      priority: "HIGH",
      source: "S02"
    },
    {
      statement: "M\u1EC7nh ph\u1EE5 = l\u1EC5 ph\u1EE5c c\u1EE7a phu nh\xE2n, n\u1EEF quan",
      assessment: "S\u1EEDa taxonomy",
      problem: "M\u1EC7nh ph\u1EE5 l\xE0 \u0111\u1ECBa v\u1ECB/h\u1EC7 ph\u1EE5c trang, kh\xF4ng ph\u1EA3i m\u1ED9t form \xE1o duy nh\u1EA5t",
      correction: "T\xE1ch status kh\u1ECFi garment",
      priority: "HIGH",
      source: "S01; S02"
    },
    {
      statement: "N\xF3n Ba T\u1EA7m / Th\xFAng",
      assessment: "T\xE1ch",
      problem: "\u0110ang g\u1ED9p hai t\xEAn/kh\xE1i ni\u1EC7m",
      correction: "T\xE1ch Ba T\u1EA7m, n\xF3n th\xFAng/quai thao; ghi contested terminology",
      priority: "HIGH",
      source: "S06; S09"
    },
    {
      statement: "Kh\u0103n R\u1EB1n n\u1EB1m d\u01B0\u1EDBi H\u1EC7 N\xF3n Che",
      assessment: "Sai taxonomy",
      problem: "Kh\u0103n kh\xF4ng ph\u1EA3i n\xF3n",
      correction: "Chuy\u1EC3n sang Kh\u0103n / v\xF9ng mi\u1EC1n",
      priority: "HIGH",
      source: "PDF"
    },
    {
      statement: "V\xE2n Ki\xEAn & Tr\xE2m d\u01B0\u1EDBi Trang s\u1EE9c",
      assessment: "S\u1EEDa taxonomy",
      problem: "V\xE2n ki\xEAn l\xE0 chi ti\u1EBFt/ph\u1EE5 ki\u1EC7n ph\u1EE5c s\u1EE9c g\u1EAFn b\u1ED9 \xE1o c\u1EE5 th\u1EC3",
      correction: "T\xE1ch V\xE2n Ki\xEAn kh\u1ECFi trang s\u1EE9c t\u1EF1 do",
      priority: "HIGH",
      source: "S01"
    },
    {
      statement: "\xC1o Ch\xE0m = \u0111\u1EB7c tr\u01B0ng v\xF9ng n\xFAi ph\xEDa B\u1EAFc",
      assessment: "Qu\xE1 r\u1ED9ng",
      problem: "C\xF3 th\u1EC3 tr\u1ED9n nhi\u1EC1u nh\xF3m/v\xF9ng",
      correction: "T\u1EA1m \u0111\u01B0a kh\u1ECFi core Kinh ph\u1EE5c",
      priority: "MEDIUM",
      source: "PDF"
    },
    {
      statement: "Kh\u1ED1 t\u1EEB \u0110\xF4ng S\u01A1n",
      assessment: "C\u1EA7n ngu\u1ED3n s\xE2u h\u01A1n",
      problem: "Claim period-specific",
      correction: "Gi\u1EEF nh\u01B0ng kh\xF4ng hard-code m\u1ED9t form/period n\u1EBFu ch\u01B0a c\xF3 ngu\u1ED3n chuy\xEAn s\xE2u",
      priority: "MEDIUM",
      source: "PDF; c\u1EA7n source chuy\xEAn kh\u1EA3o"
    }
  ],
  SOURCES: [
    {
      id: "S01",
      title: "Y ph\u1EE5c th\u1EDDi Nguy\u1EC5n t\u1EA1i B\u1EA3o t\xE0ng L\u1ECBch s\u1EED qu\u1ED1c gia",
      institution: "B\u1EA3o t\xE0ng L\u1ECBch s\u1EED Qu\u1ED1c gia",
      type: "Museum / primary collection description",
      usedFor: "Nguy\u1EC5n: \xE1o t\u1EA5c, b\u1ED5 ph\u1EE5c, v\xE2n ki\xEAn, nh\u1EADt b\xECnh, m\xE3ng b\xE0o...",
      url: "https://baotanglichsuquocgia.vn/vi/Articles/3096/18741/y-phuc-thoi-nguyen-tai-bao-tang-lich-su-quoc-gia.html"
    },
    {
      id: "S02",
      title: "Trang ph\u1EE5c cung \u0111\xECnh tri\u1EC1u Nguy\u1EC5n",
      institution: "B\u1EA3o t\xE0ng L\u1ECBch s\u1EED Qu\u1ED1c gia",
      type: "Museum / historical overview",
      usedFor: "Ph\xE2n lo\u1EA1i \u0111\u1EA1i tri\u1EC1u/th\u01B0\u1EDDng tri\u1EC1u/nghi l\u1EC5; long b\xE0o, ho\xE0ng b\xE0o, c\u1ED5n, m\xE3ng b\xE0o, m\xE3ng lan; m\u0169/\u0111ai/h\u1ED1t/hia",
      url: "https://baotanglichsu.vn/vi/Articles/3096/18303/trang-phuc-cung-djinh-trieu-nguyen.html"
    },
    {
      id: "S03",
      title: "\xC1o d\xE0i x\u01B0a v\xE0 nay",
      institution: "B\u1EA3o t\xE0ng Ph\u1EE5 n\u1EEF Nam B\u1ED9",
      type: "Museum collection/interpretation",
      usedFor: "T\u1EE9 th\xE2n + v\xE1y + kh\u0103n + n\xF3n; ng\u0169 th\xE2n ch\u1EBDn/th\u1EE5ng",
      url: "https://baotangphunu.com/ao-dai-xua-va-nay/"
    },
    {
      id: "S04",
      title: "\xC1o d\xE0i ng\u0169 th\xE2n \u2013 H\xE0nh tr\xECnh tr\u1EDF l\u1EA1i",
      institution: "B\u1EA3o t\xE0ng Ph\u1EE5 n\u1EEF Nam B\u1ED9",
      type: "Museum educational article",
      usedFor: "Ng\u0169 th\xE2n: 5 th\xE2n, \xE1o l\xF3t, qu\u1EA7n \u1ED1ng r\u1ED9ng s\xE1ng m\xE0u; context l\u1ECBch s\u1EED",
      url: "https://baotangphunu.com/4266-2/"
    },
    {
      id: "S05",
      title: "L\u1EC5 trao t\u1EB7ng \xE1o d\xE0i ng\u0169 th\xE2n truy\u1EC1n th\u1ED1ng",
      institution: "B\u1EA3o t\xE0ng Ph\u1EE5 n\u1EEF Nam B\u1ED9",
      type: "Museum artifact/event",
      usedFor: "B\u1ED9 nam g\u1ED3m m\u1EA5n + \xE1o ngo\xE0i + \xE1o l\xF3t + qu\u1EA7n; m\xF4 t\u1EA3 c\u1EA5u tr\xFAc v\xE0 ph\u1ED1i qu\u1EA7n \u1ED1ng r\u1ED9ng s\xE1ng m\xE0u",
      url: "https://baotangphunu.com/en/le-trao-tang-ao-dai-ngu-than-truyen-thong-nhan-ngay-di-san-van-hoa-23-thang-11-2/"
    },
    {
      id: "S06",
      title: "N\xF3n quai thao v\xE0 n\xF3n ba t\u1EA7m",
      institution: "B\xE1o \u0110\xE0 N\u1EB5ng / d\u1EABn t\u01B0 li\u1EC7u Henri Oger",
      type: "Press / historical discussion",
      usedFor: "Ph\xE2n bi\u1EC7t thu\u1EADt ng\u1EEF Ba T\u1EA7m, n\xF3n th\xFAng, quai thao; ghi nh\u1EADn tranh lu\u1EADn kh\xF4ng \u0111\u1ED3ng nh\u1EA5t",
      url: "https://baodanang.vn/non-quai-thao-va-non-ba-tam-3232912.html"
    },
    {
      id: "S07",
      title: "Vi\u1EC7t Ph\u1EE5c Thanh Phong \u2013 c\xE1c d\u1EA1ng th\u1EE9c",
      institution: "Vi\u1EC7t Ph\u1EE5c Thanh Phong",
      type: "Reconstruction/reference source",
      usedFor: "Giao l\u0129nh, Vi\xEAn l\u0129nh, \u0110\u1ED1i kh\xE2m, B\xE1n t\xED; h\u1EC7 Tr\u1EF1c l\u0129nh theo c\xE1ch ph\xE2n lo\u1EA1i c\u1EE7a ngu\u1ED3n",
      url: "https://www.vietphucthanhphong.com/about-as"
    },
    {
      id: "S08",
      title: "Nh\u1EEFng S\u1EF1 Th\u1EADt Th\xFA V\u1ECB V\u1EC1 Vi\u1EC7t Ph\u1EE5c \xC1o T\u1EE9 \u0110i\xEAn",
      institution: "BBCosplay / ngu\u1ED3n d\u1EABn Ng\xE0n N\u0103m \xC1o M\u0169",
      type: "Reconstruction/reference source",
      usedFor: "V\u0103n li\u1EC7u L\xFD\u2013Tr\u1EA7n v\u1EC1 T\u1EE9 \u0110i\xEAn; ngu\u1ED3n ph\u1EE5c d\u1EF1ng c\xF3 tranh lu\u1EADn, kh\xF4ng ph\u1EA3i hi\u1EC7n v\u1EADt tr\u1EF1c ti\u1EBFp",
      url: "https://bbcosplay.com/news/nhung-su-that-thu-vi-ve-viet-phuc-ao-tu-dien-3711"
    },
    {
      id: "S09",
      title: "T\xECm l\u1EA1i chi\u1EBFc n\xF3n ba t\u1EA7m",
      institution: "Th\u1EC3 thao & V\u0103n h\xF3a",
      type: "Historical press/research discussion",
      usedFor: "Ph\xE2n bi\u1EC7t n\xF3n ba t\u1EA7m, n\xF3n th\xFAng, quai thao trong d\xE2n gian",
      url: "https://thethaovanhoa.vn/tim-lai-chiec-non-ba-tam-20160714143053108.htm"
    },
    {
      id: "S10",
      title: "Kh\xFAc bi\u1EBFn t\u1EA5u c\u1EE7a chi\u1EBFc \xE1o d\xE0i truy\u1EC1n th\u1ED1ng",
      institution: "B\u1EA3o t\xE0ng Ph\u1EE5 n\u1EEF Nam B\u1ED9",
      type: "Museum educational article",
      usedFor: "Ti\u1EBFn tr\xECnh \xE1o d\xE0i TK20, Le Mur, thay \u0111\u1ED5i qu\u1EA7n/v\xE1y v\xE0 phom d\xE1ng",
      url: "https://baotangphunu.com/khuc-bien-tau-cua-chiec-ao-dai-truyen-thong/"
    }
  ],
  DATA_MODEL: {
    Garment: ["id", "name", "aliases", "category", "period", "region", "audience", "context", "construction", "evidence_level"],
    Compatibility: ["item_a", "item_b", "relation", "period_constraint", "context_constraint", "confidence", "reason", "source_ids"],
    Remix: ["modernization", "identity_preserved"],
    Warning: ["type", "message"]
  },
  RESEARCH_QUEUE: [
    {
      priority: "P0",
      topic: "Tr\u1EF1c l\u0129nh / Giao l\u0129nh / \u0110\u1ED1i kh\xE2m / C\u1ED5 th\xECa taxonomy",
      whyUnresolved: "C\xE1c ngu\u1ED3n ph\u1EE5c d\u1EF1ng s\u1EED d\u1EE5ng h\u1EC7 ph\xE2n lo\u1EA1i v\xE0 thu\u1EADt ng\u1EEF kh\xE1c nhau",
      whatToVerify: "Th\u01B0 t\u1ECBch g\u1ED1c, hi\u1EC7n v\u1EADt b\u1EA3o t\xE0ng, kh\u1EA3o c\u1EE9u h\u1ECDc thu\u1EADt",
      preferredSource: "BTLSQG + nghi\xEAn c\u1EE9u h\u1ECDc thu\u1EADt + Ng\xE0n N\u0103m \xC1o M\u0169",
      currentDecision: "Kh\xF4ng hard-code h\u1EC7 ph\xE2n lo\u1EA1i th\xE0nh ch\xE2n l\xFD tuy\u1EC7t \u0111\u1ED1i"
    },
    {
      priority: "P0",
      topic: "T\u1EE9 \u0110i\xEAn",
      whyUnresolved: "Ph\u1EE5c d\u1EF1ng d\u1EF1a tr\xEAn m\xF4 t\u1EA3 v\u0103n li\u1EC7u ng\u1EAFn, ch\u01B0a c\xF3 hi\u1EC7n v\u1EADt",
      whatToVerify: "Ch\u1EEF H\xE1n nguy\xEAn v\u0103n + kh\u1EA3o c\u1ED5 h\u1ECDc + tranh kh\u1EAFc",
      preferredSource: "T\u01B0 li\u1EC7u h\u1ECDc thu\u1EADt / b\u1EA3o t\xE0ng / Tr\u1EA7n Quang \u0110\u1EE9c d\u1EABn",
      currentDecision: "Gi\u1EEF nh\u01B0 m\u1ED9t ph\u1EE5c d\u1EF1ng c\xF2n tranh lu\u1EADn (reconstruction / debated)"
    },
    {
      priority: "P0",
      topic: "Nh\u1EADt B\xECnh",
      whyUnresolved: "B\u1ED1i c\u1EA3nh v\xE0 ph\u1EA9m c\u1EA5p ph\u1EE9c t\u1EA1p, d\u1EC5 b\u1ECB gi\u1EA3n l\u01B0\u1EE3c th\xE0nh th\u01B0\u1EDDng ph\u1EE5c",
      whatToVerify: "Kh\xE2m \u0111\u1ECBnh \u0110\u1EA1i Nam h\u1ED9i \u0111i\u1EC3n s\u1EF1 l\u1EC7 + hi\u1EC7n v\u1EADt BTLSQG",
      preferredSource: "BTLSQG / T\u01B0 li\u1EC7u c\u1ED1 \u0111\xF4 Hu\u1EBF",
      currentDecision: "Xem nh\u01B0 l\u1EC5 ph\u1EE5c cung \u0111\xECnh c\xF3 \u0111i\u1EC1u ki\u1EC7n ph\u1EA9m c\u1EA5p/nghi l\u1EC5"
    },
    {
      priority: "P0",
      topic: "M\u1EC7nh ph\u1EE5",
      whyUnresolved: "Th\u1EF1c th\u1EC3 l\xE0 \u0111\u1ECBa v\u1ECB danh x\u01B0ng ch\u1EE9 kh\xF4ng ph\u1EA3i m\u1ED9t ki\u1EC3u \xE1o duy nh\u1EA5t",
      whatToVerify: "Kh\xE2m \u0111\u1ECBnh \u0110\u1EA1i Nam h\u1ED9i \u0111i\u1EC3n s\u1EF1 l\u1EC7",
      preferredSource: "Kh\xE2m \u0111\u1ECBnh + BTLSQG",
      currentDecision: "T\xE1ch \u0111\u1ECBa v\u1ECB (status) ra kh\u1ECFi th\u1EF1c th\u1EC3 \xE1o (garment)"
    },
    {
      priority: "P0",
      topic: "Ba T\u1EA7m / Th\xFAng / Quai thao",
      whyUnresolved: "Thu\u1EADt ng\u1EEF d\xE2n gian v\xE0 tranh lu\u1EADn b\xE1o ch\xED c\xF2n m\xE2u thu\u1EABn",
      whatToVerify: "T\u1EEB \u0111i\u1EC3n l\u1ECBch s\u1EED, Henri Oger, b\u1EA3o t\xE0ng \u0111\u1ECBa ph\u01B0\u01A1ng",
      preferredSource: "T\u01B0 li\u1EC7u l\u1ECBch s\u1EED / b\u1EA3o t\xE0ng",
      currentDecision: "T\xE1ch ri\xEAng v\xE0 g\u1EAFn ghi ch\xFA thu\u1EADt ng\u1EEF tranh lu\u1EADn"
    },
    {
      priority: "P1",
      topic: "Kh\u0103n M\u1ECF Qu\u1EA1",
      whyUnresolved: "C\u1EA7n th\xEAm b\u1EB1ng ch\u1EE9ng b\u1EA3o t\xE0ng tr\u1EF1c ti\u1EBFp trong t\u1EADp ngu\u1ED3n",
      whatToVerify: "Hi\u1EC7n v\u1EADt v\xE0 \u1EA3nh t\u01B0 li\u1EC7u l\u1ECBch s\u1EED",
      preferredSource: "B\u1ED9 s\u01B0u t\u1EADp b\u1EA3o t\xE0ng",
      currentDecision: "G\u1EAFn nh\xE3n contextual, kh\xF4ng \xE1p \u0111\u1EB7t ph\u1ED5 qu\xE1t"
    },
    {
      priority: "P1",
      topic: "\xC1o Ch\xE0m",
      whyUnresolved: "Nguy c\u01A1 tr\u1ED9n l\u1EABn scope v\u0103n h\xF3a Kinh ph\u1EE5c",
      whatToVerify: "X\xE1c \u0111\u1ECBnh r\xF5 ph\u1EA1m vi d\xE2n t\u1ED9c h\u1ECDc",
      preferredSource: "B\u1EA3o t\xE0ng D\xE2n t\u1ED9c h\u1ECDc",
      currentDecision: "T\u1EA1m \u0111\u01B0a ra kh\u1ECFi core Kinh ph\u1EE5c"
    },
    {
      priority: "P1",
      topic: "Kh\u1ED1 / \u0110\xF4ng S\u01A1n",
      whyUnresolved: "C\u1EA7n b\u1EB1ng ch\u1EE9ng kh\u1EA3o c\u1ED5 theo t\u1EEBng th\u1EDDi k\u1EF3 c\u1EE5 th\u1EC3",
      whatToVerify: "Hi\u1EC7n v\u1EADt d\u1EC7t v\xE0 t\u01B0\u1EE3ng kh\u1EA3o c\u1ED5 \u0110\xF4ng S\u01A1n",
      preferredSource: "Vi\u1EC7n Kh\u1EA3o c\u1ED5 h\u1ECDc",
      currentDecision: "Kh\xF4ng hard-code m\u1ED9t m\u1EABu ph\u1EE5c d\u1EF1ng hi\u1EC7n \u0111\u1EA1i"
    },
    {
      priority: "P1",
      topic: "\xC1o Thanh Xuy\u1EBFn",
      whyUnresolved: "Ch\u01B0a \u0111\u1EE7 ch\u1EE9ng c\u1EE9 l\u1ECBch s\u1EED x\xE1c th\u1EF1c trong t\u01B0 li\u1EC7u hi\u1EC7n t\u1EA1i",
      whatToVerify: "Thu\u1EADt ng\u1EEF g\u1ED1c v\xE0 b\u1ED1i c\u1EA3nh s\u1EED d\u1EE5ng",
      preferredSource: "Th\u01B0 t\u1ECBch c\u1ED5",
      currentDecision: "T\u1EA1m \u0111\u1EC3 ngo\xE0i core cho t\u1EDBi khi \u0111\u01B0\u1EE3c x\xE1c minh"
    },
    {
      priority: "P1",
      topic: "Ph\u01B0\u1EE3ng ph\u1EE5c terminology",
      whyUnresolved: "D\u1EC5 nh\u1EA7m l\u1EABn gi\u1EEFa hoa v\u0103n (motif) v\xE0 t\xEAn g\u1ECDi \xE1o ch\xEDnh th\u1EE9c",
      whatToVerify: "Quy ch\u1EBF \u0111i\u1EC3n ch\u01B0\u01A1ng th\u1EDDi Nguy\u1EC5n",
      preferredSource: "Kh\xE2m \u0111\u1ECBnh + BTLSQG",
      currentDecision: "D\xF9ng t\xEAn g\u1ECDi th\u1EADn tr\u1ECDng k\xE8m ghi ch\xFA"
    }
  ]
};

// src/data/canonicalAssetRegistry.ts
var CANONICAL_ASSET_REGISTRY_V3 = {
  // 1. Áo Giao Lĩnh (Đúng phom dáng cổ chéo)
  G001: {
    canonicalId: "G001",
    asset: "tu_ao_ao_giao_linh_1791540421433.jpg",
    src: "/src/assets/images/tu_ao_ao_giao_linh_1791540421433.jpg",
    assetStatus: "PH\u1EE4C D\u1EF0NG",
    sourceInstitution: "Studio T\xE0ng Y C\xE1c & T\u01B0 li\u1EC7u \u0111\u1ED1i chi\u1EBFu c\u1ED5 ph\u1EE5c",
    license: "Editorial Archive License",
    verificationNote: "\u1EA2nh ph\u1EE5c d\u1EF1ng chu\u1EA9n th\u1EE9c phom d\xE1ng c\u1ED5 ch\xE9o giao l\u0129nh; \u0111\u1ED1i chi\u1EBFu t\u01B0 li\u1EC7u hi\u1EC7n v\u1EADt th\u1EDDi L\xFD-Tr\u1EA7n-L\xEA."
  },
  // Áo Trực Lĩnh (Cổ đứng song song vạt dọc)
  G002: {
    canonicalId: "G002",
    asset: "tu_ao_truc_linh_1791590575147.jpg",
    src: "/src/assets/images/tu_ao_truc_linh_1791590575147.jpg",
    assetStatus: "PH\u1EE4C D\u1EF0NG",
    sourceInstitution: "L\u01B0u tr\u1EEF kh\u1EA3o c\u1EE9u T\xE0ng Y & Hi\u1EC7n v\u1EADt L\xEA Trung H\u01B0ng",
    license: "Editorial Archive License",
    verificationNote: "\u1EA2nh ph\u1EE5c d\u1EF1ng chu\u1EA9n th\u1EE9c \xE1o Tr\u1EF1c L\u0129nh v\u1EDBi n\u1EB9p c\u1ED5 th\u1EB3ng \u0111\u1EE9ng song song ch\u1EA1y d\xE0i tr\u01B0\u1EDBc ng\u1EF1c, l\u1EE5a lam v\xE2n m\xE2y."
  },
  // Áo Đối Khâm (Hai vạt song song đối xứng)
  G003: {
    canonicalId: "G003",
    asset: "tu_ao_doi_kham_1791590587462.jpg",
    src: "/src/assets/images/tu_ao_doi_kham_1791590587462.jpg",
    assetStatus: "PH\u1EE4C D\u1EF0NG",
    sourceInstitution: "L\u01B0u tr\u1EEF kh\u1EA3o c\u1EE9u T\xE0ng Y & \u0110\u1ED1i chi\u1EBFu hi\u1EC7n v\u1EADt tri\u1EC1u Nguy\u1EC5n/L\xEA",
    license: "Editorial Archive License",
    verificationNote: "\u1EA2nh ph\u1EE5c d\u1EF1ng chu\u1EA9n \xE1o \u0110\u1ED1i Kh\xE2m kho\xE1c ngo\xE0i, hai v\u1EA1t song song bu\xF4ng th\u1EB3ng \u0111\u1ED1i x\u1EE9ng, tay th\u1EE5ng g\u1EA5m hoa."
  },
  // Áo Viên Lĩnh (Cổ tròn khép kín nẹp vai hữu)
  G006: {
    canonicalId: "G006",
    asset: "tu_ao_vien_linh_1791590597639.jpg",
    src: "/src/assets/images/tu_ao_vien_linh_1791590597639.jpg",
    assetStatus: "PH\u1EE4C D\u1EF0NG",
    sourceInstitution: "Vi\u1EC7n Nghi\xEAn c\u1EE9u C\u1ED5 ph\u1EE5c & Kh\u1EA3o c\u1EE9u th\u1EDDi L\xFD-Tr\u1EA7n-L\xEA",
    license: "Editorial Archive License",
    verificationNote: "\u1EA2nh ph\u1EE5c d\u1EF1ng phom \xE1o Vi\xEAn L\u0129nh c\u1ED5 tr\xF2n kh\xE9p k\xEDn, c\xFAc c\xE0i b\xEAn vai h\u1EEFu, s\u1EAFc v\xE0ng ho\xE0ng l\u1EA1p d\u1EC7t m\xE2y."
  },
  // 2. Áo Ngũ Thân tay chẽn (Đúng phom lập lĩnh năm thân)
  G008: {
    canonicalId: "G008",
    asset: "tu_ao_ao_ngu_than_1791540362301.jpg",
    src: "/src/assets/images/tu_ao_ao_ngu_than_1791540362301.jpg",
    assetStatus: "PH\u1EE4C D\u1EF0NG",
    sourceInstitution: "B\u1EA3o t\xE0ng Ph\u1EE5 n\u1EEF Nam B\u1ED9 & Nh\xF3m nghi\xEAn c\u1EE9u c\u1ED5 ph\u1EE5c",
    license: "Editorial Archive License",
    verificationNote: "\u1EA2nh ph\u1EE5c d\u1EF1ng chu\u1EA9n th\u1EE9c phom \xE1o ng\u0169 th\xE2n l\u1EADp l\u0129nh tay ch\u1EBDn, ng\u0169 khuy n\u1EB9p h\u1EEFu v\xE0 qu\u1EA7n tr\u1EAFng."
  },
  // Áo Tấc (Ngũ thân tay thụng đại lễ)
  G009: {
    canonicalId: "G009",
    asset: "tu_ao_ao_tac_1791590607100.jpg",
    src: "/src/assets/images/tu_ao_ao_tac_1791590607100.jpg",
    assetStatus: "PH\u1EE4C D\u1EF0NG",
    sourceInstitution: "Trung t\xE2m B\u1EA3o t\u1ED3n Di t\xEDch C\u1ED1 \u0111\xF4 Hu\u1EBF & Studio T\xE0ng Y",
    license: "Editorial Archive License",
    verificationNote: "\u1EA2nh ph\u1EE5c d\u1EF1ng chu\u1EA9n th\u1EE9c phom \xE1o T\u1EA5c l\u1EADp l\u0129nh ng\u0169 th\xE2n v\u1EDBi tay \xE1o th\u1EE5ng d\xE0i r\u1ED9ng m\u1ED9t t\u1EA5c \u0111oan trang."
  },
  // 3. Áo Tứ Thân (Đúng phom bốn vạt dân gian Bắc Bộ)
  G010: {
    canonicalId: "G010",
    asset: "tu_ao_ao_tu_than_1791540316824.jpg",
    src: "/src/assets/images/tu_ao_ao_tu_than_1791540316824.jpg",
    assetStatus: "PH\u1EE4C D\u1EF0NG",
    sourceInstitution: "B\u1EA3o t\xE0ng D\xE2n t\u1ED9c h\u1ECDc & T\u01B0 li\u1EC7u v\u0103n h\xF3a B\u1EAFc B\u1ED9",
    license: "Editorial Archive License",
    verificationNote: "\u1EA2nh ph\u1EE5c d\u1EF1ng y ph\u1EE5c T\u1EE9 Th\xE2n n\u1EEF d\xE2n gian \u0111\u1ED3ng b\u1EB1ng B\u1EAFc B\u1ED9 k\xE8m y\u1EBFm \u0111\xE0o, d\u1EA3i bao xanh v\xE0 v\xE1y \u0111\u1EE5p \u0111en."
  },
  // Yếm (Yếm đào lụa tơ tằm cổ truyền)
  G011: {
    canonicalId: "G011",
    asset: "tu_ao_yem_dao_1791590619474.jpg",
    src: "/src/assets/images/tu_ao_yem_dao_1791590619474.jpg",
    assetStatus: "PH\u1EE4C D\u1EF0NG",
    sourceInstitution: "B\u1EA3o t\xE0ng Ph\u1EE5 n\u1EEF Vi\u1EC7t Nam & T\xE0ng Y C\xE1c",
    license: "Editorial Archive License",
    verificationNote: "\u1EA2nh ph\u1EE5c d\u1EF1ng chu\u1EA9n th\u1EE9c y\u1EBFm \u0111\xE0o h\xECnh thoi l\u1EE5a t\u01A1 t\u1EB1m truy\u1EC1n th\u1ED1ng v\u1EDBi d\xE2y bu\u1ED9c c\u1ED5 v\xE0 l\u01B0ng tinh t\u1EBF."
  },
  // Váy (Váy đụp đen dân gian Bắc Bộ)
  G012: {
    canonicalId: "G012",
    asset: "tu_ao_vay_dup_1791591661475.jpg",
    src: "/src/assets/images/tu_ao_vay_dup_1791591661475.jpg",
    assetStatus: "PH\u1EE4C D\u1EF0NG",
    sourceInstitution: "B\u1EA3o t\xE0ng D\xE2n t\u1ED9c h\u1ECDc Vi\u1EC7t Nam & T\xE0ng Y C\xE1c",
    license: "Editorial Archive License",
    verificationNote: "\u1EA2nh ph\u1EE5c d\u1EF1ng chu\u1EA9n th\u1EE9c v\xE1y \u0111\u1EE5p \u0111en l\u1EE5a t\u01A1 t\u1EB1m bu\xF4ng r\u1EE7 x\u1EBFp n\u1EBFp, trang ph\u1EE5c th\xE2n d\u01B0\u1EDBi truy\u1EC1n th\u1ED1ng ph\u1EE5 n\u1EEF B\u1EAFc B\u1ED9."
  },
  // Quần ống rộng sáng màu (Quần trắng sa lụa truyền thống)
  G013: {
    canonicalId: "G013",
    asset: "tu_ao_quan_trang_1791591672868.jpg",
    src: "/src/assets/images/tu_ao_quan_trang_1791591672868.jpg",
    assetStatus: "PH\u1EE4C D\u1EF0NG",
    sourceInstitution: "Studio C\u1ED5 ph\u1EE5c T\xE0ng Y & Trung t\xE2m Nghi\xEAn c\u1EE9u C\u1ED5 ph\u1EE5c",
    license: "Editorial Archive License",
    verificationNote: "\u1EA2nh ph\u1EE5c d\u1EF1ng chu\u1EA9n th\u1EE9c qu\u1EA7n l\u1EE5a tr\u1EAFng \u1ED1ng r\u1ED9ng d\u1EA3i r\xFAt, ph\u1ED1i c\xF9ng \xE1o Ng\u0169 Th\xE2n v\xE0 \xC1o D\xE0i qua c\xE1c th\u1EDDi k\u1EF3."
  },
  // Áo Bổ Phục (Quan phục triều Nguyễn có gắn bổ tử)
  G016: {
    canonicalId: "G016",
    asset: "tu_ao_bo_phuc_1791591685057.jpg",
    src: "/src/assets/images/tu_ao_bo_phuc_1791591685057.jpg",
    assetStatus: "PH\u1EE4C D\u1EF0NG",
    sourceInstitution: "Trung t\xE2m B\u1EA3o t\u1ED3n Di t\xEDch C\u1ED1 \u0111\xF4 Hu\u1EBF & T\xE0ng Y C\xE1c",
    license: "Editorial Archive License",
    verificationNote: "\u1EA2nh ph\u1EE5c d\u1EF1ng chu\u1EA9n th\u1EE9c \xE1o B\u1ED5 Ph\u1EE5c s\u1EAFc ch\xE0m th\u1EABm \u0111\xEDnh b\u1ED5 t\u1EED th\xEAu ph\xF9 hi\u1EC7u ph\u1EA9m h\xE0m quan vi\xEAn tri\u1EC1u Nguy\u1EC5n."
  },
  // Bổ Tử (Phù hiệu phẩm hàm quan văn / quan võ)
  G017: {
    canonicalId: "G017",
    asset: "tu_ao_bo_tu_1791592305808.jpg",
    src: "/src/assets/images/tu_ao_bo_tu_1791592305808.jpg",
    assetStatus: "T\u01AF LI\u1EC6U",
    sourceInstitution: "B\u1EA3o t\xE0ng C\u1ED5 v\u1EADt Cung \u0111\xECnh Hu\u1EBF",
    license: "Museum Artifact Archive",
    verificationNote: "B\u1ED5 t\u1EED ph\u1EA9m h\xE0m quan v\u0103n th\xEAu h\xECnh B\u1EA1ch H\u1EA1c ng\u1EADm linh chi \u0111\u1EA1p s\xF3ng m\xE2y ng\u0169 s\u1EAFc vi\u1EC1n h\u1ED3i v\u0103n s\u1EAFc s\u1EA3o."
  },
  // 4. Áo Nhật Bình (Đúng cổ đối khâm chữ nhật cung đình)
  G018: {
    canonicalId: "G018",
    asset: "tu_ao_ao_nhat_binh_1791540457083.jpg",
    src: "/src/assets/images/tu_ao_ao_nhat_binh_1791540457083.jpg",
    assetStatus: "PH\u1EE4C D\u1EF0NG",
    sourceInstitution: "Trung t\xE2m B\u1EA3o t\u1ED3n Di t\xEDch C\u1ED1 \u0111\xF4 Hu\u1EBF",
    license: "Editorial Archive License",
    verificationNote: "C\u1ED5 \xE1o h\xECnh ch\u1EEF nh\u1EADt \u0111\u1ED1i kh\xE2m, vi\u1EC1n ng\u0169 s\u1EAFc c\u1EEDa tay \u0111\u1EB7c tr\u01B0ng c\u1EE7a b\u1EADc H\u1EADu phi, C\xF4ng ch\xFAa v\xE0 M\u1EC7nh ph\u1EE5 tri\u1EC1u Nguy\u1EC5n."
  },
  // Áo Mãng Bào (Lễ phục Thân vương / Hoàng tử)
  G020: {
    canonicalId: "G020",
    asset: "tu_ao_mang_bao_1791592317711.jpg",
    src: "/src/assets/images/tu_ao_mang_bao_1791592317711.jpg",
    assetStatus: "PH\u1EE4C D\u1EF0NG",
    sourceInstitution: "B\u1EA3o t\xE0ng C\u1ED5 v\u1EADt Cung \u0111\xECnh Hu\u1EBF & T\xE0ng Y C\xE1c",
    license: "Editorial Archive License",
    verificationNote: "\u1EA2nh ph\u1EE5c d\u1EF1ng chu\u1EA9n th\u1EE9c \xC1o M\xE3ng B\xE0o s\u1EAFc lam s\u1EABm th\xEAu m\xE3ng x\xE0 b\u1ED1n m\xF3ng v\xE0 th\u1EE7y ba m\xE2y cu\u1ED1n uy nghi\xEAm."
  },
  // 5. Long Bào (Hiện vật Hoàng đế triều Nguyễn)
  G022: {
    canonicalId: "G022",
    asset: "tu_ao_long_bao_1791541769402.jpg",
    src: "/src/assets/images/tu_ao_long_bao_1791541769402.jpg",
    assetStatus: "T\u01AF LI\u1EC6U",
    sourceInstitution: "B\u1EA3o t\xE0ng C\u1ED5 v\u1EADt Cung \u0111\xECnh Hu\u1EBF",
    license: "Museum Artifact Archive",
    verificationNote: "Long B\xE0o Ho\xE0ng \u0111\u1EBF th\xEAu ng\u0169 tr\u1EA3o long, m\xE2y ng\u0169 s\u1EAFc v\xE0 th\u1EE7y ba b\u1EB1ng ch\u1EC9 v\xE0ng kim."
  },
  // Hoàng Bào (Đại triều phục hoàng kim Hoàng đế)
  G023: {
    canonicalId: "G023",
    asset: "tu_ao_hoang_bao_1791591697522.jpg",
    src: "/src/assets/images/tu_ao_hoang_bao_1791591697522.jpg",
    assetStatus: "PH\u1EE4C D\u1EF0NG",
    sourceInstitution: "B\u1EA3o t\xE0ng C\u1ED5 v\u1EADt Cung \u0111\xECnh Hu\u1EBF & T\xE0ng Y C\xE1c",
    license: "Editorial Archive License",
    verificationNote: "\u1EA2nh ph\u1EE5c d\u1EF1ng chu\u1EA9n th\u1EE9c Ho\xE0ng B\xE0o \u0111\u1EA1i tri\u1EC1u s\u1EAFc v\xE0ng ho\xE0ng kim th\xEAu r\u1ED3ng n\u0103m m\xF3ng ng\u0169 tr\u1EA3o long v\xE0 m\xE2y ng\u0169 s\u1EAFc."
  },
  // Phượng Phục (Đại lễ phục thêu phượng hoàng của Hoàng Hậu)
  G025: {
    canonicalId: "G025",
    asset: "tu_ao_phuong_phuc_1791591709330.jpg",
    src: "/src/assets/images/tu_ao_phuong_phuc_1791591709330.jpg",
    assetStatus: "PH\u1EE4C D\u1EF0NG",
    sourceInstitution: "B\u1EA3o t\xE0ng L\u1ECBch s\u1EED Qu\u1ED1c gia & T\xE0ng Y C\xE1c",
    license: "Editorial Archive License",
    verificationNote: "\u1EA2nh ph\u1EE5c d\u1EF1ng chu\u1EA9n th\u1EE9c Ph\u01B0\u1EE3ng Ph\u1EE5c \u0111\u1EA1i tri\u1EC1u s\u1EAFc \u0111\u1ECF th\u1EABm th\xEAu chim ph\u01B0\u1EE3ng ng\u0169 s\u1EAFc v\xE0 hoa m\u1EABu \u0111\u01A1n qu\xFD ph\xE1i."
  },
  // 6. Áo Bà Ba (Dân gian Nam Bộ)
  G028: {
    canonicalId: "G028",
    asset: "tu_ao_ao_ba_ba_1791540391970.jpg",
    src: "/src/assets/images/tu_ao_ao_ba_ba_1791540391970.jpg",
    assetStatus: "PH\u1EE4C D\u1EF0NG",
    sourceInstitution: "B\u1EA3o t\xE0ng TP. H\u1ED3 Ch\xED Minh & T\u01B0 li\u1EC7u d\xE2n gian Nam B\u1ED9",
    license: "Historical Archive License",
    verificationNote: "Trang ph\u1EE5c \xC1o B\xE0 Ba m\u1ED9c m\u1EA1c x\u1EBB t\xE0 hai b\xEAn h\xF4ng \u0111\u1EB7c tr\u01B0ng v\xF9ng ch\xE2u th\u1ED5 s\xF4ng C\u1EEDu Long."
  },
  // 7. Áo Dài (Cổ phục tân thời cải cách)
  G030: {
    canonicalId: "G030",
    asset: "tu_ao_ao_dai_1791540293823.jpg",
    src: "/src/assets/images/tu_ao_ao_dai_1791540293823.jpg",
    assetStatus: "PH\u1EE4C D\u1EF0NG",
    sourceInstitution: "Studio T\xE0ng Y C\xE1c / L\u01B0u tr\u1EEF hi\u1EC7n v\u1EADt ph\u1EE5c ch\u1EBF",
    license: "Documented Object Photography",
    verificationNote: "\xC1o d\xE0i truy\u1EC1n th\u1ED1ng phom d\xE1ng t\xE0 su\xF4ng thanh l\u1ECBch, c\u1ED5 \u0111\u1EE9ng l\u1EADp l\u0129nh, khuy b\u1EA5m n\u1EB9p h\u1EEFu qua eo."
  },
  // Khăn Xếp / Khăn Đóng (Nam giới truyền thống)
  G031: {
    canonicalId: "G031",
    asset: "tu_ao_khan_xep_1791591919738.jpg",
    src: "/src/assets/images/tu_ao_khan_xep_1791591919738.jpg",
    assetStatus: "PH\u1EE4C D\u1EF0NG",
    sourceInstitution: "L\xE0ng ngh\u1EC1 v\u1EA5n kh\u0103n truy\u1EC1n th\u1ED1ng & T\xE0ng Y C\xE1c",
    license: "Editorial Archive License",
    verificationNote: "\u1EA2nh ph\u1EE5c d\u1EF1ng chu\u1EA9n th\u1EE9c kh\u0103n x\u1EBFp l\u1EE5a \u0111en qu\u1EA5n n\u1EBFp nghi\xEAng \u0111\u1ED3ng t\xE2m trang tr\u1ECDng c\u1EE7a nam gi\u1EDBi."
  },
  // 8. Khăn Vành Dây (Cung đình Huế)
  G032: {
    canonicalId: "G032",
    asset: "tu_ao_khan_vanh_day_1791541857698.jpg",
    src: "/src/assets/images/tu_ao_khan_vanh_day_1791541857698.jpg",
    assetStatus: "T\u01AF LI\u1EC6U",
    sourceInstitution: "Trung t\xE2m B\u1EA3o t\u1ED3n Di t\xEDch C\u1ED1 \u0111\xF4 Hu\u1EBF",
    license: "Museum Artifact Archive",
    verificationNote: "Kh\u0103n v\xE0nh d\xE2y cung \u0111\xECnh qu\u1EA5n x\u1EBFp nhi\u1EC1u v\xF2ng t\u1EC9 m\u1EC9 b\u1EB1ng v\u1EA3i l\u1EE5a xanh th\u1EABm v\xE0 ch\u1EC9 v\xE0ng kim."
  },
  // Khăn Mỏ Quạ (Phụ nữ Bắc Bộ)
  G033: {
    canonicalId: "G033",
    asset: "tu_ao_khan_mo_qua_1791591931180.jpg",
    src: "/src/assets/images/tu_ao_khan_mo_qua_1791591931180.jpg",
    assetStatus: "PH\u1EE4C D\u1EF0NG",
    sourceInstitution: "B\u1EA3o t\xE0ng D\xE2n t\u1ED9c h\u1ECDc & T\u01B0 li\u1EC7u v\u0103n h\xF3a B\u1EAFc B\u1ED9",
    license: "Editorial Archive License",
    verificationNote: "\u1EA2nh ph\u1EE5c d\u1EF1ng chu\u1EA9n kh\u0103n m\u1ECF qu\u1EA1 l\u1EE5a \u0111en g\u1EADp ch\xE9o ch\xF3p nh\u1ECDn ph\xEDa tr\u01B0\u1EDBc tr\xE1n, n\xE9t duy\xEAn c\u1ED5 truy\u1EC1n ph\u1EE5 n\u1EEF B\u1EAFc B\u1ED9."
  },
  // 9. Khăn Rằn (Nam Bộ)
  G034: {
    canonicalId: "G034",
    asset: "tu_ao_khan_ran_1791541960369.jpg",
    src: "/src/assets/images/tu_ao_khan_ran_1791541960369.jpg",
    assetStatus: "T\u01AF LI\u1EC6U",
    sourceInstitution: "B\u1EA3o t\xE0ng Ph\u1EE5 n\u1EEF Nam B\u1ED9",
    license: "Documented Object Photography",
    verificationNote: "Kh\u0103n r\u1EB1n d\u1EC7t th\u1EE7 c\xF4ng k\u1EBB s\u1ECDc caro \u0111en tr\u1EAFng truy\u1EC1n th\u1ED1ng c\u1EE7a c\u01B0 d\xE2n \u0111\u1ED3ng b\u1EB1ng s\xF4ng C\u1EEDu Long."
  },
  // Nón Lá (Dân tộc Việt Nam)
  G035: {
    canonicalId: "G035",
    asset: "tu_ao_non_la_1791591940904.jpg",
    src: "/src/assets/images/tu_ao_non_la_1791591940904.jpg",
    assetStatus: "PH\u1EE4C D\u1EF0NG",
    sourceInstitution: "L\xE0ng ngh\u1EC1 \u0111an n\xF3n Chu\xF4ng & T\xE0ng Y C\xE1c",
    license: "Editorial Archive License",
    verificationNote: "\u1EA2nh ph\u1EE5c d\u1EF1ng chu\u1EA9n th\u1EE9c n\xF3n l\xE1 ch\xF3p truy\u1EC1n th\u1ED1ng \u0111an l\xE1 n\xF3n t\u1EF1 nhi\xEAn, v\xE0nh tre chu\u1ED1t m\u1ECBn v\xE0 quai l\u1EE5a."
  },
  // 10. Nón Ba Tầm (Bắc Bộ)
  G036: {
    canonicalId: "G036",
    asset: "tu_ao_non_ba_tam_1791541813772.jpg",
    src: "/src/assets/images/tu_ao_non_ba_tam_1791541813772.jpg",
    assetStatus: "T\u01AF LI\u1EC6U",
    sourceInstitution: "B\u1EA3o t\xE0ng D\xE2n t\u1ED9c h\u1ECDc Vi\u1EC7t Nam",
    license: "Museum Artifact Archive",
    verificationNote: "N\xF3n Ba T\u1EA7m \u0111an l\xE1 c\u1ECD v\xE0nh tr\xF2n ph\u1EB3ng r\u1ED9ng k\xE8m quai thao t\u01A1 t\u1EB1m bu\xF4ng r\u1EE7 thanh tao."
  },
  // Nón Bài Thơ (Xứ Huế)
  G038: {
    canonicalId: "G038",
    asset: "tu_ao_non_bai_tho_1791592327797.jpg",
    src: "/src/assets/images/tu_ao_non_bai_tho_1791592327797.jpg",
    assetStatus: "PH\u1EE4C D\u1EF0NG",
    sourceInstitution: "L\xE0ng n\xF3n T\xE2y H\u1ED3 - X\u1EE9 Hu\u1EBF & T\xE0ng Y C\xE1c",
    license: "Editorial Archive License",
    verificationNote: "N\xF3n b\xE0i th\u01A1 x\u1EE9 Hu\u1EBF \u0111an thanh m\u1EA3nh hai l\u1EDBp l\xE1 k\xE8, \u1EA9n hi\u1EC7n b\xE0i th\u01A1 v\xE0 tranh phong c\u1EA3nh ch\xF9a Thi\xEAn M\u1EE5 khi soi \xE1nh s\xE1ng."
  },
  // Mũ Cánh Chuồn (Mũ quan đại triều)
  G039: {
    canonicalId: "G039",
    asset: "tu_ao_mu_canh_chuon_1791591950697.jpg",
    src: "/src/assets/images/tu_ao_mu_canh_chuon_1791591950697.jpg",
    assetStatus: "T\u01AF LI\u1EC6U",
    sourceInstitution: "B\u1EA3o t\xE0ng C\u1ED5 v\u1EADt Cung \u0111\xECnh Hu\u1EBF & T\xE0ng Y C\xE1c",
    license: "Museum Artifact Archive",
    verificationNote: "M\u0169 \xD4 Sa hai c\xE1nh chu\u1ED3n ngang c\u1EE7a quan l\u1EA1i tri\u1EC1u \u0111\xECnh b\u1EB1ng the \u0111an th\u1EBFp v\xE0ng hoa v\u0103n tinh x\u1EA3o."
  },
  // Vân Kiên (Áo choàng vai cánh sen mây ngũ sắc)
  G040: {
    canonicalId: "G040",
    asset: "tu_ao_van_kien_1791592339952.jpg",
    src: "/src/assets/images/tu_ao_van_kien_1791592339952.jpg",
    assetStatus: "T\u01AF LI\u1EC6U",
    sourceInstitution: "B\u1EA3o t\xE0ng C\u1ED5 v\u1EADt Cung \u0111\xECnh Hu\u1EBF & T\xE0ng Y C\xE1c",
    license: "Museum Artifact Archive",
    verificationNote: "V\xE2n ki\xEAn cho\xE0ng vai h\xECnh b\u1ED1n c\xE1nh sen v\xE0 \u0111\xE1m m\xE2y ng\u0169 s\u1EAFc th\xEAu ch\u1EC9 kim tuy\u1EBFn, ph\u1EE5 ki\u1EC7n l\u1EC5 ph\u1EE5c m\u1EC7nh ph\u1EE5 ho\xE0ng gia."
  },
  // Hia (Hia quan viên triều Nguyễn)
  G045: {
    canonicalId: "G045",
    asset: "tu_ao_hia_quan_1791592350888.jpg",
    src: "/src/assets/images/tu_ao_hia_quan_1791592350888.jpg",
    assetStatus: "T\u01AF LI\u1EC6U",
    sourceInstitution: "B\u1EA3o t\xE0ng L\u1ECBch s\u1EED Qu\u1ED1c gia & T\xE0ng Y C\xE1c",
    license: "Museum Artifact Archive",
    verificationNote: "Hia tri\u1EC1u ph\u1EE5c c\u1EE7a quan l\u1EA1i tri\u1EC1u Nguy\u1EC5n b\u1EB1ng nhung \u0111en m\u0169i cong v\u1EC3nh cao, \u0111\u1EBF v\u1EA3i b\u1EC7n qu\xE9t s\u01A1n tr\u1EAFng trang tr\u1ECDng."
  },
  // 11. Hài thêu (Cung đình)
  G046: {
    canonicalId: "G046",
    asset: "tu_ao_hai_theu_1791541907877.jpg",
    src: "/src/assets/images/tu_ao_hai_theu_1791541907877.jpg",
    assetStatus: "T\u01AF LI\u1EC6U",
    sourceInstitution: "B\u1EA3o t\xE0ng L\u1ECBch s\u1EED Qu\u1ED1c gia",
    license: "Museum Artifact Archive",
    verificationNote: "H\xE0i th\xEAu cung \u0111\xECnh m\u0169i cong b\u1ECDc l\u1EE5a sa \u0111\u1ECF th\xEAu hoa sen ch\u1EC9 v\xE0ng v\xE0 \u0111\u1EBF v\u1EA3i b\u1EC7n nhi\u1EC1u l\u1EDBp."
  },
  // Guốc Mộc (Dân gian cổ truyền)
  G047: {
    canonicalId: "G047",
    asset: "tu_ao_guoc_moc_1791591962889.jpg",
    src: "/src/assets/images/tu_ao_guoc_moc_1791591962889.jpg",
    assetStatus: "PH\u1EE4C D\u1EF0NG",
    sourceInstitution: "B\u1EA3o t\xE0ng D\xE2n t\u1ED9c h\u1ECDc & L\xE0ng ngh\u1EC1 gu\u1ED1c m\u1ED9c truy\u1EC1n th\u1ED1ng",
    license: "Editorial Archive License",
    verificationNote: "\u1EA2nh ph\u1EE5c d\u1EF1ng chu\u1EA9n th\u1EE9c gu\u1ED1c m\u1ED9c \u0111\u1EBDo t\u1EEB g\u1ED7 t\u1EF1 nhi\xEAn, quai v\u1EA3i th\u1ED5 c\u1EA9m m\u1ED9c m\u1EA1c l\u01B0u truy\u1EC1n qua nhi\u1EC1u th\u1EBF k\u1EF7."
  },
  // Quần Lá Tọa (Dân gian truyền thống)
  G014: {
    canonicalId: "G014",
    asset: "tu_ao_quan_la_toa_1791593055198.jpg",
    src: "/src/assets/images/tu_ao_quan_la_toa_1791593055198.jpg",
    assetStatus: "PH\u1EE4C D\u1EF0NG",
    sourceInstitution: "B\u1EA3o t\xE0ng D\xE2n t\u1ED9c h\u1ECDc & T\u01B0 li\u1EC7u d\xE2n gian B\u1EAFc B\u1ED9",
    license: "Editorial Archive License",
    verificationNote: "\u1EA2nh ph\u1EE5c d\u1EF1ng chu\u1EA9n th\u1EE9c Qu\u1EA7n L\xE1 T\u1ECDa \u0111\u0169ng th\u1EE5ng r\u1ED9ng b\u1EB1ng v\u1EA3i th\xF4 nhu\u1ED9m n\xE2u s\u1ED3ng truy\u1EC1n th\u1ED1ng."
  },
  // Khố (Dân tộc cổ phong)
  G015: {
    canonicalId: "G015",
    asset: "tu_ao_kho_dan_gian_1791593067158.jpg",
    src: "/src/assets/images/tu_ao_kho_dan_gian_1791593067158.jpg",
    assetStatus: "PH\u1EE4C D\u1EF0NG",
    sourceInstitution: "B\u1EA3o t\xE0ng L\u1ECBch s\u1EED Qu\u1ED1c gia & T\u01B0 li\u1EC7u c\u1ED5 phong",
    license: "Editorial Archive License",
    verificationNote: "\u1EA2nh t\u01B0 li\u1EC7u ph\u1EE5c d\u1EF1ng kh\u1ED1 v\u1EA3i ch\xE0m d\u1EC7t tay m\u1ED9c m\u1EA1c theo quy th\u1EE9c trang ph\u1EE5c lao \u0111\u1ED9ng th\u1EDDi s\u01A1 s\u1EED."
  },
  // Mãng Lan (Lễ phục Hoàng thân triều Nguyễn)
  G021: {
    canonicalId: "G021",
    asset: "tu_ao_mang_lan_1791593078866.jpg",
    src: "/src/assets/images/tu_ao_mang_lan_1791593078866.jpg",
    assetStatus: "PH\u1EE4C D\u1EF0NG",
    sourceInstitution: "B\u1EA3o t\xE0ng C\u1ED5 v\u1EADt Cung \u0111\xECnh Hu\u1EBF & T\xE0ng Y C\xE1c",
    license: "Editorial Archive License",
    verificationNote: "\u1EA2nh ph\u1EE5c d\u1EF1ng chu\u1EA9n th\u1EE9c \xE1o M\xE3ng Lan s\u1EAFc lam th\u1EABm th\xEAu m\xE3ng x\xE0 hoa lan c\u1EE7a Ho\xE0ng t\u1ED9c tri\u1EC1u Nguy\u1EC5n."
  },
  // Cổn Phục (Đại lễ phục tế Nam Giao Hoàng đế)
  G024: {
    canonicalId: "G024",
    asset: "tu_ao_con_phuc_1791593088539.jpg",
    src: "/src/assets/images/tu_ao_con_phuc_1791593088539.jpg",
    assetStatus: "PH\u1EE4C D\u1EF0NG",
    sourceInstitution: "Trung t\xE2m B\u1EA3o t\u1ED3n Di t\xEDch C\u1ED1 \u0111\xF4 Hu\u1EBF & T\xE0ng Y C\xE1c",
    license: "Editorial Archive License",
    verificationNote: "\u1EA2nh ph\u1EE5c d\u1EF1ng chu\u1EA9n th\u1EE9c C\u1ED5n Ph\u1EE5c t\u1EBF Nam Giao s\u1EAFc \u0111en th\xEAu th\u1EADp nh\u1ECB ch\u01B0\u01A1ng v\xE0 l\u01B0\u1EE1ng long tri\u1EC1u nh\u1EADt t\xF4n nghi\xEAm."
  },
  // Nón Thúng / Thúng quai thao (Quan Họ Bắc Bộ)
  G037: {
    canonicalId: "G037",
    asset: "tu_ao_non_thung_1791593237981.jpg",
    src: "/src/assets/images/tu_ao_non_thung_1791593237981.jpg",
    assetStatus: "PH\u1EE4C D\u1EF0NG",
    sourceInstitution: "B\u1EA3o t\xE0ng D\xE2n t\u1ED9c h\u1ECDc & Trung t\xE2m B\u1EA3o t\u1ED3n Quan h\u1ECD B\u1EAFc Ninh",
    license: "Editorial Archive License",
    verificationNote: "\u1EA2nh ph\u1EE5c d\u1EF1ng chu\u1EA9n n\xF3n th\xFAng l\xF2ng s\xE2u \u0111an l\xE1 c\u1ECD t\u1EF1 nhi\xEAn k\u1EBFt quai thao t\u01A1 t\u1EB1m bu\xF4ng r\u1EE7 d\xE0i."
  },
  // Trâm (Cài tóc truyền thống)
  G041: {
    canonicalId: "G041",
    asset: "tu_ao_tram_cai_toc_1791593137036.jpg",
    src: "/src/assets/images/tu_ao_tram_cai_toc_1791593137036.jpg",
    assetStatus: "T\u01AF LI\u1EC6U",
    sourceInstitution: "B\u1EA3o t\xE0ng L\u1ECBch s\u1EED Qu\u1ED1c gia & T\xE0ng Y C\xE1c",
    license: "Museum Artifact Archive",
    verificationNote: "Tr\xE2m c\xE0i t\xF3c b\u1EA1c ch\u1EA1m l\u1ED9ng hoa sen v\xE0 chim ph\u01B0\u1EE3ng n\u1EA1m ng\u1ECDc b\xEDch t\u1EF1 nhi\xEAn qu\xFD ph\xE1i."
  },
  // Đai / Thắt lưng (Đai ngọc triều đình)
  G042: {
    canonicalId: "G042",
    asset: "tu_ao_dai_that_lung_1791593101752.jpg",
    src: "/src/assets/images/tu_ao_dai_that_lung_1791593101752.jpg",
    assetStatus: "T\u01AF LI\u1EC6U",
    sourceInstitution: "B\u1EA3o t\xE0ng C\u1ED5 v\u1EADt Cung \u0111\xECnh Hu\u1EBF & T\xE0ng Y C\xE1c",
    license: "Museum Artifact Archive",
    verificationNote: "\u0110ai ng\u1ECDc tri\u1EC1u ph\u1EE5c c\u1EA9n b\u1EA1ch ng\u1ECDc vi\u1EC1n g\u1EA5m th\u1EBFp v\xE0ng hoa v\u0103n m\xE2y r\u1ED3ng cung \u0111\xECnh tri\u1EC1u Nguy\u1EC5n."
  },
  // Dây Ruột Tượng (Thắt lưng vải rỗng ruột)
  G043: {
    canonicalId: "G043",
    asset: "tu_ao_day_ruot_tuong_1791593147548.jpg",
    src: "/src/assets/images/tu_ao_day_ruot_tuong_1791593147548.jpg",
    assetStatus: "PH\u1EE4C D\u1EF0NG",
    sourceInstitution: "B\u1EA3o t\xE0ng D\xE2n t\u1ED9c h\u1ECDc & T\xE0ng Y C\xE1c",
    license: "Editorial Archive License",
    verificationNote: "D\xE2y ru\u1ED9t t\u01B0\u1EE3ng v\u1EA3i d\u1EC7t m\u1ED9c r\u1ED7ng ru\u1ED9t d\xF9ng l\xE0m th\u1EAFt l\u01B0ng ki\xEAm bao \u0111\u1EF1ng ti\u1EC1n \u0111\u1ED3ng truy\u1EC1n th\u1ED1ng."
  },
  // Hốt (Thẻ ngà/gỗ quan viên vào chầu)
  G044: {
    canonicalId: "G044",
    asset: "tu_ao_the_hot_quan_1791593160009.jpg",
    src: "/src/assets/images/tu_ao_the_hot_quan_1791593160009.jpg",
    assetStatus: "T\u01AF LI\u1EC6U",
    sourceInstitution: "B\u1EA3o t\xE0ng C\u1ED5 v\u1EADt Cung \u0111\xECnh Hu\u1EBF",
    license: "Museum Artifact Archive",
    verificationNote: "Phi\u1EBFn h\u1ED1t ng\xE0 voi u\u1ED1n cong b\xF3ng m\u1ECBn quan vi\xEAn c\u1EA7m tr\u01B0\u1EDBc ng\u1EF1c khi t\xE2u vi\u1EC7c tr\u01B0\u1EDBc ngai v\xE0ng tri\u1EC1u Nguy\u1EC5n."
  },
  // Quạt (Quạt lụa cầm tay truyền thống)
  A011: {
    canonicalId: "A011",
    asset: "tu_ao_quat_lua_co_1791593170321.jpg",
    src: "/src/assets/images/tu_ao_quat_lua_co_1791593170321.jpg",
    assetStatus: "PH\u1EE4C D\u1EF0NG",
    sourceInstitution: "L\xE0ng ngh\u1EC1 qu\u1EA1t Ch\xE0ng S\u01A1n & T\xE0ng Y C\xE1c",
    license: "Editorial Archive License",
    verificationNote: "Qu\u1EA1t nan tre b\u1ECDc sa l\u1EE5a v\u1EBD tranh th\u1EE7y m\u1EB7c hoa sen v\xE0 th\u01B0 ph\xE1p c\u1ED5 truy\u1EC1n."
  },
  // Thẻ bài (Thẻ bài quan viên triều Nguyễn)
  A012: {
    canonicalId: "A012",
    asset: "tu_ao_the_bai_quan_1791593182172.jpg",
    src: "/src/assets/images/tu_ao_the_bai_quan_1791593182172.jpg",
    assetStatus: "T\u01AF LI\u1EC6U",
    sourceInstitution: "B\u1EA3o t\xE0ng C\u1ED5 v\u1EADt Cung \u0111\xECnh Hu\u1EBF",
    license: "Museum Artifact Archive",
    verificationNote: "Th\u1EBB b\xE0i ng\xE0 voi ch\u1EA1m kh\u1EAFc r\u1ED3ng v\xE0 ch\u1EE9c danh quan l\u1EA1i k\xE8m d\u1EA3i thao t\u01A1 t\u1EB1m th\u1EAFt n\xFAt c\xE1t t\u01B0\u1EDDng."
  },
  // Áo Cổ Thìa (Khoét cong hình chiếc thìa mềm mại)
  G004: {
    canonicalId: "G004",
    asset: "ao_co_thia_1791596725420.jpg",
    src: "/src/assets/images/ao_co_thia_1791596725420.jpg",
    assetStatus: "PH\u1EE4C D\u1EF0NG",
    sourceInstitution: "Studio T\xE0ng Y C\xE1c & Kh\u1EA3o c\u1EE9u L\xEA Trung H\u01B0ng",
    license: "Editorial Archive License",
    verificationNote: "\u1EA2nh ph\u1EE5c d\u1EF1ng chu\u1EA9n th\u1EE9c phom \xE1o c\u1ED5 kho\xE9t cong h\xECnh chi\u1EBFc th\xECa tr\xEAn n\u1EC1n l\u1EE5a ng\xE0 voi thanh nh\xE3."
  },
  // Áo Bán Tí (Áo tay ngắn nửa cánh tay)
  G005: {
    canonicalId: "G005",
    asset: "ao_ban_ti_1791596737653.jpg",
    src: "/src/assets/images/ao_ban_ti_1791596737653.jpg",
    assetStatus: "PH\u1EE4C D\u1EF0NG",
    sourceInstitution: "Studio T\xE0ng Y C\xE1c & T\u01B0 li\u1EC7u \u0111\u1ED1i chi\u1EBFu c\u1ED5 ph\u1EE5c",
    license: "Editorial Archive License",
    verificationNote: "\u1EA2nh ph\u1EE5c d\u1EF1ng chu\u1EA9n th\u1EE9c \xE1o b\xE1n t\xED tay ng\u1EAFn n\u1EEDa c\xE1nh tay d\u1EC7t hoa v\u0103n g\u1EA5m c\u1ED5 \u0111i\u1EC3n."
  },
  // Áo Tứ Điên (Bốn vạt xẻ thời Lý-Trần)
  G007: {
    canonicalId: "G007",
    asset: "ao_tu_dien_1791596749479.jpg",
    src: "/src/assets/images/ao_tu_dien_1791596749479.jpg",
    assetStatus: "PH\u1EE4C D\u1EF0NG",
    sourceInstitution: "Kh\u1EA3o c\u1EE9u th\u01B0 t\u1ECBch th\u1EDDi L\xFD-Tr\u1EA7n & Studio T\xE0ng Y",
    license: "Editorial Archive License",
    verificationNote: "\u1EA2nh ph\u1EE5c d\u1EF1ng \xE1o T\u1EE9 \u0110i\xEAn m\xE0u \u0111en b\u1ED1n v\u1EA1t x\u1EBB vi\u1EC1n hoa v\u0103n v\xE0ng theo m\xF4 t\u1EA3 v\u0103n li\u1EC7u th\u01B0 t\u1ECBch c\u1ED5."
  },
  // Áo Mệnh Phụ (Cung đình triều Nguyễn)
  G019: {
    canonicalId: "G019",
    asset: "ao_menh_phu_1791596761598.jpg",
    src: "/src/assets/images/ao_menh_phu_1791596761598.jpg",
    assetStatus: "PH\u1EE4C D\u1EF0NG",
    sourceInstitution: "Trung t\xE2m B\u1EA3o t\u1ED3n C\u1ED1 \u0111\xF4 Hu\u1EBF & T\xE0ng Y C\xE1c",
    license: "Editorial Archive License",
    verificationNote: "\u1EA2nh ph\u1EE5c d\u1EF1ng ph\u1EA9m ph\u1EE5c M\u1EC7nh ph\u1EE5 tri\u1EC1u \u0111\xECnh th\xEAu ph\u01B0\u1EE3ng v\xE0 m\xE2y sa \u0111o\xE0n vi\u1EC1n ch\u1EC9 v\xE0ng kim."
  },
  // Áo Thâm (Nho sĩ / Dân gian truyền thống)
  G026: {
    canonicalId: "G026",
    asset: "ao_tham_1791596772708.jpg",
    src: "/src/assets/images/ao_tham_1791596772708.jpg",
    assetStatus: "PH\u1EE4C D\u1EF0NG",
    sourceInstitution: "B\u1EA3o t\xE0ng D\xE2n t\u1ED9c h\u1ECDc & Kh\u1EA3o c\u1EE9u Nho s\u0129 B\u1EAFc B\u1ED9",
    license: "Editorial Archive License",
    verificationNote: "\u1EA2nh ph\u1EE5c d\u1EF1ng \xE1o th\xE2m the \u0111en pha n\xE2u s\u1EABm c\u1EE7a gi\u1EDBi Nho gia truy\u1EC1n th\u1ED1ng."
  },
  // Áo Cánh (Áo nâu sồng nông thôn truyền thống)
  G027: {
    canonicalId: "G027",
    asset: "ao_canh_1791596784284.jpg",
    src: "/src/assets/images/ao_canh_1791596784284.jpg",
    assetStatus: "PH\u1EE4C D\u1EF0NG",
    sourceInstitution: "B\u1EA3o t\xE0ng D\xE2n t\u1ED9c h\u1ECDc & T\u01B0 li\u1EC7u v\u0103n h\xF3a B\u1EAFc B\u1ED9",
    license: "Editorial Archive License",
    verificationNote: "\u1EA2nh ph\u1EE5c d\u1EF1ng \xE1o c\xE1nh n\xE2u s\u1ED3ng x\u1EBB ng\u1EF1c \u0111\xEDnh c\xFAc th\u1EAFt n\xFAt v\xE0 hai t\xFAi b\u1EE5ng d\xE2n d\xE3."
  },
  // Áo Chàm (Trang phục nhuộm chàm vùng núi phía Bắc)
  G029: {
    canonicalId: "G029",
    asset: "ao_cham_1791596795750.jpg",
    src: "/src/assets/images/ao_cham_1791596795750.jpg",
    assetStatus: "T\u01AF LI\u1EC6U",
    sourceInstitution: "L\u01B0u tr\u1EEF D\xE2n t\u1ED9c h\u1ECDc v\xF9ng n\xFAi ph\xEDa B\u1EAFc & T\xE0ng Y C\xE1c",
    license: "Editorial Archive License",
    verificationNote: "\u1EA2nh ph\u1EE5c d\u1EF1ng \xE1o ch\xE0m d\u1EC7t thoi nhu\u1ED9m l\xE1 ch\xE0m t\u1EF1 nhi\xEAn v\u1EDBi h\xE0ng khuy b\u1EA1c \u0111\u1EB7c tr\u01B0ng."
  }
};

// src/domain/canonicalData.ts
var SOURCES_LIST = Viet_Phuc_Master_Research_v1_default.SOURCES || [];
var SOURCES_MAP = SOURCES_LIST.reduce(
  (acc, s) => {
    acc[s.id] = {
      id: s.id,
      name: s.title,
      institution: s.institution,
      type: s.type,
      url: s.url
    };
    return acc;
  },
  {}
);
function getSources(ids = []) {
  return ids.map((id) => SOURCES_MAP[id] || { id, name: `T\u01B0 li\u1EC7u ${id}` });
}
function getEvidenceLabelVi(level) {
  if (!level) return "Ch\u01B0a \u0111\u1EE7 t\u01B0 li\u1EC7u";
  const u = level.toUpperCase();
  if (u.includes("VERIFIED")) return "\u0110\xE3 ki\u1EC3m ch\u1EE9ng";
  if (u.includes("STRONG")) return "C\xF3 c\u01A1 s\u1EDF m\u1EA1nh";
  if (u.includes("CONSISTENT")) return "Ph\xF9 h\u1EE3p b\u1ED1i c\u1EA3nh l\u1ECBch s\u1EED";
  if (u.includes("CONTESTED")) return "C\xF3 tranh lu\u1EADn t\u01B0 li\u1EC7u";
  return "Ch\u01B0a \u0111\u1EE7 t\u01B0 li\u1EC7u";
}
function determineGenderScope(id, _name = "", _category = "", audience = []) {
  if ([
    "G010",
    "G011",
    "G012",
    "G018",
    "G019",
    "G025",
    "G032",
    "G033",
    "G036",
    "G037",
    "G038",
    "G041",
    "G043"
  ].includes(id)) {
    return "female";
  }
  if ([
    "G007",
    "G014",
    "G015",
    "G016",
    "G017",
    "G020",
    "G021",
    "G022",
    "G023",
    "G024",
    "G026",
    "G039",
    "G044",
    "G045",
    "A012"
  ].includes(id)) {
    return "male";
  }
  if (id === "G004" || audience.includes("C\u1EA7n x\xE1c minh")) {
    return "unknown";
  }
  return "unisex";
}
function getCanonicalEntityImage(id, name) {
  const assetEntry = CANONICAL_ASSET_REGISTRY_V3[id];
  if (!assetEntry) {
    return {
      imageType: "NO_VERIFIED_IMAGE",
      imageStatusLabelVi: "\u26A0 Ch\u01B0a c\xF3 \u1EA3nh x\xE1c th\u1EF1c",
      verificationNote: "\u0110ang nghi\xEAn c\u1EE9u t\u01B0 li\u1EC7u h\xECnh \u1EA3nh hi\u1EC7n v\u1EADt b\u1EA3o t\xE0ng."
    };
  }
  const imageType = assetEntry.assetStatus === "T\u01AF LI\u1EC6U" ? "DOCUMENTED_OBJECT" : assetEntry.assetStatus === "PH\u1EE4C D\u1EF0NG" ? "RECONSTRUCTION" : "RESEARCH_PLATE";
  const imageStatusLabelVi = assetEntry.assetStatus === "T\u01AF LI\u1EC6U" ? "\u2713 \u1EA2nh hi\u1EC7n v\u1EADt" : assetEntry.assetStatus === "PH\u1EE4C D\u1EF0NG" ? "\u25B3 \u1EA2nh ph\u1EE5c d\u1EF1ng" : "\u25C7 B\u1EA3n v\u1EBD kh\u1EA3o c\u1EE9u";
  return {
    src: assetEntry.src,
    alt: `${name} \xB7 ${assetEntry.assetStatus} \xB7 ${assetEntry.sourceInstitution}`,
    imageType,
    imageStatusLabelVi,
    assetStatus: assetEntry.assetStatus,
    assetFilename: assetEntry.asset,
    sourceInstitution: assetEntry.sourceInstitution,
    license: assetEntry.license,
    verificationNote: assetEntry.verificationNote
  };
}
function getBrowseCategoryLabel(cat) {
  switch (cat) {
    case "AO":
      return "\xC1o";
    case "AO_TRONG":
      return "\xC1o trong";
    case "AO_NGOAI":
      return "\xC1o ngo\xE0i";
    case "QUAN_VAY":
      return "Qu\u1EA7n & V\xE1y";
    case "GIAY_DEP":
      return "Gi\xE0y & D\xE9p";
    case "KHAN_NON":
      return "Kh\u0103n & N\xF3n";
    case "PHU_KIEN":
      return "Ph\u1EE5 ki\u1EC7n";
    default:
      return "T\u1EA5t c\u1EA3";
  }
}
function getResearchStatusLabelVi(status) {
  switch (status) {
    case "CURATED_CATALOG":
      return "T\u1EE7 \xC1o tuy\u1EC3n ch\u1ECDn";
    case "NEEDS_VERIFICATION":
      return "H\u1ED3 s\u01A1 \u0111ang x\xE1c minh";
    case "CONTESTED_UNCERTAIN":
      return "H\u1ED3 s\u01A1 tranh lu\u1EADn h\u1ECDc thu\u1EADt";
    case "OUT_OF_CORE":
      return "Ngo\xE0i ph\u1EA1m vi Kinh ph\u1EE5c";
  }
}
function buildCanonicalEntities() {
  const rawGarments2 = Viet_Phuc_Master_Research_v1_default.MASTER_GARMENTS || [];
  const rawAccessories2 = Viet_Phuc_Master_Research_v1_default.ACCESSORIES || [];
  const entities = [];
  const archivedEntities = [];
  const REMOVED_ITEM_IDS = /* @__PURE__ */ new Set(["G004", "G005", "G026", "G027", "G029"]);
  rawGarments2.forEach((g) => {
    const gid = g.id;
    let mergedRecordIds = [gid];
    const variants = [];
    let browseCategory = "AO";
    let objectType = "GARMENT";
    let researchStatus = "CURATED_CATALOG";
    let periods = g.period || [];
    let geographicRegions = [];
    let locations = [];
    let socialContext = [];
    let gender = [];
    let contexts = g.context || [];
    (g.region || []).forEach((r) => {
      if (["B\u1EAFc B\u1ED9", "Trung B\u1ED9", "Nam B\u1ED9", "To\xE0n qu\u1ED1c", "\u0110\xE0ng Ngo\xE0i", "\u0110\xE0ng Trong"].includes(r)) {
        geographicRegions.push(r);
      } else if (["Hu\u1EBF", "Kinh k\u1EF3", "Kinh B\u1EAFc", "\u0110\u1ED3ng b\u1EB1ng s\xF4ng H\u1ED3ng"].includes(r)) {
        locations.push(r);
      } else if (["Cung \u0111\xECnh", "Ho\xE0ng cung", "N\xF4ng th\xF4n"].includes(r)) {
        contexts.push(r);
      }
    });
    (g.audience || []).forEach((aud) => {
      if (["Nam", "N\u1EEF"].includes(aud)) {
        gender.push(aud);
      } else {
        socialContext.push(aud);
      }
    });
    const nameLower = g.name.toLowerCase();
    const catLower = (g.category || "").toLowerCase();
    if (catLower.includes("kh\u0103n") || catLower.includes("n\xF3n") || catLower.includes("m\u0169") || nameLower.includes("kh\u0103n") || nameLower.includes("n\xF3n") || nameLower.includes("m\u0169")) {
      browseCategory = "KHAN_NON";
      objectType = "HEADWEAR";
    } else if (catLower.includes("gi\xE0y") || catLower.includes("footwear") || nameLower.includes("h\xE0i") || nameLower.includes("hia") || nameLower.includes("gu\u1ED1c")) {
      browseCategory = "GIAY_DEP";
      objectType = "FOOTWEAR";
    } else if (catLower.includes("th\xE2n d\u01B0\u1EDBi") || nameLower.includes("v\xE1y") || nameLower.includes("qu\u1EA7n") || nameLower.includes("kh\u1ED1") || nameLower.includes("xi\xEAm")) {
      browseCategory = "QUAN_VAY";
      objectType = "GARMENT";
    } else if (catLower.includes("n\u1ED9i y") || catLower.includes("l\u1EDBp trong") || nameLower.includes("y\u1EBFm") || nameLower.includes("\xE1o l\xF3t")) {
      browseCategory = "AO_TRONG";
      objectType = "GARMENT";
    } else if (catLower.includes("\xE1o kho\xE1c") || catLower.includes("cung \u0111\xECnh") || catLower.includes("\xE1o l\u1EC5") || catLower.includes("ph\u1EE5c ph\u1EA9m") || catLower.includes("h\u1EC7 ph\u1EE5c trang") || catLower.includes("ph\u1EE5c trang n\u1EEF cung \u0111\xECnh") || nameLower.includes("long b\xE0o") || nameLower.includes("ho\xE0ng b\xE0o") || nameLower.includes("c\u1ED5n ph\u1EE5c") || nameLower.includes("m\xE3ng b\xE0o") || nameLower.includes("m\xE3ng lan") || nameLower.includes("nh\u1EADt b\xECnh") || nameLower.includes("b\u1ED5 ph\u1EE5c") || nameLower.includes("\xE1o t\u1EA5c") || nameLower.includes("ph\u01B0\u1EE3ng ph\u1EE5c") || nameLower.includes("\xE1o m\u1EC7nh ph\u1EE5")) {
      browseCategory = "AO_NGOAI";
      objectType = "GARMENT";
    } else if (nameLower.startsWith("\xE1o") || catLower.includes("\xE1o th\xE2n tr\xEAn") || catLower.includes("\xE1o b\u1ED1n v\u1EA1t") || catLower.includes("\xE1o tay ng\u1EAFn") || catLower.includes("\xE1o d\xE2n gian") || catLower.includes("\xE1o d\xE0i")) {
      browseCategory = "AO";
      objectType = "GARMENT";
    } else {
      browseCategory = "PHU_KIEN";
      objectType = "ACCESSORY";
    }
    if (gid === "G017") {
      mergedRecordIds = ["G017", "A002"];
      objectType = "COMPONENT";
      browseCategory = "PHU_KIEN";
      variants.push(
        {
          id: "bo_tu_van",
          name: "B\u1ED5 t\u1EED Quan V\u0103n",
          note: "Th\xEAu chim (H\u1EA1c, C\xF2, Tr\u0129, Nh\u1EA1n...) bi\u1EC3u th\u1ECB v\u0103n tr\u1ECB theo 9 ph\u1EA9m tr\u1EADt.",
          sourceIds: ["S01", "S02"]
        },
        {
          id: "bo_tu_vo",
          name: "B\u1ED5 t\u1EED Quan V\xF5",
          note: "Th\xEAu th\xFA (K\u1EF3 l\xE2n, S\u01B0 t\u1EED, H\u1ED5, B\xE1o...) bi\u1EC3u th\u1ECB v\xF5 c\xF4ng theo ph\u1EA9m h\xE0m.",
          sourceIds: ["S01", "S02"]
        }
      );
    } else if (gid === "G040") {
      mergedRecordIds = ["G040", "A001"];
      objectType = "ACCESSORY";
      browseCategory = "PHU_KIEN";
    } else if (gid === "G041") {
      mergedRecordIds = ["G041", "A006"];
      objectType = "ACCESSORY";
      browseCategory = "PHU_KIEN";
      variants.push(
        { id: "tram_ngoc", name: "Tr\xE2m ng\u1ECDc", note: "Tr\xE2m ng\u1ECDc b\xEDch qu\xFD t\u1ED9c, ho\xE0ng cung." },
        { id: "tram_bac", name: "Tr\xE2m b\u1EA1c / tr\xE2m g\u1ED7", note: "Tr\xE2m b\u1EA1c hoa th\u1ECB ho\u1EB7c g\u1ED7 ch\u1EA1m d\xE2n gian." }
      );
    } else if (gid === "G042") {
      mergedRecordIds = ["G042", "A003", "A004", "A013"];
      objectType = "ACCESSORY";
      browseCategory = "PHU_KIEN";
      contexts = ["Cung \u0111\xECnh", "D\xE2n gian", "L\u1EC5 h\u1ED9i", "\u0110\u1EDDi th\u01B0\u1EDDng"];
      periods = ["Nhi\u1EC1u th\u1EDDi k\u1EF3", "Nhi\u1EC1u giai \u0111o\u1EA1n", "D\xE2n gian"];
      variants.push(
        {
          id: "dai_ngoc_cung_dinh",
          name: "Ng\u1ECDc \u0111ai / \u0110ai ph\u1EA9m ph\u1EE5c",
          note: "\u0110ai c\u1EE9ng n\u1EA1m ng\u1ECDc, \u0111\u1ED3i m\u1ED3i bi\u1EC3u th\u1ECB ph\u1EA9m tr\u1EADt \u0111\u1EA1i tri\u1EC1u tri\u1EC1u Nguy\u1EC5n (A013/A003).",
          sourceIds: ["S02"]
        },
        {
          id: "that_lung_lua",
          name: "Th\u1EAFt l\u01B0ng l\u1EE5a / D\u1EA3i bao",
          note: "D\u1EA3i l\u1EE5a m\u1EC1m th\u1EAFt gi\u1EEF v\u1EA1t \xE1o t\u1EE9 th\xE2n ho\u1EB7c ng\u0169 th\xE2n d\xE2n d\xE3 (A004).",
          sourceIds: ["S04"]
        }
      );
    } else if (gid === "G043") {
      mergedRecordIds = ["G043", "A005"];
      objectType = "ACCESSORY";
      browseCategory = "PHU_KIEN";
    } else if (gid === "G044") {
      mergedRecordIds = ["G044", "A007"];
      objectType = "ACCESSORY";
      browseCategory = "PHU_KIEN";
    } else if (gid === "G045") {
      mergedRecordIds = ["G045", "A008"];
      objectType = "FOOTWEAR";
      browseCategory = "GIAY_DEP";
    } else if (gid === "G046") {
      mergedRecordIds = ["G046", "A009"];
      objectType = "FOOTWEAR";
      browseCategory = "GIAY_DEP";
      variants.push(
        { id: "hai_mom_nhai", name: "H\xE0i m\xF5m nh\xE1i cung \u0111\xECnh", note: "H\xE0i m\u0169i cong th\xEAu kim tuy\u1EBFn tri\u1EC1u Nguy\u1EC5n." },
        { id: "hai_theu_nu", name: "H\xE0i th\xEAu hoa d\xE2n gian", note: "H\xE0i l\u1EE5a th\xEAu hoa trang nh\xE3 n\u1EEF l\u01B0u." }
      );
    } else if (gid === "G047") {
      mergedRecordIds = ["G047", "A010"];
      objectType = "FOOTWEAR";
      browseCategory = "GIAY_DEP";
    }
    if (gid === "G029") {
      researchStatus = "OUT_OF_CORE";
    } else if (["G002", "G007", "G036", "G037"].includes(gid)) {
      researchStatus = "CONTESTED_UNCERTAIN";
    } else if (["G004", "G005", "G019"].includes(gid)) {
      researchStatus = "NEEDS_VERIFICATION";
    } else {
      researchStatus = "CURATED_CATALOG";
    }
    const image = getCanonicalEntityImage(gid, g.name);
    const evidenceLevel = g.evidenceLevel || "UNCERTAIN";
    const genderScope = determineGenderScope(
      gid,
      g.name,
      g.category || "",
      g.audience || []
    );
    const asItem = {
      id: gid,
      name: g.name,
      aliases: g.aliases || [],
      category: g.category || "Kh\xE1c",
      period: periods,
      region: geographicRegions,
      gender: gender.length > 0 ? gender : ["Nam", "N\u1EEF"],
      genderScope,
      context: contexts,
      construction: g.constructionNotes || "",
      layerRole: [browseCategory],
      evidenceLevel,
      culturalNotes: g.researchNotes || "",
      sourceIds: g.sourceIds || [],
      auditStatus: g.auditStatus || "CORE",
      warnings: g.warnings || "",
      raw: g
    };
    const entityObj = {
      canonicalId: `CANON_${gid}`,
      primaryRecordId: gid,
      mergedRecordIds,
      canonicalNameVi: g.name,
      aliases: g.aliases || [],
      objectType,
      browseCategory,
      browseCategoryLabel: getBrowseCategoryLabel(browseCategory),
      originalTaxonomy: g.category || "Kh\xE1c",
      variants,
      periods,
      geographicRegions: geographicRegions.length > 0 ? geographicRegions : ["To\xE0n qu\u1ED1c"],
      locations,
      socialContext,
      gender: gender.length > 0 ? gender : ["C\u1EA3 hai"],
      genderScope,
      contexts,
      constructionNotes: g.constructionNotes || "",
      layerRole: g.layerCompatibility || "",
      warnings: g.warnings || "",
      researchNotes: g.researchNotes || "",
      evidenceStatus: evidenceLevel,
      evidenceLabelVi: getEvidenceLabelVi(evidenceLevel),
      researchStatus,
      researchStatusLabelVi: getResearchStatusLabelVi(researchStatus),
      sourceIds: g.sourceIds || [],
      sources: getSources(g.sourceIds || []),
      image,
      asItem
    };
    if (REMOVED_ITEM_IDS.has(gid)) {
      archivedEntities.push(entityObj);
    } else {
      entities.push(entityObj);
    }
  });
  const uniqueAccessories = rawAccessories2.filter((a) => ["A011", "A012"].includes(a.id));
  uniqueAccessories.forEach((a) => {
    const aid = a.id;
    let researchStatus = aid === "A012" ? "NEEDS_VERIFICATION" : "CURATED_CATALOG";
    const evidenceLevel = a.evidence || "CONSISTENT";
    const genderScope = determineGenderScope(
      aid,
      a.name,
      a.taxonomy || "",
      a.userRole ? [a.userRole] : []
    );
    const asItem = {
      id: aid,
      name: a.name,
      aliases: [],
      category: a.taxonomy || "Ph\u1EE5 ki\u1EC7n",
      period: a.periodContext ? [a.periodContext] : [],
      region: [],
      gender: a.userRole ? [a.userRole] : [],
      genderScope,
      context: a.periodContext ? [a.periodContext] : [],
      construction: a.compatibilityLogic || "",
      layerRole: ["Ph\u1EE5 ki\u1EC7n"],
      evidenceLevel,
      culturalNotes: a.compatibilityLogic || "",
      sourceIds: [],
      auditStatus: a.status || "CORE",
      warnings: "",
      raw: a
    };
    entities.push({
      canonicalId: `CANON_${aid}`,
      primaryRecordId: aid,
      mergedRecordIds: [aid],
      canonicalNameVi: a.name,
      aliases: [],
      objectType: "ACCESSORY",
      browseCategory: "PHU_KIEN",
      browseCategoryLabel: "Ph\u1EE5 ki\u1EC7n",
      originalTaxonomy: a.taxonomy || "Ph\u1EE5 ki\u1EC7n",
      variants: [],
      periods: a.periodContext ? [a.periodContext] : ["Nhi\u1EC1u th\u1EDDi k\u1EF3"],
      geographicRegions: ["To\xE0n qu\u1ED1c"],
      locations: [],
      socialContext: a.userRole ? [a.userRole] : [],
      gender: ["C\u1EA3 hai"],
      genderScope,
      contexts: a.periodContext ? [a.periodContext] : [],
      constructionNotes: a.compatibilityLogic || "",
      layerRole: a.compatibilityLogic || "",
      warnings: "",
      researchNotes: aid === "A012" ? "C\u1EA7n x\xE1c \u0111\u1ECBnh lo\u1EA1i th\u1EBB b\xE0i c\u1EE5 th\u1EC3 tr\u01B0\u1EDBc khi l\u1EADp quy th\u1EE9c." : "",
      evidenceStatus: evidenceLevel,
      evidenceLabelVi: getEvidenceLabelVi(evidenceLevel),
      researchStatus,
      researchStatusLabelVi: getResearchStatusLabelVi(researchStatus),
      sourceIds: [],
      sources: [],
      image: getCanonicalEntityImage(aid, a.name),
      asItem
    });
  });
  return { entities, archivedEntities };
}
var { entities: builtEntities, archivedEntities: builtArchived } = buildCanonicalEntities();
var REMOVED_CANONICAL_IDS = /* @__PURE__ */ new Set(["G004", "G005", "G026", "G027", "G029"]);
var CANONICAL_ENTITIES = builtEntities;
var CANONICAL_ENTITIES_MAP = new Map(
  CANONICAL_ENTITIES.map((e) => [e.canonicalId, e])
);
var CURATED_CATALOG_ENTITIES = CANONICAL_ENTITIES.filter(
  (e) => e.researchStatus === "CURATED_CATALOG"
);
var RESEARCH_COLLECTION_ENTITIES = CANONICAL_ENTITIES.filter(
  (e) => e.researchStatus !== "CURATED_CATALOG"
);
var CANONICAL_STATS = {
  totalCanonical: CANONICAL_ENTITIES.length,
  curatedCount: CURATED_CATALOG_ENTITIES.length,
  researchCount: RESEARCH_COLLECTION_ENTITIES.length,
  verifiedImageCount: CANONICAL_ENTITIES.filter(
    (e) => e.image.imageType !== "NO_VERIFIED_IMAGE"
  ).length,
  pendingImageCount: CANONICAL_ENTITIES.filter(
    (e) => e.image.imageType === "NO_VERIFIED_IMAGE"
  ).length
};

// src/domain/dataAdapter.ts
function normalizeEvidenceLevel(rawLevel) {
  if (!rawLevel) return "UNKNOWN";
  const clean = rawLevel.trim().toUpperCase();
  if (clean.includes("VERIFIED")) return "VERIFIED";
  if (clean.includes("STRONG")) return "STRONGLY_SUPPORTED";
  if (clean.includes("CONSISTENT")) return "HISTORICALLY_CONSISTENT";
  if (clean.includes("CONTESTED")) return "CONTESTED";
  if (clean.includes("UNCERTAIN")) return "UNCERTAIN";
  if (clean.includes("REMIX")) return "REMIX";
  if (clean.includes("MISMATCH")) return "MISMATCH";
  if (clean.includes("NEEDS_RESEARCH")) return "NEEDS_RESEARCH";
  return "UNKNOWN";
}
function mapRelationToLabel(relationship) {
  if (!relationship) return "INSUFFICIENT_DATA";
  const rel = relationship.toUpperCase();
  if (rel.includes("MISMATCH")) return "CULTURAL_MISMATCH";
  if (rel.includes("MODERN_REMIX") || rel.includes("REMIX")) return "CONTEXTUAL_MODERN_REMIX";
  if (rel.includes("CORE_LAYER") || rel.includes("CORE_ACCESSORY") || rel.includes("CEREMONIAL_SET")) {
    return "AUTHENTIC";
  }
  if (rel.includes("HISTORICAL_TEXT_SUPPORT") || rel.includes("LABOR_DAILY") || rel.includes("REGIONAL") || rel.includes("CONTEXTUAL") || rel.includes("CONDITIONAL") || rel.includes("CORE_COMPONENT")) {
    return "HISTORICALLY_SUPPORTED";
  }
  return "INSUFFICIENT_DATA";
}
var RESEARCH_SOURCES = Viet_Phuc_Master_Research_v1_default.SOURCES || [];
var RESEARCH_SOURCES_MAP = RESEARCH_SOURCES.reduce((acc, src) => {
  acc[src.id] = src;
  return acc;
}, {});
var PDF_AUDIT_ITEMS = Viet_Phuc_Master_Research_v1_default.PDF_AUDIT || [];
var RESEARCH_QUEUE_ITEMS = Viet_Phuc_Master_Research_v1_default.RESEARCH_QUEUE || [];
var rawGarments = Viet_Phuc_Master_Research_v1_default.MASTER_GARMENTS || [];
var GARMENT_ITEMS = rawGarments.map((g, index) => {
  return {
    id: g.id || `G_${index + 1}`,
    name: g.name,
    aliases: g.aliases || [],
    category: g.category || "Kh\xE1c",
    period: g.period || [],
    region: g.region || [],
    gender: g.audience || [],
    genderScope: determineGenderScope(g.id || "", g.name, g.category || "", g.audience || []),
    context: g.context || [],
    construction: g.constructionNotes || "",
    layerRole: [g.category || "\xC1o th\xE2n tr\xEAn"],
    evidenceLevel: normalizeEvidenceLevel(g.evidenceLevel),
    culturalNotes: g.researchNotes || "",
    sourceIds: g.sourceIds || [],
    auditStatus: g.auditStatus || "CORE",
    warnings: g.warnings || "",
    raw: g
  };
});
var rawAccessories = Viet_Phuc_Master_Research_v1_default.ACCESSORIES || [];
var ACCESSORY_ITEMS = rawAccessories.map((a, index) => {
  const sources = a.source ? a.source.split(";").map((s) => s.trim()).filter((s) => s.startsWith("S")) : [];
  return {
    id: a.id || `A_${index + 1}`,
    name: a.name,
    aliases: [],
    category: a.taxonomy || "Ph\u1EE5 ki\u1EC7n",
    subcategory: a.taxonomy,
    period: a.periodContext ? [a.periodContext] : [],
    region: [],
    gender: a.userRole ? [a.userRole] : [],
    genderScope: determineGenderScope(a.id || "", a.name, a.taxonomy || "", a.userRole ? [a.userRole] : []),
    context: a.periodContext ? [a.periodContext] : [],
    construction: a.compatibilityLogic || "",
    layerRole: ["Ph\u1EE5 ki\u1EC7n"],
    evidenceLevel: normalizeEvidenceLevel(a.evidence),
    culturalNotes: a.compatibilityLogic || "",
    sourceIds: sources,
    auditStatus: a.status || "CORE",
    warnings: "",
    raw: a
  };
});
var ALL_ITEMS = [...GARMENT_ITEMS, ...ACCESSORY_ITEMS];
var ITEMS_MAP = new Map(
  ALL_ITEMS.map((item) => [item.id, item])
);
function findItemByNameOrAlias(query) {
  if (!query) return void 0;
  const q = query.toLowerCase().trim();
  return ALL_ITEMS.find((item) => {
    if (item.name.toLowerCase() === q) return true;
    if (item.id.toLowerCase() === q) return true;
    if (item.aliases?.some((a) => a.toLowerCase() === q)) return true;
    if (item.name.toLowerCase().includes(q) || q.includes(item.name.toLowerCase())) return true;
    return false;
  });
}
var rawRules = Viet_Phuc_Master_Research_v1_default.OUTFIT_RULES || [];
var COMPATIBILITY_RULES = rawRules.map((r, index) => {
  const itemA = findItemByNameOrAlias(r.baseGarment);
  const itemB = findItemByNameOrAlias(r.component);
  return {
    id: r.id || `R_${index + 1}`,
    itemAId: itemA ? itemA.id : r.baseGarmentSlug || r.baseGarment,
    itemBId: itemB ? itemB.id : r.component,
    relationshipType: r.relationship,
    label: mapRelationToLabel(r.relationship),
    conditions: {
      period: r.periodContext ? [r.periodContext] : [],
      context: r.periodContext ? [r.periodContext] : []
    },
    reason: r.whyEvidence || "",
    warning: r.whatToWarnAbout || "",
    evidenceLevel: normalizeEvidenceLevel(r.evidence),
    sourceIds: r.sourceIds || [],
    raw: r
  };
});
function extractActiveFacets(items = ALL_ITEMS) {
  const categories = /* @__PURE__ */ new Set();
  const periods = /* @__PURE__ */ new Set();
  const regions = /* @__PURE__ */ new Set();
  const audiences = /* @__PURE__ */ new Set();
  const contexts = /* @__PURE__ */ new Set();
  const evidenceLevels = /* @__PURE__ */ new Set();
  items.forEach((item) => {
    if (item.category && item.category.trim()) {
      categories.add(item.category.trim());
    }
    item.period?.forEach((p) => {
      if (p.trim()) periods.add(p.trim());
    });
    item.region?.forEach((r) => {
      if (r.trim()) regions.add(r.trim());
    });
    item.gender?.forEach((g) => {
      if (g.trim()) audiences.add(g.trim());
    });
    item.context?.forEach((c) => {
      if (c.trim()) contexts.add(c.trim());
    });
    if (item.evidenceLevel) {
      evidenceLevels.add(item.evidenceLevel);
    }
  });
  return {
    categories: Array.from(categories).sort(),
    periods: Array.from(periods).sort(),
    regions: Array.from(regions).sort(),
    audiences: Array.from(audiences).sort(),
    contexts: Array.from(contexts).sort(),
    evidenceLevels: Array.from(evidenceLevels).sort()
  };
}
var ACTIVE_CATALOG_FACETS = extractActiveFacets(ALL_ITEMS);

// src/domain/compatibilityEngine.ts
function evaluateOutfit(selectedItems) {
  if (!selectedItems || selectedItems.length === 0) {
    return {
      label: "INSUFFICIENT_DATA",
      summary: "Ch\u01B0a c\xF3 trang ph\u1EE5c n\xE0o trong b\u1ED9 ph\u1ED1i. H\xE3y ch\u1ECDn \xEDt nh\u1EA5t m\u1ED9t l\u1EDBp trang ph\u1EE5c ch\xEDnh.",
      evaluatedPairs: [],
      unmetConditions: ["C\u1EA7n ch\u1ECDn \xEDt nh\u1EA5t m\u1ED9t trang ph\u1EE5c th\xE2n tr\xEAn ho\u1EB7c b\u1ED9 ph\u1EE5c"],
      warnings: [],
      sourceIds: []
    };
  }
  if (selectedItems.length === 1) {
    const single = selectedItems[0];
    return {
      label: "INSUFFICIENT_DATA",
      summary: `\u0110\xE3 ch\u1ECDn ${single.name}. C\u1EA7n th\xEAm c\xE1c l\u1EDBp y ph\u1EE5c (l\u1EDBp l\xF3t, th\xE2n d\u01B0\u1EDBi, ph\u1EE5 ki\u1EC7n) \u0111\u1EC3 ho\xE0n ch\u1EC9nh t\u1ED5 h\u1EE3p.`,
      evaluatedPairs: [],
      unmetConditions: ["C\u1EA7n th\xEAm c\xE1c th\xE0nh ph\u1EA7n li\xEAn \u0111\u1EDBi \u0111\u1EC3 th\u1EA9m \u0111\u1ECBnh t\xEDnh \u0111\u1ED3ng b\u1ED9"],
      warnings: single.warnings ? [single.warnings] : [],
      sourceIds: single.sourceIds || []
    };
  }
  const evaluatedPairs = [];
  const warningsSet = /* @__PURE__ */ new Set();
  const unmetConditionsSet = /* @__PURE__ */ new Set();
  const allSourceIds = /* @__PURE__ */ new Set();
  const itemIds = new Set(selectedItems.map((i) => i.id));
  const hasVanKien = itemIds.has("G040") || itemIds.has("A001");
  const hasTuThan = itemIds.has("G010") || selectedItems.some((i) => i.name.includes("T\u1EE9 Th\xE2n"));
  const hasNguThan = itemIds.has("G008") || selectedItems.some((i) => i.name.includes("Ng\u0169 Th\xE2n"));
  const hasAoTac = itemIds.has("G009") || selectedItems.some((i) => i.name.includes("\xC1o T\u1EA5c"));
  const hasBoPhuc = itemIds.has("G016") || selectedItems.some((i) => i.name.includes("B\u1ED5 Ph\u1EE5c"));
  const hasLongBao = itemIds.has("G022") || selectedItems.some((i) => i.name.includes("Long B\xE0o"));
  const hasNhatBinh = itemIds.has("G018") || selectedItems.some((i) => i.name.includes("Nh\u1EADt B\xECnh"));
  const hasBaBa = itemIds.has("G028") || selectedItems.some((i) => i.name.includes("B\xE0 Ba"));
  const hasKhanRan = itemIds.has("G034") || selectedItems.some((i) => i.name.includes("Kh\u0103n R\u1EB1n"));
  const hasQuaiThao = itemIds.has("G036") || itemIds.has("G037") || selectedItems.some((i) => i.name.includes("Ba T\u1EA7m") || i.name.includes("Quai thao"));
  for (let i = 0; i < selectedItems.length; i++) {
    for (let j = i + 1; j < selectedItems.length; j++) {
      const a = selectedItems[i];
      const b = selectedItems[j];
      a.sourceIds?.forEach((s) => allSourceIds.add(s));
      b.sourceIds?.forEach((s) => allSourceIds.add(s));
      const matchedRule = COMPATIBILITY_RULES.find(
        (r) => r.itemAId === a.id && r.itemBId === b.id || r.itemAId === b.id && r.itemBId === a.id || r.raw && typeof r.raw === "object" && "baseGarment" in r.raw && "component" in r.raw && (r.raw.baseGarment.toLowerCase().includes(a.name.toLowerCase()) && r.raw.component.toLowerCase().includes(b.name.toLowerCase()) || r.raw.baseGarment.toLowerCase().includes(b.name.toLowerCase()) && r.raw.component.toLowerCase().includes(a.name.toLowerCase()))
      );
      if (matchedRule) {
        matchedRule.sourceIds?.forEach((s) => allSourceIds.add(s));
        if (matchedRule.warning) warningsSet.add(matchedRule.warning);
        evaluatedPairs.push({
          itemAId: a.id,
          itemBId: b.id,
          ruleId: matchedRule.id,
          label: matchedRule.label,
          reason: matchedRule.reason || `Ph\xF9 h\u1EE3p theo quy t\u1EAFc ${matchedRule.id}`,
          warning: matchedRule.warning,
          sourceIds: matchedRule.sourceIds || []
        });
        continue;
      }
      if (a.id === "G040" || a.id === "A001" || b.id === "G040" || b.id === "A001") {
        const other = a.id === "G040" || a.id === "A001" ? b : a;
        if (other.name.includes("T\u1EE9 Th\xE2n") || other.name.includes("B\xE0 Ba")) {
          warningsSet.add("V\xE2n ki\xEAn l\xE0 chi ti\u1EBFt ph\u1EA9m ph\u1EE5c cung \u0111\xECnh tri\u1EC1u Nguy\u1EC5n, xung \u0111\u1ED9t ho\xE0n to\xE0n khi g\u1EAFn v\xE0o trang ph\u1EE5c d\xE2n gian.");
          evaluatedPairs.push({
            itemAId: a.id,
            itemBId: b.id,
            ruleId: "R018",
            label: "CULTURAL_MISMATCH",
            reason: "Kh\xE1c h\u1EC7 ph\u1EE5c trang: V\xE2n ki\xEAn thu\u1ED9c ph\u1EA9m ph\u1EE5c cung \u0111\xECnh, kh\xF4ng ph\u1EA3i ph\u1EE5 ki\u1EC7n th\u1EDDi trang t\u1EF1 do.",
            warning: "C\u1EA3nh b\xE1o cultural mismatch nghi\xEAm tr\u1ECDng.",
            sourceIds: ["S01"]
          });
          continue;
        } else if (other.name.includes("Ng\u0169 Th\xE2n") && !other.name.includes("T\u1EA5c")) {
          warningsSet.add("V\xE2n ki\xEAn ch\u1EC9 \u0111\u01B0\u1EE3c ghi nh\u1EADn tr\xEAn m\u1ED9t s\u1ED1 ph\u1EA9m ph\u1EE5c/b\u1ED5 ph\u1EE5c c\u1EE5 th\u1EC3, kh\xF4ng auto-enable cho m\u1ECDi \xE1o ng\u0169 th\xE2n d\xE2n gian.");
          unmetConditionsSet.add("C\u1EA7n ch\u1EE9ng minh ph\u1EA9m h\xE0m qu\xFD t\u1ED9c/quan ch\u1EE9c \u0111\u1EC3 di\u1EC7n V\xE2n ki\xEAn v\u1EDBi \xE1o ng\u0169 th\xE2n.");
          evaluatedPairs.push({
            itemAId: a.id,
            itemBId: b.id,
            ruleId: "R019",
            label: "UNCERTAIN",
            reason: "Ch\u01B0a \u0111\u1EE7 b\u1EB1ng ch\u1EE9ng ph\u1EA9m h\xE0m \u0111\u1EC3 cho ph\xE9p V\xE2n ki\xEAn \u0111i c\xF9ng \xE1o ng\u0169 th\xE2n th\u01B0\u1EDDng nh\u1EADt.",
            warning: "C\u1EA7n x\xE1c \u0111\u1ECBnh th\xEAm b\u1ED1i c\u1EA3nh ph\u1EA9m c\u1EA5p tri\u1EC1u \u0111\xECnh.",
            sourceIds: ["S01"]
          });
          continue;
        } else if (hasBoPhuc || hasAoTac) {
          evaluatedPairs.push({
            itemAId: a.id,
            itemBId: b.id,
            ruleId: "R010",
            label: "HISTORICALLY_SUPPORTED",
            reason: "V\xE2n ki\xEAn \u0111i c\xF9ng \xE1o th\u1EDD / b\u1ED5 ph\u1EE5c / \xE1o t\u1EA5c cung \u0111\xECnh c\xF3 hi\u1EC7n v\u1EADt t\u1EA1i BTLSQG.",
            sourceIds: ["S01"]
          });
          continue;
        } else {
          unmetConditionsSet.add("V\xE2n ki\xEAn \u0111\xF2i h\u1ECFi \xE1o \u0111i k\xE8m ph\u1EA3i l\xE0 l\u1EC5 ph\u1EE5c cung \u0111\xECnh tri\u1EC1u Nguy\u1EC5n v\xE0 c\xF3 ph\u1EA9m tr\u1EADt x\xE1c \u0111\u1ECBnh.");
          evaluatedPairs.push({
            itemAId: a.id,
            itemBId: b.id,
            label: "INSUFFICIENT_DATA",
            reason: "C\u1EA7n x\xE1c \u0111\u1ECBnh th\xEAm b\u1ED1i c\u1EA3nh: V\xE2n ki\xEAn kh\xF4ng ph\u1EA3i trang s\u1EE9c t\u1EF1 do.",
            warning: "Ch\u1EC9 cho ph\xE9p khi garment + period + rank + context kh\u1EDBp.",
            sourceIds: ["S01"]
          });
          continue;
        }
      }
      if (hasTuThan && (a.id === "G034" || b.id === "G034") || hasBaBa && (hasQuaiThao || a.id === "G033" || b.id === "G033")) {
        warningsSet.add("Xung \u0111\u1ED9t kh\xF4ng gian v\u0103n h\xF3a v\xF9ng mi\u1EC1n: Kh\u0103n r\u1EB1n Nam B\u1ED9 c\u1ECDc c\u1EA1ch v\u1EDBi \xE1o T\u1EE9 th\xE2n B\u1EAFc B\u1ED9.");
        evaluatedPairs.push({
          itemAId: a.id,
          itemBId: b.id,
          ruleId: "R022",
          label: "CULTURAL_MISMATCH",
          reason: "Kh\xE1c bi\u1EC7t v\xF9ng mi\u1EC1n v\xE0 kh\xF4ng gian \u0111\u1ECBa v\u0103n h\xF3a l\u1ECBch s\u1EED.",
          warning: "Kh\xF4ng n\xEAn gh\xE9p ph\u1EE5 ki\u1EC7n Nam B\u1ED9 v\xE0o \xE1o truy\u1EC1n th\u1ED1ng Kinh B\u1EAFc.",
          sourceIds: ["S03"]
        });
        continue;
      }
      const periodsA = a.period || [];
      const periodsB = b.period || [];
      const isAncientOnlyA = periodsA.some((p) => p.includes("L\xFD") || p.includes("Tr\u1EA7n") || p.includes("\u0110\xF4ng S\u01A1n")) && !periodsA.some((p) => p.includes("Nguy\u1EC5n"));
      const isNguyenOnlyB = periodsB.some((p) => p.includes("Nguy\u1EC5n")) && !periodsB.some((p) => p.includes("L\xFD") || p.includes("Tr\u1EA7n"));
      if (isAncientOnlyA && isNguyenOnlyB || periodsA.some((p) => p.includes("Nguy\u1EC5n")) && periodsB.some((p) => p.includes("L\xFD") || p.includes("Tr\u1EA7n")) && !periodsB.some((p) => p.includes("Nguy\u1EC5n"))) {
        warningsSet.add(`L\u1EC7ch tri\u1EC1u \u0111\u1EA1i v\xE0 th\u1EDDi k\u1EF3 l\u1ECBch s\u1EED gi\u1EEFa ${a.name} v\xE0 ${b.name}.`);
        evaluatedPairs.push({
          itemAId: a.id,
          itemBId: b.id,
          ruleId: "R022",
          label: "CULTURAL_MISMATCH",
          reason: "Kh\xE1c bi\u1EC7t tri\u1EC1u \u0111\u1EA1i: Kh\xF4ng gh\xE9p ph\u1EE5 ki\u1EC7n/c\u1EA5u tr\xFAc c\u1EE7a Nguy\u1EC5n v\xE0o set L\xFD\u2013Tr\u1EA7n khi kh\xF4ng c\xF3 c\u01A1 s\u1EDF.",
          warning: "Hi\u1EC3n th\u1ECB period mismatch.",
          sourceIds: ["S01", "S02"]
        });
        continue;
      }
      const sharedContext = a.context?.some((c) => b.context?.includes(c));
      const sharedPeriod = a.period?.some((p) => b.period?.includes(p));
      if (sharedPeriod || sharedContext) {
        evaluatedPairs.push({
          itemAId: a.id,
          itemBId: b.id,
          label: "HISTORICALLY_SUPPORTED",
          reason: `Ph\xF9 h\u1EE3p v\u1EC1 b\u1ED1i c\u1EA3nh th\u1EDDi k\u1EF3/kh\xF4ng gian (${a.period?.[0] || "truy\u1EC1n th\u1ED1ng"}).`,
          sourceIds: [...a.sourceIds || [], ...b.sourceIds || []]
        });
      } else {
        evaluatedPairs.push({
          itemAId: a.id,
          itemBId: b.id,
          label: "INSUFFICIENT_DATA",
          reason: "Ch\u01B0a c\xF3 quy t\u1EAFc \u0111\u1ED1i chi\u1EBFu tr\u1EF1c ti\u1EBFp trong Master Research v1.",
          sourceIds: []
        });
      }
    }
  }
  if (hasTuThan) {
    if (!itemIds.has("G011")) {
      unmetConditionsSet.add("\xC1o T\u1EE9 Th\xE2n truy\u1EC1n th\u1ED1ng c\xF3 Y\u1EBFm (G011) l\xE0 l\u1EDBp trong c\u1ED1t l\xF5i.");
    }
    if (!itemIds.has("G012")) {
      unmetConditionsSet.add("\xC1o T\u1EE9 Th\xE2n truy\u1EC1n th\u1ED1ng m\u1EB7c c\xF9ng V\xE1y \u0111\u1EE5p (G012) l\xE0m trang ph\u1EE5c th\xE2n d\u01B0\u1EDBi.");
    }
    if (!itemIds.has("G042") && !itemIds.has("A004")) {
      unmetConditionsSet.add("\xC1o T\u1EE9 Th\xE2n c\u1EA7n Th\u1EAFt l\u01B0ng / D\u1EA3i bao l\u1EE5a (G042/A004) \u0111\u1EC3 gi\u1EEF n\u1EBFp v\u1EA1t \xE1o.");
    }
  }
  if (hasNguThan) {
    if (!itemIds.has("G013")) {
      unmetConditionsSet.add("\xC1o Ng\u0169 Th\xE2n th\u01B0\u1EDDng m\u1EB7c c\xF9ng Qu\u1EA7n \u1ED1ng r\u1ED9ng s\xE1ng m\xE0u (G013) theo ngu\u1ED3n B\u1EA3o t\xE0ng Ph\u1EE5 n\u1EEF Nam B\u1ED9.");
    }
  }
  if (hasLongBao) {
    if (!itemIds.has("G044") && !itemIds.has("A007")) {
      unmetConditionsSet.add("Long b\xE0o \u0111\u1EA1i tri\u1EC1u nguy\xEAn b\u1ED9 c\u1EA7n H\u1ED1t ng\u1ECDc (G044/A007), M\u0169 C\u1EEDu Long, \u0110ai v\xE0 Hia.");
    }
  }
  let overallLabel = "AUTHENTIC";
  const hasMismatch = evaluatedPairs.some((p) => p.label === "CULTURAL_MISMATCH");
  const hasRemix = evaluatedPairs.some((p) => p.label === "CONTEXTUAL_MODERN_REMIX");
  const hasUncertain = evaluatedPairs.some((p) => p.label === "UNCERTAIN") || selectedItems.some((i) => i.evidenceLevel === "UNCERTAIN" || i.evidenceLevel === "CONTESTED");
  const hasInsufficient = evaluatedPairs.some((p) => p.label === "INSUFFICIENT_DATA") || unmetConditionsSet.size > 0;
  if (hasMismatch) {
    overallLabel = "CULTURAL_MISMATCH";
  } else if (hasRemix) {
    overallLabel = "CONTEXTUAL_MODERN_REMIX";
  } else if (hasUncertain) {
    overallLabel = "UNCERTAIN";
  } else if (hasInsufficient) {
    overallLabel = "INSUFFICIENT_DATA";
  } else if (evaluatedPairs.every((p) => p.label === "AUTHENTIC")) {
    overallLabel = "AUTHENTIC";
  } else {
    overallLabel = "HISTORICALLY_SUPPORTED";
  }
  let summary = "";
  switch (overallLabel) {
    case "CULTURAL_MISMATCH":
      summary = "Ph\xE1t hi\u1EC7n s\u1EF1 kh\xF4ng ph\xF9 h\u1EE3p r\xF5 r\u1EC7t v\u1EC1 th\u1EDDi k\u1EF3, quy ch\u1EBF ph\u1EA9m h\xE0m ho\u1EB7c kh\xF4ng gian v\u0103n h\xF3a gi\u1EEFa c\xE1c m\xF3n \u0111\u1ED3.";
      break;
    case "CONTEXTUAL_MODERN_REMIX":
      summary = "B\u1ED9 ph\u1ED1i theo phong c\xE1ch Hi\u1EC7n \u0111\u1EA1i H\xF3a (Modern Remix). Mang t\xEDnh s\xE1ng t\u1EA1o c\xE1 nh\xE2n, kh\xF4ng xem l\xE0 ph\u1EE5c d\u1EF1ng l\u1ECBch s\u1EED nguy\xEAn b\u1EA3n.";
      break;
    case "UNCERTAIN":
      summary = "T\u1ED5 h\u1EE3p ch\u1EE9a c\xE1c th\xE0nh ph\u1EA7n \u0111ang trong qu\xE1 tr\xECnh tranh lu\u1EADn h\u1ECDc thu\u1EADt ho\u1EB7c ch\u01B0a \u0111\u1EE7 ch\u1EE9ng c\u1EE9 \u0111\u1ED1i chi\u1EBFu (v\xED d\u1EE5: T\u1EE9 \u0110i\xEAn, n\xF3n Ba T\u1EA7m).";
      break;
    case "INSUFFICIENT_DATA":
      summary = "T\u1ED5 h\u1EE3p c\xF2n thi\u1EBFu m\u1ED9t s\u1ED1 l\u1EDBp y ph\u1EE5c c\u1ED1t l\xF5i ho\u1EB7c b\u1ED1i c\u1EA3nh c\u1EA7n thi\u1EBFt theo quy th\u1EE9c ghi nh\u1EADn trong t\u01B0 li\u1EC7u.";
      break;
    case "AUTHENTIC":
      summary = "T\u1ED5 h\u1EE3p y ph\u1EE5c chu\u1EA9n m\u1EF1c, \u0111\u1EA7y \u0111\u1EE7 c\xE1c l\u1EDBp v\xE0 chi ti\u1EBFt \u0111\xE3 \u0111\u01B0\u1EE3c x\xE1c th\u1EF1c qua t\u01B0 li\u1EC7u hi\u1EC7n v\u1EADt b\u1EA3o t\xE0ng.";
      break;
    case "HISTORICALLY_SUPPORTED":
      summary = "T\u1ED5 h\u1EE3p h\xF2a h\u1EE3p v\xE0 ph\xF9 h\u1EE3p v\u1EDBi c\xE1c ngu\u1ED3n t\u01B0 li\u1EC7u l\u1ECBch s\u1EED hi\u1EC7n c\xF3.";
      break;
    default:
      summary = "\u0110ang th\u1EA9m \u0111\u1ECBnh t\u1ED5 h\u1EE3p trang ph\u1EE5c.";
  }
  return {
    label: overallLabel,
    summary,
    evaluatedPairs,
    unmetConditions: Array.from(unmetConditionsSet),
    warnings: Array.from(warningsSet),
    sourceIds: Array.from(allSourceIds)
  };
}

// src/domain/advisorEngine.ts
var ACTIVE_ITEMS_MAP = /* @__PURE__ */ new Map();
CANONICAL_ENTITIES.forEach((e) => {
  if (!REMOVED_CANONICAL_IDS.has(e.primaryRecordId)) {
    ACTIVE_ITEMS_MAP.set(e.primaryRecordId, e.asItem);
  }
});
function resolveRecommendation(rawRec) {
  const validItems = [];
  const validIds = [];
  for (const id of rawRec.itemIds) {
    if (REMOVED_CANONICAL_IDS.has(id)) {
      continue;
    }
    const item = ACTIVE_ITEMS_MAP.get(id) || ITEMS_MAP.get(id);
    if (item && !REMOVED_CANONICAL_IDS.has(item.id)) {
      if (!validIds.includes(item.id)) {
        validIds.push(item.id);
        validItems.push(item);
      }
    }
  }
  if (validItems.length === 0) {
    return null;
  }
  const evaluation = evaluateOutfit(validItems);
  return {
    id: rawRec.id || `rec_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`,
    title: rawRec.title,
    itemIds: validIds,
    items: validItems,
    evaluation,
    whySuits: rawRec.whySuits,
    stylingColorNotes: rawRec.stylingColorNotes,
    comfortNotes: rawRec.comfortNotes,
    culturalEvidenceStatus: rawRec.culturalEvidenceStatus || evaluation.label,
    warnings: rawRec.warnings || (evaluation.warnings.length > 0 ? evaluation.warnings.join("; ") : void 0)
  };
}
var STUDENT_CULTURAL_EVENT_RECS = [
  {
    title: "\xC1o Ng\u0169 Th\xE2n Tay Ch\u1EBDn N\u0103ng \u0110\u1ED9ng (Nam/N\u1EEF)",
    itemIds: ["G008", "G013", "G031", "G047"],
    whySuits: "Phom d\xE1ng ng\u0169 th\xE2n l\u1ECBch thi\u1EC7p, tay ch\u1EBDn g\u1ECDn g\xE0ng, k\xEDn \u0111\xE1o, c\u1EF1c k\u1EF3 ph\xF9 h\u1EE3p cho m\xF4i tr\u01B0\u1EDDng h\u1ECDc \u0111\u01B0\u1EDDng v\xE0 c\xE1c ho\u1EA1t \u0111\u1ED9ng giao l\u01B0u v\u0103n h\xF3a thanh ni\xEAn.",
    stylingColorNotes: "Khuy\xEAn ch\u1ECDn s\u1EAFc xanh lam g\u1ED1m, v\xE0ng m\u1EE1 g\xE0 ho\u1EB7c tr\u1EAFng be; ph\u1ED1i c\xF9ng kh\u0103n x\u1EBFp \u0111en/lam v\xE0 gu\u1ED1c m\u1ED9c thanh nh\xE3.",
    comfortNotes: "Tay \xE1o may ch\u1EBDn v\u1EEBa v\u1EB7n gi\xFAp c\u1EED \u0111\u1ED9ng vi\u1EBFt v\u1EBD, giao ti\u1EBFp d\u1EC5 d\xE0ng; m\u1EB7c tho\u1EA3i m\xE1i su\u1ED1t 4\u20136 ti\u1EBFng trong khu\xF4n vi\xEAn tr\u01B0\u1EDDng.",
    culturalEvidenceStatus: "HISTORICALLY_SUPPORTED",
    warnings: "Tr\xE1nh ch\u1ECDn m\xE0u s\u1EAFc qu\xE1 ph\xF4 tr\u01B0\u01A1ng ho\u1EB7c v\u1EA3i l\u1EA5p l\xE1nh ph\u1EA3n quang; n\xEAn d\xF9ng v\u1EA3i l\u1EE5a t\u01A1, \u0111\u0169i ho\u1EB7c th\xF4 t\u1EF1 nhi\xEAn."
  },
  {
    title: "\xC1o T\u1EE9 Th\xE2n Kinh B\u1EAFc Duy\xEAn D\xE1ng (N\u1EEF)",
    itemIds: ["G010", "G011", "G012", "G042", "G033"],
    whySuits: "Mang \u0111\u1EADm d\u1EA5u \u1EA5n d\xE2n gian \u0111\u1ED3ng b\u1EB1ng B\u1EAFc B\u1ED9, ph\xF9 h\u1EE3p cho c\xE1c ti\u1EBFt m\u1EE5c v\u0103n ngh\u1EC7, gian h\xE0ng v\u0103n h\xF3a ho\u1EB7c ng\xE0y h\u1ED9i Vi\u1EC7t ph\u1EE5c h\u1ECDc sinh - sinh vi\xEAn.",
    stylingColorNotes: "\xC1o t\u1EE9 th\xE2n m\xE0u n\xE2u tr\u1EA7m ho\u1EB7c ch\xE0m nh\u1EB9 bu\xF4ng v\u1EA1t, h\xE9 l\u1ED9 y\u1EBFm \u0111\xE0o ho\u1EB7c y\u1EBFm hoa sen b\xEAn trong, th\u1EAFt l\u01B0ng l\u1EE5a xanh/h\u1ED3ng bu\xF4ng r\u1EE7.",
    comfortNotes: "V\u1EA1t \xE1o bu\u1ED9c nh\u1EB9 tr\u01B0\u1EDBc b\u1EE5ng t\u1EA1o \u0111\u1ED9 \xF4m t\u1EF1 nhi\xEAn, v\xE1y \u0111\u1EE5p \u0111en x\xF2e r\u1ED9ng ti\u1EC7n b\u01B0\u1EDBc \u0111i.",
    culturalEvidenceStatus: "HISTORICALLY_SUPPORTED",
    warnings: "L\u01B0u \xFD kh\xF4ng gh\xE9p ph\u1EE5 ki\u1EC7n cung \u0111\xECnh nh\u01B0 V\xE2n Ki\xEAn v\xE0o \xE1o T\u1EE9 Th\xE2n \u0111\u1EC3 gi\u1EEF v\u1EB9n nguy\xEAn t\xEDnh d\xE2n gian."
  },
  {
    title: "\xC1o B\xE0 Ba Nam B\u1ED9 Ph\xF3ng Kho\xE1ng (Nam/N\u1EEF)",
    itemIds: ["G028", "G034", "G047"],
    whySuits: "L\u1EF1a ch\u1ECDn m\u1ED9c m\u1EA1c, g\u1EA7n g\u0169i, n\u0103ng \u0111\u1ED9ng cho c\xE1c ho\u1EA1t \u0111\u1ED9ng ngo\u1EA1i kh\xF3a, h\u1ED9i tr\u1EA1i hay tr\xF2 ch\u01A1i d\xE2n gian t\u1EA1i tr\u01B0\u1EDDng.",
    stylingColorNotes: "Gam m\xE0u \u0111en, n\xE2u \u0111\u1EA5t ho\u1EB7c t\xEDm than truy\u1EC1n th\u1ED1ng; \u0111i\u1EC3m xuy\u1EBFt chi\u1EBFc kh\u0103n r\u1EB1n s\u1ECDc \u0111en tr\u1EAFng qu\xE0ng c\u1ED5.",
    comfortNotes: "Ch\u1EA5t v\u1EA3i m\xE1t, th\u1EA5m h\xFAt m\u1ED3 h\xF4i t\u1ED1t, \u0111\u1ED9 b\u1EC1n cao, l\xFD t\u01B0\u1EDFng cho c\u1EA3 ng\xE0y ho\u1EA1t \u0111\u1ED9ng ngo\xE0i tr\u1EDDi.",
    culturalEvidenceStatus: "HISTORICALLY_SUPPORTED"
  }
];
var HERITAGE_VISIT_PHOTO_RECS = [
  {
    title: "\xC1o T\u1EA5c L\u1EC5 Ph\u1EE5c Trang Tr\u1ECDng (Nam/N\u1EEF)",
    itemIds: ["G009", "G013", "G031", "A011"],
    whySuits: "\xC1o T\u1EA5c (\xE1o ng\u0169 th\xE2n tay th\u1EE5ng) l\xE0 l\u1EC5 ph\u1EE5c chu\u1EA9n m\u1EF1c tri\u1EC1u Nguy\u1EC5n. T\xE0 \xE1o th\u1EE5ng r\u1ED9ng bu\xF4ng d\xE0i t\u1EA1o \u0111\u1ED9 bay b\u1ED5ng m\u1EF9 mi\u1EC1u khi ch\u1EE5p \u1EA3nh t\u1EA1i c\xE1c kh\xF4ng gian c\u1ED5 k\xEDnh nh\u01B0 V\u0103n Mi\u1EBFu, Ho\xE0ng th\xE0nh hay ch\xF9a chi\u1EC1n.",
    stylingColorNotes: "S\u1EAFc \u0111\u1ECF \u0111i\u1EC1u, xanh thi\xEAn thanh ho\u1EB7c v\xE0ng qu\xFD t\u1ED9c; ph\u1ED1i c\xF9ng qu\u1EA7n tr\u1EAFng r\u1ED9ng s\xE1ng m\xE0u, kh\u0103n \u0111\xF3ng ch\u1EC9nh t\u1EC1 v\xE0 qu\u1EA1t l\u1EE5a c\u1ED5 c\u1EA7m tay.",
    comfortNotes: "Tay th\u1EE5ng d\xE0i c\u1EA7n v\xE9n nh\u1EB9 khi th\u1EAFp h\u01B0\u01A1ng hay di chuy\u1EC3n qua l\u1ED1i h\u1EB9p; th\xEDch h\u1EE3p d\u1EA1o ng\u1EAFm ch\u1EE5p \u1EA3nh t\u1EEB 2\u20133 ti\u1EBFng.",
    culturalEvidenceStatus: "AUTHENTIC",
    warnings: "Khi v\xE0o gian th\u1EDD t\xF4n nghi\xEAm, n\xEAn gi\u1EEF t\xE0 \xE1o bu\xF4ng th\u1EA3 trang tr\u1ECDng, tr\xE1nh bu\u1ED9c v\u1EA1t t\xF9y ti\u1EC7n."
  },
  {
    title: "\xC1o Nh\u1EADt B\xECnh Cung \u0110\xECnh Hu\u1EBF (N\u1EEF)",
    itemIds: ["G018", "G013", "G032", "G046"],
    whySuits: "Ph\u1EA9m ph\u1EE5c qu\xFD ph\xE1i c\u1EE7a m\u1EC7nh ph\u1EE5 v\xE0 h\u1EADu phi tri\u1EC1u Nguy\u1EC5n v\u1EDBi d\u1EA3i c\u1ED5 ch\u1EEF nh\u1EADt r\u1EF1c r\u1EE1 v\xE0 d\u1EA3i ng\u0169 s\u1EAFc ng\u0169 h\xE0nh \u1EDF c\u1ED5 tay, t\xF4n l\xEAn v\u1EBB \u0111\xE0i c\xE1c khi ch\u1EE5p \u1EA3nh t\u1EA1i di t\xEDch ki\u1EBFn tr\xFAc c\u1ED5.",
    stylingColorNotes: "Hoa v\u0103n loan ph\u01B0\u1EE3ng tr\xEAn n\u1EC1n v\u1EA3i g\u1EA5m sa; ph\u1ED1i c\xF9ng kh\u0103n v\xE0nh d\xE2y qu\u1EA5n \u0111\u1EC1u \u0111\u1EB7n v\xE0 h\xE0i th\xEAu hoa sen.",
    comfortNotes: "Trang ph\u1EE5c trang tr\u1ECDng nhi\u1EC1u l\u1EDBp, n\xEAn ch\u1ECDn ng\xE0y th\u1EDDi ti\u1EBFt d\u1ECBu m\xE1t v\xE0 c\xF3 ng\u01B0\u1EDDi h\u1ED7 tr\u1EE3 ch\u1EC9nh n\u1EBFp \xE1o khi l\xEAn h\xECnh.",
    culturalEvidenceStatus: "AUTHENTIC",
    warnings: "\xC1o Nh\u1EADt B\xECnh c\xF3 quy th\u1EE9c hoa v\u0103n nghi\xEAm ng\u1EB7t; kh\xF4ng n\xEAn t\u1EF1 \xFD ph\u1ED1i c\xF9ng c\xE1c ph\u1EE5 ki\u1EC7n ngo\u1EA1i lai."
  },
  {
    title: "\xC1o Giao L\u0129nh C\u1ED5 K\xEDnh Th\u1EDDi L\xEA (Nam/N\u1EEF)",
    itemIds: ["G001", "G013", "G047"],
    whySuits: "D\xE1ng \xE1o v\u1EA1t ch\xE9o giao l\u0129nh c\u1ED5 k\xEDnh th\u1EDDi L\xFD - Tr\u1EA7n - L\xEA, t\u1EA1o n\xEAn chi\u1EC1u s\xE2u l\u1ECBch s\u1EED \u0111\u1ED9c \u0111\xE1o cho b\u1ED9 \u1EA3nh t\u1EA1i c\xE1c di ch\u1EC9 kh\u1EA3o c\u1ED5 hay \u0111\u1EC1n \u0111\xECnh c\u1ED5 truy\u1EC1n.",
    stylingColorNotes: "Gam m\xE0u tr\u1EA7m m\u1ED9c nh\u01B0 x\xE1m tro, n\xE2u tr\xE0 ho\u1EB7c lam tr\u1EA7m \u0111\u1EC3 l\xE0m n\u1ED5i b\u1EADt \u0111\u01B0\u1EDDng n\xE9t v\u1EA1t ch\xE9o thanh nh\xE3.",
    comfortNotes: "Phom d\xE1ng r\u1ED9ng r\xE3i, tho\xE1ng m\xE1t, d\u1EC5 ch\u1ECBu khi t\u1EA3n b\u1ED9 th\u0103m th\xFA.",
    culturalEvidenceStatus: "HISTORICALLY_SUPPORTED"
  }
];
var WEDDING_GUEST_RECS = [
  {
    title: "\xC1o Ng\u0169 Th\xE2n Tay Ch\u1EBDn L\u1EE5a G\u1EA5m Nh\xE3 Nh\u1EB7n (Nam/N\u1EEF)",
    itemIds: ["G008", "G013", "G031", "G046"],
    whySuits: "V\u1EEBa \u0111\u1EE7 trang tr\u1ECDng \u0111\u1EC3 t\xF4n tr\u1ECDng ng\xE0y vui c\u1EE7a gia ch\u1EE7, v\u1EEBa gi\u1EEF s\u1EF1 ch\u1EEBng m\u1EF1c thanh l\u1ECBch, kh\xF4ng l\u1EA5n \xE1t trang ph\u1EE5c c\u1EE7a c\xF4 d\xE2u ch\xFA r\u1EC3.",
    stylingColorNotes: "Gam m\xE0u tao nh\xE3: h\u1ED3ng ph\u1EA5n, xanh ng\u1ECDc, xanh r\xEAu ho\u1EB7c be v\xE0ng; d\u1EC7t hoa v\u0103n ch\xECm tinh t\u1EBF, \u0111i k\xE8m h\xE0i th\xEAu \xEAm ch\xE2n.",
    comfortNotes: "\u0110\u1ED9 \xF4m v\u1EEBa v\u1EB7n, ng\u1ED3i d\u1EF1 ti\u1EC7c hay ch\xFAc r\u01B0\u1EE3u \u0111\u1EC1u tho\u1EA3i m\xE1i, thanh tho\xE1t.",
    culturalEvidenceStatus: "HISTORICALLY_SUPPORTED",
    warnings: "Kh\xE1ch m\u1EDDi kh\xF4ng n\xEAn ch\u1ECDn trang ph\u1EE5c th\xEAu r\u1ED3ng ph\u01B0\u1EE3ng \u0111\u1EA1i l\u1EC5 hay s\u1EAFc \u0111\u1ECF r\u1EF1c nguy\xEAn c\xE2y \u0111\u1EC3 nh\u01B0\u1EDDng t\xE2m \u0111i\u1EC3m cho \u0111\xF4i t\xE2n lang t\xE2n n\u01B0\u01A1ng."
  },
  {
    title: "\xC1o D\xE0i D\xE1ng X\u01B0a L\u1ECBch Thi\u1EC7p (Nam/N\u1EEF)",
    itemIds: ["G030", "G047"],
    whySuits: "L\u1EF1a ch\u1ECDn an to\xE0n, ph\u1ED5 bi\u1EBFn v\xE0 t\xF4n d\xE1ng cho m\u1ECDi \u0111\u1ED9 tu\u1ED5i khi tham d\u1EF1 h\xF4n l\u1EC5 truy\u1EC1n th\u1ED1ng ho\u1EB7c ti\u1EC7c c\u01B0\u1EDBi hi\u1EC7n \u0111\u1EA1i.",
    stylingColorNotes: "M\xE0u ph\u1EA5n nh\u1EA1t, xanh ng\u1ECDc b\xEDch ho\u1EB7c tr\u1EAFng kem \u0111i\u1EC3m hoa v\u0103n tao nh\xE3.",
    comfortNotes: "D\u1EC5 d\xE0ng di chuy\u1EC3n, b\u01B0\u1EDBc l\xEAn xe v\xE0 \u0111\u1EE9ng tr\xF2 chuy\u1EC7n su\u1ED1t bu\u1ED5i l\u1EC5.",
    culturalEvidenceStatus: "HISTORICALLY_SUPPORTED"
  },
  {
    title: "\xC1o T\u1EA5c T\u01A1 T\u1EB1m Tr\u1EBB Trung (Nam/N\u1EEF)",
    itemIds: ["G009", "G013", "G031"],
    whySuits: "D\xE0nh cho kh\xE1ch m\u1EDDi th\xE2n thi\u1EBFt mu\u1ED1n th\u1EC3 hi\u1EC7n s\u1EF1 tr\xE2n tr\u1ECDng \u0111\u1EB7c bi\u1EC7t v\u1EDBi ng\xE0y tr\u1ECDng \u0111\u1EA1i mang phong c\xE1ch c\u1ED5 truy\u1EC1n.",
    stylingColorNotes: "M\xE0u xanh l\u1EE5c nh\u1EA1t, v\xE0ng m\u1EE1 g\xE0 ho\u1EB7c lam nh\u1EA1t, kh\xF4ng tr\xF9ng s\u1EAFc \u0111\u1ECF \u0111\u1EA1i l\u1EC5 c\u1EE7a c\xF4 d\xE2u ch\xFA r\u1EC3.",
    comfortNotes: "N\xEAn ch\u1ECDn ch\u1EA5t li\u1EC7u t\u01A1 t\u1EB1m m\u1EC1m r\u0169, nh\u1EB9 nh\xE0ng.",
    culturalEvidenceStatus: "AUTHENTIC",
    warnings: "TUY\u1EC6T \u0110\u1ED0I KH\xD4NG m\u1EB7c Long B\xE0o (G022) hay Ph\u01B0\u1EE3ng Ph\u1EE5c \u0111\u1EA1i l\u1EC5 khi \u0111i d\u1EF1 c\u01B0\u1EDBi ng\u01B0\u1EDDi kh\xE1c."
  }
];
var CASUAL_OUTING_RECS = [
  {
    title: "\xC1o B\xE0 Ba C\xE1ch \u0110i\u1EC7u D\u1EA1o Ph\u1ED1 (Nam/N\u1EEF)",
    itemIds: ["G028", "G047", "G034"],
    whySuits: "V\u1EBB \u0111\u1EB9p dung d\u1ECB, t\u1EF1 nhi\xEAn, mang l\u1EA1i c\u1EA3m gi\xE1c th\u01B0 th\xE1i tuy\u1EC7t \u0111\u1ED1i khi ng\u1ED3i c\xE0 ph\xEA tr\xF2 chuy\u1EC7n c\xF9ng b\u1EA1n b\xE8 hay d\u1EA1o ph\u1ED1 \u0111i b\u1ED9.",
    stylingColorNotes: "Ch\u1EA5t li\u1EC7u lanh, \u0111\u0169i m\u1ED9c m\u1EA1c m\xE0u n\xE2u \u0111\u1EA5t, be h\u1EA1t d\u1EBB ho\u1EB7c xanh pastel nh\u1EB9 nh\xE0ng.",
    comfortNotes: "C\u1ED5 \xE1o kho\xE9t tr\xF2n tho\xE1ng m\xE1t, x\u1EBB t\xE0 hai b\xEAn h\xF4ng t\u1EA1o s\u1EF1 linh ho\u1EA1t khi \u0111\u1EE9ng ng\u1ED3i.",
    culturalEvidenceStatus: "HISTORICALLY_SUPPORTED"
  },
  {
    title: "\xC1o Ng\u0169 Th\xE2n \u0110\u0169i Bu\xF4ng Nh\u1EB9 Nh\xE0ng (Nam/N\u1EEF)",
    itemIds: ["G008", "G013", "G047"],
    whySuits: "Ph\u1ED1i ki\u1EC3u th\u01B0\u1EDDng ph\u1EE5c tho\u1EA3i m\xE1i: \xE1o ng\u0169 th\xE2n tay ch\u1EBDn may b\u1EB1ng v\u1EA3i \u0111\u0169i m\u1EC1m bu\xF4ng nh\u1EB9 c\xF9ng qu\u1EA7n \u1ED1ng r\u1ED9ng, kh\xF4ng c\u1EA7n \u0111\u1ED9i kh\u0103n x\u1EBFp.",
    stylingColorNotes: "T\xF4ng m\xE0u c\xE1t ch\xE1y, x\xE1m tro ho\u1EB7c tr\u1EAFng ng\xE0 m\u1ED9c m\u1EA1c; k\u1EBFt h\u1EE3p gu\u1ED1c m\u1ED9c thanh \xE2m l\xE1ch c\xE1ch \u0111\u1EB7c tr\u01B0ng.",
    comfortNotes: "M\u1EC1m m\u1EA1i, th\u1EA5m h\xFAt m\u1ED3 h\xF4i t\u1ED1t, l\xFD t\u01B0\u1EDFng cho nh\u1EEFng bu\u1ED5i chi\u1EC1u th\u01B0 gi\xE3n cu\u1ED1i tu\u1EA7n.",
    culturalEvidenceStatus: "HISTORICALLY_SUPPORTED"
  }
];
var CULTURAL_GIFT_SUGGESTIONS = [
  {
    id: "gift_quat_lua",
    name: "Qu\u1EA1t L\u1EE5a V\u1EBD C\u1ED5 Truy\u1EC1n (A011)",
    itemOrCategory: "A011",
    canonicalItemId: "A011",
    culturalMeaning: "Bi\u1EC3u tr\u01B0ng cho phong th\xE1i nho nh\xE3, tri th\u1EE9c v\xE0 l\xE0n gi\xF3 an l\xE0nh, thanh t\u1ECBnh trong m\u1EF9 h\u1ECDc ph\u01B0\u01A1ng \u0110\xF4ng.",
    suitableFor: "B\u1EA1n b\xE8 qu\u1ED1c t\u1EBF, \u0111\u1ED1i t\xE1c ngo\u1EA1i giao, th\u1EA7y c\xF4 gi\xE1o ho\u1EB7c ng\u01B0\u1EDDi y\xEAu ngh\u1EC7 thu\u1EADt truy\u1EC1n th\u1ED1ng.",
    budgetLevel: "V\u1EEBa ph\u1EA3i (kho\u1EA3ng 250.000\u0111 \u2013 600.000\u0111 t\xF9y \u0111\u1ED9 tinh x\u1EA3o nan tre v\xE0 n\xE9t v\u1EBD)",
    notes: "M\xF3n qu\xE0 g\u1ECDn nh\u1EB9, d\u1EC5 \u0111\xF3ng h\u1ED9p mang \u0111i n\u01B0\u1EDBc ngo\xE0i; gi\u1EA3i th\xEDch r\xF5 \u0111\xE2y l\xE0 s\u1EA3n ph\u1EA9m th\u1EE7 c\xF4ng m\u1EF9 ngh\u1EC7 \u0111\u01B0\u01A1ng \u0111\u1EA1i l\u1EA5y c\u1EA3m h\u1EE9ng t\u1EEB th\u01B0 t\u1ECBch c\u1ED5."
  },
  {
    id: "gift_khan_ran",
    name: "Kh\u0103n R\u1EB1n D\u1EC7t Th\u1EE7 C\xF4ng Nam B\u1ED9 (G034)",
    itemOrCategory: "G034",
    canonicalItemId: "G034",
    culturalMeaning: "Bi\u1EC3u t\u01B0\u1EE3ng c\u1EE7a t\xEDnh c\xE1ch ch\xE2n ph\u01B0\u01A1ng, b\u1EC1n b\u1EC9, \xE2n t\xECnh v\xE0 l\xF2ng hi\u1EBFu kh\xE1ch c\u1EE7a ng\u01B0\u1EDDi d\xE2n ph\u01B0\u01A1ng Nam.",
    suitableFor: "B\u1EA1n b\xE8 ph\u01B0\u01A1ng xa, kh\xE1ch du l\u1ECBch, qu\xE0 t\u1EB7ng t\u1EADp th\u1EC3 ho\u1EB7c thanh ni\xEAn tr\u1EBB th\xEDch x\xEA d\u1ECBch.",
    budgetLevel: "Ti\u1EBFt ki\u1EC7m (kho\u1EA3ng 80.000\u0111 \u2013 180.000\u0111 cho d\xF2ng d\u1EC7t s\u1EE3i b\xF4ng t\u1EF1 nhi\xEAn)",
    notes: "C\xF3 t\xEDnh \u1EE9ng d\u1EE5ng h\xE0ng ng\xE0y cao (che n\u1EAFng, th\u1EA5m m\u1ED3 h\xF4i, qu\xE0ng c\u1ED5 gi\u1EEF \u1EA5m)."
  },
  {
    id: "gift_non_bai_tho",
    name: "N\xF3n B\xE0i Th\u01A1 X\u1EE9 Hu\u1EBF (G038)",
    itemOrCategory: "G038",
    canonicalItemId: "G038",
    culturalMeaning: "K\u1EBFt tinh n\xE9t thi v\u1ECB, k\xEDn \u0111\xE1o c\u1EE7a ng\u01B0\u1EDDi con g\xE1i s\xF4ng H\u01B0\u01A1ng; soi l\xEAn \xE1nh s\xE1ng s\u1EBD th\u1EA5y \u1EA9n hi\u1EC7n c\xE2u th\u01A1 v\xE0 nh\xE0nh tr\xFAc.",
    suitableFor: "Ph\u1EE5 n\u1EEF, m\u1EB9, c\xF4 gi\xE1o, ng\u01B0\u1EDDi th\xE2n n\u1EEF gi\u1EDBi nh\xE2n d\u1ECBp k\u1EF7 ni\u1EC7m, sinh nh\u1EADt ho\u1EB7c 8/3.",
    budgetLevel: "H\u1EE3p l\xFD (kho\u1EA3ng 150.000\u0111 \u2013 350.000\u0111)",
    notes: "C\u1EA7n b\u1EA3o qu\u1EA3n n\u01A1i kh\xF4 r\xE1o, tr\xE1nh va \u0111\u1EADp m\u1EA1nh l\xE0m m\xF3p l\xE1 g\xE2n n\xF3n."
  },
  {
    id: "gift_tram_cai_toc",
    name: "Tr\xE2m C\xE0i T\xF3c M\u1EF9 Ngh\u1EC7 (G041)",
    itemOrCategory: "G041",
    canonicalItemId: "G041",
    culturalMeaning: "M\xF3n t\xEDn v\u1EADt \u0111\xE0i c\xE1c, ch\xFAc cho v\u1EBB \u0111\u1EB9p \u0111\u1EB1m th\u1EAFm, nhu thu\u1EADn v\xE0 duy\xEAn d\xE1ng theo th\u1EDDi gian.",
    suitableFor: "B\u1EA1n g\xE1i, ng\u01B0\u1EDDi y\xEAu, b\u1EA1n b\xE8 n\u1EEF th\xEDch b\xFAi t\xF3c v\xE0 di\u1EC7n trang ph\u1EE5c truy\u1EC1n th\u1ED1ng.",
    budgetLevel: "\u0110a d\u1EA1ng (kho\u1EA3ng 150.000\u0111 cho tr\xE2m g\u1ED7 kh\u1EA3m x\xE0 c\u1EEB \u0111\u1EBFn 800.000\u0111 cho tr\xE2m b\u1EA1c ch\u1EA1m l\u1ED9ng)",
    notes: "\u0110\u01B0\u1EE3c ch\u1EBF t\xE1c t\u1EEB g\u1ED7 qu\xFD, s\u1EEBng ho\u1EB7c b\u1EA1c m\u1EF9 ngh\u1EC7 \u0111\u01B0\u01A1ng \u0111\u1EA1i."
  },
  {
    id: "gift_hai_theu",
    name: "H\xE0i Th\xEAu Hoa Sen Truy\u1EC1n Th\u1ED1ng (G046)",
    itemOrCategory: "G046",
    canonicalItemId: "G046",
    culturalMeaning: "Bi\u1EC3u tr\u01B0ng cho t\u1EEBng b\u01B0\u1EDBc ch\xE2n nh\u1EB9 nh\xE0ng, thanh tao nh\u01B0 \u0111\xF3a sen tinh khi\u1EBFt n\u1EDF gi\u1EEFa \u0111\u1EDDi th\u01B0\u1EDDng.",
    suitableFor: "C\xF4 d\xE2u trong l\u1EC5 \u0111\xEDnh h\xF4n, ng\u01B0\u1EDDi th\xE2n di\u1EC7n l\u1EC5 T\u1EBFt ho\u1EB7c di\u1EC5n vi\xEAn k\u1ECBch h\xE1t truy\u1EC1n th\u1ED1ng.",
    budgetLevel: "Trung cao (kho\u1EA3ng 350.000\u0111 \u2013 750.000\u0111 cho m\u0169i h\xE0i th\xEAu tay t\u1EC9 m\u1EC9)",
    notes: "C\u1EA7n bi\u1EBFt ch\xEDnh x\xE1c c\u1EE1 ch\xE2n ng\u01B0\u1EDDi nh\u1EADn tr\u01B0\u1EDBc khi ch\u1ECDn \u0111\u1EB7t may."
  }
];
function generateAdvisorResponse(userQuery, userDate, _location) {
  const queryLower = (userQuery || "").toLowerCase();
  const dateStr = userDate || (/* @__PURE__ */ new Date()).toLocaleDateString("vi-VN", {
    weekday: "long",
    day: "2-digit",
    month: "2-digit",
    year: "numeric"
  });
  const isGiftQuery = (queryLower.includes("qu\xE0") || queryLower.includes("t\u1EB7ng") || queryLower.includes("gift") || queryLower.includes("mua k\u1EF7 ni\u1EC7m") || queryLower.includes("\u0111\u1ED3 l\u01B0u ni\u1EC7m")) && !queryLower.includes("ch\u1EE5p \u1EA3nh") && !queryLower.includes("ch\u1EE5p h\xECnh");
  if (isGiftQuery) {
    return {
      message: `Ch\xE0o b\u1EA1n, g\u1EEDi t\u1EB7ng m\u1ED9t m\xF3n qu\xE0 mang phong v\u1ECB v\u0103n h\xF3a Vi\u1EC7t Nam l\xE0 c\xE1ch r\u1EA5t tao nh\xE3 \u0111\u1EC3 trao g\u1EEDi t\xE2m t\xECnh. D\u01B0\u1EDBi \u0111\xE2y l\xE0 c\xE1c g\u1EE3i \xFD qu\xE0 t\u1EB7ng \u0111\u01B0\u1EE3c ch\u1EAFt l\u1ECDc t\u1EEB di s\u1EA3n th\u1EE7 c\xF4ng truy\u1EC1n th\u1ED1ng:`,
      quickActions: [
        "Qu\xE0 t\u1EB7ng cho b\u1EA1n qu\u1ED1c t\u1EBF",
        "Qu\xE0 t\u1EB7ng ng\xE2n s\xE1ch d\u01B0\u1EDBi 300k",
        "G\u1EE3i \xFD trang ph\u1EE5c h\xF4m nay",
        "Gi\u1EA3i th\xEDch ngu\u1ED3n t\u01B0 li\u1EC7u"
      ],
      giftSuggestions: CULTURAL_GIFT_SUGGESTIONS,
      dateContext: dateStr,
      sourcesCited: [
        { id: "S01", title: "Ng\xE0n N\u0103m \xC1o M\u0169", institution: "Tr\u1EA7n Quang \u0110\u1EE9c (NXB Th\u1EBF Gi\u1EDBi)" },
        { id: "S03", title: "Trang Ph\u1EE5c Vi\u1EC7t Nam", institution: "B\u1EA1ch Th\xE1i B\u01B0\u1EDFi / Vi\u1EC7n M\u1EF9 Thu\u1EADt" }
      ]
    };
  }
  if (queryLower.includes("tr\u01B0\u1EDDng") || queryLower.includes("sinh vi\xEAn") || queryLower.includes("h\u1ECDc sinh") || queryLower.includes("ng\xE0y h\u1ED9i") || queryLower.includes("h\u1ED9i tr\u1EA1i") || queryLower.includes("clb") || queryLower.includes("v\u0103n ngh\u1EC7")) {
    const resolvedRecs = STUDENT_CULTURAL_EVENT_RECS.map((r) => resolveRecommendation(r)).filter(
      (r) => Boolean(r)
    );
    return {
      message: `Ch\xE0o b\u1EA1n! Tham gia ng\xE0y h\u1ED9i v\u0103n h\xF3a t\u1EA1i tr\u01B0\u1EDDng h\u1ECDc l\xE0 d\u1ECBp tuy\u1EC7t v\u1EDDi \u0111\u1EC3 di\u1EC7n Vi\u1EC7t Ph\u1EE5c. Ti\xEAu ch\xED quan tr\u1ECDng nh\u1EA5t l\xE0 l\u1ECBch s\u1EF1, chu\u1EA9n m\u1EF1c h\u1ECDc \u0111\u01B0\u1EDDng nh\u01B0ng v\u1EABn tho\u1EA3i m\xE1i di chuy\u1EC3n v\xE0 ho\u1EA1t \u0111\u1ED9ng su\u1ED1t ng\xE0y d\xE0i (${dateStr}). D\u01B0\u1EDBi \u0111\xE2y l\xE0 3 ph\u01B0\u01A1ng \xE1n l\xFD t\u01B0\u1EDFng t\u1EEB T\u1EE7 \xC1o X\u01B0a:`,
      quickActions: [
        "Ph\u1ED1i b\u1ED9 \xC1o Ng\u0169 Th\xE2n",
        "Ph\u1ED1i b\u1ED9 \xC1o T\u1EE9 Th\xE2n",
        "T\xECm \u0111\u1ED3 \u0111i ch\u1EE5p \u1EA3nh",
        "G\u1EE3i \xFD qu\xE0 t\u1EB7ng"
      ],
      recommendations: resolvedRecs,
      dateContext: dateStr,
      sourcesCited: [
        { id: "S01", title: "Ng\xE0n N\u0103m \xC1o M\u0169", institution: "Tr\u1EA7n Quang \u0110\u1EE9c (NXB Th\u1EBF Gi\u1EDBi)" },
        { id: "S02", title: "\u0110\u1EA1i Nam Th\u1EF1c L\u1EE5c", institution: "Qu\u1ED1c S\u1EED Qu\xE1n Tri\u1EC1u Nguy\u1EC5n" }
      ]
    };
  }
  if (queryLower.includes("ch\u1EE5p \u1EA3nh") || queryLower.includes("di t\xEDch") || queryLower.includes("ho\xE0ng th\xE0nh") || queryLower.includes("v\u0103n mi\u1EBFu") || queryLower.includes("hu\u1EBF") || queryLower.includes("h\u1ED9i an") || queryLower.includes("ch\xF9a") || queryLower.includes("\u0111\u1EC1n") || queryLower.includes("tham quan") || queryLower.includes("check in")) {
    const resolvedRecs = HERITAGE_VISIT_PHOTO_RECS.map((r) => resolveRecommendation(r)).filter(
      (r) => Boolean(r)
    );
    return {
      message: `Ch\xE0o b\u1EA1n! Khi \u0111\u1EBFn th\u0103m c\xE1c kh\xF4ng gian di t\xEDch l\u1ECBch s\u1EED v\xE0 ch\u1EE5p \u1EA3nh l\u01B0u ni\u1EC7m (${dateStr}), trang ph\u1EE5c c\u1EA7n \u0111\u1EA1t s\u1EF1 t\xF4n nghi\xEAm n\u01A1i c\u1EEDa di s\u1EA3n \u0111\u1ED3ng th\u1EDDi t\u1EA1o hi\u1EC7u \u1EE9ng th\u1ECB gi\xE1c thanh tho\xE1t, c\u1ED5 k\xEDnh tr\u01B0\u1EDBc \u1ED1ng k\xEDnh:`,
      quickActions: [
        "Ph\u1ED1i b\u1ED9 \xC1o T\u1EA5c",
        "Ph\u1ED1i b\u1ED9 \xC1o Nh\u1EADt B\xECnh",
        "G\u1EE3i \xFD trang ph\u1EE5c h\xF4m nay",
        "Gi\u1EA3i th\xEDch ngu\u1ED3n t\u01B0 li\u1EC7u"
      ],
      recommendations: resolvedRecs,
      dateContext: dateStr,
      sourcesCited: [
        { id: "S01", title: "Ng\xE0n N\u0103m \xC1o M\u0169", institution: "Tr\u1EA7n Quang \u0110\u1EE9c (NXB Th\u1EBF Gi\u1EDBi)" },
        { id: "S02", title: "Kh\xE2m \u0110\u1ECBnh \u0110\u1EA1i Nam H\u1ED9i \u0110i\u1EC3n S\u1EF1 L\u1EC7", institution: "N\u1ED9i C\xE1c Tri\u1EC1u Nguy\u1EC5n" }
      ]
    };
  }
  if (queryLower.includes("c\u01B0\u1EDBi") || queryLower.includes("h\xF4n l\u1EC5") || queryLower.includes("ti\u1EC7c c\u01B0\u1EDBi") || queryLower.includes("\u0103n c\u01B0\u1EDBi") || queryLower.includes("\u0111\xE1m c\u01B0\u1EDBi")) {
    const resolvedRecs = WEDDING_GUEST_RECS.map((r) => resolveRecommendation(r)).filter(
      (r) => Boolean(r)
    );
    return {
      message: `Ch\xE0o b\u1EA1n! \u0110i d\u1EF1 \u0111\xE1m c\u01B0\u1EDBi b\u1EB1ng trang ph\u1EE5c truy\u1EC1n th\u1ED1ng l\xE0 m\u1ED9t ngh\u0129a c\u1EED r\u1EA5t trang tr\u1ECDng v\xE0 \u0111\u1EADm \u0111\xE0 b\u1EA3n s\u1EAFc. Nguy\xEAn t\u1EAFc v\xE0ng cho kh\xE1ch m\u1EDDi l\xE0 nh\xE3 nh\u1EB7n, t\xF4n nghi\xEAm, tr\xE1nh m\u1EB7c s\u1EAFc \u0111\u1ECF \u0111\u1EA1i l\u1EC5 r\u1EF1c r\u1EE1 \u0111\u1EC3 nh\u01B0\u1EDDng t\xE2m \u0111i\u1EC3m cho c\xF4 d\xE2u ch\xFA r\u1EC3:`,
      quickActions: [
        "Ph\u1ED1i b\u1ED9 \xC1o Ng\u0169 Th\xE2n l\u1EE5a",
        "Ph\u1ED1i b\u1ED9 \xC1o D\xE0i hi\u1EC7n \u0111\u1EA1i",
        "G\u1EE3i \xFD qu\xE0 t\u1EB7ng m\u1EEBng c\u01B0\u1EDBi",
        "Gi\u1EA3i th\xEDch ngu\u1ED3n t\u01B0 li\u1EC7u"
      ],
      recommendations: resolvedRecs,
      dateContext: dateStr,
      sourcesCited: [
        { id: "S01", title: "Ng\xE0n N\u0103m \xC1o M\u0169", institution: "Tr\u1EA7n Quang \u0110\u1EE9c (NXB Th\u1EBF Gi\u1EDBi)" },
        { id: "S04", title: "B\u1EA3o t\xE0ng L\u1ECBch s\u1EED Qu\u1ED1c gia", institution: "BTLSQG Vi\u1EC7t Nam" }
      ]
    };
  }
  if (queryLower.includes("d\u1EA1o ph\u1ED1") || queryLower.includes("c\xE0 ph\xEA") || queryLower.includes("cu\u1ED1i tu\u1EA7n") || queryLower.includes("tho\u1EA3i m\xE1i") || queryLower.includes("nh\u1EB9 nh\xE0ng") || queryLower.includes("h\xF4m nay") || queryLower.includes("b\xECnh th\u01B0\u1EDDng") || queryLower.includes("casual")) {
    const resolvedRecs = CASUAL_OUTING_RECS.map((r) => resolveRecommendation(r)).filter(
      (r) => Boolean(r)
    );
    return {
      message: `Ch\xE0o b\u1EA1n! Cho nh\u1EEFng k\u1EBF ho\u1EA1ch d\u1EA1o ph\u1ED1, g\u1EB7p g\u1EE1 b\u1EA1n b\xE8 hay ng\u1ED3i c\xE0 ph\xEA th\u01B0 gi\xE3n (${dateStr}), ch\xFAng m\xECnh \u01B0u ti\xEAn \u0111\u1ED9 nh\u1EB9 m\xE1t, phom d\xE1ng bay b\u1ED5ng v\xE0 c\u1EED \u0111\u1ED9ng linh ho\u1EA1t:`,
      quickActions: [
        "Ph\u1ED1i b\u1ED9 \xC1o B\xE0 Ba",
        "Ph\u1ED1i b\u1ED9 Ng\u0169 Th\xE2n v\u1EA3i \u0111\u0169i",
        "T\xECm \u0111\u1ED3 \u0111i ch\u1EE5p \u1EA3nh",
        "G\u1EE3i \xFD qu\xE0 t\u1EB7ng"
      ],
      recommendations: resolvedRecs,
      dateContext: dateStr,
      sourcesCited: [
        { id: "S01", title: "Ng\xE0n N\u0103m \xC1o M\u0169", institution: "Tr\u1EA7n Quang \u0110\u1EE9c" },
        { id: "S03", title: "Trang Ph\u1EE5c Vi\u1EC7t Nam", institution: "Vi\u1EC7n M\u1EF9 Thu\u1EADt" }
      ]
    };
  }
  if (queryLower.includes("ngu\u1ED3n") || queryLower.includes("t\u01B0 li\u1EC7u") || queryLower.includes("s01") || queryLower.includes("s02") || queryLower.includes("tr\u1EA7n quang \u0111\u1EE9c") || queryLower.includes("b\u1EB1ng ch\u1EE9ng") || queryLower.includes("ch\u1EE9ng c\u1EE9")) {
    const sources = Object.values(RESEARCH_SOURCES_MAP).slice(0, 4);
    return {
      message: `T\xE0ng Y x\xE2y d\u1EF1ng h\u1EC7 th\u1ED1ng quy th\u1EE9c v\xE0 th\u1EA9m \u0111\u1ECBnh y ph\u1EE5c d\u1EF1a tr\xEAn c\xE1c t\xE0i li\u1EC7u kh\u1EA3o c\u1EE9u l\u1ECBch s\u1EED v\xE0 hi\u1EC7n v\u1EADt b\u1EA3o t\xE0ng ch\xEDnh th\u1ED1ng. Ch\xFAng m\xECnh tuy\u1EC7t \u0111\u1ED1i kh\xF4ng d\xF9ng AI \u0111\u1EC3 t\u1EF1 phong "chu\u1EA9n m\u1EF1c l\u1ECBch s\u1EED" m\xE0 lu\xF4n b\xE1m s\xE1t ngu\u1ED3n d\u1EABn:`,
      quickActions: [
        "G\u1EE3i \xFD trang ph\u1EE5c h\xF4m nay",
        "T\xECm \u0111\u1ED3 \u0111i ch\u1EE5p \u1EA3nh",
        "G\u1EE3i \xFD qu\xE0 t\u1EB7ng",
        "Ph\u1ED1i b\u1ED9 n\xE0y"
      ],
      sourcesCited: sources.map((s) => ({
        id: s.id,
        title: s.title,
        institution: s.institution
      })),
      dateContext: dateStr
    };
  }
  const defaultRecs = STUDENT_CULTURAL_EVENT_RECS.slice(0, 2).map((r) => resolveRecommendation(r)).filter(
    (r) => Boolean(r)
  );
  return {
    message: `Ch\xE0o b\u1EA1n! H\xF4m nay (${dateStr}), b\u1EA1n \u0111ang c\xF3 k\u1EBF ho\u1EA1ch \u0111i \u0111\xE2u hay tham d\u1EF1 s\u1EF1 ki\u1EC7n g\xEC? B\u1EA1n c\xF3 th\u1EC3 chia s\u1EBB ng\u1EAFn g\u1ECDn:
\u2022 D\u1ECBp tham d\u1EF1 (ng\xE0y h\u1ED9i tr\u01B0\u1EDDng, \u0111i ch\xF9a/di t\xEDch, \u0111\xE1m c\u01B0\u1EDBi, d\u1EA1o ph\u1ED1, ch\u1EE5p \u1EA3nh...)
\u2022 Phong c\xE1ch mong mu\u1ED1n (thanh nh\xE3, truy\u1EC1n th\u1ED1ng c\u1ED5 \u0111i\u1EC3n hay c\xE1ch t\xE2n tr\u1EBB trung)
\u2022 Gi\u1EDBi h\u1EA1n c\u1EA7n l\u01B0u \xFD (th\u1EDDi gian m\u1EB7c, th\u1EDDi ti\u1EBFt, \u0111\u1ED9 tho\u1EA3i m\xE1i di chuy\u1EC3n)

Ho\u1EB7c ch\u1ECDn nhanh m\u1ED9t trong c\xE1c g\u1EE3i \xFD d\u01B0\u1EDBi \u0111\xE2y \u0111\u1EC3 T\xE0ng Y t\u01B0 v\u1EA5n ngay nh\xE9:`,
    quickActions: [
      "G\u1EE3i \xFD trang ph\u1EE5c h\xF4m nay",
      "T\xECm \u0111\u1ED3 \u0111i ch\u1EE5p \u1EA3nh di t\xEDch",
      "Trang ph\u1EE5c d\u1EF1 \u0111\xE1m c\u01B0\u1EDBi",
      "\u0110\u1ED3 tho\u1EA3i m\xE1i d\u1EA1o ph\u1ED1 c\xE0 ph\xEA",
      "G\u1EE3i \xFD qu\xE0 t\u1EB7ng v\u0103n h\xF3a"
    ],
    recommendations: defaultRecs,
    dateContext: dateStr
  };
}

// src/domain/tryOnPipeline.ts
var GARMENT_IMAGE_ASSET_MAP = {
  G001: "tu_ao_ao_giao_linh_1791540421433.jpg",
  G002: "tu_ao_truc_linh_1791590575147.jpg",
  G003: "tu_ao_doi_kham_1791590587462.jpg",
  G006: "tu_ao_vien_linh_1791590597639.jpg",
  G007: "ao_tu_dien_1791596749479.jpg",
  G008: "tu_ao_ao_ngu_than_1791540362301.jpg",
  G009: "tu_ao_ao_tac_1791590607100.jpg",
  G010: "tu_ao_ao_tu_than_1791540316824.jpg",
  G011: "tu_ao_yem_dao_1791590619474.jpg",
  G012: "tu_ao_vay_dup_1791591661475.jpg",
  G013: "tu_ao_quan_trang_1791591672868.jpg",
  G014: "tu_ao_quan_la_toa_1791593055198.jpg",
  G015: "tu_ao_kho_dan_gian_1791593067158.jpg",
  G016: "tu_ao_bo_phuc_1791591685057.jpg",
  G017: "tu_ao_bo_tu_1791592305808.jpg",
  G018: "tu_ao_ao_nhat_binh_1791540457083.jpg",
  G019: "ao_menh_phu_1791596761598.jpg",
  G020: "tu_ao_mang_bao_1791592317711.jpg",
  G021: "tu_ao_mang_lan_1791593078866.jpg",
  G022: "tu_ao_long_bao_1791541769402.jpg",
  G023: "tu_ao_hoang_bao_1791591697522.jpg",
  G024: "tu_ao_con_phuc_1791593088539.jpg",
  G025: "tu_ao_phuong_phuc_1791591709330.jpg",
  G028: "tu_ao_ao_ba_ba_1791540391970.jpg",
  G030: "tu_ao_ao_dai_1791540293823.jpg",
  G031: "tu_ao_khan_xep_1791591919738.jpg",
  G032: "tu_ao_khan_vanh_day_1791541857698.jpg",
  G033: "tu_ao_khan_mo_qua_1791591931180.jpg",
  G034: "tu_ao_khan_ran_1791541960369.jpg",
  G035: "tu_ao_non_la_1791591940904.jpg",
  G036: "tu_ao_non_ba_tam_1791541813772.jpg",
  G037: "tu_ao_non_thung_1791593237981.jpg",
  G038: "tu_ao_non_bai_tho_1791592327797.jpg",
  G039: "tu_ao_mu_canh_chuon_1791591950697.jpg",
  G040: "tu_ao_van_kien_1791592339952.jpg",
  G041: "tu_ao_tram_cai_toc_1791593137036.jpg",
  G042: "tu_ao_dai_that_lung_1791593101752.jpg",
  G043: "tu_ao_day_ruot_tuong_1791593147548.jpg",
  G044: "tu_ao_the_hot_quan_1791593160009.jpg",
  G045: "tu_ao_hia_quan_1791592350888.jpg",
  G046: "tu_ao_hai_theu_1791541907877.jpg",
  G047: "tu_ao_guoc_moc_1791591962889.jpg",
  A011: "tu_ao_quat_lua_co_1791593170321.jpg",
  A012: "tu_ao_the_bai_quan_1791593182172.jpg"
};
var BASE_MODEL_ASSET_MAP = {
  female: "female_base_model_1791456212298.jpg",
  male: "male_base_model_1791456224566.jpg"
};
function validateTryOnInputs(input, apiKey, isAssetAvailable) {
  if (!apiKey || apiKey.trim() === "" || apiKey === "MY_GEMINI_API_KEY") {
    return {
      valid: false,
      status: 503,
      errorType: "NO_API_KEY",
      error: "Ch\u01B0a c\u1EA5u h\xECnh GEMINI_API_KEY tr\xEAn m\xE1y ch\u1EE7. Vui l\xF2ng thi\u1EBFt l\u1EADp kh\xF3a API trong m\u1EE5c Settings > Secrets."
    };
  }
  const targetIds = Array.isArray(input.selectedItemIds) && input.selectedItemIds.length > 0 ? input.selectedItemIds : input.referenceItemId ? [input.referenceItemId] : [];
  if (targetIds.length === 0) {
    return {
      valid: false,
      status: 400,
      errorType: "MISSING_SELECTION",
      error: "Vui l\xF2ng ch\u1ECDn \xEDt nh\u1EA5t m\u1ED9t trang ph\u1EE5c ho\u1EB7c ph\u1EE5 ki\u1EC7n tr\u01B0\u1EDBc khi y\xEAu c\u1EA7u t\u1EA1o \u1EA3nh."
    };
  }
  const gender = input.gender === "male" ? "male" : "female";
  const baseModelFilename = BASE_MODEL_ASSET_MAP[gender];
  if (!isAssetAvailable(baseModelFilename)) {
    return {
      valid: false,
      status: 404,
      errorType: "MISSING_BASE_MODEL",
      error: `Kh\xF4ng t\xECm th\u1EA5y t\u1EC7p \u1EA3nh ng\u01B0\u1EDDi m\u1EABu c\u01A1 s\u1EDF (${baseModelFilename}) tr\xEAn h\u1EC7 th\u1ED1ng.`
    };
  }
  const missingErrors = [];
  const resolvedAssets = [];
  for (const id of targetIds) {
    const filename = GARMENT_IMAGE_ASSET_MAP[id];
    if (!filename) {
      missingErrors.push(`M\xE3 trang ph\u1EE5c "${id}" ch\u01B0a c\xF3 \xE1nh x\u1EA1 t\u1EC7p t\u01B0 li\u1EC7u tham chi\u1EBFu`);
      continue;
    }
    if (!isAssetAvailable(filename)) {
      missingErrors.push(
        `Kh\xF4ng t\xECm th\u1EA5y t\u1EC7p t\u01B0 li\u1EC7u "${filename}" tr\xEAn \u0111\u0129a cho th\u1EF1c th\u1EC3 "${id}"`
      );
      continue;
    }
    const mimeType = filename.endsWith(".png") ? "image/png" : "image/jpeg";
    resolvedAssets.push({ id, filename, mimeType });
  }
  if (missingErrors.length > 0) {
    return {
      valid: false,
      status: 422,
      errorType: "MISSING_REFERENCE_IMAGE",
      error: `Thi\u1EBFu t\u01B0 li\u1EC7u h\xECnh \u1EA3nh tham chi\u1EBFu b\u1EAFt bu\u1ED9c: ${missingErrors.join("; ")}.`
    };
  }
  const mode = input.mode || (targetIds.length === 1 ? "single_item_try_on" : "complete_outfit_try_on");
  return {
    valid: true,
    targetIds,
    mode,
    gender,
    baseModelFilename,
    itemAssets: resolvedAssets
  };
}
function sanitizeErrorMessage(message, apiKey) {
  let cleaned = String(message || "");
  if (apiKey && apiKey.length > 4) {
    cleaned = cleaned.split(apiKey).join("[REDACTED]");
  }
  cleaned = cleaned.replace(/AIza[0-9A-Za-z-_]{35}/g, "[REDACTED_API_KEY]");
  cleaned = cleaned.replace(/Bearer\s+[A-Za-z0-9\-._~+/]+=*/gi, "Bearer [REDACTED_TOKEN]");
  return cleaned;
}
function classifyGeminiError(err, apiKey) {
  const rawMsg = String(err?.message || err || "");
  const sanitized = sanitizeErrorMessage(rawMsg, apiKey);
  const lower = sanitized.toLowerCase();
  const statusCode = Number(err?.status || err?.statusCode || 0);
  const errorCode = String(err?.code || err?.error?.code || "");
  const isQuota = statusCode === 429 || errorCode === "RESOURCE_EXHAUSTED" || lower.includes("429") || lower.includes("resource_exhausted") || lower.includes("quota") || lower.includes("rate limit") || lower.includes("too many requests") || lower.includes("limit exceeded");
  const isFreeTierZero = lower.includes("limit: 0") || lower.includes("free_tier") || lower.includes("plan and billing") || lower.includes("billing details");
  if (isQuota) {
    if (isFreeTierZero) {
      return {
        status: 429,
        errorType: "PAID_PLAN_REQUIRED",
        messageVi: "M\xF4 h\xECnh t\u1EA1o \u1EA3nh AI (gemini-3.1-flash-lite-image) y\xEAu c\u1EA7u kh\xF3a API tr\u1EA3 ph\xED (Paid API key / billing plan). D\u1EF1 \xE1n hi\u1EC7n kh\xF4ng c\xF3 h\u1EA1n m\u1EE9c mi\u1EC5n ph\xED (limit: 0) cho m\xF4 h\xECnh n\xE0y. Vui l\xF2ng thi\u1EBFt l\u1EADp ho\u1EB7c ch\u1ECDn kh\xF3a API tr\u1EA3 ph\xED trong m\u1EE5c Settings > Secrets.",
        sanitizedDetails: sanitized,
        isPaidPlanRequired: true
      };
    }
    return {
      status: 429,
      errorType: "QUOTA_EXCEEDED",
      messageVi: 'H\u1EA1n m\u1EE9c t\u1EA1o \u1EA3nh AI (Gemini Nano Banana) hi\u1EC7n \u0111ang ch\u1EA1m gi\u1EDBi h\u1EA1n ho\u1EB7c t\u1EA1m th\u1EDDi b\u1EADn. Vui l\xF2ng b\u1EA5m "Th\u1EED l\u1EA1i" sau gi\xE2y l\xE1t.',
      sanitizedDetails: sanitized
    };
  }
  const isAuth = statusCode === 401 || statusCode === 403 || errorCode === "PERMISSION_DENIED" || errorCode === "UNAUTHENTICATED" || lower.includes("api_key_invalid") || lower.includes("api key not valid") || lower.includes("permission_denied") || lower.includes("unauthenticated") || lower.includes("forbidden") || lower.includes("unauthorized") || lower.includes("invalid api key") || lower.includes("key is invalid");
  if (isAuth) {
    return {
      status: 403,
      errorType: "INVALID_API_KEY",
      messageVi: "Kh\xF3a API Gemini kh\xF4ng h\u1EE3p l\u1EC7 ho\u1EB7c kh\xF4ng c\xF3 quy\u1EC1n truy c\u1EADp m\xF4 h\xECnh t\u1EA1o \u1EA3nh. Vui l\xF2ng ki\u1EC3m tra l\u1EA1i c\u1EA5u h\xECnh API key trong Settings > Secrets.",
      sanitizedDetails: sanitized
    };
  }
  const isModelUnavailable = statusCode === 404 || errorCode === "NOT_FOUND" || lower.includes("model") && (lower.includes("not found") || lower.includes("not supported") || lower.includes("not available") || lower.includes("unsupported") || lower.includes("does not exist"));
  if (isModelUnavailable) {
    return {
      status: 502,
      errorType: "MODEL_UNAVAILABLE",
      messageVi: "M\xF4 h\xECnh t\u1EA1o \u1EA3nh (gemini-3.1-flash-lite-image) t\u1EA1m th\u1EDDi kh\xF4ng kh\u1EA3 d\u1EE5ng. Vui l\xF2ng th\u1EED l\u1EA1i sau.",
      sanitizedDetails: sanitized
    };
  }
  const isNetwork = statusCode === 504 || lower.includes("etimedout") || lower.includes("econnreset") || lower.includes("fetch failed") || lower.includes("timeout") || lower.includes("socket hang up") || lower.includes("deadline_exceeded") || lower.includes("network error");
  if (isNetwork) {
    return {
      status: 504,
      errorType: "NETWORK_TIMEOUT",
      messageVi: 'K\u1EBFt n\u1ED1i m\u1EA1ng t\u1EDBi d\u1ECBch v\u1EE5 Gemini b\u1ECB gi\xE1n \u0111o\u1EA1n ho\u1EB7c qu\xE1 th\u1EDDi gian ch\u1EDD. Vui l\xF2ng b\u1EA5m "Th\u1EED l\u1EA1i".',
      sanitizedDetails: sanitized
    };
  }
  return {
    status: 502,
    errorType: "API_ERROR",
    messageVi: `L\u1ED7i k\u1EBFt n\u1ED1i d\u1ECBch v\u1EE5 t\u1EA1o \u1EA3nh Gemini: ${sanitized || "Y\xEAu c\u1EA7u kh\xF4ng th\xE0nh c\xF4ng"}. Vui l\xF2ng b\u1EA5m "Th\u1EED l\u1EA1i".`,
    sanitizedDetails: sanitized
  };
}
function extractGeminiImageResponse(response) {
  let foundImage = null;
  let textParts = [];
  const candidates = response?.candidates;
  if (Array.isArray(candidates)) {
    for (const candidate of candidates) {
      const parts = candidate?.content?.parts;
      if (Array.isArray(parts)) {
        for (const part of parts) {
          if (part?.inlineData?.data) {
            foundImage = {
              data: part.inlineData.data,
              mimeType: part.inlineData.mimeType || "image/jpeg"
            };
            break;
          } else if (part?.text) {
            textParts.push(part.text.trim());
          }
        }
      }
      if (foundImage) break;
    }
  }
  if (foundImage) {
    return {
      ok: true,
      imageUrl: `data:${foundImage.mimeType};base64,${foundImage.data}`,
      mimeType: foundImage.mimeType,
      base64Data: foundImage.data
    };
  }
  return {
    ok: false,
    errorType: "NO_IMAGE_DATA",
    returnedText: textParts.join(" ").trim()
  };
}

// server.ts
var __filename = fileURLToPath(import.meta.url);
var __dirname = path.dirname(__filename);
function getGeminiClient() {
  const key = process.env.GEMINI_API_KEY || "";
  if (!key || key.trim() === "" || key === "MY_GEMINI_API_KEY") {
    return { client: null, apiKey: "" };
  }
  return {
    client: new GoogleGenAI({
      apiKey: key,
      httpOptions: {
        headers: {
          "User-Agent": "aistudio-build"
        }
      }
    }),
    apiKey: key
  };
}
async function startServer() {
  const app = express();
  const isProd = process.env.NODE_ENV === "production";
  const PORT = isProd && process.env.PORT ? Number(process.env.PORT) : 3e3;
  const distPath = path.resolve(__dirname, "dist");
  app.use(express.json());
  app.use("/public/assets", express.static(path.resolve(__dirname, "public/assets")));
  app.use("/assets", express.static(path.resolve(__dirname, "public/assets")));
  app.get("/api/health", (_req, res) => {
    const { apiKey } = getGeminiClient();
    res.json({
      status: "healthy",
      env: isProd ? "production" : "development",
      hasGeminiKey: Boolean(apiKey),
      timestamp: (/* @__PURE__ */ new Date()).toISOString()
    });
  });
  const dataDir = path.resolve(__dirname, "data");
  const contributionsFilePath = path.resolve(dataDir, "contributions.json");
  let writeQueue = Promise.resolve();
  const rateLimitMap = /* @__PURE__ */ new Map();
  app.get("/api/contributions", (_req, res) => {
    return res.status(405).json({
      ok: false,
      error: "Ph\u01B0\u01A1ng th\u1EE9c kh\xF4ng \u0111\u01B0\u1EE3c h\u1ED7 tr\u1EE3. Kh\xF4ng c\xF3 quy\u1EC1n truy c\u1EADp danh s\xE1ch \u0111\xF3ng g\xF3p."
    });
  });
  app.post("/api/contributions", async (req, res) => {
    try {
      const clientIp = req.headers["x-forwarded-for"]?.split(",")[0]?.trim() || req.socket.remoteAddress || "unknown-ip";
      const now = Date.now();
      const windowMs = 5 * 60 * 1e3;
      const maxRequests = 10;
      const timestamps = (rateLimitMap.get(clientIp) || []).filter(
        (t) => now - t < windowMs
      );
      if (timestamps.length >= maxRequests) {
        return res.status(429).json({
          ok: false,
          error: "B\u1EA1n \u0111\xE3 g\u1EEDi qu\xE1 nhi\u1EC1u y\xEAu c\u1EA7u trong th\u1EDDi gian ng\u1EAFn. Vui l\xF2ng ch\u1EDD v\xE0i ph\xFAt tr\u01B0\u1EDBc khi g\u1EEDi l\u1EA1i."
        });
      }
      timestamps.push(now);
      rateLimitMap.set(clientIp, timestamps);
      const body = req.body;
      if (!body || typeof body !== "object") {
        return res.status(400).json({
          ok: false,
          error: "D\u1EEF li\u1EC7u g\u1EEDi l\xEAn kh\xF4ng \u0111\xFAng \u0111\u1ECBnh d\u1EA1ng JSON."
        });
      }
      const { target, detail, sourceReference, contactEmail } = body;
      if (typeof target !== "string" || !target.trim()) {
        return res.status(400).json({
          ok: false,
          error: "Vui l\xF2ng nh\u1EADp m\u1EE5c trang ph\u1EE5c ho\u1EB7c n\u1ED9i dung c\u1EA7n g\xF3p \xFD."
        });
      }
      const trimmedTarget = target.trim();
      if (trimmedTarget.length < 2 || trimmedTarget.length > 250) {
        return res.status(400).json({
          ok: false,
          error: "M\u1EE5c trang ph\u1EE5c c\u1EA7n g\xF3p \xFD ph\u1EA3i c\xF3 \u0111\u1ED9 d\xE0i t\u1EEB 2 \u0111\u1EBFn 250 k\xFD t\u1EF1."
        });
      }
      if (typeof detail !== "string" || !detail.trim()) {
        return res.status(400).json({
          ok: false,
          error: "Vui l\xF2ng nh\u1EADp chi ti\u1EBFt \u0111\xEDnh ch\xEDnh v\xE0 d\u1EABn ch\u1EE9ng tham kh\u1EA3o (t\u1ED1i thi\u1EC3u 10 k\xFD t\u1EF1)."
        });
      }
      const trimmedDetail = detail.trim();
      if (trimmedDetail.length < 10) {
        return res.status(400).json({
          ok: false,
          error: "N\u1ED9i dung g\xF3p \xFD qu\xE1 ng\u1EAFn. Vui l\xF2ng m\xF4 t\u1EA3 chi ti\u1EBFt h\u01A1n (t\u1ED1i thi\u1EC3u 10 k\xFD t\u1EF1)."
        });
      }
      if (trimmedDetail.length > 5e3) {
        return res.status(400).json({
          ok: false,
          error: "N\u1ED9i dung g\xF3p \xFD v\u01B0\u1EE3t qu\xE1 gi\u1EDBi h\u1EA1n cho ph\xE9p (t\u1ED1i \u0111a 5.000 k\xFD t\u1EF1)."
        });
      }
      let trimmedSource = "";
      if (sourceReference !== void 0 && sourceReference !== null) {
        if (typeof sourceReference !== "string") {
          return res.status(400).json({
            ok: false,
            error: "Ngu\u1ED3n tham kh\u1EA3o ph\u1EA3i l\xE0 chu\u1ED7i v\u0103n b\u1EA3n."
          });
        }
        trimmedSource = sourceReference.trim();
        if (trimmedSource.length > 1e3) {
          return res.status(400).json({
            ok: false,
            error: "Ngu\u1ED3n tham kh\u1EA3o kh\xF4ng \u0111\u01B0\u1EE3c v\u01B0\u1EE3t qu\xE1 1.000 k\xFD t\u1EF1."
          });
        }
        if (/^https?:\/\//i.test(trimmedSource)) {
          try {
            new URL(trimmedSource);
          } catch {
            return res.status(400).json({
              ok: false,
              error: "\u0110\u01B0\u1EDDng d\u1EABn ngu\u1ED3n tham kh\u1EA3o kh\xF4ng \u0111\xFAng \u0111\u1ECBnh d\u1EA1ng URL h\u1EE3p l\u1EC7."
            });
          }
        }
      }
      let trimmedEmail = "";
      if (contactEmail !== void 0 && contactEmail !== null) {
        if (typeof contactEmail !== "string") {
          return res.status(400).json({
            ok: false,
            error: "Email li\xEAn h\u1EC7 ph\u1EA3i l\xE0 chu\u1ED7i v\u0103n b\u1EA3n."
          });
        }
        trimmedEmail = contactEmail.trim();
        if (trimmedEmail.length > 0) {
          if (trimmedEmail.length > 200) {
            return res.status(400).json({
              ok: false,
              error: "\u0110\u1ECBa ch\u1EC9 email kh\xF4ng \u0111\u01B0\u1EE3c v\u01B0\u1EE3t qu\xE1 200 k\xFD t\u1EF1."
            });
          }
          const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
          if (!emailRegex.test(trimmedEmail)) {
            return res.status(400).json({
              ok: false,
              error: "\u0110\u1ECBa ch\u1EC9 email kh\xF4ng \u0111\xFAng \u0111\u1ECBnh d\u1EA1ng. Vui l\xF2ng ki\u1EC3m tra l\u1EA1i."
            });
          }
        }
      }
      const receiptId = "CP-" + Date.now().toString(36).toUpperCase() + "-" + Math.random().toString(36).substring(2, 6).toUpperCase();
      const submittedAt = (/* @__PURE__ */ new Date()).toISOString();
      const newRecord = {
        id: receiptId,
        target: trimmedTarget,
        detail: trimmedDetail,
        sourceReference: trimmedSource || void 0,
        contactEmail: trimmedEmail || void 0,
        submittedAt,
        status: "pending"
      };
      await new Promise((resolve, reject) => {
        writeQueue = writeQueue.then(async () => {
          if (!fs.existsSync(dataDir)) {
            fs.mkdirSync(dataDir, { recursive: true });
          }
          let existing = [];
          if (fs.existsSync(contributionsFilePath)) {
            try {
              const content = fs.readFileSync(contributionsFilePath, "utf-8");
              existing = JSON.parse(content);
              if (!Array.isArray(existing)) {
                existing = [];
              }
            } catch (parseErr) {
              console.warn(
                "Could not parse existing contributions file, starting fresh array:",
                parseErr
              );
              existing = [];
            }
          }
          existing.push(newRecord);
          const tempFilePath = `${contributionsFilePath}.${Date.now()}.tmp`;
          fs.writeFileSync(tempFilePath, JSON.stringify(existing, null, 2), "utf-8");
          fs.renameSync(tempFilePath, contributionsFilePath);
          resolve();
        }).catch((writeErr) => {
          console.error("Failed to write contribution to disk:", writeErr);
          reject(writeErr);
        });
      });
      return res.status(201).json({
        ok: true,
        id: newRecord.id,
        submittedAt: newRecord.submittedAt,
        message: "\u0110\xE3 ti\u1EBFp nh\u1EADn h\u1ED3 s\u01A1 \u0111\xF3ng g\xF3p th\xE0nh c\xF4ng."
      });
    } catch (err) {
      console.error("Server error handling contribution submission:", err);
      return res.status(500).json({
        ok: false,
        error: "M\xE1y ch\u1EE7 t\u1EA1m th\u1EDDi kh\xF4ng th\u1EC3 l\u01B0u tr\u1EEF \u0111\xF3ng g\xF3p. Vui l\xF2ng th\u1EED l\u1EA1i sau gi\xE2y l\xE1t."
      });
    }
  });
  app.post("/api/advisor/chat", async (req, res) => {
    try {
      const { message, history = [], userDate, location } = req.body;
      const userMessage = (message || "").trim();
      const localDate = userDate || (/* @__PURE__ */ new Date()).toLocaleDateString("vi-VN", {
        weekday: "long",
        day: "2-digit",
        month: "2-digit",
        year: "numeric"
      });
      if (!userMessage) {
        const initial = generateAdvisorResponse("", localDate, location);
        return res.json({ ok: true, data: initial });
      }
      const { client: geminiClient, apiKey: geminiApiKey } = getGeminiClient();
      if (geminiClient && geminiApiKey) {
        try {
          const systemInstruction = `B\u1EA1n l\xE0 'C\u1ED1 V\u1EA5n T\xE0ng Y' (Vi\u1EC7t Ph\u1EE5c Occasion & Heritage Advisor) \u2014 chuy\xEAn gia y ph\u1EE5c truy\u1EC1n th\u1ED1ng Vi\u1EC7t Nam c\u1EE7a d\u1EF1 \xE1n T\xE0ng Y (Vi\u1EC7t Ph\u1EE5c Remix).

S\u1EE8 M\u1EC6NH:
T\u01B0 v\u1EA5n trang ph\u1EE5c truy\u1EC1n th\u1ED1ng Vi\u1EC7t Nam ph\xF9 h\u1EE3p nh\u1EA5t cho k\u1EBF ho\u1EA1ch c\u1EE7a ng\u01B0\u1EDDi d\xF9ng h\xF4m nay ('H\xF4m nay t\xF4i n\xEAn m\u1EB7c g\xEC?') d\u1EF1a tr\xEAn b\u1ED1i c\u1EA3nh, s\u1EF1 ki\u1EC7n, \u0111\u1ECBa \u0111i\u1EC3m, th\u1EDDi gian, phong c\xE1ch v\xE0 c\xE1c gi\u1EDBi h\u1EA1n th\u1EF1c t\u1EBF; ho\u1EB7c t\u01B0 v\u1EA5n qu\xE0 t\u1EB7ng v\u0103n h\xF3a \xFD ngh\u0129a.

DANH M\u1EE4C TH\u1EF0C TH\u1EC2 KH\u1EA2 D\u1EE4NG (CH\u1EC8 \u0110\u01AF\u1EE2C PH\xC9P KHUY\u1EBEN NGH\u1ECA T\u1EEA DANH S\xC1CH 42 TRANG PH\u1EE4C & PH\u1EE4 KI\u1EC6N CHU\u1EA8N N\xC0Y):
- G001: \xC1o Giao L\u0129nh (L\xFD, Tr\u1EA7n, L\xEA, Nguy\u1EC5n nghi l\u1EC5 - Nam, N\u1EEF)
- G002: \xC1o Tr\u1EF1c L\u0129nh (L\xEA Trung H\u01B0ng - Nam, N\u1EEF)
- G003: \xC1o \u0110\u1ED1i Kh\xE2m (L\xEA Trung H\u01B0ng, Nguy\u1EC5n - Nam, N\u1EEF)
- G006: \xC1o Vi\xEAn L\u0129nh (L\xFD, Tr\u1EA7n, L\xEA, Nguy\u1EC5n - Nam, N\u1EEF)
- G007: \xC1o T\u1EE9 \u0110i\xEAn (L\xFD, Tr\u1EA7n - Nam)
- G008: \xC1o Ng\u0169 Th\xE2n tay ch\u1EBDn (Nguy\u1EC5n, C\u1EADn \u0111\u1EA1i - Nam, N\u1EEF)
- G009: \xC1o T\u1EA5c (\xC1o ng\u0169 th\xE2n tay th\u1EE5ng, l\u1EC5 ph\u1EE5c trang tr\u1ECDng tri\u1EC1u Nguy\u1EC5n - Nam, N\u1EEF)
- G010: \xC1o T\u1EE9 Th\xE2n (B\u1EAFc B\u1ED9 truy\u1EC1n th\u1ED1ng - N\u1EEF)
- G011: Y\u1EBFm (N\u1ED9i y truy\u1EC1n th\u1ED1ng - N\u1EEF)
- G012: V\xE1y (V\xE1y \u0111\u1EE5p d\xE2n gian B\u1EAFc B\u1ED9 - N\u1EEF)
- G013: Qu\u1EA7n \u1ED1ng r\u1ED9ng s\xE1ng m\xE0u / Qu\u1EA7n tr\u1EAFng (Nguy\u1EC5n, C\u1EADn \u0111\u1EA1i - Nam, N\u1EEF)
- G014: Qu\u1EA7n L\xE1 T\u1ECDa (D\xE2n gian - Nam)
- G015: Kh\u1ED1 (C\u1ED5 \u0111\u1EA1i, \u0110\xF4ng S\u01A1n - Nam)
- G016: \xC1o B\u1ED5 Ph\u1EE5c (Quan l\u1EA1i tri\u1EC1u \u0111\xECnh Nguy\u1EC5n - Nam)
- G017: B\u1ED5 T\u1EED (Ph\u1EA9m ph\u1EE5c quan l\u1EA1i Nguy\u1EC5n)
- G018: \xC1o Nh\u1EADt B\xECnh (H\u1EADu phi, c\xF4ng ch\xFAa, cung t\u1EA7n, m\u1EC7nh ph\u1EE5 tri\u1EC1u Nguy\u1EC5n - N\u1EEF)
- G019: \xC1o M\u1EC7nh Ph\u1EE5 (Ph\u1EE5 n\u1EEF ph\u1EA9m tr\u1EADt tri\u1EC1u Nguy\u1EC5n - N\u1EEF)
- G020: \xC1o M\xE3ng B\xE0o (Ho\xE0ng th\xE2n, quan l\u1EA1i c\u1EA5p cao - Nam)
- G021: M\xE3ng Lan (Ho\xE0ng t\u1EED, th\xE1i t\u1EED - Nam)
- G022: Long B\xE0o (Ho\xE0ng \u0111\u1EBF/Vua tri\u1EC1u Nguy\u1EC5n - Nam)
- G023: Ho\xE0ng B\xE0o (Ho\xE0ng \u0111\u1EBF/Vua tri\u1EC1u Nguy\u1EC5n - Nam)
- G024: C\u1ED5n Ph\u1EE5c (\u0110\u1EA1i l\u1EC5 t\u1EBF giao Ho\xE0ng \u0111\u1EBF - Nam)
- G025: Ph\u01B0\u1EE3ng Ph\u1EE5c (Ho\xE0ng h\u1EADu, c\xF4ng ch\xFAa tri\u1EC1u Nguy\u1EC5n - N\u1EEF)
- G028: \xC1o B\xE0 Ba (Nam B\u1ED9, C\u1EADn \u0111\u1EA1i & Hi\u1EC7n \u0111\u1EA1i - Nam, N\u1EEF)
- G030: \xC1o D\xE0i hi\u1EC7n \u0111\u1EA1i (Th\u1EBF k\u1EF7 20 - nay - Nam, N\u1EEF)
- G031: Kh\u0103n X\u1EBFp / Kh\u0103n \u0110\xF3ng (Nguy\u1EC5n, C\u1EADn \u0111\u1EA1i - Nam, N\u1EEF)
- G032: Kh\u0103n V\xE0nh D\xE2y (N\u1EEF cung \u0111\xECnh, m\u1EC7nh ph\u1EE5 Nguy\u1EC5n - N\u1EEF)
- G033: Kh\u0103n M\u1ECF Qu\u1EA1 (B\u1EAFc B\u1ED9 truy\u1EC1n th\u1ED1ng - N\u1EEF)
- G034: Kh\u0103n R\u1EB1n (Nam B\u1ED9, C\u1EADn \u0111\u1EA1i & Hi\u1EC7n \u0111\u1EA1i - Nam, N\u1EEF)
- G035: N\xF3n L\xE1 (To\xE0n qu\u1ED1c, nhi\u1EC1u th\u1EDDi k\u1EF3 - Nam, N\u1EEF)
- G036: N\xF3n Ba T\u1EA7m (B\u1EAFc B\u1ED9 truy\u1EC1n th\u1ED1ng - N\u1EEF)
- G037: N\xF3n Th\xFAng / Th\xFAng quai thao (Quan h\u1ECD Kinh B\u1EAFc - N\u1EEF)
- G038: N\xF3n B\xE0i Th\u01A1 (X\u1EE9 Hu\u1EBF, C\u1EADn \u0111\u1EA1i & Hi\u1EC7n \u0111\u1EA1i - N\u1EEF)
- G039: M\u0169 C\xE1nh Chu\u1ED3n (Quan l\u1EA1i tri\u1EC1u \u0111\xECnh - Nam)
- G040: V\xE2n Ki\xEAn (Cung \u0111\xECnh / ph\u1EA9m ph\u1EE5c qu\xFD t\u1ED9c Nguy\u1EC5n)
- G041: Tr\xE2m (Tr\xE2m c\xE0i t\xF3c truy\u1EC1n th\u1ED1ng - N\u1EEF)
- G042: \u0110ai / Th\u1EAFt l\u01B0ng (D\u1EA3i l\u1EE5a th\u1EAFt l\u01B0ng - Nam, N\u1EEF)
- G043: D\xE2y Ru\u1ED9t T\u01B0\u1EE3ng (D\xE2n gian B\u1EAFc B\u1ED9 - N\u1EEF)
- G044: H\u1ED1t (Quan l\u1EA1i / tri\u1EC1u l\u1EC5 Nguy\u1EC5n - Nam)
- G045: Hia (Quan l\u1EA1i / \u0111\u1EA1i l\u1EC5 Nguy\u1EC5n - Nam)
- G046: H\xE0i (H\xE0i th\xEAu truy\u1EC1n th\u1ED1ng - Nam, N\u1EEF)
- G047: Gu\u1ED1c M\u1ED9c (D\xE2n gian truy\u1EC1n th\u1ED1ng - Nam, N\u1EEF)
- A011: Qu\u1EA1t L\u1EE5a C\u1ED5 (Ph\u1EE5 ki\u1EC7n tao nh\xE3, qu\xE0 t\u1EB7ng v\u0103n h\xF3a)
- A012: Th\u1EBB B\xE0i Quan (Tri\u1EC1u \u0111\xECnh)

TUY\u1EC6T \u0110\u1ED0I KH\xD4NG KHUY\u1EBEN NGH\u1ECA 5 TRANG PH\u1EE4C \u0110\xC3 LO\u1EA0I KH\u1ECEI CATALOG HO\u1EA0T \u0110\u1ED8NG:
- G004 (\xC1o C\u1ED5 Th\xECa)
- G005 (\xC1o B\xE1n T\xED)
- G026 (\xC1o Th\xE2m)
- G027 (\xC1o C\xE1nh)
- G029 (\xC1o Ch\xE0m)

QUY T\u1EAEC B\u1EAET BU\u1ED8C V\u1EC0 V\u0102N H\xD3A V\xC0 L\u1ECACH S\u1EEC:
1. KH\xD4NG t\u1EF1 b\u1ECBa trang ph\u1EE5c, ID, ngu\u1ED3n g\u1ED1c ho\u1EB7c quy t\u1EAFc l\u1ECBch s\u1EED.
2. KH\xD4NG t\u1EF1 \xFD tuy\xEAn b\u1ED1 m\u1ED9t b\u1ED9 ph\u1ED1i l\xE0 '\u0111\xFAng chu\u1EA9n l\u1ECBch s\u1EED' (Authentic) n\u1EBFu kh\xF4ng c\xF3 t\u01B0 li\u1EC7u \u0111\u1ED1i chi\u1EBFu. H\u1EC7 th\u1ED1ng s\u1EED d\u1EE5ng 5 m\u1EE9c:
   - AUTHENTIC (Chu\u1EA9n m\u1EF1c t\u01B0 li\u1EC7u b\u1EA3o t\xE0ng)
   - HISTORICALLY_SUPPORTED (Ph\xF9 h\u1EE3p b\u1ED1i c\u1EA3nh l\u1ECBch s\u1EED)
   - CONTEXTUAL_MODERN_REMIX (C\xE1ch t\xE2n \u0111\u01B0\u01A1ng \u0111\u1EA1i c\xF3 \xFD th\u1EE9c)
   - UNCERTAIN (H\u1ECDc gi\u1EDBi c\xF2n tranh lu\u1EADn ho\u1EB7c thi\u1EBFu b\u1EB1ng ch\u1EE9ng x\xE1c th\u1EF1c)
   - CULTURAL_MISMATCH (Xung \u0111\u1ED9t kh\xF4ng gian v\u0103n h\xF3a, tri\u1EC1u \u0111\u1EA1i ho\u1EB7c ph\u1EA9m c\u1EA5p)
3. C\u1EA3nh b\xE1o nghi\xEAm c\u1EA5m gh\xE9p sai quy th\u1EE9c:
   - TUY\u1EC6T \u0110\u1ED0I KH\xD4NG gh\xE9p V\xE2n Ki\xEAn (G040) v\xE0o \xC1o T\u1EE9 Th\xE2n (G010) hay \xC1o B\xE0 Ba (G028). V\xE2n Ki\xEAn l\xE0 ph\u1EA9m ph\u1EE5c cung \u0111\xECnh.
   - TUY\u1EC6T \u0110\u1ED0I KH\xD4NG gh\xE9p Kh\u0103n R\u1EB1n Nam B\u1ED9 (G034) v\xE0o \xC1o T\u1EE9 Th\xE2n Kinh B\u1EAFc (G010).
   - KH\xD4NG gh\xE9p M\u0169 C\xE1nh Chu\u1ED3n (G039) hay H\u1ED1t (G044) v\xE0o trang ph\u1EE5c d\xE2n gian th\u01B0\u1EDDng nh\u1EADt.
   - Long b\xE0o (G022) / Ho\xE0ng b\xE0o (G023) / \xC1o Nh\u1EADt B\xECnh \u0111\u1EA1i l\u1EC5 kh\xF4ng d\xF9ng cho s\u1EF1 ki\u1EC7n th\xF4ng th\u01B0\u1EDDng.
4. KH\xD4NG nh\u1EA7m l\u1EABn vi\u1EC7c l\u1ECDc gi\u1EDBi t\xEDnh m\xF4 h\xECnh (model-gender) v\u1EDBi t\xEDnh ph\xF9 h\u1EE3p v\u0103n h\xF3a.
5. V\u1EC1 ng\xE0y 'h\xF4m nay' v\xE0 \u0111\u1ECBa \u0111i\u1EC3m:
   - D\xF9ng ng\xE0y \u0111\u1ECBa ph\u01B0\u01A1ng do \u1EE9ng d\u1EE5ng g\u1EEDi t\u1EDBi n\u1EBFu c\xF3: ${localDate}.
   - KH\xD4NG b\u1ECBa th\u1EDDi ti\u1EBFt th\u1EDDi gian th\u1EF1c hay gi\u1EDD m\u1EDF c\u1EEDa n\u1EBFu kh\xF4ng c\xF3 d\u1EEF li\u1EC7u th\u1EF1c t\u1EBF. Ch\u1EC9 h\u1ECFi th\xE0nh ph\u1ED1/khu v\u1EF1c khi th\u1EF1c s\u1EF1 c\u1EA7n.
6. Khi ng\u01B0\u1EDDi d\xF9ng h\u1ECFi v\u1EC1 qu\xE0 t\u1EB7ng:
   - H\u1ECFi ng\u01B0\u1EDDi nh\u1EADn, d\u1ECBp t\u1EB7ng v\xE0 ng\xE2n s\xE1ch n\u1EBFu ch\u01B0a r\xF5.
   - G\u1EE3i \xFD qu\xE0 t\u1EB7ng th\u1EF1c t\u1EBF, c\xF3 \xFD ngh\u0129a v\u0103n h\xF3a chu\u1EA9n m\u1EF1c (Qu\u1EA1t l\u1EE5a A011, Kh\u0103n r\u1EB1n G034, N\xF3n b\xE0i th\u01A1 G038, Tr\xE2m c\xE0i t\xF3c G041, H\xE0i th\xEAu G046).
   - Ph\xE2n bi\u1EC7t r\xF5 qu\xE0 th\u1EE7 c\xF4ng \u0111\u01B0\u01A1ng \u0111\u1EA1i l\u1EA5y c\u1EA3m h\u1EE9ng di s\u1EA3n v\u1EDBi c\u1ED5 v\u1EADt/hi\u1EC7n v\u1EADt g\u1ED1c.
7. Khi g\u1EE3i \xFD trang ph\u1EE5c, h\xE3y \u0111\u01B0a ra 2\u20133 ph\u01B0\u01A1ng \xE1n ph\xF9 h\u1EE3p, m\u1ED7i ph\u01B0\u01A1ng \xE1n c\xF3:
   - title: T\xEAn b\u1ED9 ph\u1ED1i
   - itemIds: Danh s\xE1ch ID chu\u1EA9n x\xE1c th\u1EF1c th\u1EC3 (v\xED d\u1EE5: ['G008', 'G013', 'G031', 'G047'])
   - whySuits: V\xEC sao ph\xF9 h\u1EE3p v\u1EDBi d\u1ECBp v\xE0 ho\u1EA1t \u0111\u1ED9ng ng\u01B0\u1EDDi d\xF9ng d\u1EF1 \u0111\u1ECBnh
   - stylingColorNotes: G\u1EE3i \xFD m\xE0u s\u1EAFc v\xE0 ph\u1ED1i ph\u1EE5 ki\u1EC7n
   - comfortNotes: L\u01B0u \xFD v\u1EC1 \u0111\u1ED9 tho\u1EA3i m\xE1i, th\u1EDDi gian m\u1EB7c ho\u1EB7c dress code
   - culturalEvidenceStatus: M\u1EE9c \u0111\u1ED9 t\u01B0 li\u1EC7u (AUTHENTIC, HISTORICALLY_SUPPORTED, CONTEXTUAL_MODERN_REMIX, UNCERTAIN)
   - warnings: C\u1EA3nh b\xE1o l\u01B0u \xFD v\u0103n h\xF3a n\u1EBFu c\xF3
8. Lu\xF4n tr\u1EA3 v\u1EC1 ph\u1EA3n h\u1ED3i DUY NH\u1EA4T b\u1EB1ng m\u1ED9t chu\u1ED7i JSON h\u1EE3p l\u1EC7 kh\xF4ng b\u1ECDc markdown theo schema:
{
  "message": "L\u1EDDi nh\u1EAFn \u0111\u1ED1i tho\u1EA1i th\xE2n thi\u1EC7n, nh\xE3 nh\u1EB7n, s\xFAc t\xEDch",
  "quickActions": ["G\u1EE3i \xFD trang ph\u1EE5c h\xF4m nay", "T\xECm \u0111\u1ED3 \u0111i ch\u1EE5p \u1EA3nh", "Ph\u1ED1i b\u1ED9 n\xE0y", "Gi\u1EA3i th\xEDch ngu\u1ED3n t\u01B0 li\u1EC7u", "G\u1EE3i \xFD qu\xE0 t\u1EB7ng"],
  "recommendations": [
    {
      "title": "T\xEAn b\u1ED9 ph\u1ED1i",
      "itemIds": ["G008", "G013", "G031", "G047"],
      "whySuits": "V\xEC sao ph\xF9 h\u1EE3p",
      "stylingColorNotes": "G\u1EE3i \xFD ph\u1ED1i m\xE0u",
      "comfortNotes": "L\u01B0u \xFD di chuy\u1EC3n",
      "culturalEvidenceStatus": "HISTORICALLY_SUPPORTED",
      "warnings": ""
    }
  ],
  "giftSuggestions": [
    {
      "name": "T\xEAn m\xF3n qu\xE0",
      "itemOrCategory": "A011",
      "culturalMeaning": "\xDD ngh\u0129a bi\u1EC3u tr\u01B0ng",
      "suitableFor": "\u0110\u1ED1i t\u01B0\u1EE3ng ph\xF9 h\u1EE3p",
      "budgetLevel": "M\u1EE9c ng\xE2n s\xE1ch",
      "notes": "L\u01B0u \xFD v\u0103n h\xF3a"
    }
  ]
}`;
          const formattedContents = [
            ...history.slice(-6).map((h) => ({
              role: h.role === "model" ? "model" : "user",
              parts: [{ text: h.text }]
            })),
            {
              role: "user",
              parts: [
                {
                  text: `Th\u1EDDi gian hi\u1EC7n t\u1EA1i: ${localDate}${location ? ` - \u0110\u1ECBa \u0111i\u1EC3m: ${location}` : ""}. C\xE2u h\u1ECFi c\u1EE7a ng\u01B0\u1EDDi d\xF9ng: "${userMessage}"`
                }
              ]
            }
          ];
          const geminiResponse = await geminiClient.models.generateContent({
            model: "gemini-3.8-flash",
            contents: formattedContents,
            config: {
              systemInstruction,
              responseMimeType: "application/json",
              temperature: 0.7
            }
          });
          const rawText = geminiResponse.text?.trim() || "";
          if (rawText) {
            let clean = rawText;
            if (clean.startsWith("```")) {
              clean = clean.replace(/^```(?:json)?\s*/i, "").replace(/\s*```$/, "");
            }
            const parsed = JSON.parse(clean);
            if (parsed && typeof parsed.message === "string") {
              if (Array.isArray(parsed.recommendations)) {
                parsed.recommendations = parsed.recommendations.map((r) => resolveRecommendation(r)).filter(Boolean);
              }
              parsed.dateContext = localDate;
              return res.json({ ok: true, data: parsed });
            }
          }
        } catch (apiError) {
          console.warn("Gemini generateContent error, switching to deterministic advisor:", apiError);
        }
      }
      const fallback = generateAdvisorResponse(userMessage, localDate, location);
      return res.json({ ok: true, data: fallback });
    } catch (err) {
      console.error("Advisor chat server error:", err);
      const fallback = generateAdvisorResponse(
        req.body?.message || "",
        req.body?.userDate,
        req.body?.location
      );
      return res.json({ ok: true, data: fallback });
    }
  });
  app.post("/api/try-on", async (req, res) => {
    const requestId = req.body?.requestId || `req_${Date.now()}`;
    const mode = req.body?.mode || "complete_outfit_try_on";
    try {
      let resolveAssetBuffer = function(filename) {
        const p1 = path.resolve(publicAssetsDir, filename);
        if (fs.existsSync(p1)) return fs.readFileSync(p1);
        const p2 = path.resolve(srcAssetsDir, filename);
        if (fs.existsSync(p2)) return fs.readFileSync(p2);
        return null;
      }, isAssetAvailable = function(filename) {
        return Boolean(resolveAssetBuffer(filename));
      };
      const publicAssetsDir = path.resolve(__dirname, "public/assets");
      const srcAssetsDir = path.resolve(__dirname, "src/assets/images");
      const { client: geminiClient, apiKey: geminiApiKey } = getGeminiClient();
      const validation = validateTryOnInputs(req.body, geminiApiKey, isAssetAvailable);
      if (!validation.valid) {
        return res.status(validation.status).json({
          ok: false,
          requestId,
          mode,
          error: validation.error,
          errorType: validation.errorType
        });
      }
      const imageParts = [];
      const shouldIncludeBaseModel = validation.mode !== "reference_image_edit" || Boolean(req.body.includeBaseModel);
      if (shouldIncludeBaseModel) {
        const baseBuffer = resolveAssetBuffer(validation.baseModelFilename);
        if (baseBuffer) {
          imageParts.push({
            inlineData: {
              data: baseBuffer.toString("base64"),
              mimeType: "image/jpeg"
            }
          });
        }
      }
      for (const asset of validation.itemAssets) {
        const buf = resolveAssetBuffer(asset.filename);
        if (buf) {
          imageParts.push({
            inlineData: {
              data: buf.toString("base64"),
              mimeType: asset.mimeType
            }
          });
        }
      }
      const userPrompt = (req.body.prompt || req.body.customPrompt || "").trim();
      let effectivePrompt = userPrompt;
      if (!effectivePrompt) {
        if (validation.mode === "single_item_try_on") {
          const singleId = validation.targetIds[0];
          const isAccessory = [
            "G031",
            "G032",
            "G033",
            "G034",
            "G035",
            "G036",
            "G037",
            "G038",
            "G039",
            "G040",
            "G041",
            "G042",
            "G043",
            "G044",
            "G045",
            "G046",
            "G047",
            "A011",
            "A012"
          ].includes(singleId);
          if (isAccessory) {
            effectivePrompt = `High-end photorealistic studio photograph of the model wearing ONLY the single traditional accessory (${singleId}).
PRESERVE NEUTRAL BASE MODEL: The model must wear a neutral, plain, unobtrusive ivory/light grey modern minimalist base shirt and trousers.
DO NOT INVENT A FULL COSTUME: Absolutely do NOT generate a complete traditional ceremonial robe, dragon robe, \xC1o B\xE0 Ba, \xC1o Nh\u1EADt B\xECnh, or \xC1o T\u1EE9 Th\xE2n merely because an accessory was selected.
NO UNSELECTED ACCESSORIES: Do NOT add unselected jewelry, extra hats, cloaks, scarves, or fans.
Position the selected accessory accurately matching the reference image. Clean warm ivory archival studio backdrop.`;
          } else {
            effectivePrompt = `High-end photorealistic studio photograph of the model wearing the specific traditional Vietnamese garment (${singleId}).
Faithfully render the cut, collar style, sleeve width, and fabric texture matching the reference image.
Neutral modest plain underlayer and straight trousers for modesty only. Do NOT add unselected outer coats, sashes, or hats.`;
          }
        } else if (validation.mode === "reference_image_edit") {
          effectivePrompt = `Masterpiece editorial photograph based strictly on the provided reference artifact of (${validation.targetIds[0]}).
Accurately reproduce the collar cut, seam construction, textile texture, and silhouette shown in the reference image. Professional archival museum presentation.`;
        } else {
          effectivePrompt = `High-end photorealistic editorial studio photograph of the model wearing complete coordinated traditional Vietnamese outfit (${req.body.outfitTitle || "Vi\u1EC7t Ph\u1EE5c"}).
Faithfully incorporate all selected garment layers: ${validation.targetIds.join(", ")}.
Maintain authentic Vietnamese traditional construction. Neutral warm ivory studio background with soft lighting.`;
        }
      }
      try {
        const response = await geminiClient.models.generateContent({
          model: "gemini-3.1-flash-lite-image",
          contents: {
            parts: [
              ...imageParts,
              {
                text: effectivePrompt
              }
            ]
          },
          config: {
            responseModalities: ["TEXT", "IMAGE"]
          }
        });
        const extracted = extractGeminiImageResponse(response);
        if (extracted.ok) {
          return res.json({
            ok: true,
            requestId,
            mode: validation.mode,
            imageUrl: extracted.imageUrl,
            serviceUsed: "gemini-3.1-flash-lite-image (Nano Banana)",
            isFallback: false
          });
        }
        const safeDiagnostic = extracted.returnedText ? extracted.returnedText.substring(0, 300) : "Kh\xF4ng c\xF3 ph\u1EA3n h\u1ED3i t\u1EEB m\xF4 h\xECnh";
        console.warn(`[try-on] Gemini model returned text only without image data. Diagnostic: ${safeDiagnostic}`);
        return res.status(502).json({
          ok: false,
          requestId,
          mode: validation.mode,
          error: 'M\xF4 h\xECnh t\u1EA1o \u1EA3nh kh\xF4ng tr\u1EA3 v\u1EC1 ph\u1EA7n d\u1EEF li\u1EC7u h\xECnh \u1EA3nh (ch\u1EC9 ph\u1EA3n h\u1ED3i v\u0103n b\u1EA3n). Vui l\xF2ng b\u1EA5m "Th\u1EED l\u1EA1i".',
          errorType: "NO_IMAGE_DATA",
          diagnostic: safeDiagnostic
        });
      } catch (apiErr) {
        const classified = classifyGeminiError(apiErr, geminiApiKey);
        if (classified.errorType === "PAID_PLAN_REQUIRED" || classified.errorType === "QUOTA_EXCEEDED") {
          console.info(`[try-on] Quota status (${classified.status}, ${classified.errorType})`);
        } else {
          console.warn(`[try-on] Notice: ${classified.errorType} (status=${classified.status}): ${classified.sanitizedDetails}`);
        }
        return res.status(classified.status).json({
          ok: false,
          requestId,
          mode: validation.mode,
          error: classified.messageVi,
          errorType: classified.errorType
        });
      }
    } catch (err) {
      console.error("Try-on server exception:", err);
      return res.status(500).json({
        ok: false,
        requestId,
        mode,
        error: "L\u1ED7i m\xE1y ch\u1EE7 trong qu\xE1 tr\xECnh x\u1EED l\xFD y\xEAu c\u1EA7u t\u1EA1o \u1EA3nh: " + (err?.message || "L\u1ED7i kh\xF4ng x\xE1c \u0111\u1ECBnh"),
        errorType: "SERVER_ERROR"
      });
    }
  });
  if (isProd && fs.existsSync(distPath)) {
    app.use(express.static(distPath));
    app.get("*", (_req, res) => {
      const indexPath = path.resolve(distPath, "index.html");
      if (fs.existsSync(indexPath)) {
        res.sendFile(indexPath);
      } else {
        res.status(404).send("Application build not found. Run npm run build first.");
      }
    });
  } else {
    const { createServer } = await import("vite");
    const vite = await createServer({
      server: { middlewareMode: true },
      appType: "spa"
    });
    app.use(vite.middlewares);
  }
  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server listening on http://0.0.0.0:${PORT} (${isProd ? "production" : "development"})`);
  });
}
startServer().catch((err) => {
  console.error("Failed to start server:", err);
  process.exit(1);
});
