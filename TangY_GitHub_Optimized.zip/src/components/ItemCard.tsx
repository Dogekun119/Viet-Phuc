import React from 'react';
import { CanonicalEntity } from '../domain/canonicalData';
import { ArrowUpRight } from 'lucide-react';

interface ItemCardProps {
  entity: CanonicalEntity;
  onSelectDetail: (entity: CanonicalEntity) => void;
  sizeVariant?: 'large' | 'compact';
}

export const ItemCard: React.FC<ItemCardProps> = ({
  entity,
  onSelectDetail,
  sizeVariant = 'compact',
}) => {
  const isLarge = sizeVariant === 'large';
  const hasVerifiedImage =
    entity.image.imageType !== 'NO_VERIFIED_IMAGE' && Boolean(entity.image.src);

  // Period label
  const periodText =
    entity.periods && entity.periods.length > 0
      ? entity.periods.join(' · ')
      : 'Di sản cổ truyền';

  // Context metadata snippet (Category · Region · Context)
  const metaItems = [
    entity.browseCategoryLabel,
    entity.geographicRegions.length > 0 && entity.geographicRegions[0] !== 'Toàn quốc'
      ? entity.geographicRegions[0]
      : null,
    entity.contexts.length > 0 ? entity.contexts[0] : null,
  ].filter(Boolean);

  const contextSnippet = metaItems.slice(0, 2).join(' · ');

  // Evidence status text (Restrained editorial labels per specification)
  const getEvidenceText = () => {
    switch (entity.evidenceStatus) {
      case 'VERIFIED':
        return 'Đã xác thực';
      case 'HISTORICALLY_CONSISTENT':
        return 'Phù hợp tư liệu';
      case 'CONTESTED':
        return 'Tranh luận';
      case 'UNCERTAIN':
      default:
        return 'Đang nghiên cứu';
    }
  };

  const evidenceLabel = getEvidenceText();

  // Subtle Image provenance note (TƯ LIỆU · PHỤC DỰNG · KHẢO CỨU)
  const getImageProvenanceTag = () => {
    if (entity.image.assetStatus) {
      switch (entity.image.assetStatus) {
        case 'TƯ LIỆU':
          return { label: 'Tư liệu', color: 'text-[#2E5A44] border-[#2E5A44]/30' };
        case 'PHỤC DỰNG':
          return { label: 'Phục dựng', color: 'text-[#1E3A5F] border-[#1E3A5F]/30' };
        case 'KHẢO CỨU':
          return { label: 'Khảo cứu', color: 'text-[#A63D2F] border-[#A63D2F]/30' };
      }
    }
    switch (entity.image.imageType) {
      case 'DOCUMENTED_OBJECT':
      case 'HISTORICAL_IMAGE':
        return { label: 'Tư liệu', color: 'text-[#2E5A44] border-[#2E5A44]/30' };
      case 'RECONSTRUCTION':
        return { label: 'Phục dựng', color: 'text-[#1E3A5F] border-[#1E3A5F]/30' };
      case 'RESEARCH_PLATE':
        return { label: 'Khảo cứu', color: 'text-[#A63D2F] border-[#A63D2F]/30' };
      default:
        return null;
    }
  };

  const imageTag = getImageProvenanceTag();

  return (
    <article
      onClick={() => onSelectDetail(entity)}
      className="group cursor-pointer flex flex-col justify-between w-full"
    >
      {/* =========================================================================
          1. IMAGE FIRST (BORDERLESS / EDITORIAL)
      ========================================================================= */}
      <div
        className={`relative w-full overflow-hidden bg-[#EAE6DE] select-none ${
          isLarge
            ? 'aspect-[4/3] sm:aspect-[16/11]'
            : 'aspect-[3/4]'
        }`}
      >
        {hasVerifiedImage ? (
          <>
            <img
              src={entity.image.src}
              alt={entity.image.alt || entity.canonicalNameVi}
              loading="lazy"
              className="h-full w-full object-cover object-top transition-transform duration-500 ease-out group-hover:scale-[1.02]"
            />
            {/* Minimal editorial provenance indicator */}
            {imageTag && (
              <div className="absolute top-3 right-3 z-10 pointer-events-none">
                <span
                  className={`inline-flex items-center text-[10px] uppercase tracking-wider px-2 py-0.5 bg-[#F4F1EA]/90 backdrop-blur-md border ${imageTag.color} font-medium shadow-2xs`}
                >
                  {imageTag.label}
                </span>
              </div>
            )}
          </>
        ) : (
          /* Dignified museum archival specimen folio plate fallback */
          <div className="w-full h-full p-6 sm:p-7 flex flex-col justify-between bg-[#EBE7DF] border border-[#D8D3C9]/70 relative">
            <div className="flex items-center justify-between text-[10px] font-mono tracking-widest text-[#77736B] uppercase">
              <span>{entity.primaryRecordId}</span>
              <span className="text-[#A63D2F] font-sans font-medium">Khảo cứu</span>
            </div>

            <div className="my-auto py-3 space-y-1.5 text-center px-1">
              <h4
                className={`font-raven text-[#171717] uppercase tracking-wide font-normal leading-snug ${
                  isLarge ? 'text-2xl sm:text-3xl' : 'text-xl sm:text-2xl'
                }`}
              >
                {entity.canonicalNameVi}
              </h4>
              <p className="text-xs text-[#77736B] italic font-editorial">
                {entity.browseCategoryLabel}
              </p>
            </div>

            <div className="text-[11px] text-[#77736B] text-center border-t border-[#D8D3C9]/70 pt-2 tracking-wide font-light">
              Tư liệu thư tịch &amp; bản vẽ
            </div>
          </div>
        )}
      </div>

      {/* =========================================================================
          2. BELOW IMAGE: GARMENT NAME → PERIOD → ESSENTIAL INFO
      ========================================================================= */}
      <div className="pt-3.5 sm:pt-4 flex-1 flex flex-col justify-between space-y-2">
        <div className="space-y-1">
          {/* GARMENT NAME */}
          <div className="flex items-start justify-between gap-2">
            <h3
              className={`font-raven text-[#171717] group-hover:text-[#A63D2F] transition-colors duration-500 leading-snug uppercase tracking-wide ${
                isLarge
                  ? 'text-2xl sm:text-3xl'
                  : 'text-lg sm:text-xl'
              }`}
            >
              {entity.canonicalNameVi}
            </h3>
            <ArrowUpRight className="w-4 h-4 text-[#77736B] opacity-0 -translate-x-1 translate-y-1 group-hover:opacity-100 group-hover:translate-x-1 group-hover:-translate-y-1 group-hover:text-[#A63D2F] transition-all duration-500 shrink-0 mt-1" />
          </div>

          {/* PERIOD (THỜI KỲ) — Immediately under garment name */}
          <p className="text-xs text-[#524E48] group-hover:text-[#171717] transition-colors duration-500 tracking-wider uppercase font-light">
            {periodText}
          </p>
        </div>

        {/* Essential context & understated evidence label */}
        <div className="pt-2 flex items-center justify-between text-xs text-[#77736B] border-t border-[#D8D3C9]/50">
          <span className="truncate max-w-[170px] sm:max-w-[220px] group-hover:text-[#383531] transition-colors duration-500">
            {contextSnippet || entity.browseCategoryLabel}
          </span>
          <div className="flex items-center gap-3 shrink-0 ml-2">
            <span className="text-[11px] text-[#77736B] uppercase tracking-wider hidden sm:inline">
              {evidenceLabel}
            </span>
            <span className="text-[11px] uppercase tracking-wider text-[#171717] group-hover:text-[#A63D2F] transition-colors duration-500 font-medium">
              Chi tiết &rarr;
            </span>
          </div>
        </div>
      </div>
    </article>
  );
};
