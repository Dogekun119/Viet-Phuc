import React, { useState, useRef, useEffect } from 'react';
import { Item } from '../../domain/types';
import {
  COMPATIBILITY_RULES,
  getImageAssetForRecord,
  RESEARCH_SOURCES_MAP,
} from '../../domain/dataAdapter';
import {
  MagneticButton,
  SectionEntrance,
  SplitLineReveal,
} from '../motion/MotionPrimitives';
import {
  generateUnifiedImage,
  ImageGenerationResult,
  buildReferenceImageEditPrompt,
  VERIFIED_REFERENCE_ASSET_MAP,
} from '../../services/geminiImage';
import { Sparkles, AlertCircle, RefreshCw, X, Download } from 'lucide-react';

interface ItemDetailScreenProps {
  item: Item;
  onBackToCatalog: () => void;
  onUseInBuilder: (item: Item) => void;
}

export const ItemDetailScreen: React.FC<ItemDetailScreenProps> = ({
  item,
  onBackToCatalog,
  onUseInBuilder,
}) => {
  const asset = getImageAssetForRecord(item.id);
  const hasReferenceAsset = Boolean(VERIFIED_REFERENCE_ASSET_MAP[item.id] || asset?.src);

  // Tạo & Chỉnh Ảnh studio state
  const [isStudioOpen, setIsStudioOpen] = useState(false);
  const [studioGender, setStudioGender] = useState<'female' | 'male'>('female');
  const [customPrompt, setCustomPrompt] = useState('');
  const [isGenerating, setIsGenerating] = useState(false);
  const [studioResult, setStudioResult] = useState<ImageGenerationResult | null>(null);
  const latestRequestIdRef = useRef<string>('');

  // Reset studio when item changes
  useEffect(() => {
    setStudioResult(null);
    setCustomPrompt('');
    setIsGenerating(false);
    latestRequestIdRef.current = '';
  }, [item.id]);

  const defaultPrompt = buildReferenceImageEditPrompt(item, customPrompt, studioGender);

  const handleGenerateReferenceImage = async () => {
    if (isGenerating) return;

    const reqId = `req_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`;
    latestRequestIdRef.current = reqId;
    setIsGenerating(true);
    setStudioResult(null);

    try {
      const res = await generateUnifiedImage({
        requestId: reqId,
        mode: 'reference_image_edit',
        gender: studioGender,
        selectedItemIds: [item.id],
        referenceItemId: item.id,
        customPrompt: customPrompt || defaultPrompt,
        outfitTitle: item.name,
      });

      if (latestRequestIdRef.current === reqId) {
        setStudioResult(res);
      }
    } catch {
      if (latestRequestIdRef.current === reqId) {
        setStudioResult({
          ok: false,
          label: 'MINH HỌA AI TẠO & CHỈNH ẢNH',
          disclaimer: 'MINH HỌA AI · KHÔNG PHẢI ẢNH TƯ LIỆU LỊCH SỬ',
          promptUsed: customPrompt || defaultPrompt,
          serviceUsed: 'gemini-3.1-flash-lite-image',
          isFallback: false,
          mode: 'reference_image_edit',
          requestId: reqId,
          error: 'Có lỗi trong quá trình kết nối máy chủ tạo ảnh. Vui lòng bấm "Thử lại".',
          errorType: 'API_ERROR',
        });
      }
    } finally {
      if (latestRequestIdRef.current === reqId) {
        setIsGenerating(false);
      }
    }
  };

  // Find related compatibility rules
  const relatedRules = COMPATIBILITY_RULES.filter(
    (r) =>
      r.itemAId === item.id ||
      r.itemBId === item.id ||
      (r.raw &&
        typeof r.raw === 'object' &&
        'baseGarment' in r.raw &&
        ((r.raw as any).baseGarment.toLowerCase().includes(item.name.toLowerCase()) ||
          (r.raw as any).component.toLowerCase().includes(item.name.toLowerCase())))
  );

  return (
    <div className="space-y-16 pb-20">
      {/* Top Operational Bar */}
      <div className="pt-6 flex flex-wrap items-center justify-between gap-4 border-b border-[#141312]/15 pb-5">
        <button
          type="button"
          onClick={onBackToCatalog}
          className="group inline-flex items-center gap-2 text-xs font-medium tracking-wider uppercase text-[#6E675F] hover:text-[#0D0C0B] transition-colors duration-200 cursor-pointer whitespace-nowrap"
        >
          <span className="inline-block transition-transform duration-200 group-hover:-translate-x-1">
            &larr;
          </span>
          <span>Quay lại Tủ Áo Xưa &amp; Danh mục</span>
        </button>

        <div className="flex items-center gap-3 text-xs font-tabular tracking-widest text-[#6E675F]">
          <span>MÃ: {item.id}</span>
          <span aria-hidden="true">·</span>
          <span className="text-[#9E2A1C] font-semibold uppercase">
            STATUS: {item.auditStatus || 'CORE'}
          </span>
          <span aria-hidden="true">·</span>
          <span className="text-[#2E5A44] font-medium uppercase">
            EVIDENCE: {item.evidenceLevel}
          </span>
        </div>
      </div>

      {/* Main Exhibition Layout */}
      <section className="grid grid-cols-1 lg:grid-cols-12 gap-10 lg:gap-16 items-start">
        {/* Left 5 Cols: Visual / Museum Plate */}
        <div className="lg:col-span-5 space-y-4">
          <div className="relative aspect-[3/4] w-full overflow-hidden bg-[#EAE6DD] border border-[#141312]/15 flex flex-col items-center justify-center p-6 text-center">
            {asset ? (
              <img
                src={asset.src}
                alt={asset.alt || item.name}
                className="h-full w-full object-cover"
              />
            ) : (
              <div className="space-y-3 select-none">
                <span className="font-tabular text-xs tracking-widest text-[#9E2A1C] uppercase block">
                  HỒ SƠ KHẢO CỨU · {item.id}
                </span>
                <p className="font-raven text-2xl text-[#0D0C0B] font-semibold px-4">
                  {item.name}
                </p>
                <div className="border-t border-[#141312]/20 pt-3 max-w-[240px] mx-auto">
                  <p className="text-xs text-[#6E675F] italic font-editorial">
                    Bản ghi tư liệu lưu trữ · Chưa có ảnh hiện vật xác thực
                  </p>
                  <p className="text-[10px] text-[#8A8177] font-tabular mt-1 uppercase tracking-wider">
                    Đang đối chiếu hiện vật bảo tàng
                  </p>
                </div>
              </div>
            )}
          </div>

          <div className="border-t border-[#141312]/15 pt-3 text-xs text-[#6E675F] space-y-1">
            <p>
              <span className="font-semibold text-[#0D0C0B]">Phân loại:</span>{' '}
              {item.category}
            </p>
            {item.aliases && item.aliases.length > 0 && (
              <p>
                <span className="font-semibold text-[#0D0C0B]">Tên gọi khác:</span>{' '}
                {item.aliases.join(', ')}
              </p>
            )}
          </div>
        </div>

        {/* Right 7 Cols: Detailed Dossier */}
        <div className="lg:col-span-7 space-y-10">
          <div className="space-y-4 border-b border-[#0D0C0B] pb-6">
            <div className="flex items-center gap-2 text-xs font-tabular tracking-[0.16em] text-[#6E675F] uppercase">
              <span>HỒ SƠ HIỆN VẬT</span>
              <span aria-hidden="true">·</span>
              <span>{item.category}</span>
            </div>

            <SplitLineReveal
              as="h1"
              lines={[item.name]}
              className="font-raven text-4xl sm:text-6xl font-semibold text-[#0D0C0B] uppercase leading-none"
            />

            <dl className="grid grid-cols-1 sm:grid-cols-3 gap-4 pt-3 text-xs">
              <div className="border-l border-[#0D0C0B]/30 pl-3">
                <dt className="text-[#6E675F] font-tabular uppercase">Thời kỳ</dt>
                <dd className="font-medium text-[#0D0C0B] mt-0.5">
                  {item.period && item.period.length > 0
                    ? item.period.join(', ')
                    : 'Nhiều thời kỳ'}
                </dd>
              </div>
              <div className="border-l border-[#0D0C0B]/30 pl-3">
                <dt className="text-[#6E675F] font-tabular uppercase">Vùng miền</dt>
                <dd className="font-medium text-[#0D0C0B] mt-0.5">
                  {item.region && item.region.length > 0
                    ? item.region.join(', ')
                    : 'Toàn quốc / Bối cảnh lịch sử'}
                </dd>
              </div>
              <div className="border-l border-[#0D0C0B]/30 pl-3">
                <dt className="text-[#6E675F] font-tabular uppercase">Bối cảnh sử dụng</dt>
                <dd className="font-medium text-[#0D0C0B] mt-0.5">
                  {item.context && item.context.length > 0
                    ? item.context.join(', ')
                    : 'Lễ nghi / Đời thường'}
                </dd>
              </div>
            </dl>
          </div>

          {/* Research Chapters */}
          <div className="space-y-8 text-sm">
            {/* 01: Cấu trúc */}
            {item.construction && (
              <div className="border-b border-[#141312]/15 pb-6 space-y-2">
                <div className="flex items-center gap-2">
                  <span className="font-tabular text-xs text-[#9E2A1C]">/01</span>
                  <h2 className="font-raven text-xl font-medium text-[#0D0C0B] uppercase">
                    Cấu trúc &amp; Nhận diện đã xác minh
                  </h2>
                </div>
                <p className="text-[#3D3934] leading-relaxed pl-6">
                  {item.construction}
                </p>
              </div>
            )}

            {/* 02: Phối có cơ sở */}
            {(item.culturalNotes || (item.raw as any)?.layerCompatibility) && (
              <div className="border-b border-[#141312]/15 pb-6 space-y-2">
                <div className="flex items-center gap-2">
                  <span className="font-tabular text-xs text-[#9E2A1C]">/02</span>
                  <h2 className="font-raven text-xl font-medium text-[#0D0C0B] uppercase">
                    Layer / Phối có cơ sở lịch sử
                  </h2>
                </div>
                <p className="text-[#3D3934] leading-relaxed pl-6">
                  {(item.raw as any)?.layerCompatibility || item.culturalNotes}
                </p>
              </div>
            )}

            {/* 03: Cảnh báo cần tránh */}
            {(item.warnings || (item.raw as any)?.warnings) && (
              <div className="border-b border-[#141312]/15 pb-6 space-y-2">
                <div className="flex items-center gap-2">
                  <span className="font-tabular text-xs text-[#9E2A1C]">/03</span>
                  <h2 className="font-raven text-xl font-medium text-[#9E2A1C] uppercase">
                    Phối cần tránh / Cảnh báo văn hóa
                  </h2>
                </div>
                <div className="bg-[#9E2A1C]/5 border-l-2 border-[#9E2A1C] p-3 text-[#3D3934] text-xs leading-relaxed ml-6">
                  {item.warnings || (item.raw as any)?.warnings}
                </div>
              </div>
            )}
          </div>

          {/* Related Compatibility Rules from dataset */}
          {relatedRules.length > 0 && (
            <SectionEntrance showTopRule={false} className="space-y-4">
              <div className="border-b border-[#0D0C0B] pb-2 flex items-baseline justify-between">
                <h3 className="font-raven text-xl font-medium text-[#0D0C0B] uppercase">
                  Quy tắc phối đồ liên quan ({relatedRules.length})
                </h3>
                <span className="font-tabular text-xs text-[#6E675F]">
                  MASTER RULES R001–R022
                </span>
              </div>

              <div className="divide-y divide-[#141312]/15 max-h-[300px] overflow-y-auto pr-2">
                {relatedRules.map((rule) => (
                  <div key={rule.id} className="py-3 space-y-1 text-xs">
                    <div className="flex items-center justify-between gap-2">
                      <span className="font-tabular font-semibold text-[#9E2A1C]">
                        [{rule.id}] {rule.relationshipType}
                      </span>
                      <span className="text-[10px] font-tabular uppercase px-2 py-0.5 border border-[#141312]/20 bg-[#EFECE5]">
                        {rule.label}
                      </span>
                    </div>
                    <p className="text-[#3D3934]">
                      <span className="font-medium text-[#0D0C0B]">Lý do:</span>{' '}
                      {rule.reason}
                    </p>
                    {rule.warning && (
                      <p className="text-[#9E2A1C] italic">
                        <span className="not-italic font-medium">Lưu ý:</span>{' '}
                        {rule.warning}
                      </p>
                    )}
                  </div>
                ))}
              </div>
            </SectionEntrance>
          )}

          {/* Primary Reference Sources */}
          {item.sourceIds && item.sourceIds.length > 0 && (
            <SectionEntrance showTopRule={false} className="space-y-4">
              <h3 className="font-raven text-xl font-medium text-[#0D0C0B] uppercase border-b border-[#0D0C0B] pb-2">
                Nguồn tư liệu đối chiếu ({item.sourceIds.length})
              </h3>
              <div className="space-y-2">
                {item.sourceIds.map((sId) => {
                  const src = RESEARCH_SOURCES_MAP[sId];
                  if (!src) return null;
                  return (
                    <div
                      key={sId}
                      className="p-3 border border-[#141312]/15 bg-[#F6F4EF]/70 space-y-1 text-xs"
                    >
                      <div className="flex items-center justify-between gap-2">
                        <span className="font-tabular font-semibold text-[#9E2A1C]">
                          [{src.id}] {src.institution}
                        </span>
                        <span className="text-[10px] text-[#6E675F]">
                          {src.type}
                        </span>
                      </div>
                      <p className="font-medium text-[#0D0C0B]">{src.title}</p>
                      <p className="text-[#6E675F] text-[11px]">
                        Ứng dụng: {src.usedFor}
                      </p>
                      {src.url && (
                        <a
                          href={src.url}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="inline-flex items-center gap-1 text-[11px] font-tabular text-[#9E2A1C] hover:underline cursor-pointer pt-1"
                        >
                          <span>Xem nguồn bảo tàng</span> &rarr;
                        </a>
                      )}
                    </div>
                  );
                })}
              </div>
            </SectionEntrance>
          )}

          {/* Action Buttons */}
          <div className="border-t border-[#0D0C0B] pt-8 flex flex-wrap items-center gap-4">
            <button
              type="button"
              onClick={() => setIsStudioOpen(true)}
              className="px-6 py-4 bg-[#A63D2F] text-white text-xs font-medium tracking-[0.14em] uppercase hover:bg-[#8B2E21] transition-all cursor-pointer flex items-center gap-2 shadow-sm"
            >
              <Sparkles className="w-4 h-4 text-amber-200" />
              <span>Tạo &amp; Chỉnh Ảnh (AI Studio) &rarr;</span>
            </button>
            <MagneticButton
              type="button"
              variant="primary"
              onClick={() => onUseInBuilder(item)}
              className="px-8 py-4 text-xs font-medium tracking-[0.14em] uppercase"
            >
              Dùng trong Outfit Builder &rarr;
            </MagneticButton>
            <MagneticButton
              type="button"
              variant="outline"
              onClick={onBackToCatalog}
              className="px-8 py-4 text-xs font-medium tracking-[0.14em] uppercase"
            >
              Quay lại Tủ Áo Xưa
            </MagneticButton>
          </div>
        </div>
      </section>

      {/* =========================================================================
          TẠO & CHỈNH ẢNH STUDIO MODAL (REFERENCE_IMAGE_EDIT)
      ========================================================================= */}
      {isStudioOpen && (
        <div
          role="dialog"
          aria-modal="true"
          className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-[#0D0C0B]/85 backdrop-blur-sm animate-fadeIn"
          onClick={() => setIsStudioOpen(false)}
        >
          <div
            className="relative w-full max-w-4xl bg-[#F7F4EE] border border-[#141312]/20 shadow-2xl p-6 sm:p-8 space-y-6 max-h-[92vh] overflow-y-auto"
            onClick={(e) => e.stopPropagation()}
          >
            {/* Header */}
            <div className="flex items-start justify-between border-b border-[#141312]/15 pb-4">
              <div className="space-y-1">
                <div className="flex items-center gap-2 text-[10px] font-tabular tracking-[0.2em] text-[#A63D2F] uppercase font-semibold">
                  <Sparkles className="w-3.5 h-3.5" />
                  <span>STUDIO TẠO &amp; CHỈNH ẢNH (REFERENCE IMAGE EDIT)</span>
                </div>
                <h3 className="font-raven text-2xl sm:text-3xl font-normal text-[#0D0C0B] uppercase">
                  Tạo &amp; Tinh Chỉnh Ảnh: {item.name}
                </h3>
              </div>
              <button
                type="button"
                onClick={() => setIsStudioOpen(false)}
                className="text-2xl text-[#6E675F] hover:text-[#0D0C0B] cursor-pointer p-1 leading-none"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Educational Disclaimer */}
            <div className="p-2.5 bg-[#A63D2F]/10 border border-[#A63D2F]/30 text-center">
              <span className="text-xs font-tabular tracking-wider uppercase font-semibold text-[#A63D2F]">
                MINH HỌA AI TỪ TƯ LIỆU THAM CHIẾU · KHÔNG PHẢI ẢNH HIỆN VẬT GỐC
              </span>
            </div>

            {/* Studio Workspace: 2 Columns */}
            <div className="grid grid-cols-1 md:grid-cols-12 gap-6 items-start">
              {/* Left Column (5 cols): Reference Asset & Result Preview */}
              <div className="md:col-span-5 space-y-4">
                <div className="text-xs font-tabular uppercase tracking-wider text-[#6E675F] flex items-center justify-between">
                  <span>Ảnh tư liệu tham chiếu:</span>
                  <span className="text-[#A63D2F] font-mono text-[10px]">[{item.id}]</span>
                </div>

                <div className="relative aspect-[3/4] bg-[#EAE6DD] border border-[#141312]/20 overflow-hidden flex items-center justify-center">
                  {studioResult?.imageUrl ? (
                    <div className="w-full h-full relative">
                      <img
                        src={studioResult.imageUrl}
                        alt={`Ảnh tạo sinh - ${item.name}`}
                        className="w-full h-full object-contain object-center"
                      />
                      <div className="absolute top-2 right-2 px-2 py-0.5 bg-[#171717]/80 text-white text-[9px] font-tabular uppercase tracking-wider border border-white/20">
                        Đã tạo mới
                      </div>
                    </div>
                  ) : asset?.src ? (
                    <img
                      src={asset.src}
                      alt={asset.alt || item.name}
                      className="w-full h-full object-cover object-top"
                    />
                  ) : (
                    <div className="p-6 text-center space-y-2 text-xs text-[#77736B]">
                      <p className="font-raven text-lg text-[#171717]">Chưa có ảnh tư liệu gốc</p>
                      <p className="text-[11px]">Sử dụng mô tả cấu trúc để tạo hình phom dáng</p>
                    </div>
                  )}

                  {isGenerating && (
                    <div className="absolute inset-0 bg-[#0E0C0A]/75 backdrop-blur-xs flex flex-col items-center justify-center p-4 text-center text-white space-y-3 z-20">
                      <div className="w-10 h-10 border-2 border-[#C8A97E] border-t-transparent rounded-full animate-spin" />
                      <p className="text-xs font-tabular uppercase tracking-wider text-[#C8A97E]">
                        Gemini Nano Banana đang kiến tạo ảnh...
                      </p>
                    </div>
                  )}
                </div>

                {/* Error Banner */}
                {studioResult?.error && !isGenerating && (
                  <div className="p-3 bg-[#991B1B]/10 border border-[#991B1B]/30 rounded text-[#991B1B] text-xs space-y-2">
                    <div className="flex items-start gap-2">
                      <AlertCircle className="w-4 h-4 shrink-0 text-[#991B1B] mt-0.5" />
                      <p className="text-[11px] leading-relaxed">{studioResult.error}</p>
                    </div>
                    <button
                      type="button"
                      onClick={handleGenerateReferenceImage}
                      className="inline-flex items-center gap-1.5 px-3 py-1 bg-[#991B1B] text-white text-[10px] uppercase font-tabular tracking-wider cursor-pointer hover:bg-[#7f1616]"
                    >
                      <RefreshCw className="w-3 h-3" />
                      <span>Thử lại</span>
                    </button>
                  </div>
                )}
              </div>

              {/* Right Column (7 cols): Prompt Controls & Construction Details */}
              <div className="md:col-span-7 space-y-5">
                {/* Dáng người mẫu */}
                <div className="space-y-2">
                  <label className="text-xs font-tabular uppercase tracking-wider text-[#6E675F] block">
                    Dáng người mẫu mục tiêu:
                  </label>
                  <div className="inline-flex items-center p-0.5 border border-[#141312]/20 bg-[#EAE6DD]">
                    <button
                      type="button"
                      onClick={() => setStudioGender('female')}
                      className={`px-4 py-1.5 text-xs font-tabular tracking-wider uppercase transition-all cursor-pointer ${
                        studioGender === 'female'
                          ? 'bg-[#0D0C0B] text-white font-medium'
                          : 'text-[#6E675F] hover:text-[#0D0C0B]'
                      }`}
                    >
                      Dáng Nữ
                    </button>
                    <button
                      type="button"
                      onClick={() => setStudioGender('male')}
                      className={`px-4 py-1.5 text-xs font-tabular tracking-wider uppercase transition-all cursor-pointer ${
                        studioGender === 'male'
                          ? 'bg-[#0D0C0B] text-white font-medium'
                          : 'text-[#6E675F] hover:text-[#0D0C0B]'
                      }`}
                    >
                      Dáng Nam
                    </button>
                  </div>
                </div>

                {/* Construction Spec */}
                {item.construction && (
                  <div className="p-3 bg-[#EAE6DD]/60 border border-[#141312]/10 space-y-1 text-xs">
                    <span className="font-tabular text-[10px] uppercase tracking-wider text-[#A63D2F] font-semibold block">
                      Quy thức nhận diện &amp; Cấu trúc đã thẩm định:
                    </span>
                    <p className="text-[#3D3934] leading-relaxed text-[11px]">{item.construction}</p>
                  </div>
                )}

                {/* Prompt Input */}
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <label className="text-xs font-tabular uppercase tracking-wider text-[#6E675F]">
                      Prompt tạo ảnh từ tư liệu (Động):
                    </label>
                    <button
                      type="button"
                      onClick={() => setCustomPrompt('')}
                      className="text-[10px] font-tabular uppercase text-[#A63D2F] hover:underline cursor-pointer"
                    >
                      Đặt lại prompt gốc
                    </button>
                  </div>
                  <textarea
                    rows={6}
                    value={customPrompt || defaultPrompt}
                    onChange={(e) => setCustomPrompt(e.target.value)}
                    className="w-full p-3 bg-white border border-[#141312]/20 text-xs font-mono text-[#0D0C0B] focus:border-[#A63D2F] focus:outline-none leading-relaxed"
                    placeholder="Nhập chỉ dẫn tạo hoặc chỉnh ảnh..."
                  />
                  <p className="text-[10px] text-[#77736B] italic font-editorial">
                    * Prompt được tự động xây dựng từ tên dạng thức, phom dáng cổ/tay, chất liệu vải và tư liệu ảnh đã xác minh.
                  </p>
                </div>

                {/* Studio Actions */}
                <div className="pt-3 border-t border-[#141312]/15 flex items-center justify-between gap-4">
                  <button
                    type="button"
                    onClick={handleGenerateReferenceImage}
                    disabled={isGenerating}
                    className="px-6 py-3 bg-[#A63D2F] hover:bg-[#8B2E21] text-white text-xs font-medium font-tabular tracking-wider uppercase transition-colors cursor-pointer flex items-center gap-2 disabled:opacity-40 shadow-sm"
                  >
                    <Sparkles className="w-4 h-4 text-amber-200" />
                    <span>{isGenerating ? 'Đang tạo ảnh...' : 'Tạo ảnh từ tư liệu'}</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => setIsStudioOpen(false)}
                    className="px-5 py-3 border border-[#141312]/20 text-xs font-tabular uppercase tracking-wider hover:border-[#141312]/40 text-[#6E675F] cursor-pointer"
                  >
                    Đóng
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
