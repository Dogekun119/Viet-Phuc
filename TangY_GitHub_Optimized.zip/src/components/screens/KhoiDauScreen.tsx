import React, { useEffect, useRef } from 'react';
import { EntryPath, ScreenId } from '../../types';
import {
  HERO_EDITORIAL_IMAGE,
  CARD_TU_AO_IMAGE,
  CARD_PHOI_PHUC_IMAGE,
  CARD_TU_LIEU_IMAGE,
} from '../../data/visualAssets';
import { ArrowRight, ArrowUpRight } from 'lucide-react';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { prefersReducedMotion } from '../motion/MotionPrimitives';

gsap.registerPlugin(ScrollTrigger);

interface KhoiDauScreenProps {
  onNavigate: (screen: ScreenId) => void;
  onStartRemixWithEntry?: (entry: EntryPath) => void;
  onOpenAdvisor?: () => void;
}

export const KhoiDauScreen: React.FC<KhoiDauScreenProps> = ({
  onNavigate,
  onOpenAdvisor,
}) => {
  // 4 Featured canonical garments from research data
  const featuredGarments = [
    {
      id: 'G010',
      name: 'Áo Tứ Thân',
      context: 'Bắc Bộ · Dân gian',
      image: '/src/assets/images/tu_ao_ao_tu_than_1791540316824.jpg',
      alt: 'Minh họa phom dáng Áo Tứ Thân bốn vạt Bắc Bộ truyền thống',
      status: 'Đã kiểm chứng',
    },
    {
      id: 'G008',
      name: 'Áo Ngũ Thân',
      context: 'Cung đình · Nguyễn',
      image: '/src/assets/images/tu_ao_ao_ngu_than_1791540362301.jpg',
      alt: 'Áo ngũ thân lập lĩnh tay chẽn truyền thống',
      status: 'Đã kiểm chứng',
    },
    {
      id: 'G018',
      name: 'Nhật Bình',
      context: 'Cung đình · Nguyễn',
      image: '/src/assets/images/tu_ao_ao_nhat_binh_1791540457083.jpg',
      alt: 'Áo Nhật Bình cổ đối khâm ngũ sắc triều Nguyễn',
      status: 'Đã kiểm chứng',
    },
    {
      id: 'G009',
      name: 'Áo Tấc',
      context: 'Quan lại · Nguyễn',
      image: '/src/assets/images/tu_ao_ao_tac_1791590607100.jpg',
      alt: 'Áo Tấc ngũ thân tay thụng lễ phục',
      status: 'Đã kiểm chứng',
    },
  ];

  // Motion refs
  const heroSectionRef = useRef<HTMLElement | null>(null);
  const heroImageContainerRef = useRef<HTMLDivElement | null>(null);
  const heroLabelRef = useRef<HTMLDivElement | null>(null);
  const heroTitleRef = useRef<HTMLHeadingElement | null>(null);
  const heroSub1Ref = useRef<HTMLParagraphElement | null>(null);
  const heroSub2Ref = useRef<HTMLParagraphElement | null>(null);
  const heroCtaRef = useRef<HTMLDivElement | null>(null);
  const heroTaglineRef = useRef<HTMLDivElement | null>(null);

  // Scroll reveal containers
  const featuredSectionRef = useRef<HTMLElement | null>(null);
  const discoverySectionRef = useRef<HTMLElement | null>(null);
  const manifestoSectionRef = useRef<HTMLElement | null>(null);

  useEffect(() => {
    if (prefersReducedMotion()) return;

    const ctx = gsap.context(() => {
      // 1. Hero Entrance Animations (Gentle fade-in + slight upward movement + 80-120ms stagger)
      const tl = gsap.timeline({ defaults: { ease: 'power3.out' } });

      if (heroImageContainerRef.current) {
        tl.fromTo(
          heroImageContainerRef.current,
          { opacity: 0 },
          { opacity: 1, duration: 1.2, ease: 'power2.out' },
          0
        );
      }

      if (heroLabelRef.current) {
        tl.fromTo(
          heroLabelRef.current,
          { opacity: 0, y: 14 },
          { opacity: 1, y: 0, duration: 0.9 },
          0.1
        );
      }

      if (heroTitleRef.current) {
        tl.fromTo(
          heroTitleRef.current,
          { opacity: 0, y: 22 },
          { opacity: 1, y: 0, duration: 1.0 },
          0.2
        );
      }

      if (heroSub1Ref.current) {
        tl.fromTo(
          heroSub1Ref.current,
          { opacity: 0, y: 16 },
          { opacity: 1, y: 0, duration: 0.9 },
          0.32
        );
      }

      if (heroSub2Ref.current) {
        tl.fromTo(
          heroSub2Ref.current,
          { opacity: 0, y: 16 },
          { opacity: 1, y: 0, duration: 0.9 },
          0.44
        );
      }

      if (heroCtaRef.current) {
        tl.fromTo(
          heroCtaRef.current,
          { opacity: 0, y: 18 },
          { opacity: 1, y: 0, duration: 0.9 },
          0.56
        );
      }

      if (heroTaglineRef.current) {
        tl.fromTo(
          heroTaglineRef.current,
          { opacity: 0, y: 14 },
          { opacity: 1, y: 0, duration: 1.0 },
          0.35
        );
      }

      // 2. Hero Background Subtle Parallax (Moves ~8-12px while scrolling)
      if (heroSectionRef.current && heroImageContainerRef.current) {
        gsap.to(heroImageContainerRef.current, {
          y: 12,
          ease: 'none',
          scrollTrigger: {
            trigger: heroSectionRef.current,
            start: 'top top',
            end: 'bottom top',
            scrub: 0.6,
          },
        });
      }

      // 3. Featured Section Scroll Reveal (opacity: 0 -> 1, translateY: 24px -> 0)
      if (featuredSectionRef.current) {
        gsap.fromTo(
          featuredSectionRef.current.querySelectorAll('.reveal-item'),
          { opacity: 0, y: 24 },
          {
            opacity: 1,
            y: 0,
            duration: 0.85,
            stagger: 0.1,
            ease: 'power3.out',
            scrollTrigger: {
              trigger: featuredSectionRef.current,
              start: 'top 85%',
              once: true,
            },
          }
        );
      }

      // 4. Discovery Section Scroll Reveal
      if (discoverySectionRef.current) {
        gsap.fromTo(
          discoverySectionRef.current.querySelectorAll('.reveal-card'),
          { opacity: 0, y: 26 },
          {
            opacity: 1,
            y: 0,
            duration: 0.9,
            stagger: 0.12,
            ease: 'power3.out',
            scrollTrigger: {
              trigger: discoverySectionRef.current,
              start: 'top 82%',
              once: true,
            },
          }
        );
      }

      // 5. Manifesto Section Scroll Reveal
      if (manifestoSectionRef.current) {
        gsap.fromTo(
          manifestoSectionRef.current.querySelectorAll('.reveal-manifesto'),
          { opacity: 0, y: 22 },
          {
            opacity: 1,
            y: 0,
            duration: 0.8,
            stagger: 0.08,
            ease: 'power3.out',
            scrollTrigger: {
              trigger: manifestoSectionRef.current,
              start: 'top 85%',
              once: true,
            },
          }
        );
      }
    });

    return () => ctx.revert();
  }, []);

  return (
    <div className="w-full">
      {/* =========================================================================
          01. HERO SECTION — CINEMATIC EDITORIAL VIỆT PHỤC
          Full-width cinematic hero with authentic Áo Tứ Thân photograph.
          Woman on RIGHT side, negative space on LEFT.
          Subtle dark scrim only on left side so typography remains crystal clear.
          Extremely subtle parallax (6-12px) and 3 gentle drifting petals.
      ========================================================================= */}
      <section
        ref={heroSectionRef}
        className="relative bg-[#0E0C0A] text-[#F4F1EA] min-h-[85vh] lg:min-h-[92vh] flex items-center overflow-hidden border-b border-[#F4F1EA]/10 px-6 sm:px-12 lg:px-16 py-14 lg:py-24"
      >
        {/* Full-width Cinematic Image with responsive crop & focal alignment */}
        <div
          ref={heroImageContainerRef}
          className="absolute inset-0 w-full h-full z-0 overflow-hidden pointer-events-none select-none will-change-transform"
        >
          <img
            src={HERO_EDITORIAL_IMAGE}
            alt="Việt Phục Áo Tứ Thân — Những gì còn lại, những gì đang được tìm lại"
            className="w-full h-full object-cover object-[78%_center] sm:object-[75%_center] lg:object-[right_center] opacity-90 lg:opacity-100 filter contrast-[1.03] animate-ken-burns origin-center"
          />
          {/* Subtle dark overlay ONLY on LEFT side so typography is perfectly legible without covering woman */}
          <div className="absolute inset-0 bg-gradient-to-r from-[#0E0C0A]/95 via-[#0E0C0A]/70 to-transparent w-full lg:w-[62%]" />
          <div className="absolute inset-0 bg-gradient-to-t from-[#0E0C0A]/90 via-transparent to-black/20" />
        </div>

        {/* Atmospheric Motion: 3 subtle, low-opacity drifting flower petals */}
        <div
          className="absolute inset-0 pointer-events-none z-1 overflow-hidden"
          aria-hidden="true"
        >
          {/* Petal 1 */}
          <div className="absolute top-[8%] left-[26%] w-2.5 h-3 bg-[#EAD8C7] rounded-[60%_40%_70%_30%] blur-[0.6px] animate-petal-1" />
          {/* Petal 2 */}
          <div className="absolute top-[4%] left-[64%] w-3 h-3.5 bg-[#F2DDD0] rounded-[45%_55%_35%_65%] blur-[0.8px] animate-petal-2" />
          {/* Petal 3 */}
          <div className="absolute top-[12%] left-[45%] w-2 h-2.5 bg-[#D6B8A2] rounded-[50%_50%_60%_40%] blur-[0.5px] animate-petal-3" />
        </div>

        {/* Content Container */}
        <div className="relative z-10 max-w-[1440px] mx-auto w-full grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
          {/* LEFT: Contextual Label, Title, Statement, CTA */}
          <div className="lg:col-span-7 space-y-6 sm:space-y-8 pr-0 lg:pr-8">
            {/* Small Contextual Label */}
            <div
              ref={heroLabelRef}
              className="inline-flex items-center gap-3 text-xs font-mono tracking-[0.25em] text-[#C8A97E] uppercase"
            >
              <span>01 / 04</span>
              <span className="w-8 h-[1px] bg-[#C8A97E]/50" />
              <span>TÀNG Y CÁC</span>
            </div>

            {/* Large "VIỆT PHỤC" Title & Statement */}
            <div className="space-y-4">
              <h1
                ref={heroTitleRef}
                className="font-raven text-6xl sm:text-8xl lg:text-[104px] font-normal tracking-[0.04em] uppercase text-[#F4F1EA] leading-[0.92]"
              >
                Việt Phục
              </h1>
              <div className="space-y-1 pt-1">
                <p
                  ref={heroSub1Ref}
                  className="font-editorial text-2xl sm:text-3xl lg:text-4xl text-[#E8E2D5] font-light italic leading-snug drop-shadow-sm"
                >
                  Những gì còn lại.
                </p>
                <p
                  ref={heroSub2Ref}
                  className="font-editorial text-2xl sm:text-3xl lg:text-4xl text-[#E8E2D5] font-light italic leading-snug drop-shadow-sm"
                >
                  Những gì đang được tìm lại.
                </p>
              </div>
            </div>

            {/* Primary CTAs: "KHÁM PHÁ →" & "HỎI CỐ VẤN TÀNG Y" */}
            <div ref={heroCtaRef} className="pt-4 sm:pt-6 flex flex-wrap items-center gap-6">
              <button
                type="button"
                onClick={() => onNavigate('tu-ao-xua')}
                className="group inline-flex items-center gap-4 cursor-pointer"
              >
                <span className="w-12 h-12 rounded-full bg-[#A63D2F] text-white flex items-center justify-center transition-all duration-300 group-hover:scale-108 group-hover:bg-[#8F2E22] shadow-lg shrink-0">
                  <ArrowRight className="w-5 h-5 transition-transform duration-300 group-hover:translate-x-1" />
                </span>
                <span className="font-raven text-base sm:text-lg tracking-[0.18em] uppercase text-[#F4F1EA] group-hover:text-[#C8A97E] transition-colors font-medium">
                  Khám phá &rarr;
                </span>
              </button>

              {onOpenAdvisor && (
                <button
                  type="button"
                  onClick={onOpenAdvisor}
                  className="group inline-flex items-center gap-2.5 px-4 py-3 rounded-full border border-[#C8A97E]/40 bg-[#0E0C0A]/70 hover:bg-[#C8A97E]/15 text-[#C8A97E] hover:text-[#F4F1EA] transition-all cursor-pointer backdrop-blur-md shadow-md"
                >
                  <span className="w-6 h-6 rounded-full bg-[#A63D2F] text-white text-[11px] font-raven font-bold flex items-center justify-center">
                    藏
                  </span>
                  <span className="font-raven text-xs sm:text-sm tracking-wider uppercase font-medium">
                    Hôm nay mặc gì? — Hỏi Cố Vấn
                  </span>
                </button>
              )}
            </div>
          </div>

          {/* RIGHT / TOP RIGHT: Contextual Tagline (aligned away from woman) */}
          <div
            ref={heroTaglineRef}
            className="lg:col-span-5 hidden lg:flex flex-col items-end justify-between h-full space-y-12 text-right"
          >
            <div className="text-[11px] font-mono tracking-[0.22em] uppercase text-[#C8BFB0] space-y-1 leading-relaxed border-r-2 border-[#A63D2F] pr-4 drop-shadow-sm">
              <div>TƯ LIỆU</div>
              <div>HIỆN VẬT</div>
              <div>PHỤC DỰNG</div>
              <div className="text-[#C8A97E]">VÀ NHIỀU HƠN NỮA</div>
            </div>

            <div className="p-4 bg-[#0E0C0A]/75 backdrop-blur-md border border-[#F4F1EA]/15 text-left max-w-xs space-y-1 text-xs shadow-md">
              <span className="text-[#C8A97E] font-mono text-[10px] uppercase tracking-wider block">
                Hệ thống dữ liệu chuẩn hóa
              </span>
              <p className="text-[#E8E2D5]/90 text-[11px] leading-relaxed">
                49 thực thể y phục và phụ kiện được đối chiếu nghiêm cẩn qua thư tịch và bảo tàng.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* =========================================================================
          TRANSITION TO WARM IVORY EDITORIAL SURFACE
      ========================================================================= */}
      <div className="text-[#171717] transition-colors duration-300 relative z-10">
        <div className="max-w-[1440px] mx-auto px-6 sm:px-12 py-20 sm:py-28 space-y-24 sm:space-y-32">
          {/* =====================================================================
              02. DẠNG THỨC NỔI BẬT (FEATURED GARMENTS)
              Áo Tứ Thân · Áo Ngũ Thân · Nhật Bình · Áo Tấc
          ===================================================================== */}
          <section ref={featuredSectionRef} className="space-y-10 sm:space-y-12">
            <div className="flex items-end justify-between border-b border-[#D8D3C9] pb-4 reveal-item">
              <div>
                <span className="text-[11px] font-mono tracking-[0.2em] text-[#77736B] uppercase block mb-1">
                  TUYỂN TẬP ĐIỂN HÌNH
                </span>
                <h2 className="font-raven text-3xl sm:text-4xl lg:text-5xl font-normal text-[#171717] uppercase tracking-wide">
                  Dạng Thức Nổi Bật
                </h2>
              </div>
              <button
                type="button"
                onClick={() => onNavigate('tu-ao-xua')}
                className="group inline-flex items-center gap-1.5 text-xs font-medium uppercase tracking-wider text-[#171717] hover:text-[#A63D2F] transition-colors cursor-pointer"
              >
                <span>Xem tất cả</span>
                <span className="transition-transform duration-300 group-hover:translate-x-1">
                  &rarr;
                </span>
              </button>
            </div>

            {/* 4 Cards Editorial Grid (Borderless / Image First / Refined Hover) */}
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-x-6 gap-y-10 items-start">
              {featuredGarments.map((garment) => (
                <article
                  key={garment.id}
                  onClick={() => onNavigate('tu-ao-xua')}
                  className="group cursor-pointer flex flex-col justify-between space-y-3 reveal-item"
                >
                  {/* Image First with refined 1.00 -> 1.025 hover scale */}
                  <div className="relative aspect-[3/4] w-full overflow-hidden bg-[#E8E3DA]">
                    <img
                      src={garment.image}
                      alt={garment.alt}
                      loading="lazy"
                      className="w-full h-full object-cover object-top transition-transform duration-700 ease-out group-hover:scale-[1.025]"
                    />
                    <div className="absolute top-3 right-3">
                      <span className="text-[10px] uppercase tracking-wider px-2 py-0.5 bg-[#F4F1EA]/85 backdrop-blur-md border border-[#D8D3C9]/80 text-[#171717] font-medium">
                        {garment.status}
                      </span>
                    </div>
                  </div>

                  {/* Below Image: Name & Metadata */}
                  <div className="pt-1 space-y-1">
                    <div className="flex items-start justify-between gap-2">
                      <h3 className="font-raven text-xl sm:text-2xl font-normal text-[#171717] group-hover:text-[#A63D2F] transition-colors uppercase tracking-wide leading-snug">
                        {garment.name}
                      </h3>
                      <ArrowUpRight className="w-4 h-4 text-[#77736B] opacity-0 -translate-x-1 translate-y-1 group-hover:opacity-100 group-hover:translate-x-0 group-hover:translate-y-0 group-hover:text-[#A63D2F] transition-all duration-300 shrink-0 mt-1" />
                    </div>
                    <p className="text-xs text-[#77736B] tracking-wide">
                      {garment.context}
                    </p>
                  </div>
                </article>
              ))}
            </div>
          </section>

          {/* =====================================================================
              03. DISCOVERY SECTION — TỦ ÁO / PHỐI PHỤC / TƯ LIỆU
              Large typography, evocative photographic panels, generous whitespace
          ===================================================================== */}
          <section ref={discoverySectionRef} className="space-y-6">
            <div className="text-[11px] font-mono tracking-[0.2em] text-[#77736B] uppercase mb-2 reveal-card">
              LỐI VÀO KHÁM PHÁ
            </div>

            {/* Top Row: 2 Cards (TỦ ÁO & PHỐI PHỤC) */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {/* Card 1: TỦ ÁO */}
              <div
                onClick={() => onNavigate('tu-ao-xua')}
                className="group relative aspect-[16/11] sm:aspect-[16/10] overflow-hidden bg-[#12100E] p-8 sm:p-10 flex flex-col justify-end cursor-pointer transition-all duration-300 reveal-card"
              >
                <img
                  src={CARD_TU_AO_IMAGE}
                  alt="Khám phá Tủ Áo Cổ Truyền"
                  className="absolute inset-0 w-full h-full object-cover object-center opacity-65 group-hover:opacity-75 group-hover:scale-[1.025] transition-all duration-700 ease-out"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/50 to-transparent" />

                <div className="relative z-10 space-y-3">
                  <div className="flex items-center justify-between text-xs font-mono tracking-widest text-[#C8A97E] uppercase">
                    <span>/ 01</span>
                    <span>49 HIỆN VẬT</span>
                  </div>
                  <h3 className="font-raven text-3xl sm:text-4xl text-white uppercase tracking-wider font-normal">
                    Tủ Áo
                  </h3>
                  <p className="font-editorial text-base text-white/85 italic max-w-sm leading-relaxed">
                    Khám phá những dạng thức Việt phục được ghi nhận, phục dựng và nghiên cứu.
                  </p>
                  <div className="pt-2 text-xs font-medium uppercase tracking-widest text-white group-hover:text-[#C8A97E] transition-colors inline-flex items-center gap-2">
                    <span>Xem tủ áo</span>
                    <span className="transition-transform duration-300 group-hover:translate-x-1">
                      &rarr;
                    </span>
                  </div>
                </div>
              </div>

              {/* Card 2: PHỐI PHỤC */}
              <div
                onClick={() => onNavigate('phoi-phuc')}
                className="group relative aspect-[16/11] sm:aspect-[16/10] overflow-hidden bg-[#12100E] p-8 sm:p-10 flex flex-col justify-end cursor-pointer transition-all duration-300 reveal-card"
              >
                <img
                  src={CARD_PHOI_PHUC_IMAGE}
                  alt="Thực nghiệm Phối Phục Lịch Sử"
                  className="absolute inset-0 w-full h-full object-cover object-[center_35%] opacity-65 group-hover:opacity-75 group-hover:scale-[1.025] transition-all duration-700 ease-out"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/50 to-transparent" />

                <div className="relative z-10 space-y-3">
                  <div className="flex items-center justify-between text-xs font-mono tracking-widest text-[#C8A97E] uppercase">
                    <span>/ 02</span>
                    <span>KHÔNG GIAN THỰC NGHIỆM</span>
                  </div>
                  <h3 className="font-raven text-3xl sm:text-4xl text-white uppercase tracking-wider font-normal">
                    Phối Phục
                  </h3>
                  <p className="font-editorial text-base text-white/85 italic max-w-sm leading-relaxed">
                    Thử nghiệm kết hợp các lớp trang phục theo giới tính, bối cảnh và quy tắc lớp lang.
                  </p>
                  <div className="pt-2 text-xs font-medium uppercase tracking-widest text-white group-hover:text-[#C8A97E] transition-colors inline-flex items-center gap-2">
                    <span>Bắt đầu phối</span>
                    <span className="transition-transform duration-300 group-hover:translate-x-1">
                      &rarr;
                    </span>
                  </div>
                </div>
              </div>
            </div>

            {/* Bottom Wide Card: TƯ LIỆU */}
            <div
              onClick={() => onNavigate('tu-ao-xua')}
              className="group relative aspect-[21/9] sm:aspect-[24/9] overflow-hidden bg-[#12100E] p-8 sm:p-12 flex flex-col justify-end cursor-pointer transition-all duration-300 reveal-card"
            >
              <img
                src={CARD_TU_LIEU_IMAGE}
                alt="Khám phá Tư Liệu Khảo Cứu"
                className="absolute inset-0 w-full h-full object-cover object-[center_40%] opacity-55 group-hover:opacity-65 group-hover:scale-[1.025] transition-all duration-700 ease-out"
              />
              <div className="absolute inset-0 bg-gradient-to-r from-black/95 via-black/75 to-transparent" />

              <div className="relative z-10 space-y-2.5 max-w-xl">
                <div className="flex items-center gap-3 text-xs font-mono tracking-widest text-[#C8A97E] uppercase">
                  <span>/ 03</span>
                  <span>10 NGUỒN BẢO TÀNG · S01–S10</span>
                </div>
                <h3 className="font-raven text-3xl sm:text-4xl text-white uppercase tracking-wider font-normal">
                  Tư Liệu
                </h3>
                <p className="font-editorial text-base text-white/85 italic leading-relaxed">
                  Tìm hiểu câu chuyện phía sau mỗi dạng thức.
                </p>
                <div className="pt-2 text-xs font-medium uppercase tracking-widest text-white group-hover:text-[#C8A97E] transition-colors inline-flex items-center gap-2">
                  <span>Xem tư liệu</span>
                  <span className="transition-transform duration-300 group-hover:translate-x-1">
                    &rarr;
                  </span>
                </div>
              </div>
            </div>
          </section>

          {/* =====================================================================
              04. EDITORIAL MANIFESTO (GIỮ NẾP & MINH BẠCH HỌC THUẬT)
          ===================================================================== */}
          <section ref={manifestoSectionRef} className="border-t border-[#D8D3C9] pt-14 space-y-8">
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
              <div className="lg:col-span-4 space-y-2 reveal-manifesto">
                <span className="text-[11px] font-mono tracking-[0.2em] text-[#77736B] uppercase block">
                  TÔN CHỈ KHẢO CỨU
                </span>
                <h3 className="font-raven text-2xl sm:text-3xl font-normal text-[#171717] uppercase">
                  Giữ Nếp &amp; Đối Chiếu
                </h3>
                <p className="font-editorial text-sm text-[#77736B] italic leading-relaxed">
                  &ldquo;AI có thể sáng tạo phong cách, nhưng không được sáng tạo sự thật văn hóa.&rdquo;
                </p>
              </div>

              <div className="lg:col-span-8 grid grid-cols-1 sm:grid-cols-3 gap-6 text-xs">
                <div className="p-5 bg-white/50 border border-[#D8D3C9] space-y-2 reveal-manifesto hover:border-[#A63D2F]/40 transition-colors duration-300">
                  <span className="font-mono text-[#A63D2F] font-bold text-sm block">
                    01
                  </span>
                  <h4 className="font-medium text-[#171717] uppercase tracking-wide">
                    Có Nguồn Hiện Vật
                  </h4>
                  <p className="text-[#524D46] leading-relaxed">
                    Mọi phom dáng đều đối chiếu từ bảo tàng quốc gia và thư tịch cổ chính thống.
                  </p>
                </div>

                <div className="p-5 bg-white/50 border border-[#D8D3C9] space-y-2 reveal-manifesto hover:border-[#A63D2F]/40 transition-colors duration-300">
                  <span className="font-mono text-[#A63D2F] font-bold text-sm block">
                    02
                  </span>
                  <h4 className="font-medium text-[#171717] uppercase tracking-wide">
                    Quy Tắc Tương Thích
                  </h4>
                  <p className="text-[#524D46] leading-relaxed">
                    Cảnh báo khách quan khi phối sai lệch bối cảnh lịch sử hoặc niên đại.
                  </p>
                </div>

                <div className="p-5 bg-white/50 border border-[#D8D3C9] space-y-2 reveal-manifesto hover:border-[#A63D2F]/40 transition-colors duration-300">
                  <span className="font-mono text-[#A63D2F] font-bold text-sm block">
                    03
                  </span>
                  <h4 className="font-medium text-[#171717] uppercase tracking-wide">
                    Minh Bạch Bất Định
                  </h4>
                  <p className="text-[#524D46] leading-relaxed">
                    Giữ nguyên nhãn tranh luận học thuật cho các chi tiết chưa đủ cứ liệu xác minh.
                  </p>
                </div>
              </div>
            </div>
          </section>
        </div>
      </div>
    </div>
  );
};
