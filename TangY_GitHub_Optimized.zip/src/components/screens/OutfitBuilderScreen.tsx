import React, { useMemo, useState, useRef, useEffect } from 'react';
import { Item, OutfitEvaluation, SavedUserOutfit } from '../../domain/types';
import {
  CANONICAL_ENTITIES,
  CANONICAL_ENTITIES_MAP,
  type ModelGender,
  isItemCompatibleWithGender,
} from '../../domain/canonicalData';
import {
  evaluateOutfit,
  getRecommendedNextItems,
} from '../../domain/compatibilityEngine';
import {
  generateUnifiedImage,
  ImageGenerationResult,
  GenerationMode,
  isAccessoryItem,
} from '../../services/geminiImage';
import {
  MagneticButton,
  SectionEntrance,
  SplitLineReveal,
} from '../motion/MotionPrimitives';
import { ModelStage } from '../model/ModelStage';
import {
  resolveLayersForItems,
  TEST_OUTFIT_LAYERS,
  GarmentLayerData,
  CANONICAL_STYLING_MAP,
} from '../../domain/garmentLayers';
import phoiPhucModelImage from '../../assets/images/phoi_phuc_woman_1791389738675.jpg';
import { Share2, Download, Copy, Check, AlertCircle, RefreshCw } from 'lucide-react';
import {
  exportAndShareOutfitComposition,
  triggerBlobDownload,
  type ShareCompositionResult,
} from '../../utils/outfitShareExport';

interface OutfitBuilderScreenProps {
  initialSelectedItems?: Item[];
  onSaveOutfit: (outfit: SavedUserOutfit) => void;
  onCompareOutfit: (outfit: SavedUserOutfit) => void;
  onViewItemDetail: (item: Item) => void;
  onOpenAdvisor?: () => void;
}

// 7 Standard Wardrobe Categories (1 category visible at a time)
type WardrobeCategory =
  | 'OUTER'
  | 'UNDER'
  | 'LOWER'
  | 'HEAD'
  | 'BELT'
  | 'ACC'
  | 'FOOT';

interface CategoryTabConfig {
  id: WardrobeCategory;
  label: string;
}

const CATEGORY_TABS: CategoryTabConfig[] = [
  { id: 'OUTER', label: 'Áo' },
  { id: 'UNDER', label: 'Lớp trong' },
  { id: 'LOWER', label: 'Thân dưới' },
  { id: 'HEAD', label: 'Khăn / Nón' },
  { id: 'BELT', label: 'Thắt lưng' },
  { id: 'ACC', label: 'Phụ kiện' },
  { id: 'FOOT', label: 'Giày & Footwear' },
];

// Helper to categorize each canonical item cleanly into one of the 7 tabs
function getItemCategory(item: Item): WardrobeCategory {
  const id = item.id;
  const name = item.name.toLowerCase();
  const cat = (item.category || '').toLowerCase();

  if (
    ['G011'].includes(id) ||
    cat.includes('nội y') ||
    cat.includes('lớp trong') ||
    name.includes('yếm') ||
    name.includes('áo lót')
  ) {
    return 'UNDER';
  }
  if (
    ['G012', 'G013', 'G014', 'G024'].includes(id) ||
    cat.includes('thân dưới') ||
    name.includes('váy') ||
    name.includes('quần') ||
    name.includes('khố') ||
    name.includes('xiêm')
  ) {
    return 'LOWER';
  }
  if (
    ['G031', 'G032', 'G033', 'G034', 'G035', 'G036', 'G037'].includes(id) ||
    cat.includes('khăn') ||
    cat.includes('nón') ||
    cat.includes('mũ') ||
    name.includes('khăn') ||
    name.includes('nón') ||
    name.includes('mũ')
  ) {
    return 'HEAD';
  }
  if (
    ['G042', 'G043'].includes(id) ||
    cat.includes('thắt lưng') ||
    cat.includes('đai') ||
    name.includes('thắt lưng') ||
    name.includes('dải lưng') ||
    name.includes('đai') ||
    name.includes('dây ruột tượng')
  ) {
    return 'BELT';
  }
  if (
    ['G045', 'G046', 'G047'].includes(id) ||
    cat.includes('giày') ||
    cat.includes('footwear') ||
    name.includes('hài') ||
    name.includes('guốc') ||
    name.includes('hia')
  ) {
    return 'FOOT';
  }
  if (
    ['G017', 'G039', 'G040', 'G041', 'G044', 'A011', 'A012'].includes(id) ||
    cat.includes('phụ kiện') ||
    name.includes('trâm') ||
    name.includes('vân kiên') ||
    name.includes('bổ tử') ||
    name.includes('hốt') ||
    name.includes('quạt') ||
    name.includes('thẻ bài')
  ) {
    return 'ACC';
  }
  return 'OUTER';
}

// Exactly 4 Visible Layer Indicators on the Model Preview
interface ModelIndicator {
  category: WardrobeCategory;
  label: string;
  side: 'left' | 'right';
  topPercent: string;
}

const MODEL_INDICATORS: ModelIndicator[] = [
  { category: 'HEAD', label: 'KHĂN / NÓN', side: 'left', topPercent: '13%' },
  { category: 'OUTER', label: 'ÁO', side: 'left', topPercent: '34%' },
  { category: 'UNDER', label: 'LỚP TRONG', side: 'right', topPercent: '42%' },
  { category: 'LOWER', label: 'THÂN DƯỚI', side: 'right', topPercent: '68%' },
];

export const OutfitBuilderScreen: React.FC<OutfitBuilderScreenProps> = ({
  initialSelectedItems = [],
  onSaveOutfit,
  onCompareOutfit,
  onViewItemDetail,
  onOpenAdvisor,
}) => {
  // ONE source of truth for Model Gender: "female" | "male"
  const [selectedModelGender, setSelectedModelGender] =
    useState<ModelGender>('female');

  // CRITICAL DATA RULE: Exact 44 active canonical entities from CANONICAL_ENTITIES
  // (Excludes 5 removed garments: Áo Cổ Thìa, Áo Bán Tí, Áo Thâm, Áo Cánh, Áo Chàm)
  // Filtered by selectedModelGender ('female' or 'male')
  const canonicalWardrobeItems: Item[] = useMemo(() => {
    return CANONICAL_ENTITIES
      .map((e) => e.asItem)
      .filter((item) => isItemCompatibleWithGender(item, selectedModelGender));
  }, [selectedModelGender]);

  // INITIAL OUTFIT: Complete curated outfit (Áo Tứ Thân + Yếm + Váy + Thắt lưng + Khăn mỏ quạ)
  const [selectedItems, setSelectedItems] = useState<Item[]>(() => {
    if (initialSelectedItems && initialSelectedItems.length > 0) {
      return initialSelectedItems;
    }
    const defaultIds = ['G010', 'G011', 'G012', 'G042', 'G033'];
    return defaultIds
      .map((id) => {
        const entity = CANONICAL_ENTITIES.find(
          (e) => e.primaryRecordId === id || e.mergedRecordIds.includes(id)
        );
        return entity?.asItem;
      })
      .filter((i): i is Item => Boolean(i));
  });

  // Keep selectedItems synchronized whenever initialSelectedItems changes from Advisor or Catalog
  useEffect(() => {
    if (initialSelectedItems && initialSelectedItems.length > 0) {
      setSelectedItems(initialSelectedItems);

      // Auto-switch model gender if items are gender-exclusive
      const hasMaleOnly = initialSelectedItems.some((i) => i.genderScope === 'male');
      const hasFemaleOnly = initialSelectedItems.some((i) => i.genderScope === 'female');
      if (hasMaleOnly && !hasFemaleOnly) {
        setSelectedModelGender('male');
      } else if (hasFemaleOnly && !hasMaleOnly) {
        setSelectedModelGender('female');
      }
    }
  }, [initialSelectedItems]);

  // Handle Model Gender Switching: keep compatible layers or switch to canonical starter
  const handleSelectGender = (gender: ModelGender) => {
    if (gender === selectedModelGender) return;
    latestRequestIdRef.current = `req_gender_${Date.now()}`;
    setSelectedModelGender(gender);
    setTryOnResult(null); // Reset try-on to base model on gender change
    setIsGeneratingTryOn(false);

    setSelectedItems((prev) => {
      const compatible = prev.filter((item) =>
        isItemCompatibleWithGender(item, gender)
      );

      // If empty or missing base outer garment, provide starter for chosen gender
      if (
        compatible.length === 0 ||
        !compatible.some((i) => getItemCategory(i) === 'OUTER')
      ) {
        const starterIds =
          gender === 'male'
            ? ['G008', 'G013', 'G031', 'G047'] // Ngũ Thân nam + Quần sáng màu + Khăn xếp + Guốc mộc
            : ['G010', 'G011', 'G012', 'G042', 'G033']; // Tứ Thân nữ + Yếm + Váy + Thắt lưng + Khăn mỏ quạ

        return starterIds
          .map((id) => {
            const entity = CANONICAL_ENTITIES.find(
              (e) => e.primaryRecordId === id || e.mergedRecordIds.includes(id)
            );
            return entity?.asItem;
          })
          .filter((i): i is Item => Boolean(i));
      }

      return compatible;
    });
  };

  // Current active wardrobe category (Only one category visible at a time)
  const [activeCategory, setActiveCategory] =
    useState<WardrobeCategory>('OUTER');

  // Try-on and research modals state
  const [isTryOnOpen, setIsTryOnOpen] = useState(false);
  const [isGeneratingTryOn, setIsGeneratingTryOn] = useState(false);
  const [tryOnResult, setTryOnResult] = useState<ImageGenerationResult | null>(null);
  const [isResearchModalOpen, setIsResearchModalOpen] = useState(false);
  const [saveToast, setSaveToast] = useState<string | null>(null);
  const latestRequestIdRef = useRef<string>('');

  // Outfit composition export & sharing states
  const [isSharing, setIsSharing] = useState(false);
  const [shareResult, setShareResult] = useState<ShareCompositionResult | null>(null);
  const [isShareModalOpen, setIsShareModalOpen] = useState(false);
  const [copyFeedback, setCopyFeedback] = useState(false);

  const wardrobeSectionRef = useRef<HTMLDivElement | null>(null);

  // Active transparent garment layers resolved for the current outfit
  const activeGarmentLayers = useMemo<GarmentLayerData[]>(() => {
    return resolveLayersForItems(selectedItems);
  }, [selectedItems]);

  // Deterministic Cultural Evaluation
  const evaluation: OutfitEvaluation = useMemo(() => {
    return evaluateOutfit(selectedItems);
  }, [selectedItems]);

  // Recommended next items for harmonic styling
  const recommendedItems = useMemo(() => {
    return getRecommendedNextItems(selectedItems);
  }, [selectedItems]);

  // Human-friendly title of the current outfit
  const outfitTitle = useMemo(() => {
    const outer = selectedItems.find((i) => getItemCategory(i) === 'OUTER');
    if (outer) return outer.name.toUpperCase();
    if (selectedItems.length > 0) return selectedItems[0].name.toUpperCase();
    return 'BỘ PHỐI TRỐNG';
  }, [selectedItems]);

  // Subtle sub-layers summary: Yếm · Váy · Thắt lưng · Khăn
  const outfitSubLayers = useMemo(() => {
    if (selectedItems.length === 0) return 'Chưa chọn lớp trang phục';
    return selectedItems.map((i) => i.name).join(' · ');
  }, [selectedItems]);

  // Translate technical evaluation status to user-facing badge
  const statusConfig = useMemo(() => {
    switch (evaluation.label) {
      case 'AUTHENTIC':
        return {
          label: 'XÁC THỰC',
          dotColor: 'bg-[#2E5A44]',
          textColor: 'text-[#2E5A44]',
          isMatch: true,
        };
      case 'HISTORICALLY_SUPPORTED':
        return {
          label: 'PHÙ HỢP TƯ LIỆU',
          dotColor: 'bg-[#2E5A44]',
          textColor: 'text-[#2E5A44]',
          isMatch: true,
        };
      case 'CONTEXTUAL_MODERN_REMIX':
        return {
          label: 'REMIX HIỆN ĐẠI',
          dotColor: 'bg-[#C89B3C]',
          textColor: 'text-[#8C6219]',
          isMatch: true,
        };
      case 'UNCERTAIN':
        return {
          label: 'ĐANG TRANH LUẬN',
          dotColor: 'bg-[#633B5B]',
          textColor: 'text-[#633B5B]',
          isMatch: true,
        };
      case 'CULTURAL_MISMATCH':
        return {
          label: 'KHÔNG PHÙ HỢP',
          dotColor: 'bg-[#9E2A1C]',
          textColor: 'text-[#9E2A1C]',
          isMatch: false,
        };
      case 'INSUFFICIENT_DATA':
      default:
        return {
          label: 'CHƯA ĐỦ TƯ LIỆU',
          dotColor: 'bg-[#8A8177]',
          textColor: 'text-[#6E675F]',
          isMatch: true,
        };
    }
  }, [evaluation.label]);

  // Single concise explanation text
  const shortExplanation = useMemo(() => {
    if (evaluation.label === 'CULTURAL_MISMATCH') {
      return (
        evaluation.warnings[0] ||
        'Lớp trang phục này không phù hợp với bối cảnh đang chọn vì khác biệt về thời kỳ hoặc không gian văn hóa.'
      );
    }
    if (evaluation.summary) {
      return evaluation.summary;
    }
    return 'Tổ hợp này phù hợp với bối cảnh trang phục theo dữ liệu tư liệu hiện có.';
  }, [evaluation]);

  // Wardrobe items in current active category
  const currentCategoryItems = useMemo(() => {
    return canonicalWardrobeItems.filter(
      (item) => getItemCategory(item) === activeCategory
    );
  }, [canonicalWardrobeItems, activeCategory]);

  // Single-item Try-On handler for "+ Mặc vào" on a single garment/accessory
  const triggerSingleItemTryOn = async (item: Item) => {
    if (isGeneratingTryOn) return;

    const reqId = `req_single_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`;
    latestRequestIdRef.current = reqId;
    setIsGeneratingTryOn(true);
    setTryOnResult(null);

    try {
      const res = await generateUnifiedImage({
        requestId: reqId,
        mode: 'single_item_try_on',
        gender: selectedModelGender,
        selectedItemIds: [item.id],
        referenceItemId: item.id,
        outfitTitle: item.name,
      });

      if (latestRequestIdRef.current === reqId) {
        setTryOnResult(res);
      }
    } catch {
      if (latestRequestIdRef.current === reqId) {
        setTryOnResult({
          ok: false,
          label: 'MINH HỌA AI THỬ TRANG PHỤC ĐƠN MÓN',
          disclaimer: 'MINH HỌA AI · KHÔNG PHẢI ẢNH TƯ LIỆU LỊCH SỬ',
          promptUsed: '',
          serviceUsed: 'gemini-3.1-flash-lite-image',
          isFallback: false,
          mode: 'single_item_try_on',
          requestId: reqId,
          error: 'Có lỗi trong quá trình kết nối dịch vụ tạo ảnh. Vui lòng bấm "Thử lại".',
          errorType: 'API_ERROR',
        });
      }
    } finally {
      if (latestRequestIdRef.current === reqId) {
        setIsGeneratingTryOn(false);
      }
    }
  };

  // Wardrobe click interaction: Toggle or replace in slot
  const handleToggleItem = (item: Item) => {
    // Invalidate in-flight requests and clear stale preview
    latestRequestIdRef.current = `req_change_${Date.now()}`;
    setTryOnResult(null);
    setIsGeneratingTryOn(false);

    const isEquipped = selectedItems.some((i) => i.id === item.id);
    if (isEquipped) {
      setSelectedItems((prev) => {
        const remaining = prev.filter((i) => i.id !== item.id);
        if (remaining.length === 1) {
          triggerSingleItemTryOn(remaining[0]);
        }
        return remaining;
      });
      return;
    }

    const slot = getItemCategory(item);
    // For single-layer slots (Áo, Lớp trong, Thân dưới, Khăn/Nón, Giày), replace existing
    const existingInSlot = selectedItems.find(
      (i) => getItemCategory(i) === slot
    );

    let nextItems: Item[];
    if (existingInSlot && slot !== 'ACC') {
      nextItems = selectedItems.map((i) => (i.id === existingInSlot.id ? item : i));
    } else {
      nextItems = [...selectedItems, item];
    }

    setSelectedItems(nextItems);

    // If only 1 item is now selected, activate single-item generation
    if (nextItems.length === 1) {
      triggerSingleItemTryOn(item);
    }
  };

  // Clicking an indicator around the model switches the wardrobe tab
  const handleIndicatorClick = (cat: WardrobeCategory) => {
    setActiveCategory(cat);
    wardrobeSectionRef.current?.scrollIntoView({
      behavior: 'smooth',
      block: 'start',
    });
  };

  // Reset to starter set for the active gender
  const handleReset = () => {
    latestRequestIdRef.current = `req_reset_${Date.now()}`;
    setTryOnResult(null); // Reset try-on to base model on reset
    setIsGeneratingTryOn(false);
    const starterIds =
      selectedModelGender === 'male'
        ? ['G008', 'G013', 'G031', 'G047']
        : ['G010', 'G011', 'G012', 'G042', 'G033'];

    const starter = starterIds
      .map((id) => {
        const entity = CANONICAL_ENTITIES.find(
          (e) => e.primaryRecordId === id || e.mergedRecordIds.includes(id)
        );
        return entity?.asItem;
      })
      .filter((i): i is Item => Boolean(i));
    setSelectedItems(starter);
  };

  // Primary Action: THỬ TRÊN NGƯỜI →
  const handleTryOn = async () => {
    if (selectedItems.length === 0 || isGeneratingTryOn) return;

    const reqId = `req_tryon_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`;
    latestRequestIdRef.current = reqId;
    setIsGeneratingTryOn(true);
    setTryOnResult(null);

    const mode: GenerationMode =
      selectedItems.length === 1 ? 'single_item_try_on' : 'complete_outfit_try_on';

    try {
      const res = await generateUnifiedImage({
        requestId: reqId,
        mode,
        gender: selectedModelGender,
        selectedItemIds: selectedItems.map((i) => i.id),
        referenceItemId: selectedItems[0]?.id,
        outfitTitle,
        evaluation,
        evaluationSummary: shortExplanation,
        compatibilityConstraints: evaluation.warnings,
      });

      if (latestRequestIdRef.current === reqId) {
        setTryOnResult(res);
      }
    } catch {
      if (latestRequestIdRef.current === reqId) {
        setTryOnResult({
          ok: false,
          label: mode === 'single_item_try_on' ? 'MINH HỌA AI THỬ TRANG PHỤC ĐƠN MÓN' : 'MINH HỌA AI THỬ TRÊN NGƯỜI',
          disclaimer: 'MINH HỌA AI · KHÔNG PHẢI ẢNH TƯ LIỆU LỊCH SỬ',
          promptUsed: '',
          serviceUsed: 'gemini-3.1-flash-lite-image',
          isFallback: false,
          mode,
          requestId: reqId,
          error: 'Có lỗi trong quá trình kết nối dịch vụ tạo ảnh. Vui lòng bấm "Thử lại".',
          errorType: 'API_ERROR',
        });
      }
    } finally {
      if (latestRequestIdRef.current === reqId) {
        setIsGeneratingTryOn(false);
      }
    }
  };

  // Save outfit action
  const handleSaveOutfit = () => {
    if (selectedItems.length === 0) return;
    const newOutfit: SavedUserOutfit = {
      id: `outfit-${Date.now()}`,
      name: `Bộ phối ${outfitTitle}`,
      items: [...selectedItems],
      createdAt: new Date().toLocaleDateString('vi-VN'),
      evaluation,
    };
    onSaveOutfit(newOutfit);
    setSaveToast('Đã lưu bộ phối vào Sổ Phối!');
    setTimeout(() => setSaveToast(null), 3500);
  };

  // Compare outfit action
  const handleCompare = () => {
    if (selectedItems.length === 0) return;
    const newOutfit: SavedUserOutfit = {
      id: `outfit-${Date.now()}`,
      name: `Bộ phối ${outfitTitle}`,
      items: [...selectedItems],
      createdAt: new Date().toLocaleDateString('vi-VN'),
      evaluation,
    };
    onCompareOutfit(newOutfit);
  };

  // Share outfit composition action: generates image and triggers browser share dialog
  const handleShareOutfit = async () => {
    if (selectedItems.length === 0 || isSharing) return;
    setIsSharing(true);
    try {
      const statusColorHex = statusConfig.dotColor.includes('2E5A44')
        ? '#2E5A44'
        : statusConfig.dotColor.includes('C89B3C')
        ? '#C89B3C'
        : statusConfig.dotColor.includes('633B5B')
        ? '#633B5B'
        : statusConfig.dotColor.includes('9E2A1C')
        ? '#9E2A1C'
        : '#8A8177';

      const result = await exportAndShareOutfitComposition({
        gender: selectedModelGender,
        layers: activeGarmentLayers,
        selectedItems,
        outfitTitle,
        outfitSubLayers,
        evaluation,
        shortExplanation,
        statusLabel: statusConfig.label,
        statusColorHex,
        tryOnImageUrl: tryOnResult?.imageUrl,
      });

      setShareResult(result);
      if (!result.aborted) {
        setSaveToast(result.message);
        setTimeout(() => setSaveToast(null), 4500);
      }
    } catch (error) {
      console.error('Failed to export and share outfit:', error);
      setSaveToast('Không thể tạo ảnh chia sẻ. Vui lòng thử lại.');
      setTimeout(() => setSaveToast(null), 4000);
    } finally {
      setIsSharing(false);
    }
  };

  // Copy share link / text helper
  const handleCopyShareLink = async () => {
    try {
      const textToCopy = `Tàng Y — Bộ phối ${outfitTitle} (${selectedModelGender === 'female' ? 'Dáng Nữ' : 'Dáng Nam'})\n${window.location.href}`;
      await navigator.clipboard.writeText(textToCopy);
      setCopyFeedback(true);
      setTimeout(() => setCopyFeedback(false), 2500);
    } catch {
      // Ignore
    }
  };

  return (
    <div className="space-y-16 pb-24 text-[#171717]">
      {/* =========================================================================
          TOP STAGE: 3 PRIMARY COLUMNS (INTRODUCTION · MODEL · RESULT)
      ========================================================================= */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 xl:gap-12 items-start pt-2 sm:pt-4">
        {/* -----------------------------------------------------------------------
            1. INTRODUCTION (LEFT - 3 COLS)
        ----------------------------------------------------------------------- */}
        <div className="lg:col-span-3 space-y-6 order-2 lg:order-1">
          <SectionEntrance showTopRule={false} className="space-y-6">
            <div className="space-y-2">
              <span className="font-tabular text-4xl sm:text-5xl font-light text-[#9E2A1C] tracking-tighter">
                01
              </span>
              <div className="text-xs font-tabular tracking-[0.2em] text-[#6E675F] uppercase">
                PHỐI PHỤC
              </div>
              <SplitLineReveal
                as="h1"
                lines={['TẠO NÊN BỘ', 'TRANG PHỤC', 'THEO CÁCH CỦA BẠN']}
                className="font-raven text-2xl sm:text-3xl font-normal text-[#0D0C0B] uppercase tracking-wide leading-tight pt-1"
              />
            </div>

            <p className="text-sm text-[#4A453E] leading-relaxed font-body">
              Chọn và thay đổi từng lớp trang phục, sau đó thử bộ phối trên
              người.
            </p>

            {/* Subtle Reset & Advisor Buttons */}
            <div className="pt-4 border-t border-[#141312]/10 space-y-3">
              {onOpenAdvisor && (
                <button
                  type="button"
                  onClick={onOpenAdvisor}
                  className="w-full text-left px-3.5 py-2.5 rounded-lg border border-[#A63D2F]/25 bg-[#A63D2F]/5 hover:bg-[#A63D2F]/10 text-xs text-[#171717] transition-all cursor-pointer flex items-center justify-between group"
                >
                  <div className="flex items-center gap-2">
                    <span className="w-5 h-5 rounded-full bg-[#A63D2F] text-white text-[10px] font-raven font-bold flex items-center justify-center">
                      藏
                    </span>
                    <div>
                      <span className="font-medium text-[#A63D2F] block">
                        Cần gợi ý trang phục hôm nay?
                      </span>
                      <span className="text-[11px] text-[#6E675F]">
                        Hỏi Cố Vấn Tàng Y
                      </span>
                    </div>
                  </div>
                  <span className="text-[#A63D2F] text-sm group-hover:translate-x-0.5 transition-transform">
                    →
                  </span>
                </button>
              )}

              {selectedItems.length > 0 && (
                <button
                  type="button"
                  onClick={handleReset}
                  className="text-xs font-tabular tracking-wider uppercase text-[#6E675F] hover:text-[#9E2A1C] transition-colors cursor-pointer flex items-center gap-1.5"
                >
                  <span>↺ Đặt lại bộ phối</span>
                  <span className="text-[10px] text-[#8A8177]">
                    ({selectedItems.length} món)
                  </span>
                </button>
              )}
            </div>
          </SectionEntrance>
        </div>

        {/* -----------------------------------------------------------------------
            2. MODEL (CENTER - 5 COLS)
            The visual center with generous breathing room and 4 quiet indicators
        ----------------------------------------------------------------------- */}
        <div className="lg:col-span-5 order-1 lg:order-2 flex flex-col items-center">
          <SectionEntrance
            showTopRule={false}
            className="w-full max-w-[460px] mx-auto"
          >
            {/* 3. Compact Selector: CHỌN NGƯỜI MẪU [NỮ] [NAM] */}
            <div className="flex items-center justify-between mb-3 w-full px-0.5">
              <div className="flex items-center gap-2">
                <span className="w-1.5 h-1.5 rounded-full bg-[#9E2A1C]" />
                <span className="text-[11px] font-tabular tracking-[0.16em] uppercase text-[#6E675F]">
                  CHỌN NGƯỜI MẪU
                </span>
                {tryOnResult?.imageUrl && (
                  <span className="text-[10px] font-tabular text-[#9E2A1C] uppercase tracking-wider ml-1">
                    [Đang hiển thị ảnh thử AI]
                  </span>
                )}
              </div>
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={handleShareOutfit}
                  disabled={selectedItems.length === 0 || isSharing}
                  className="inline-flex items-center gap-1.5 px-2.5 py-1 text-xs font-tabular tracking-wider uppercase border border-[#141312]/20 bg-[#EAE6DD] hover:bg-[#0D0C0B] hover:text-[#F7F4EE] text-[#4A453E] transition-all cursor-pointer disabled:opacity-40"
                  title="Xuất ảnh phối phục và mở hộp thoại chia sẻ trình duyệt"
                >
                  {isSharing ? (
                    <span className="w-3.5 h-3.5 border-2 border-current border-t-transparent rounded-full animate-spin" />
                  ) : (
                    <Share2 className="w-3.5 h-3.5" />
                  )}
                  <span className="hidden sm:inline">{isSharing ? 'Đang tạo...' : 'Chia sẻ'}</span>
                </button>
                <div
                  role="group"
                  aria-label="Chọn người mẫu: Nữ hoặc Nam"
                  className="inline-flex items-center p-0.5 border border-[#141312]/20 bg-[#EAE6DD]"
                >
                  <button
                    type="button"
                    onClick={() => handleSelectGender('female')}
                    className={`px-3.5 py-1 text-xs font-tabular tracking-wider uppercase transition-all cursor-pointer ${
                      selectedModelGender === 'female'
                        ? 'bg-[#0D0C0B] text-[#F7F4EE] font-medium shadow-xs'
                        : 'text-[#6E675F] hover:text-[#0D0C0B]'
                    }`}
                  >
                    NỮ
                  </button>
                  <button
                    type="button"
                    onClick={() => handleSelectGender('male')}
                    className={`px-3.5 py-1 text-xs font-tabular tracking-wider uppercase transition-all cursor-pointer ${
                      selectedModelGender === 'male'
                        ? 'bg-[#0D0C0B] text-[#F7F4EE] font-medium shadow-xs'
                        : 'text-[#6E675F] hover:text-[#0D0C0B]'
                    }`}
                  >
                    NAM
                  </button>
                </div>
              </div>
            </div>

            {/* Reusable ModelStage (BaseModel + Photorealistic Try-On Display) */}
            <ModelStage
              selectedModelGender={selectedModelGender}
              tryOnImageUrl={tryOnResult?.imageUrl}
              isGenerating={isGeneratingTryOn}
              hasError={Boolean(tryOnResult?.error)}
              errorMessage={tryOnResult?.error}
              onRetry={handleTryOn}
            >
              {/* MAXIMUM 4 SUBTLE EDITORIAL LAYER INDICATORS */}
              {MODEL_INDICATORS.map((ind) => {
                const item = selectedItems.find(
                  (i) => getItemCategory(i) === ind.category
                );
                const isEquipped = Boolean(item);
                const styling = item ? CANONICAL_STYLING_MAP.get(item.id) : undefined;
                const hasVisualAsset = Boolean(
                  styling &&
                    styling.asset &&
                    (styling.stylingReadiness === 'READY' ||
                      styling.stylingReadiness === 'PARTIAL')
                );

                return (
                  <div
                    key={ind.category}
                    className="absolute z-20"
                    style={{
                      top: ind.topPercent,
                      left: ind.side === 'left' ? '14px' : 'auto',
                      right: ind.side === 'right' ? '14px' : 'auto',
                    }}
                  >
                    <button
                      type="button"
                      onClick={() => handleIndicatorClick(ind.category)}
                      className={`text-left px-2 py-1 border backdrop-blur-md transition-all cursor-pointer group flex flex-col gap-0.5 ${
                        isEquipped
                          ? 'bg-[#F4F1EA]/90 border-[#141312]/30 hover:border-[#9E2A1C]'
                          : 'bg-[#F4F1EA]/60 border-[#141312]/15 hover:bg-[#F4F1EA]/90'
                      }`}
                    >
                      <span className="text-[9px] font-tabular tracking-[0.16em] uppercase text-[#6E675F] group-hover:text-[#9E2A1C]">
                        {ind.label}
                      </span>
                      <span
                        className={`text-[11px] font-raven truncate max-w-[120px] sm:max-w-[140px] ${
                          isEquipped
                            ? 'text-[#0D0C0B] font-medium'
                            : 'text-[#8A8177] italic'
                        }`}
                      >
                        {isEquipped ? item?.name : 'Chọn món...'}
                      </span>
                      {isEquipped && !hasVisualAsset && (
                        <span className="text-[8.5px] font-tabular text-[#8A8177] tracking-wider">
                          {styling?.stylingReadiness === 'RESEARCH'
                            ? '· Đang nghiên cứu'
                            : '· Bản tư liệu'}
                        </span>
                      )}
                    </button>

                    {/* Thin Editorial Connecting Line */}
                    <div
                      className="absolute pointer-events-none hidden sm:block"
                      style={{
                        top: '50%',
                        left: ind.side === 'left' ? '100%' : 'auto',
                        right: ind.side === 'right' ? '100%' : 'auto',
                        width: '24px',
                        height: '1px',
                        backgroundColor: isEquipped
                          ? 'rgba(158, 42, 28, 0.45)'
                          : 'rgba(20, 19, 18, 0.2)',
                      }}
                    >
                      <span
                        className={`absolute -top-1 w-2 h-2 rounded-full border ${
                          ind.side === 'left' ? '-right-1' : '-left-1'
                        } ${
                          isEquipped
                            ? 'bg-[#9E2A1C] border-white'
                            : 'bg-[#8A8177] border-white'
                        }`}
                      />
                    </div>
                  </div>
                );
              })}

              {/* Bottom Caption */}
              <div className="absolute bottom-3 inset-x-4 z-20 pointer-events-none flex items-center justify-between text-[11px] font-tabular text-[#F4F1EA]/90 drop-shadow-sm">
                <span className="truncate pr-2">{outfitTitle}</span>
                <span className="shrink-0 tracking-widest uppercase text-[10px] text-[#F4F1EA]/75">
                  1:1 MANNEQUIN
                </span>
              </div>
            </ModelStage>
          </SectionEntrance>
        </div>

        {/* -----------------------------------------------------------------------
            3. CURRENT OUTFIT / RESULT (RIGHT - 4 COLS)
        ----------------------------------------------------------------------- */}
        <div className="lg:col-span-4 space-y-6 order-3">
          <SectionEntrance showTopRule={false} className="space-y-6">
            <div className="space-y-2">
              <span className="font-tabular text-4xl sm:text-5xl font-light text-[#9E2A1C] tracking-tighter">
                02
              </span>
              <div className="text-xs font-tabular tracking-[0.2em] text-[#6E675F] uppercase">
                KẾT QUẢ PHỐI
              </div>
              <h2 className="font-raven text-2xl font-normal text-[#0D0C0B] uppercase tracking-wide leading-tight pt-0.5">
                {outfitTitle}
              </h2>
              <p className="text-xs text-[#6E675F] leading-relaxed">
                {outfitSubLayers}
              </p>
            </div>

            {/* Cultural Result Card */}
            <div className="p-4 sm:p-5 border border-[#141312]/15 bg-[#F4F1EA]/80 space-y-4">
              {/* Compatibility Status */}
              <div className="flex items-center gap-2">
                <span
                  className={`w-2.5 h-2.5 rounded-full ${statusConfig.dotColor}`}
                />
                <span
                  className={`text-xs font-tabular tracking-wider uppercase font-semibold ${statusConfig.textColor}`}
                >
                  ● {statusConfig.label}
                </span>
              </div>

              {/* One Concise Explanation */}
              <p className="text-xs text-[#3D3934] leading-relaxed">
                "{shortExplanation}"
              </p>

              {/* Incompatible Quick Suggestion */}
              {!statusConfig.isMatch && recommendedItems.length > 0 && (
                <div className="pt-2 border-t border-[#141312]/10">
                  <button
                    type="button"
                    onClick={() => handleToggleItem(recommendedItems[0])}
                    className="text-xs font-tabular uppercase tracking-wider text-[#9E2A1C] hover:underline cursor-pointer flex items-center gap-1"
                  >
                    <span>GỢI Ý THAY THẾ:</span>
                    <span className="font-medium">
                      + Thử {recommendedItems[0].name} →
                    </span>
                  </button>
                </div>
              )}

              {/* Academic Source Modal Trigger */}
              <div className="pt-2 border-t border-[#141312]/10 flex items-center justify-between">
                <button
                  type="button"
                  onClick={() => setIsResearchModalOpen(true)}
                  className="text-[11px] font-tabular uppercase tracking-wider text-[#6E675F] hover:text-[#0D0C0B] cursor-pointer"
                >
                  XEM TƯ LIỆU →
                </button>
                <span className="text-[10px] text-[#8A8177] font-tabular">
                  {selectedItems.length} thành phần
                </span>
              </div>

              {/* PRIMARY ACTION: THỬ TRÊN NGƯỜI → */}
              <div className="pt-2">
                <MagneticButton
                  type="button"
                  variant="primary"
                  onClick={handleTryOn}
                  disabled={selectedItems.length === 0}
                  className="w-full py-3 text-xs uppercase tracking-wider text-center font-medium shadow-sm disabled:opacity-40"
                >
                  THỬ TRÊN NGƯỜI →
                </MagneticButton>
              </div>

              {/* Secondary Actions */}
              <div className="pt-1 grid grid-cols-3 gap-2">
                <button
                  type="button"
                  onClick={handleSaveOutfit}
                  disabled={selectedItems.length === 0}
                  className="py-1.5 text-[11px] font-tabular uppercase tracking-wider border border-[#141312]/20 hover:border-[#141312]/40 text-[#4A453E] hover:text-[#0D0C0B] transition-colors cursor-pointer text-center disabled:opacity-40"
                >
                  Lưu bộ
                </button>
                <button
                  type="button"
                  onClick={handleCompare}
                  disabled={selectedItems.length === 0}
                  className="py-1.5 text-[11px] font-tabular uppercase tracking-wider border border-[#141312]/20 hover:border-[#141312]/40 text-[#4A453E] hover:text-[#0D0C0B] transition-colors cursor-pointer text-center disabled:opacity-40"
                >
                  So bộ
                </button>
                <button
                  type="button"
                  onClick={handleShareOutfit}
                  disabled={selectedItems.length === 0 || isSharing}
                  className="py-1.5 text-[11px] font-tabular uppercase tracking-wider border border-[#9E2A1C]/50 bg-[#9E2A1C]/10 hover:bg-[#9E2A1C] hover:text-white text-[#9E2A1C] transition-all cursor-pointer text-center font-medium disabled:opacity-40 flex items-center justify-center gap-1 shadow-xs"
                  title="Xuất ảnh phối phục và mở hộp thoại chia sẻ của trình duyệt"
                >
                  {isSharing ? (
                    <span className="w-3 h-3 border-2 border-current border-t-transparent rounded-full animate-spin" />
                  ) : (
                    <Share2 className="w-3.5 h-3.5" />
                  )}
                  <span>{isSharing ? 'Đang tạo...' : 'Chia sẻ'}</span>
                </button>
              </div>

              {saveToast && (
                <div className="space-y-1 pt-1 text-center animate-fadeIn">
                  <p className="text-xs text-[#2E5A44] font-medium leading-tight">
                    {saveToast}
                  </p>
                  {shareResult && (
                    <button
                      type="button"
                      onClick={() => setIsShareModalOpen(true)}
                      className="text-[10px] font-tabular text-[#9E2A1C] hover:underline cursor-pointer inline-block"
                    >
                      [Xem &amp; tải lại ảnh phối phục đã xuất]
                    </button>
                  )}
                </div>
              )}
            </div>
          </SectionEntrance>
        </div>
      </div>

      {/* =========================================================================
          4. WARDROBE (BOTTOM - INTERACTIVE VISUAL CLOTHING RACK)
          Header: 03 CHỌN THÀNH PHẦN
          Horizontal visual cards with clean image + name
      ========================================================================= */}
      <div
        ref={wardrobeSectionRef}
        className="pt-12 border-t border-[#141312]/15 space-y-6"
      >
        <SectionEntrance showTopRule={false} className="space-y-6">
          {/* Section Header */}
          <div className="flex flex-col sm:flex-row sm:items-baseline justify-between gap-2">
            <div className="space-y-1">
              <div className="flex items-center gap-2">
                <span className="font-tabular text-2xl font-light text-[#9E2A1C]">
                  03
                </span>
                <span className="text-xs font-tabular tracking-[0.2em] text-[#6E675F] uppercase">
                  CHỌN THÀNH PHẦN
                </span>
                <span className="text-[10px] font-tabular tracking-wider px-2 py-0.5 border border-[#141312]/15 bg-[#EAE6DE] text-[#4A453E] uppercase">
                  DÁNG {selectedModelGender === 'female' ? 'NỮ' : 'NAM'} · {canonicalWardrobeItems.length} MÓN KHẢ DỤNG
                </span>
              </div>
              <h3 className="font-raven text-xl sm:text-2xl font-normal text-[#0D0C0B] uppercase tracking-wide">
                Tủ Áo Di Sản
              </h3>
            </div>
            <p className="text-xs text-[#6E675F] font-tabular">
              Nhấp vào trang phục để mặc thử lên người mẫu ({canonicalWardrobeItems.length}/49 thực thể chuẩn)
            </p>
          </div>

          {/* 7 Horizontal Category Tabs (Only one visible at a time) */}
          <div className="flex items-center gap-2 overflow-x-auto pb-2 border-b border-[#141312]/12 no-scrollbar">
            {CATEGORY_TABS.map((cat) => {
              const isActive = activeCategory === cat.id;
              const count = canonicalWardrobeItems.filter(
                (i) => getItemCategory(i) === cat.id
              ).length;

              return (
                <button
                  key={cat.id}
                  type="button"
                  onClick={() => setActiveCategory(cat.id)}
                  className={`px-4 py-2 text-xs font-tabular uppercase tracking-wider transition-all cursor-pointer border whitespace-nowrap flex items-center gap-2 shrink-0 ${
                    isActive
                      ? 'bg-[#0D0C0B] text-[#F7F4EE] border-[#0D0C0B] shadow-sm'
                      : 'border-[#141312]/15 text-[#6E675F] hover:text-[#0D0C0B] hover:border-[#141312]/35 bg-[#F4F1EA]/60'
                  }`}
                >
                  <span>{cat.label}</span>
                  <span
                    className={`text-[10px] ${
                      isActive ? 'text-[#F7F4EE]/70' : 'text-[#8A8177]'
                    }`}
                  >
                    ({count})
                  </span>
                </button>
              );
            })}
          </div>

          {/* Visual Horizontal Wardrobe Cards */}
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-4">
            {currentCategoryItems.map((item, index) => {
              const isEquipped = selectedItems.some((i) => i.id === item.id);
              const canonical =
                CANONICAL_ENTITIES_MAP.get(`CANON_${item.id}`) ||
                CANONICAL_ENTITIES_MAP.get(item.id);
              const styling = CANONICAL_STYLING_MAP.get(item.id);
              const imgSrc = canonical?.image?.src;

              return (
                <div
                  key={item.id}
                  onClick={() => handleToggleItem(item)}
                  className={`group border transition-all cursor-pointer flex flex-col justify-between overflow-hidden ${
                    isEquipped
                      ? 'border-[#9E2A1C] bg-[#9E2A1C]/5 ring-1 ring-[#9E2A1C]/40 shadow-sm'
                      : 'border-[#141312]/15 bg-[#F4F1EA]/80 hover:border-[#141312]/35 hover:bg-[#F4F1EA]'
                  }`}
                >
                  {/* Garment Image */}
                  <div className="relative aspect-[3/3.2] bg-[#EAE6DD] overflow-hidden">
                    {imgSrc ? (
                      <img
                        src={imgSrc}
                        alt={item.name}
                        loading="lazy"
                        style={index === 0 ? { backgroundColor: '#000000' } : undefined}
                        className={`w-full h-full object-cover object-center group-hover:scale-105 transition-transform duration-500 ${
                          index === 0 ? 'bg-[#000000]' : ''
                        }`}
                      />
                    ) : (
                      <div className="w-full h-full flex flex-col items-center justify-center p-3 text-center bg-[#E8E4DA]/60">
                        <span className="font-raven text-lg text-[#141312]/30 mb-0.5">
                          藏
                        </span>
                        <span className="text-[10px] font-tabular uppercase tracking-wider text-[#6E675F]">
                          Bản lưu trữ
                        </span>
                      </div>
                    )}

                    {/* Subtle Equipped Badge */}
                    {isEquipped && (
                      <div className="absolute top-2 right-2 px-1.5 py-0.5 bg-[#9E2A1C] text-white text-[9px] font-tabular uppercase tracking-wider font-semibold">
                        Đang mặc
                      </div>
                    )}
                  </div>

                  {/* Garment Name + Status if no visual asset */}
                  <div className="p-3 space-y-1.5 flex flex-col justify-between flex-1">
                    <div>
                      <h4
                        className="font-raven text-xs sm:text-sm font-medium text-[#0D0C0B] group-hover:text-[#9E2A1C] line-clamp-1 leading-snug"
                        title={item.name}
                      >
                        {item.name}
                      </h4>

                      {/* Discreet status for items without layer asset */}
                      {styling?.stylingReadiness === 'RESEARCH' && (
                        <span className="text-[10px] font-tabular text-[#9E2A1C]/80 block pt-0.5">
                          Đang nghiên cứu
                        </span>
                      )}
                      {styling?.stylingReadiness === 'CATALOG_ONLY' && (
                        <span className="text-[10px] font-tabular text-[#8A8177] block pt-0.5">
                          Bản tư liệu
                        </span>
                      )}
                    </div>

                    {/* Quick Detail Link */}
                    <div className="pt-1.5 border-t border-[#141312]/10 flex items-center justify-between text-[10px] font-tabular text-[#6E675F]">
                      <span className="text-[#9E2A1C] font-medium">
                        {isEquipped ? 'Bỏ ra' : '+ Mặc vào'}
                      </span>
                      <button
                        type="button"
                        onClick={(e) => {
                          e.stopPropagation();
                          onViewItemDetail(item);
                        }}
                        className="hover:text-[#0D0C0B] cursor-pointer"
                      >
                        Chi tiết →
                      </button>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </SectionEntrance>
      </div>

      {/* =========================================================================
          VIRTUAL TRY-ON MODAL (TRIGGERED BY THỬ TRÊN NGƯỜI →)
      ========================================================================= */}
      {isTryOnOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-[#141312]/75 backdrop-blur-sm animate-fadeIn">
          <div className="relative w-full max-w-2xl bg-[#F7F4EE] border border-[#141312]/20 shadow-2xl p-6 sm:p-8 space-y-6 max-h-[90vh] overflow-y-auto">
            {/* Modal Header */}
            <div className="flex items-start justify-between border-b border-[#141312]/12 pb-4">
              <div className="space-y-1">
                <div className="text-[10px] font-tabular tracking-[0.2em] text-[#6E675F] uppercase">
                  VIRTUAL TRY-ON STUDIO
                </div>
                <h3 className="font-raven text-2xl font-normal text-[#0D0C0B] uppercase tracking-wide">
                  Thử Trang Phục Trên Người
                </h3>
              </div>
              <button
                type="button"
                onClick={() => setIsTryOnOpen(false)}
                className="text-2xl text-[#6E675F] hover:text-[#0D0C0B] cursor-pointer p-1"
              >
                ×
              </button>
            </div>

            {/* MANDATORY DISCLAIMER LABEL */}
            <div className="p-2.5 bg-[#9E2A1C]/10 border border-[#9E2A1C]/30 text-center">
              <span className="text-xs font-tabular tracking-wider uppercase font-semibold text-[#9E2A1C]">
                MINH HỌA AI · KHÔNG PHẢI ẢNH TƯ LIỆU LỊCH SỬ
              </span>
            </div>

            {/* Try-On Content */}
            {isGeneratingTryOn ? (
              <div className="py-16 text-center space-y-3">
                <div className="w-8 h-8 border-2 border-[#9E2A1C] border-t-transparent rounded-full animate-spin mx-auto" />
                <p className="text-xs font-tabular text-[#6E675F] uppercase tracking-wider">
                  Đang khởi tạo phối phục qua AI Studio...
                </p>
              </div>
            ) : tryOnResult?.error ? (
              <div className="py-12 px-6 text-center space-y-4 bg-white/60 border border-[#9E2A1C]/20">
                <AlertCircle className="w-8 h-8 text-[#9E2A1C] mx-auto" />
                <div className="space-y-1">
                  <h4 className="font-raven text-lg text-[#0D0C0B] uppercase">Không thể hoàn thành tạo ảnh</h4>
                  <p className="text-xs text-[#6E675F] max-w-md mx-auto leading-relaxed">
                    {tryOnResult.error}
                  </p>
                </div>
                <div className="pt-2 flex items-center justify-center gap-3">
                  <button
                    type="button"
                    onClick={handleTryOn}
                    className="px-5 py-2.5 bg-[#9E2A1C] text-white text-xs font-tabular uppercase tracking-wider hover:bg-[#832014] cursor-pointer flex items-center gap-2 shadow-xs"
                  >
                    <RefreshCw className="w-3.5 h-3.5" />
                    <span>Thử lại</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => setIsTryOnOpen(false)}
                    className="px-4 py-2.5 border border-[#141312]/20 text-xs font-tabular uppercase tracking-wider text-[#6E675F] hover:text-[#0D0C0B] cursor-pointer"
                  >
                    Đóng
                  </button>
                </div>
              </div>
            ) : (
              <div className="space-y-6">
                {/* Visual Preview */}
                <div className="relative aspect-[3/4] max-w-[360px] mx-auto border border-[#141312]/20 overflow-hidden shadow-sm bg-[#EFECE5]">
                  <img
                    src={tryOnResult?.imageUrl || phoiPhucModelImage}
                    alt={`Thử trên người - ${outfitTitle}`}
                    className="w-full h-full object-cover object-top"
                  />
                  <div className="absolute bottom-2 inset-x-2 p-2 bg-[#141312]/80 backdrop-blur-xs text-white text-[10px] font-tabular text-center uppercase tracking-wider">
                    {outfitTitle}
                  </div>
                </div>

                {/* Outfit Layers Recap */}
                <div className="p-3.5 bg-[#EAE6DD]/60 border border-[#141312]/10 space-y-2">
                  <div className="text-[10px] font-tabular uppercase tracking-wider text-[#6E675F]">
                    Các lớp y phục đang mặc:
                  </div>
                  <div className="flex flex-wrap gap-1.5">
                    {selectedItems.map((item) => (
                      <span
                        key={item.id}
                        className="px-2 py-0.5 bg-white text-xs font-raven border border-[#141312]/10"
                      >
                        {item.name}
                      </span>
                    ))}
                  </div>
                </div>

                {/* Prompt Used Inspection */}
                {tryOnResult?.promptUsed && (
                  <details className="border border-[#141312]/10 bg-white/50 p-3 text-xs group">
                    <summary className="font-tabular text-[10px] uppercase tracking-wider text-[#6E675F] cursor-pointer hover:text-[#0D0C0B] select-none">
                      ▶ Xem prompt AI đã sử dụng
                    </summary>
                    <pre className="mt-2 text-[10px] font-mono text-[#4A453F] whitespace-pre-wrap leading-relaxed max-h-40 overflow-y-auto bg-[#F4F1EA] p-2 border border-[#141312]/10">
                      {tryOnResult.promptUsed}
                    </pre>
                  </details>
                )}

                {/* Action footer */}
                <div className="flex items-center justify-between gap-3 pt-2">
                  <button
                    type="button"
                    onClick={handleShareOutfit}
                    disabled={isSharing}
                    className="px-4 py-2 text-xs font-tabular uppercase tracking-wider border border-[#9E2A1C] bg-[#9E2A1C] text-white hover:bg-[#852115] transition-colors cursor-pointer flex items-center gap-1.5 shadow-xs"
                    title="Xuất ảnh phối phục và mở hộp thoại chia sẻ trình duyệt"
                  >
                    {isSharing ? (
                      <span className="w-3.5 h-3.5 border-2 border-white border-t-transparent rounded-full animate-spin" />
                    ) : (
                      <Share2 className="w-3.5 h-3.5" />
                    )}
                    <span>{isSharing ? 'Đang tạo...' : 'Chia sẻ ảnh này'}</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => setIsTryOnOpen(false)}
                    className="px-5 py-2 text-xs font-tabular uppercase tracking-wider border border-[#141312]/20 hover:border-[#141312]/40 text-[#0D0C0B] cursor-pointer"
                  >
                    Đóng
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>
      )}

      {/* =========================================================================
          RESEARCH & CITATIONS MODAL (TRIGGERED BY XEM TƯ LIỆU →)
      ========================================================================= */}
      {isResearchModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-[#141312]/75 backdrop-blur-sm animate-fadeIn">
          <div className="relative w-full max-w-xl bg-[#F7F4EE] border border-[#141312]/20 shadow-2xl p-6 sm:p-8 space-y-6 max-h-[85vh] overflow-y-auto">
            <div className="flex items-start justify-between border-b border-[#141312]/12 pb-3">
              <div className="space-y-1">
                <div className="text-[10px] font-tabular tracking-[0.2em] text-[#6E675F] uppercase">
                  TƯ LIỆU KHẢO CHỨNG
                </div>
                <h3 className="font-raven text-xl font-normal text-[#0D0C0B] uppercase">
                  Cơ Sở Lịch Sử &amp; Nguồn Tư Liệu
                </h3>
              </div>
              <button
                type="button"
                onClick={() => setIsResearchModalOpen(false)}
                className="text-2xl text-[#6E675F] hover:text-[#0D0C0B] cursor-pointer p-1"
              >
                ×
              </button>
            </div>

            <div className="space-y-4 text-xs text-[#3D3934] leading-relaxed">
              <div className="space-y-1 p-3 bg-white/70 border border-[#141312]/10">
                <span className="font-semibold text-[#0D0C0B] block">
                  Đánh giá tổng quan:
                </span>
                <p>{shortExplanation}</p>
              </div>

              {evaluation.warnings.length > 0 && (
                <div className="p-3 bg-[#9E2A1C]/5 border-l-2 border-[#9E2A1C] space-y-1">
                  <span className="font-semibold text-[#9E2A1C] block uppercase tracking-wider text-[10px]">
                    Lưu ý lịch sử:
                  </span>
                  <ul className="list-disc list-inside space-y-0.5 text-[11px]">
                    {evaluation.warnings.map((w, idx) => (
                      <li key={idx}>{w}</li>
                    ))}
                  </ul>
                </div>
              )}

              {evaluation.sourceIds.length > 0 && (
                <div className="space-y-1 pt-2 border-t border-[#141312]/10">
                  <span className="font-tabular text-[10px] uppercase tracking-wider text-[#6E675F] block">
                    Mã nguồn tư liệu trong Master Research:
                  </span>
                  <div className="flex flex-wrap gap-1.5">
                    {evaluation.sourceIds.map((sid) => (
                      <span
                        key={sid}
                        className="px-2 py-0.5 bg-[#EAE6DD] text-[#9E2A1C] font-semibold border border-[#141312]/15 text-[11px]"
                      >
                        {sid}
                      </span>
                    ))}
                  </div>
                </div>
              )}
            </div>

            <div className="flex justify-end pt-2">
              <button
                type="button"
                onClick={() => setIsResearchModalOpen(false)}
                className="px-4 py-2 text-xs font-tabular uppercase tracking-wider border border-[#141312]/20 hover:border-[#141312]/40 text-[#0D0C0B] cursor-pointer"
              >
                Đã hiểu
              </button>
            </div>
          </div>
        </div>
      )}

      {/* =========================================================================
          SHARE & EXPORT PREVIEW MODAL
      ========================================================================= */}
      {isShareModalOpen && shareResult && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-[#141312]/75 backdrop-blur-sm animate-fadeIn">
          <div className="relative w-full max-w-xl bg-[#F7F4EE] border border-[#141312]/20 shadow-2xl p-5 sm:p-7 space-y-5 max-h-[90vh] overflow-y-auto">
            {/* Modal Header */}
            <div className="flex items-start justify-between border-b border-[#141312]/12 pb-3">
              <div className="space-y-1">
                <div className="text-[10px] font-tabular tracking-[0.2em] text-[#9E2A1C] uppercase font-semibold">
                  HỒ SƠ PHỐI KHẢO · ARCHIVAL SPECIMEN
                </div>
                <h3 className="font-raven text-xl font-normal text-[#0D0C0B] uppercase">
                  Ảnh Phối Phục Đã Xuất
                </h3>
              </div>
              <button
                type="button"
                onClick={() => setIsShareModalOpen(false)}
                className="text-2xl text-[#6E675F] hover:text-[#0D0C0B] cursor-pointer p-1 leading-none"
              >
                ×
              </button>
            </div>

            {/* Specimen Preview */}
            <div className="relative border border-[#141312]/20 bg-[#EFECE5] shadow-sm max-w-[340px] mx-auto overflow-hidden">
              <img
                src={shareResult.dataUrl}
                alt={`Ảnh phối phục ${outfitTitle}`}
                className="w-full h-auto object-contain"
              />
            </div>

            <p className="text-xs text-[#524B43] text-center font-tabular">
              Ảnh phối phục chuẩn 1080×1520px chất lượng cao bao gồm người mẫu, các lớp y phục, thẩm định và nguồn tư liệu.
            </p>

            {/* Actions */}
            <div className="flex flex-col sm:flex-row items-center justify-between gap-3 pt-2 border-t border-[#141312]/10">
              <div className="flex items-center gap-2 w-full sm:w-auto">
                <button
                  type="button"
                  onClick={() => triggerBlobDownload(shareResult.blob, shareResult.filename)}
                  className="flex-1 sm:flex-initial px-3.5 py-2 text-xs font-tabular uppercase tracking-wider border border-[#141312]/20 hover:border-[#141312]/40 bg-[#EAE6DD] text-[#0D0C0B] cursor-pointer flex items-center justify-center gap-1.5"
                >
                  <Download className="w-3.5 h-3.5" />
                  <span>Tải ảnh PNG</span>
                </button>
                <button
                  type="button"
                  onClick={handleCopyShareLink}
                  className="flex-1 sm:flex-initial px-3.5 py-2 text-xs font-tabular uppercase tracking-wider border border-[#141312]/20 hover:border-[#141312]/40 text-[#4A453E] cursor-pointer flex items-center justify-center gap-1.5"
                >
                  {copyFeedback ? <Check className="w-3.5 h-3.5 text-[#2E5A44]" /> : <Copy className="w-3.5 h-3.5" />}
                  <span>{copyFeedback ? 'Đã chép!' : 'Chép link'}</span>
                </button>
              </div>

              <div className="flex items-center gap-2 w-full sm:w-auto justify-end">
                <button
                  type="button"
                  onClick={handleShareOutfit}
                  disabled={isSharing}
                  className="flex-1 sm:flex-initial px-4 py-2 text-xs font-tabular uppercase tracking-wider bg-[#9E2A1C] hover:bg-[#832014] text-white cursor-pointer flex items-center justify-center gap-1.5 shadow-sm"
                >
                  <Share2 className="w-3.5 h-3.5" />
                  <span>Mở chia sẻ</span>
                </button>
                <button
                  type="button"
                  onClick={() => setIsShareModalOpen(false)}
                  className="px-4 py-2 text-xs font-tabular uppercase tracking-wider border border-[#141312]/20 text-[#6E675F] hover:text-[#0D0C0B] cursor-pointer"
                >
                  Đóng
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
