import React, { useMemo, useState } from 'react';
import { Item } from '../../domain/types';
import {
  CANONICAL_ENTITIES,
  CanonicalEntity,
  BrowseCategory,
  CANONICAL_STATS,
  getBrowseCategoryLabel,
} from '../../domain/canonicalData';
import { ItemCard } from '../ItemCard';
import {
  Search,
  SlidersHorizontal,
  X,
  RotateCcw,
  ArrowUpRight,
  ExternalLink,
  AlertCircle,
  CheckCircle2,
  BookOpen,
} from 'lucide-react';

interface CatalogScreenProps {
  onSelectItemDetail: (item: Item) => void;
  onAddItemToBuilder?: (item: Item) => void;
}

// 7 Simple browse categories as requested + 'Tất cả'
const CATEGORY_TABS: Array<{ id: BrowseCategory; label: string }> = [
  { id: 'ALL', label: 'Tất cả' },
  { id: 'AO', label: 'Áo' },
  { id: 'AO_TRONG', label: 'Áo trong' },
  { id: 'AO_NGOAI', label: 'Áo ngoài' },
  { id: 'QUAN_VAY', label: 'Quần & Váy' },
  { id: 'GIAY_DEP', label: 'Giày & Dép' },
  { id: 'KHAN_NON', label: 'Khăn & Nón' },
  { id: 'PHU_KIEN', label: 'Phụ kiện' },
];

export const CatalogScreen: React.FC<CatalogScreenProps> = ({
  onSelectItemDetail,
  onAddItemToBuilder,
}) => {
  // 1. Search Query
  const [searchQuery, setSearchQuery] = useState('');
  const [isSearchFocused, setIsSearchFocused] = useState(false);

  // 2. Active Category Navigation
  const [activeCategory, setActiveCategory] = useState<BrowseCategory>('ALL');

  // 3. Floating Filter Drawer Toggle
  const [isFilterOpen, setIsFilterOpen] = useState(false);

  // 4. Advanced Filter Criteria
  const [selectedPeriod, setSelectedPeriod] = useState('ALL');
  const [selectedRegion, setSelectedRegion] = useState('ALL');
  const [selectedContext, setSelectedContext] = useState('ALL');
  const [selectedEvidence, setSelectedEvidence] = useState('ALL');
  const [selectedImageStatus, setSelectedImageStatus] = useState<
    'ALL' | 'HAS_IMAGE' | 'NO_IMAGE'
  >('ALL');
  const [selectedResearchStatus, setSelectedResearchStatus] = useState<
    'ALL' | 'CURATED' | 'RESEARCH'
  >('ALL');

  // 5. Active Detailed Entity for in-place Editorial Inspection Panel
  const [inspectingEntity, setInspectingEntity] = useState<CanonicalEntity | null>(
    null
  );

  // Count active filters (excluding 'ALL')
  const activeFilterCount = useMemo(() => {
    let count = 0;
    if (selectedPeriod !== 'ALL') count++;
    if (selectedRegion !== 'ALL') count++;
    if (selectedContext !== 'ALL') count++;
    if (selectedEvidence !== 'ALL') count++;
    if (selectedImageStatus !== 'ALL') count++;
    if (selectedResearchStatus !== 'ALL') count++;
    return count;
  }, [
    selectedPeriod,
    selectedRegion,
    selectedContext,
    selectedEvidence,
    selectedImageStatus,
    selectedResearchStatus,
  ]);

  // Combined Progressive Filtering Engine
  const filteredEntities = useMemo(() => {
    return CANONICAL_ENTITIES.filter((entity) => {
      // 1. Category Tab
      if (activeCategory !== 'ALL' && entity.browseCategory !== activeCategory) {
        return false;
      }

      // 2. Research status filter
      if (
        selectedResearchStatus === 'CURATED' &&
        entity.researchStatus !== 'CURATED_CATALOG'
      ) {
        return false;
      }
      if (
        selectedResearchStatus === 'RESEARCH' &&
        entity.researchStatus === 'CURATED_CATALOG'
      ) {
        return false;
      }

      // 3. Search query
      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase().trim();
        const matchesName = entity.canonicalNameVi.toLowerCase().includes(q);
        const matchesAlias = entity.aliases.some((a) =>
          a.toLowerCase().includes(q)
        );
        const matchesVariant = entity.variants.some((v) =>
          v.name.toLowerCase().includes(q)
        );
        const matchesPeriod = entity.periods.some((p) =>
          p.toLowerCase().includes(q)
        );
        const matchesRegion = entity.geographicRegions.some((r) =>
          r.toLowerCase().includes(q)
        );
        const matchesContext = entity.contexts.some((c) =>
          c.toLowerCase().includes(q)
        );
        const matchesCategory = entity.browseCategoryLabel
          .toLowerCase()
          .includes(q);

        if (
          !matchesName &&
          !matchesAlias &&
          !matchesVariant &&
          !matchesPeriod &&
          !matchesRegion &&
          !matchesContext &&
          !matchesCategory
        ) {
          return false;
        }
      }

      // 4. Period filter
      if (selectedPeriod !== 'ALL') {
        const pUpper = selectedPeriod;
        const matchesP = entity.periods.some((p) => {
          const lower = p.toLowerCase();
          if (pUpper === 'NGUYEN') return lower.includes('nguyễn');
          if (pUpper === 'LE') return lower.includes('lê');
          if (pUpper === 'LY_TRAN') return lower.includes('lý') || lower.includes('trần');
          if (pUpper === 'CAN_DAI')
            return lower.includes('cận đại') || lower.includes('thế kỷ 20') || lower.includes('đầu 20');
          if (pUpper === 'DAN_GIAN') return lower.includes('dân gian');
          return true;
        });
        if (!matchesP) return false;
      }

      // 5. Region filter
      if (selectedRegion !== 'ALL') {
        const rUpper = selectedRegion;
        const matchesR =
          entity.geographicRegions.some((r) => {
            const lower = r.toLowerCase();
            if (rUpper === 'BAC_BO') return lower.includes('bắc');
            if (rUpper === 'TRUNG_BO') return lower.includes('trung') || lower.includes('huế');
            if (rUpper === 'NAM_BO') return lower.includes('nam');
            if (rUpper === 'TOAN_QUOC') return lower.includes('toàn quốc');
            return true;
          }) ||
          (rUpper === 'TOAN_QUOC' && entity.geographicRegions.length === 0);
        if (!matchesR) return false;
      }

      // 6. Context filter
      if (selectedContext !== 'ALL') {
        const cUpper = selectedContext;
        const matchesC = entity.contexts.some((c) => {
          const lower = c.toLowerCase();
          if (cUpper === 'CUNG_DINH') return lower.includes('cung đình') || lower.includes('triều');
          if (cUpper === 'NGHI_LE') return lower.includes('nghi lễ') || lower.includes('tế');
          if (cUpper === 'LE_HOI') return lower.includes('hội') || lower.includes('cưới');
          if (cUpper === 'DOI_THUONG') return lower.includes('thường') || lower.includes('lao động');
          return true;
        });
        if (!matchesC) return false;
      }

      // 7. Evidence filter
      if (selectedEvidence !== 'ALL') {
        if (selectedEvidence === 'VERIFIED' && entity.evidenceStatus !== 'VERIFIED')
          return false;
        if (
          selectedEvidence === 'CONSISTENT' &&
          entity.evidenceStatus !== 'HISTORICALLY_CONSISTENT'
        )
          return false;
        if (selectedEvidence === 'CONTESTED' && entity.evidenceStatus !== 'CONTESTED')
          return false;
        if (selectedEvidence === 'UNCERTAIN' && entity.evidenceStatus !== 'UNCERTAIN')
          return false;
      }

      // 8. Image status filter
      if (selectedImageStatus !== 'ALL') {
        const hasVerifiedImg =
          entity.image.imageType !== 'NO_VERIFIED_IMAGE' && Boolean(entity.image.src);
        if (selectedImageStatus === 'HAS_IMAGE' && !hasVerifiedImg) return false;
        if (selectedImageStatus === 'NO_IMAGE' && hasVerifiedImg) return false;
      }

      return true;
    });
  }, [
    activeCategory,
    searchQuery,
    selectedPeriod,
    selectedRegion,
    selectedContext,
    selectedEvidence,
    selectedImageStatus,
    selectedResearchStatus,
  ]);

  const handleResetFilters = () => {
    setSelectedPeriod('ALL');
    setSelectedRegion('ALL');
    setSelectedContext('ALL');
    setSelectedEvidence('ALL');
    setSelectedImageStatus('ALL');
    setSelectedResearchStatus('ALL');
  };

  const handleResetAll = () => {
    setSearchQuery('');
    setActiveCategory('ALL');
    handleResetFilters();
  };

  // Helper for asymmetric editorial layout (strict 12-col alignment without masonry chaos)
  const getEditorialCardLayout = (index: number, total: number) => {
    if (total === 1) {
      return {
        className: 'lg:col-span-8 lg:col-start-3 md:col-span-2 col-span-1',
        sizeVariant: 'large' as const,
      };
    }
    if (total === 2) {
      return {
        className: 'lg:col-span-6 md:col-span-1 col-span-1',
        sizeVariant: 'large' as const,
      };
    }
    // Rhythmic 12-column recurring rows: [6+3+3], [3+3+6], [4+4+4], [3+6+3]
    const rhythm = [
      { span: 'lg:col-span-6 md:col-span-2 col-span-1', size: 'large' as const },
      { span: 'lg:col-span-3 md:col-span-1 col-span-1', size: 'compact' as const },
      { span: 'lg:col-span-3 md:col-span-1 col-span-1', size: 'compact' as const },
      { span: 'lg:col-span-3 md:col-span-1 col-span-1', size: 'compact' as const },
      { span: 'lg:col-span-3 md:col-span-1 col-span-1', size: 'compact' as const },
      { span: 'lg:col-span-6 md:col-span-2 col-span-1', size: 'large' as const },
      { span: 'lg:col-span-4 md:col-span-1 col-span-1', size: 'compact' as const },
      { span: 'lg:col-span-4 md:col-span-1 col-span-1', size: 'compact' as const },
      { span: 'lg:col-span-4 md:col-span-2 col-span-1', size: 'compact' as const },
      { span: 'lg:col-span-3 md:col-span-1 col-span-1', size: 'compact' as const },
      { span: 'lg:col-span-6 md:col-span-2 col-span-1', size: 'large' as const },
      { span: 'lg:col-span-3 md:col-span-1 col-span-1', size: 'compact' as const },
    ];
    const item = rhythm[index % rhythm.length];
    return {
      className: item.span,
      sizeVariant: item.size,
    };
  };

  return (
    <div className="min-h-screen text-[#171717] pb-32">
      {/* =========================================================================
          1. REFINED EDITORIAL HERO (REDUCED HEIGHT BY 35–40% FOR FASTER CATALOG TRANSITION)
      ========================================================================= */}
      <header className="pt-8 pb-6 sm:pt-12 sm:pb-8 border-b border-[#D8D3C9]/70 flex flex-col md:flex-row md:items-end justify-between gap-6">
        <div className="max-w-4xl space-y-2.5 sm:space-y-3">
          <div className="flex items-center gap-3 text-xs text-[#77736B] font-mono tracking-widest uppercase">
            <span>TÀNG Y CÁC · TỦ ÁO TRUYỀN THỐNG</span>
            <span>·</span>
            <span>44 THỰC THỂ KHẢO CỨU</span>
          </div>
          <h1 className="font-raven text-5xl sm:text-7xl lg:text-8xl font-normal text-[#171717] tracking-[0.02em] uppercase leading-none">
            Tủ Áo
          </h1>
          <p className="font-editorial text-lg sm:text-2xl text-[#77736B] italic font-light leading-relaxed">
            &ldquo;Những dạng thức Việt phục qua tư liệu, hiện vật và phục dựng.&rdquo;
          </p>
        </div>
      </header>

      {/* =========================================================================
          INTERACTIVE FLOATING CONTROLS
          Liquid-glass sticky bar: Typography Navigation · Minimal Search · Bộ Lọc
      ========================================================================= */}
      <section className="sticky top-20 z-40 bg-[#F4F1EA]/85 backdrop-blur-md border-b border-[#D8D3C9]/80 py-4 transition-all">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-5">
          {/* 1. Category Navigation (Typography Navigation - Zero pills) */}
          <nav
            aria-label="Phân loại y phục"
            className="flex items-center gap-6 sm:gap-8 overflow-x-auto no-scrollbar py-1"
          >
            {CATEGORY_TABS.map((tab) => {
              const isActive = activeCategory === tab.id;
              return (
                <button
                  key={tab.id}
                  type="button"
                  onClick={() => setActiveCategory(tab.id)}
                  className={`text-sm tracking-wider uppercase whitespace-nowrap cursor-pointer transition-colors duration-200 pb-1 border-b-2 ${
                    isActive
                      ? 'text-[#171717] font-semibold border-[#A63D2F]'
                      : 'text-[#77736B] hover:text-[#171717] border-transparent font-normal'
                  }`}
                >
                  {tab.label}
                </button>
              );
            })}
          </nav>

          {/* 2. Minimal Editorial Search & "Bộ Lọc" Trigger */}
          <div className="flex items-center gap-4 shrink-0">
            {/* Minimal Editorial Search Field */}
            <div className="relative flex items-center border-b border-[#D8D3C9] focus-within:border-[#171717] transition-colors py-1 w-52 sm:w-64">
              <Search className="w-4 h-4 text-[#77736B] mr-2 shrink-0" />
              <input
                type="text"
                value={searchQuery}
                onFocus={() => setIsSearchFocused(true)}
                onBlur={() => setIsSearchFocused(false)}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Tìm kiếm trong tủ áo..."
                className="w-full bg-transparent text-sm text-[#171717] placeholder:text-[#77736B] focus:outline-none"
              />
              {searchQuery && (
                <button
                  type="button"
                  onClick={() => setSearchQuery('')}
                  className="text-[#77736B] hover:text-[#171717] cursor-pointer ml-1"
                >
                  <X className="w-3.5 h-3.5" />
                </button>
              )}
            </div>

            {/* "Bộ Lọc" Floating Button */}
            <button
              type="button"
              onClick={() => setIsFilterOpen((prev) => !prev)}
              className={`inline-flex items-center gap-2 px-3.5 py-1.5 text-xs uppercase tracking-wider transition-all cursor-pointer border ${
                isFilterOpen || activeFilterCount > 0
                  ? 'border-[#A63D2F] text-[#A63D2F] bg-[#A63D2F]/5 font-semibold'
                  : 'border-[#D8D3C9] text-[#171717] hover:border-[#171717] bg-white/40 backdrop-blur-xs'
              }`}
            >
              <SlidersHorizontal className="w-3.5 h-3.5" />
              <span>Bộ lọc</span>
              {activeFilterCount > 0 && (
                <span className="w-4 h-4 rounded-full bg-[#A63D2F] text-white text-[10px] flex items-center justify-center font-mono">
                  {activeFilterCount}
                </span>
              )}
            </button>
          </div>
        </div>

        {/* =======================================================================
            FLOATING LIQUID-GLASS FILTER DRAWER
        ======================================================================= */}
        {isFilterOpen && (
          <div className="mt-4 p-6 sm:p-8 bg-[#F4F1EA]/95 backdrop-blur-xl border border-[#D8D3C9] shadow-[0_16px_40px_rgba(23,23,23,0.08)] space-y-6 animate-in fade-in slide-in-from-top-2 duration-200">
            <div className="flex items-center justify-between border-b border-[#D8D3C9] pb-3">
              <span className="font-raven text-base font-medium uppercase tracking-wider text-[#171717]">
                Tiêu Chí Khảo Cứu
              </span>
              <div className="flex items-center gap-4">
                {activeFilterCount > 0 && (
                  <button
                    type="button"
                    onClick={handleResetFilters}
                    className="inline-flex items-center gap-1.5 text-xs text-[#A63D2F] hover:underline cursor-pointer uppercase tracking-wider"
                  >
                    <RotateCcw className="w-3 h-3" />
                    <span>Đặt lại ({activeFilterCount})</span>
                  </button>
                )}
                <button
                  type="button"
                  onClick={() => setIsFilterOpen(false)}
                  className="text-[#77736B] hover:text-[#171717] cursor-pointer"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 text-xs">
              {/* 1. Thời kỳ */}
              <div className="space-y-2">
                <label className="block uppercase text-[11px] text-[#77736B] tracking-wider">
                  Thời kỳ
                </label>
                <select
                  value={selectedPeriod}
                  onChange={(e) => setSelectedPeriod(e.target.value)}
                  className="w-full bg-[#F4F1EA] border border-[#D8D3C9] py-2 px-3 text-xs text-[#171717] focus:border-[#171717] focus:outline-none cursor-pointer"
                >
                  <option value="ALL">Tất cả thời kỳ</option>
                  <option value="NGUYEN">Triều Nguyễn (1802–1945)</option>
                  <option value="LE">Lê Trung Hưng (1533–1789)</option>
                  <option value="LY_TRAN">Thời Lý – Trần (1009–1400)</option>
                  <option value="CAN_DAI">Cận đại &amp; Đầu TK 20</option>
                  <option value="DAN_GIAN">Dân gian truyền thống</option>
                </select>
              </div>

              {/* 2. Vùng / Khu vực */}
              <div className="space-y-2">
                <label className="block uppercase text-[11px] text-[#77736B] tracking-wider">
                  Vùng / Khu vực
                </label>
                <select
                  value={selectedRegion}
                  onChange={(e) => setSelectedRegion(e.target.value)}
                  className="w-full bg-[#F4F1EA] border border-[#D8D3C9] py-2 px-3 text-xs text-[#171717] focus:border-[#171717] focus:outline-none cursor-pointer"
                >
                  <option value="ALL">Tất cả vùng miền</option>
                  <option value="BAC_BO">Bắc Bộ (Đồng bằng, Kinh Bắc)</option>
                  <option value="TRUNG_BO">Trung Bộ (Huế, Đàng Trong)</option>
                  <option value="NAM_BO">Nam Bộ (Phương Nam)</option>
                  <option value="TOAN_QUOC">Toàn quốc</option>
                </select>
              </div>

              {/* 3. Bối cảnh */}
              <div className="space-y-2">
                <label className="block uppercase text-[11px] text-[#77736B] tracking-wider">
                  Bối cảnh
                </label>
                <select
                  value={selectedContext}
                  onChange={(e) => setSelectedContext(e.target.value)}
                  className="w-full bg-[#F4F1EA] border border-[#D8D3C9] py-2 px-3 text-xs text-[#171717] focus:border-[#171717] focus:outline-none cursor-pointer"
                >
                  <option value="ALL">Tất cả bối cảnh</option>
                  <option value="CUNG_DINH">Cung đình &amp; Triều chính</option>
                  <option value="NGHI_LE">Nghi lễ &amp; Tế tự</option>
                  <option value="LE_HOI">Lễ hội &amp; Cưới hỏi</option>
                  <option value="DOI_THUONG">Đời thường &amp; Lao động</option>
                </select>
              </div>

              {/* 4. Chứng cứ */}
              <div className="space-y-2">
                <label className="block uppercase text-[11px] text-[#77736B] tracking-wider">
                  Chứng cứ
                </label>
                <select
                  value={selectedEvidence}
                  onChange={(e) => setSelectedEvidence(e.target.value)}
                  className="w-full bg-[#F4F1EA] border border-[#D8D3C9] py-2 px-3 text-xs text-[#171717] focus:border-[#171717] focus:outline-none cursor-pointer"
                >
                  <option value="ALL">Tất cả mức độ</option>
                  <option value="VERIFIED">Đã kiểm chứng</option>
                  <option value="CONSISTENT">Có cơ sở mạnh / Phù hợp bối cảnh</option>
                  <option value="CONTESTED">Có tranh luận tư liệu</option>
                  <option value="UNCERTAIN">Chưa đủ tư liệu</option>
                </select>
              </div>

              {/* 5. Tình trạng hình ảnh */}
              <div className="space-y-2">
                <label className="block uppercase text-[11px] text-[#77736B] tracking-wider">
                  Tình trạng hình ảnh
                </label>
                <select
                  value={selectedImageStatus}
                  onChange={(e) => setSelectedImageStatus(e.target.value as any)}
                  className="w-full bg-[#F4F1EA] border border-[#D8D3C9] py-2 px-3 text-xs text-[#171717] focus:border-[#171717] focus:outline-none cursor-pointer"
                >
                  <option value="ALL">Tất cả tình trạng ảnh</option>
                  <option value="HAS_IMAGE">Có ảnh khảo cứu xác thực</option>
                  <option value="NO_IMAGE">Đang bổ sung tư liệu ảnh</option>
                </select>
              </div>

              {/* 6. Tình trạng nghiên cứu */}
              <div className="space-y-2">
                <label className="block uppercase text-[11px] text-[#77736B] tracking-wider">
                  Tình trạng nghiên cứu
                </label>
                <select
                  value={selectedResearchStatus}
                  onChange={(e) => setSelectedResearchStatus(e.target.value as any)}
                  className="w-full bg-[#F4F1EA] border border-[#D8D3C9] py-2 px-3 text-xs text-[#171717] focus:border-[#171717] focus:outline-none cursor-pointer"
                >
                  <option value="ALL">Tất cả hồ sơ</option>
                  <option value="CURATED">Tủ áo tuyển chọn (Xác thực cao)</option>
                  <option value="RESEARCH">Hồ sơ đang tiếp tục nghiên cứu</option>
                </select>
              </div>
            </div>

            <div className="flex justify-end pt-2 border-t border-[#D8D3C9]">
              <button
                type="button"
                onClick={() => setIsFilterOpen(false)}
                className="px-6 py-2 bg-[#171717] text-[#F4F1EA] text-xs uppercase tracking-wider font-medium hover:bg-[#A63D2F] transition-colors cursor-pointer"
              >
                Áp dụng
              </button>
            </div>
          </div>
        )}
      </section>

      {/* =========================================================================
          ACTIVE FILTER CHIPS (IF ANY)
      ========================================================================= */}
      {(searchQuery || activeCategory !== 'ALL' || activeFilterCount > 0) && (
        <div className="pt-6 flex flex-wrap items-center gap-3 text-xs">
          <span className="text-[#77736B] uppercase tracking-wider text-[11px]">
            Đang lọc:
          </span>

          {searchQuery && (
            <span className="inline-flex items-center gap-1.5 px-3 py-1 bg-white/70 border border-[#D8D3C9] text-[#171717]">
              <span>Từ khóa: &ldquo;{searchQuery}&rdquo;</span>
              <button
                type="button"
                onClick={() => setSearchQuery('')}
                className="hover:text-[#A63D2F] cursor-pointer"
              >
                <X className="w-3 h-3" />
              </button>
            </span>
          )}

          {activeCategory !== 'ALL' && (
            <span className="inline-flex items-center gap-1.5 px-3 py-1 bg-white/70 border border-[#D8D3C9] text-[#171717]">
              <span>Danh mục: {getBrowseCategoryLabel(activeCategory)}</span>
              <button
                type="button"
                onClick={() => setActiveCategory('ALL')}
                className="hover:text-[#A63D2F] cursor-pointer"
              >
                <X className="w-3 h-3" />
              </button>
            </span>
          )}

          {activeFilterCount > 0 && (
            <span className="inline-flex items-center gap-1.5 px-3 py-1 bg-white/70 border border-[#D8D3C9] text-[#171717]">
              <span>{activeFilterCount} tiêu chí nâng cao</span>
              <button
                type="button"
                onClick={handleResetFilters}
                className="hover:text-[#A63D2F] cursor-pointer"
              >
                <X className="w-3 h-3" />
              </button>
            </span>
          )}

          <button
            type="button"
            onClick={handleResetAll}
            className="text-xs text-[#A63D2F] hover:underline uppercase tracking-wider font-medium ml-2 cursor-pointer"
          >
            [Xóa tất cả]
          </button>
        </div>
      )}

      {/* =========================================================================
          IMAGE-FIRST EDITORIAL CATALOG GRID (ASYMMETRIC EDITORIAL GRID)
      ========================================================================= */}
      <section className="pt-8 sm:pt-10 space-y-8">
        <div className="flex items-baseline justify-between border-b border-[#D8D3C9]/70 pb-3">
          <span className="text-xs uppercase tracking-[0.14em] text-[#77736B]">
            Bộ Sưu Tập Khảo Cứu — {filteredEntities.length} Hiện Vật &amp; Dạng Thức
          </span>
          <span className="text-xs uppercase tracking-[0.16em] text-[#A63D2F] font-mono">
            Lưu Trữ Tàng Y
          </span>
        </div>

        {filteredEntities.length === 0 ? (
          <div className="py-24 text-center space-y-4 max-w-md mx-auto">
            <h3 className="font-raven text-3xl text-[#171717] font-normal">
              Không tìm thấy hiện vật
            </h3>
            <p className="text-sm text-[#77736B] leading-relaxed">
              Không có y phục nào khớp với tiêu chí tìm kiếm hiện tại. Hãy thử chọn danh mục khác hoặc đặt lại bộ lọc.
            </p>
            <div className="pt-2">
              <button
                type="button"
                onClick={handleResetAll}
                className="px-6 py-2.5 bg-[#171717] text-[#F4F1EA] text-xs uppercase tracking-wider font-medium hover:bg-[#A63D2F] transition-colors cursor-pointer"
              >
                Xem toàn bộ tủ áo
              </button>
            </div>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-12 gap-x-8 gap-y-12 sm:gap-x-10 sm:gap-y-16 items-start">
            {filteredEntities.map((entity, index) => {
              const layout = getEditorialCardLayout(index, filteredEntities.length);
              return (
                <div key={entity.canonicalId} className={layout.className}>
                  <ItemCard
                    entity={entity}
                    sizeVariant={layout.sizeVariant}
                    onSelectDetail={(e) => setInspectingEntity(e)}
                  />
                </div>
              );
            })}
          </div>
        )}
      </section>

      {/* =========================================================================
          RESTRAINED LIQUID-GLASS DETAIL DRAWER / INSPECTION MODAL
      ========================================================================= */}
      {inspectingEntity && (
        <div
          className="fixed inset-0 z-50 bg-[#171717]/60 backdrop-blur-sm flex items-center justify-center p-4 sm:p-6 animate-backdrop-fade"
          onClick={() => setInspectingEntity(null)}
        >
          <div
            className="bg-[#F4F1EA]/95 backdrop-blur-xl text-[#171717] w-full max-w-3xl max-h-[90vh] overflow-y-auto border border-[#D8D3C9] shadow-[0_24px_50px_rgba(23,23,23,0.15)] p-6 sm:p-10 space-y-8 relative animate-drawer-slide will-change-transform"
            onClick={(e) => e.stopPropagation()}
          >
            {/* Close button */}
            <button
              type="button"
              onClick={() => setInspectingEntity(null)}
              className="absolute top-6 right-6 text-[#77736B] hover:text-[#171717] p-2 transition-colors cursor-pointer"
              title="Đóng hồ sơ"
            >
              <X className="w-5 h-5" />
            </button>

            {/* Modal Header */}
            <div className="border-b border-[#D8D3C9] pb-6 space-y-3">
              <div className="flex flex-wrap items-center gap-3 text-xs tracking-wider uppercase text-[#77736B]">
                <span className="text-[#A63D2F] font-semibold">HỒ SƠ KHẢO CỨU</span>
                <span>·</span>
                <span>{inspectingEntity.browseCategoryLabel}</span>
                <span>·</span>
                <span className="font-medium text-[#171717]">
                  {inspectingEntity.evidenceLabelVi}
                </span>
              </div>

              <h2 className="font-raven text-4xl sm:text-5xl font-normal text-[#171717] uppercase tracking-wide">
                {inspectingEntity.canonicalNameVi}
              </h2>

              {inspectingEntity.aliases.length > 0 && (
                <p className="text-sm text-[#77736B] italic font-editorial">
                  Tên gọi khác: {inspectingEntity.aliases.join(', ')}
                </p>
              )}
            </div>

            {/* Visual Provenance Section */}
            <div className="p-6 bg-[#EAE6DE]/60 border border-[#D8D3C9] space-y-4">
              <div className="flex items-center justify-between text-xs tracking-wider uppercase text-[#77736B]">
                <span>Tư liệu hình ảnh (Image Provenance)</span>
                <span className="text-[#171717] font-medium">
                  {inspectingEntity.image.imageStatusLabelVi}
                </span>
              </div>

              {inspectingEntity.image.src ? (
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-6 items-center">
                  <div className="sm:col-span-1 aspect-[3/4] overflow-hidden bg-[#E8E3DA]">
                    <img
                      src={inspectingEntity.image.src}
                      alt={
                        inspectingEntity.image.alt ||
                        inspectingEntity.canonicalNameVi
                      }
                      className="w-full h-full object-cover object-top"
                    />
                  </div>
                  <div className="sm:col-span-2 space-y-2.5 text-xs text-[#524D46] leading-relaxed">
                    <p>
                      <strong className="text-[#171717]">Đơn vị cung cấp:</strong>{' '}
                      {inspectingEntity.image.sourceInstitution}
                    </p>
                    <p>
                      <strong className="text-[#171717]">Giấy phép sử dụng:</strong>{' '}
                      {inspectingEntity.image.license}
                    </p>
                    {inspectingEntity.image.verificationNote && (
                      <p className="p-3 bg-white/60 border border-[#D8D3C9] text-[11px] italic text-[#171717]">
                        * {inspectingEntity.image.verificationNote}
                      </p>
                    )}
                  </div>
                </div>
              ) : (
                <div className="p-4 bg-white/40 border border-dashed border-[#D8D3C9] space-y-1.5 text-xs text-[#77736B]">
                  <p className="font-medium text-[#A63D2F]">
                    Chưa có hình ảnh xác thực đạt chuẩn bảo tàng
                  </p>
                  <p className="text-[11px] leading-relaxed">
                    Hệ thống không sử dụng ảnh minh họa AI hoặc ảnh ngẫu nhiên để đảm bảo tính nghiêm cẩn văn hóa.
                  </p>
                </div>
              )}
            </div>

            {/* Dimensions Grid */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
              <div className="p-4 bg-white/40 border border-[#D8D3C9] space-y-1">
                <span className="uppercase text-[10px] tracking-wider text-[#77736B] block">
                  Thời kỳ
                </span>
                <span className="font-medium text-[#171717] text-sm">
                  {inspectingEntity.periods.join(', ') || 'Nhiều thời kỳ'}
                </span>
              </div>

              <div className="p-4 bg-white/40 border border-[#D8D3C9] space-y-1">
                <span className="uppercase text-[10px] tracking-wider text-[#77736B] block">
                  Vùng địa lý
                </span>
                <span className="font-medium text-[#171717] text-sm">
                  {[...inspectingEntity.geographicRegions, ...inspectingEntity.locations].join(' · ') || 'Toàn quốc'}
                </span>
              </div>

              <div className="p-4 bg-white/40 border border-[#D8D3C9] space-y-1">
                <span className="uppercase text-[10px] tracking-wider text-[#77736B] block">
                  Tầng lớp &amp; Đối tượng
                </span>
                <span className="font-medium text-[#171717] text-sm">
                  {[...inspectingEntity.socialContext, ...inspectingEntity.gender].join(' · ') || 'Mọi tầng lớp'}
                </span>
              </div>

              <div className="p-4 bg-white/40 border border-[#D8D3C9] space-y-1">
                <span className="uppercase text-[10px] tracking-wider text-[#77736B] block">
                  Bối cảnh sử dụng
                </span>
                <span className="font-medium text-[#171717] text-sm">
                  {inspectingEntity.contexts.join(', ') || 'Đời thường & lễ nghi'}
                </span>
              </div>
            </div>

            {/* Construction & Academic Notes */}
            <div className="space-y-4 border-t border-[#D8D3C9] pt-6 text-xs leading-relaxed">
              {inspectingEntity.constructionNotes && (
                <div>
                  <strong className="text-[#171717] block mb-1">
                    Cấu trúc &amp; Quy thức may mặc:
                  </strong>
                  <p className="text-[#524D46]">{inspectingEntity.constructionNotes}</p>
                </div>
              )}

              {inspectingEntity.warnings && (
                <div className="p-4 bg-[#F7EBE8] border border-[#A63D2F]/20 text-[#A63D2F] space-y-1">
                  <strong className="block font-medium">Lưu ý sai lệch lịch sử:</strong>
                  <p className="text-[11px] leading-relaxed">{inspectingEntity.warnings}</p>
                </div>
              )}

              {inspectingEntity.researchNotes && (
                <div className="p-4 bg-[#EDF2F7] border border-[#2E4A62]/20 text-[#2E4A62] space-y-1">
                  <strong className="block font-medium">Ghi chú nghiên cứu:</strong>
                  <p className="text-[11px] leading-relaxed">{inspectingEntity.researchNotes}</p>
                </div>
              )}
            </div>

            {/* Source Citations */}
            {inspectingEntity.sources.length > 0 && (
              <div className="border-t border-[#D8D3C9] pt-6 space-y-3 text-xs">
                <span className="uppercase text-[10px] tracking-wider text-[#77736B] block font-medium">
                  Tư liệu tham chiếu ({inspectingEntity.sources.length})
                </span>
                <div className="space-y-2">
                  {inspectingEntity.sources.map((src) => (
                    <div
                      key={src.id}
                      className="flex items-center justify-between p-2.5 bg-white/50 border border-[#D8D3C9]"
                    >
                      <span className="font-medium text-[#171717]">
                        [{src.id}] {src.name} {src.institution ? `— ${src.institution}` : ''}
                      </span>
                      {src.url && (
                        <a
                          href={src.url}
                          target="_blank"
                          rel="noreferrer"
                          className="text-[#A63D2F] hover:underline inline-flex items-center gap-1 font-mono text-[11px]"
                        >
                          <span>Xem nguồn</span>
                          <ExternalLink className="w-3 h-3" />
                        </a>
                      )}
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Bottom Actions */}
            <div className="pt-6 border-t border-[#D8D3C9] flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <span className="text-[10px] text-[#77736B] font-mono">
                Mã thực thể: {inspectingEntity.canonicalId}
              </span>
              <div className="flex items-center gap-3">
                {onAddItemToBuilder && (
                  <button
                    type="button"
                    onClick={() => {
                      setInspectingEntity(null);
                      onAddItemToBuilder(inspectingEntity.asItem);
                    }}
                    className="px-5 py-2.5 border border-[#171717] text-[#171717] text-xs font-medium uppercase tracking-wider hover:bg-[#171717] hover:text-[#F4F1EA] transition-colors cursor-pointer"
                  >
                    Đưa vào phối phục
                  </button>
                )}
                <button
                  type="button"
                  onClick={() => {
                    setInspectingEntity(null);
                    onSelectItemDetail(inspectingEntity.asItem);
                  }}
                  className="inline-flex items-center gap-2 px-6 py-2.5 bg-[#171717] text-[#F4F1EA] text-xs font-medium uppercase tracking-wider hover:bg-[#A63D2F] transition-colors cursor-pointer"
                >
                  <span>Chuyện áo chi tiết</span>
                  <ArrowUpRight className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
