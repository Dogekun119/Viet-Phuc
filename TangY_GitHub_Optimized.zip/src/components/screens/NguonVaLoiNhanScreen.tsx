import React, { useId, useMemo, useState } from 'react';
import {
  MagneticButton,
  SectionEntrance,
  SplitLineReveal,
} from '../motion/MotionPrimitives';
import {
  EVIDENCE_LEVEL_DISPLAY,
  EvidenceLevel,
  RESEARCH_QUEUE,
  RESEARCH_SOURCES,
} from '../../data/researchMaster';
import { ALL_ITEMS, PDF_AUDIT_ITEMS } from '../../domain/dataAdapter';
import {
  Search,
  X,
  ExternalLink,
  CheckCircle2,
  AlertCircle,
  Loader2,
  ChevronDown,
  ChevronUp,
  BookOpen,
  Send,
  Info,
  ShieldCheck,
  RotateCcw,
  Check,
  Layers,
} from 'lucide-react';

interface SubmissionReceipt {
  id: string;
  submittedAt: string;
  message: string;
}

export const NguonVaLoiNhanScreen: React.FC = () => {
  // Search state for Research Sources S01 - S10
  const [sourceSearchQuery, setSourceSearchQuery] = useState('');

  // Queue priority filter: ALL, P0, P1
  const [selectedQueuePriority, setSelectedQueuePriority] = useState<
    'ALL' | 'P0' | 'P1'
  >('ALL');

  // Expanded items in Research Queue (for progressive disclosure)
  const [expandedQueueTopics, setExpandedQueueTopics] = useState<Record<string, boolean>>({});

  // Collapsible toggle for PDF Audit section (collapsed by default to keep page compact)
  const [isAuditTableOpen, setIsAuditTableOpen] = useState(false);
  const [auditPriorityFilter, setAuditPriorityFilter] = useState<'ALL' | 'HIGH'>('ALL');

  // Form State
  const [target, setTarget] = useState('');
  const [detail, setDetail] = useState('');
  const [sourceReference, setSourceReference] = useState('');
  const [contactEmail, setContactEmail] = useState('');

  // Form Validation & Interaction State
  const [formErrors, setFormErrors] = useState<{
    target?: string;
    detail?: string;
    sourceReference?: string;
    contactEmail?: string;
  }>({});
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [serverError, setServerError] = useState<string | null>(null);
  const [submissionReceipt, setSubmissionReceipt] = useState<SubmissionReceipt | null>(null);

  const datalistId = useId();

  // Sources data & search filtering
  const allSources = useMemo(() => Object.values(RESEARCH_SOURCES), []);

  const filteredSources = useMemo(() => {
    const q = sourceSearchQuery.trim().toLowerCase();
    if (!q) return allSources;
    return allSources.filter((src) => {
      const matchId = src.id.toLowerCase().includes(q);
      const matchTitle = src.title.toLowerCase().includes(q);
      const matchInst = src.institution.toLowerCase().includes(q);
      const matchType = src.type.toLowerCase().includes(q);
      const matchUsed = src.usedFor.toLowerCase().includes(q);
      return matchId || matchTitle || matchInst || matchType || matchUsed;
    });
  }, [allSources, sourceSearchQuery]);

  // Evidence levels
  const evidenceLevels = useMemo(
    () =>
      Object.entries(EVIDENCE_LEVEL_DISPLAY) as [
        EvidenceLevel,
        (typeof EVIDENCE_LEVEL_DISPLAY)[EvidenceLevel],
      ][],
    []
  );

  // Filtered queue items
  const filteredQueue = useMemo(() => {
    if (selectedQueuePriority === 'ALL') return RESEARCH_QUEUE;
    return RESEARCH_QUEUE.filter((item) => item.priority === selectedQueuePriority);
  }, [selectedQueuePriority]);

  // Check if all filtered queue items are expanded
  const areAllQueueExpanded = useMemo(() => {
    if (filteredQueue.length === 0) return false;
    return filteredQueue.every((item) => expandedQueueTopics[item.topic]);
  }, [filteredQueue, expandedQueueTopics]);

  const handleToggleAllQueue = () => {
    if (areAllQueueExpanded) {
      setExpandedQueueTopics({});
    } else {
      const all: Record<string, boolean> = {};
      filteredQueue.forEach((item) => {
        all[item.topic] = true;
      });
      setExpandedQueueTopics(all);
    }
  };

  // Filtered PDF Audit items
  const filteredAuditItems = useMemo(() => {
    if (auditPriorityFilter === 'ALL') return PDF_AUDIT_ITEMS;
    return PDF_AUDIT_ITEMS.filter((item) => item.priority === 'HIGH');
  }, [auditPriorityFilter]);

  // Suggestions for autocomplete datalist (Garments G001-G047, Accessories A001-A013, Sources S01-S10)
  const suggestions = useMemo(() => {
    const list: string[] = [];
    allSources.forEach((s) => {
      list.push(`${s.id}: ${s.title}`);
    });
    ALL_ITEMS.slice(0, 48).forEach((item) => {
      list.push(`${item.id} - ${item.name}`);
    });
    return list;
  }, [allSources]);

  // Client-side validation function
  const validateForm = (): boolean => {
    const errors: {
      target?: string;
      detail?: string;
      sourceReference?: string;
      contactEmail?: string;
    } = {};

    const trimmedTarget = target.trim();
    if (!trimmedTarget) {
      errors.target = 'Vui lòng nhập mục trang phục hoặc nội dung cần góp ý.';
    } else if (trimmedTarget.length < 2) {
      errors.target = 'Mục góp ý cần tối thiểu 2 ký tự.';
    } else if (trimmedTarget.length > 250) {
      errors.target = 'Mục góp ý không được vượt quá 250 ký tự.';
    }

    const trimmedDetail = detail.trim();
    if (!trimmedDetail) {
      errors.detail = 'Vui lòng nhập chi tiết đính chính và căn cứ đối chiếu.';
    } else if (trimmedDetail.length < 10) {
      errors.detail = 'Nội dung góp ý quá ngắn. Vui lòng mô tả chi tiết hơn (tối thiểu 10 ký tự).';
    } else if (trimmedDetail.length > 5000) {
      errors.detail = 'Nội dung góp ý không được vượt quá 5.000 ký tự.';
    }

    const trimmedSource = sourceReference.trim();
    if (trimmedSource) {
      if (trimmedSource.length > 1000) {
        errors.sourceReference = 'Nguồn tham khảo không được vượt quá 1.000 ký tự.';
      } else if (/^https?:\/\//i.test(trimmedSource)) {
        try {
          new URL(trimmedSource);
        } catch {
          errors.sourceReference = 'Đường dẫn nguồn tham khảo không đúng định dạng URL hợp lệ.';
        }
      }
    }

    const trimmedEmail = contactEmail.trim();
    if (trimmedEmail) {
      if (trimmedEmail.length > 200) {
        errors.contactEmail = 'Địa chỉ email không được vượt quá 200 ký tự.';
      } else {
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        if (!emailRegex.test(trimmedEmail)) {
          errors.contactEmail = 'Địa chỉ email không hợp lệ (ví dụ: nguyenvana@gmail.com).';
        }
      }
    }

    setFormErrors(errors);
    return Object.keys(errors).length === 0;
  };

  // Submission handler with real API call
  const handleSubmitContribution = async (e: React.FormEvent) => {
    e.preventDefault();
    setServerError(null);

    if (!validateForm()) {
      return;
    }

    setIsSubmitting(true);

    try {
      const payload = {
        target: target.trim(),
        detail: detail.trim(),
        sourceReference: sourceReference.trim() || undefined,
        contactEmail: contactEmail.trim() || undefined,
      };

      const response = await fetch('/api/contributions', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(payload),
      });

      const data = await response.json().catch(() => null);

      if (!response.ok || !data?.ok) {
        const errorMessage =
          data?.error ||
          (response.status === 429
            ? 'Bạn đã gửi quá nhiều yêu cầu trong thời gian ngắn. Vui lòng chờ vài phút trước khi gửi lại.'
            : 'Máy chủ tạm thời không thể lưu trữ đóng góp. Vui lòng thử lại sau giây lát.');
        setServerError(errorMessage);
        setIsSubmitting(false);
        return;
      }

      // Success: server confirmed saving
      setSubmissionReceipt({
        id: data.id,
        submittedAt: data.submittedAt || new Date().toISOString(),
        message: data.message || 'Đã tiếp nhận hồ sơ đóng góp thành công.',
      });
      setFormErrors({});
      // Clear form inputs upon successful submission
      setTarget('');
      setDetail('');
      setSourceReference('');
      setContactEmail('');
    } catch (err: any) {
      setServerError(
        'Lỗi kết nối tới máy chủ. Vui lòng kiểm tra đường truyền mạng và thử lại.'
      );
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleResetForm = () => {
    setSubmissionReceipt(null);
    setServerError(null);
    setFormErrors({});
  };

  const toggleQueueTopic = (topic: string) => {
    setExpandedQueueTopics((prev) => ({
      ...prev,
      [topic]: !prev[topic],
    }));
  };

  return (
    <div className="space-y-12 pb-24 max-w-6xl mx-auto">
      {/* 0. Header: Concise & Editorial */}
      <header className="pt-4 sm:pt-6 border-b border-[#141312]/15 pb-6 space-y-3">
        <div className="flex items-center gap-2 text-xs text-[#6E675F] font-tabular tracking-[0.16em] uppercase">
          <BookOpen className="w-3.5 h-3.5 text-[#9E2A1C]" />
          <span>MINH BẠCH HỌC THUẬT</span>
          <span aria-hidden="true">·</span>
          <span>NGUỒN TƯ LIỆU ĐỐI CHIẾU</span>
        </div>

        <SplitLineReveal
          as="h1"
          lines={['Nguồn & Lời Nhắn']}
          className="font-raven text-4xl sm:text-6xl font-semibold text-[#0D0C0B] uppercase leading-none"
        />

        <p className="text-sm text-[#4A453E] max-w-3xl leading-relaxed pt-1">
          Hệ thống dữ liệu của <span className="font-semibold text-[#0D0C0B]">Việt Phục Remix</span> tuân thủ
          tôn chỉ cốt lõi: <em className="text-[#9E2A1C] font-serif not-italic font-semibold">&ldquo;AI có thể sáng tạo phong cách, nhưng không được sáng tạo sự thật văn hóa.&rdquo;</em> Mọi
          chi tiết y phục đều được truy nguyên từ tư liệu bảo tàng và thư tịch đối chiếu, phân biệt rạch ròi
          giữa di sản xác thực và phong cách cách tân đương đại.
        </p>
      </header>

      {/* Main 2-column Grid on Desktop */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 lg:gap-14">
        {/* Left Column: S01-S10 Sources & Evidence Standards */}
        <div className="lg:col-span-7 space-y-12">
          {/* 1. Danh sách nguồn tham khảo (S01 - S10) with Search */}
          <SectionEntrance showTopRule={false} className="space-y-4">
            <div className="border-b border-[#0D0C0B] pb-3 flex flex-col sm:flex-row sm:items-end justify-between gap-2">
              <div>
                <p className="font-tabular text-xs text-[#9E2A1C] font-semibold">/01</p>
                <h2 className="font-raven text-2xl sm:text-3xl font-medium text-[#0D0C0B] uppercase mt-0.5">
                  Nguồn Tư Liệu Gốc (S01 – S10)
                </h2>
              </div>
              <span className="font-tabular text-xs text-[#6E675F] sm:text-right">
                {filteredSources.length}/{allSources.length} TƯ LIỆU ĐỐI CHIẾU
              </span>
            </div>

            {/* Search Input */}
            <div className="relative">
              <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-[#6E675F]">
                <Search className="w-4 h-4" />
              </div>
              <input
                type="text"
                value={sourceSearchQuery}
                onChange={(e) => setSourceSearchQuery(e.target.value)}
                placeholder="Tìm theo mã [S01], tên sách, cơ quan bảo tàng, ứng dụng..."
                className="w-full pl-9 pr-9 py-2.5 bg-[#FAF7F0] border border-[#141312]/20 text-xs sm:text-sm text-[#0D0C0B] placeholder:text-[#8C8479] focus:outline-none focus:border-[#9E2A1C] transition-colors"
                aria-label="Tìm kiếm nguồn tư liệu"
              />
              {sourceSearchQuery && (
                <button
                  type="button"
                  onClick={() => setSourceSearchQuery('')}
                  className="absolute inset-y-0 right-0 pr-3 flex items-center text-[#6E675F] hover:text-[#0D0C0B] cursor-pointer"
                  title="Xóa tìm kiếm"
                  aria-label="Xóa tìm kiếm"
                >
                  <X className="w-4 h-4" />
                </button>
              )}
            </div>

            {/* Empty State when no source matches search */}
            {filteredSources.length === 0 ? (
              <div className="p-8 border border-dashed border-[#141312]/25 bg-[#FAF7F0] text-center space-y-3">
                <Search className="w-7 h-7 text-[#9E2A1C]/60 mx-auto" />
                <p className="text-sm text-[#0D0C0B] font-medium">
                  Không tìm thấy tư liệu nào phù hợp với từ khóa &ldquo;{sourceSearchQuery}&rdquo;
                </p>
                <p className="text-xs text-[#6E675F]">
                  Bạn có thể tìm theo mã nguồn (S01..S10), tên sách hoặc cơ quan bảo tàng.
                </p>
                <button
                  type="button"
                  onClick={() => setSourceSearchQuery('')}
                  className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-tabular uppercase border border-[#0D0C0B] text-[#0D0C0B] hover:bg-[#0D0C0B] hover:text-[#FAF7F0] transition-colors cursor-pointer"
                >
                  <RotateCcw className="w-3 h-3" />
                  <span>Xóa bộ lọc tìm kiếm</span>
                </button>
              </div>
            ) : (
              <div className="divide-y divide-[#141312]/15">
                {filteredSources.map((src) => (
                  <article
                    key={src.id}
                    className="py-3.5 space-y-1.5 hover:bg-[#FAF7F0]/60 transition-colors p-2.5 rounded-sm"
                  >
                    <div className="flex items-baseline justify-between gap-2">
                      <span className="font-tabular text-xs font-bold text-[#9E2A1C] bg-[#9E2A1C]/10 px-1.5 py-0.5 border border-[#9E2A1C]/25">
                        [{src.id}]
                      </span>
                      <span className="text-[11px] font-tabular tracking-wider uppercase text-[#6E675F] text-right truncate">
                        {src.institution}
                      </span>
                    </div>

                    <h3 className="font-raven text-base sm:text-lg font-medium text-[#0D0C0B] leading-snug">
                      {src.title}
                    </h3>

                    <div className="text-xs text-[#3D3934] space-y-1">
                      <p>
                        <span className="text-[#6E675F] font-medium">Phân loại:</span>{' '}
                        {src.type}
                      </p>
                      <p>
                        <span className="text-[#6E675F] font-medium">Ứng dụng:</span>{' '}
                        {src.usedFor}
                      </p>
                    </div>

                    {src.url && (
                      <div className="pt-1">
                        <a
                          href={src.url}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="inline-flex items-center gap-1.5 text-xs font-tabular text-[#9E2A1C] hover:underline cursor-pointer group"
                        >
                          <span>Mở nguồn tư liệu</span>
                          <ExternalLink className="w-3.5 h-3.5 group-hover:translate-x-0.5 transition-transform" />
                        </a>
                      </div>
                    )}
                  </article>
                ))}
              </div>
            )}
          </SectionEntrance>

          {/* 2. Chuẩn mực phân định bằng chứng (Evidence Levels) */}
          <SectionEntrance showTopRule={false} className="space-y-4">
            <div className="border-b border-[#0D0C0B] pb-3">
              <p className="font-tabular text-xs text-[#9E2A1C] font-semibold">/02</p>
              <h2 className="font-raven text-2xl sm:text-3xl font-medium text-[#0D0C0B] uppercase mt-0.5">
                Chuẩn Mực Phân Định Bằng Chứng
              </h2>
              <p className="text-xs text-[#6E675F] mt-1 leading-relaxed">
                Hệ thống tuân thủ 6 mức độ bằng chứng nghiêm ngặt. Không biến thông tin{' '}
                <strong className="text-[#0D0C0B]">UNCERTAIN</strong> hoặc{' '}
                <strong className="text-[#0D0C0B]">CONTESTED</strong> thành{' '}
                <strong className="text-[#2E5A44]">VERIFIED</strong> chỉ vì nghe thuận tai. Cấp độ{' '}
                <strong className="text-[#1E3A5F]">CONSISTENT</strong> chỉ thể hiện sự phù hợp bối cảnh, chưa đồng nghĩa với VERIFIED trên toàn bộ tổ hợp phối.
              </p>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
              {evidenceLevels.map(([key, item]) => (
                <div
                  key={key}
                  className="border border-[#141312]/15 bg-[#FAF7F0] p-3.5 space-y-1.5"
                >
                  <div className="flex items-center justify-between gap-2">
                    <span
                      className={`text-[10px] font-tabular font-bold uppercase px-2 py-0.5 border ${item.tagClass}`}
                    >
                      {key}
                    </span>
                    <span className="text-xs font-semibold text-[#0D0C0B]">
                      {item.label}
                    </span>
                  </div>
                  <p className="text-xs text-[#4A453E] leading-relaxed">
                    {item.description}
                  </p>
                </div>
              ))}
            </div>
          </SectionEntrance>
        </div>

        {/* Right Column: Cultural Quote, Research Queue & Feedback Form */}
        <div className="lg:col-span-5 space-y-12">
          {/* 3. Lời nhắn về tôn trọng văn hóa */}
          <SectionEntrance showTopRule={false} className="space-y-3">
            <div className="border-b border-[#0D0C0B] pb-2">
              <p className="font-tabular text-xs text-[#9E2A1C] font-semibold">/03</p>
              <h2 className="font-raven text-2xl font-medium text-[#0D0C0B] uppercase mt-0.5">
                Lời Nhắn Về Tôn Trọng Văn Hóa
              </h2>
            </div>

            <blockquote className="border-l-3 border-[#9E2A1C] pl-5 py-2.5 space-y-2 bg-[#FAF7F0]/60 pr-3">
              <p className="font-editorial text-xl sm:text-2xl italic text-[#0D0C0B] leading-snug">
                &ldquo;Cổ phục là kết tinh tâm hồn và mỹ cảm của tiền nhân; thấu
                hiểu nguồn cội chính là nền tảng vững chắc nhất để sáng tạo mà không
                làm mất đi căn cước văn hóa.&rdquo;
              </p>
              <p className="text-xs text-[#6E675F] font-tabular tracking-wide">
                Thông điệp Giữ Nếp · Học hỏi từ lịch sử, sáng tạo có hiểu biết
              </p>
            </blockquote>
          </SectionEntrance>

          {/* 4. Hồ sơ đang thẩm định (Research Queue - Tái cấu trúc 3 lớp rõ ràng) */}
          <SectionEntrance showTopRule={false} className="space-y-4">
            <div className="border-b border-[#0D0C0B] pb-3 flex flex-col sm:flex-row sm:items-end justify-between gap-2">
              <div>
                <p className="font-tabular text-xs text-[#9E2A1C] font-semibold">/04</p>
                <h2 className="font-raven text-2xl font-medium text-[#0D0C0B] uppercase mt-0.5">
                  Hồ Sơ Đang Thẩm Định
                </h2>
              </div>
              <div className="flex items-center gap-1.5 text-[11px] font-tabular">
                {(['ALL', 'P0', 'P1'] as const).map((pri) => (
                  <button
                    key={pri}
                    type="button"
                    onClick={() => setSelectedQueuePriority(pri)}
                    className={`px-2 py-0.5 uppercase cursor-pointer border transition-colors ${
                      selectedQueuePriority === pri
                        ? 'bg-[#0D0C0B] text-[#FAF7F0] border-[#0D0C0B] font-semibold'
                        : 'border-[#141312]/20 text-[#6E675F] hover:text-[#0D0C0B]'
                    }`}
                  >
                    {pri === 'ALL' ? `Tất cả (${RESEARCH_QUEUE.length})` : pri}
                  </button>
                ))}
                <span className="text-[#6E675F] px-1" aria-hidden="true">|</span>
                <button
                  type="button"
                  onClick={handleToggleAllQueue}
                  className="px-1.5 py-0.5 text-[10px] uppercase text-[#6E675F] hover:text-[#0D0C0B] underline cursor-pointer"
                  title={areAllQueueExpanded ? 'Thu gọn tất cả hồ sơ' : 'Mở rộng tất cả hồ sơ'}
                >
                  {areAllQueueExpanded ? 'Thu gọn' : 'Mở hết'}
                </button>
              </div>
            </div>

            <p className="text-xs text-[#6E675F] leading-relaxed">
              Các chủ đề cần đối chiếu thêm do khác biệt về nguồn phục dựng, thuật ngữ hoặc cách phân loại. Trạng thái thẩm định không đồng nghĩa với kết luận đúng hoặc sai ({filteredQueue.length}/{RESEARCH_QUEUE.length} hồ sơ):
            </p>

            {/* P0 / P1 Priority Guidance Note */}
            <div className="flex flex-wrap items-center gap-x-4 gap-y-1 text-[11px] font-tabular text-[#6E675F] bg-[#FAF7F0] p-2 border border-[#141312]/10">
              <span className="flex items-center gap-1">
                <span className="inline-block w-2 h-2 rounded-full bg-[#9E2A1C]"></span>
                <strong>P0:</strong> Ưu tiên hàng đầu (phân loại cốt lõi &amp; quy chế)
              </span>
              <span className="flex items-center gap-1">
                <span className="inline-block w-2 h-2 rounded-full bg-[#1E3A5F]"></span>
                <strong>P1:</strong> Ưu tiên bổ trợ (thu thập thêm khảo chứng)
              </span>
            </div>

            {/* Empty state for filter */}
            {filteredQueue.length === 0 ? (
              <div className="p-6 border border-dashed border-[#141312]/20 bg-[#FAF7F0] text-center text-xs text-[#6E675F]">
                Không có hồ sơ nào thuộc mức ưu tiên đã chọn.
              </div>
            ) : (
              <div className="space-y-3">
                {filteredQueue.map((item, idx) => {
                  const isExpanded = expandedQueueTopics[item.topic] ?? false;
                  return (
                    <article
                      key={idx}
                      className="border border-[#141312]/15 bg-[#FAF7F0] p-3.5 text-xs space-y-2 transition-all hover:border-[#141312]/30"
                    >
                      {/* Lớp 1: Nhận diện nhanh (Topic + Priority Badge + Toggle Button) */}
                      <div className="flex items-start justify-between gap-2">
                        <button
                          type="button"
                          onClick={() => toggleQueueTopic(item.topic)}
                          aria-expanded={isExpanded}
                          className="text-left font-raven text-sm sm:text-base font-semibold text-[#0D0C0B] hover:text-[#9E2A1C] flex-1 cursor-pointer flex items-center gap-1.5 focus:outline-none focus:ring-1 focus:ring-[#9E2A1C]"
                        >
                          <span className="leading-snug">{item.topic}</span>
                          {isExpanded ? (
                            <ChevronUp className="w-3.5 h-3.5 text-[#6E675F] shrink-0" />
                          ) : (
                            <ChevronDown className="w-3.5 h-3.5 text-[#6E675F] shrink-0" />
                          )}
                        </button>
                        <span
                          className={`text-[10px] font-tabular font-bold px-1.5 py-0.5 border shrink-0 ${
                            item.priority === 'P0'
                              ? 'text-[#9E2A1C] border-[#9E2A1C]/30 bg-[#9E2A1C]/10'
                              : 'text-[#1E3A5F] border-[#1E3A5F]/30 bg-[#1E3A5F]/10'
                          }`}
                        >
                          {item.priority}
                        </span>
                      </div>

                      {/* Lớp 2: Tóm tắt quét nhanh (Vấn đề chính) */}
                      <p className="text-[#524B43] leading-relaxed">
                        <span className="font-semibold text-[#1A1816]">Vấn đề:</span>{' '}
                        {item.whyUnresolved}
                      </p>

                      {/* Lớp 3: Chi tiết khi mở rộng (Đầy đủ nội dung nghiên cứu gốc) */}
                      {isExpanded && (
                        <div className="pt-2.5 border-t border-[#141312]/10 space-y-2 text-xs text-[#3D3934] animate-drawer-slide">
                          <p>
                            <span className="font-semibold text-[#1A1816]">Quyết định xử lý hiện tại:</span>{' '}
                            <span className="italic text-[#0D0C0B]">{item.currentDecision}</span>
                          </p>
                          {item.whatToVerify && (
                            <p>
                              <span className="font-semibold text-[#1A1816]">Hạng mục cần đối chiếu:</span>{' '}
                              <span className="text-[#524B43]">{item.whatToVerify}</span>
                            </p>
                          )}
                          {item.preferredSource && (
                            <p>
                              <span className="font-semibold text-[#1A1816]">Nguồn dẫn ưu tiên:</span>{' '}
                              <span className="font-tabular text-[#6E675F]">{item.preferredSource}</span>
                            </p>
                          )}
                        </div>
                      )}
                    </article>
                  );
                })}
              </div>
            )}
          </SectionEntrance>

          {/* 5. Góp Ý & Đính Chính Tư Liệu (Form - Tinh chỉnh hoàn thiện) */}
          <SectionEntrance showTopRule={false} className="space-y-4">
            <div className="border-b border-[#0D0C0B] pb-3">
              <p className="font-tabular text-xs text-[#9E2A1C] font-semibold">/05</p>
              <h2 className="font-raven text-2xl font-medium text-[#0D0C0B] uppercase mt-0.5">
                Góp ý &amp; Đính chính tư liệu
              </h2>
            </div>

            {/* Giới thiệu ngắn & 3 loại đóng góp */}
            <div className="bg-[#FAF7F0] border border-[#141312]/15 p-3.5 space-y-2.5 text-xs text-[#4A453E]">
              <p className="leading-relaxed">
                Giúp chúng tôi hoàn thiện kho tư liệu Việt phục bằng cách đính chính dữ kiện, bổ sung nguồn tham khảo đáng tin cậy hoặc chỉ ra những vấn đề còn tranh luận. Mọi đóng góp đều được xem xét trước khi cập nhật dữ liệu.
              </p>

              <div className="border-t border-[#141312]/10 pt-2 space-y-1.5 text-[11.5px] text-[#3D3934]">
                <div className="flex items-start gap-1.5">
                  <Check className="w-3.5 h-3.5 text-[#9E2A1C] shrink-0 mt-0.5" />
                  <span>Đính chính dữ kiện về trang phục, cấu trúc may, niên đại hoặc bối cảnh.</span>
                </div>
                <div className="flex items-start gap-1.5">
                  <Check className="w-3.5 h-3.5 text-[#9E2A1C] shrink-0 mt-0.5" />
                  <span>Bổ sung nguồn từ bảo tàng, thư tịch, sách hoặc nghiên cứu chuyên ngành.</span>
                </div>
                <div className="flex items-start gap-1.5">
                  <Check className="w-3.5 h-3.5 text-[#9E2A1C] shrink-0 mt-0.5" />
                  <span>Báo cáo thuật ngữ, phân loại hoặc nhận định còn tranh luận.</span>
                </div>
              </div>
            </div>

            {/* Success Notification View */}
            {submissionReceipt ? (
              <div
                role="status"
                aria-live="polite"
                className="border border-[#2E5A44]/40 bg-[#FAF7F0] p-5 space-y-3"
              >
                <div className="flex items-start gap-3">
                  <CheckCircle2 className="w-5 h-5 text-[#2E5A44] shrink-0 mt-0.5" />
                  <div className="space-y-1">
                    <h3 className="font-raven text-lg font-medium text-[#2E5A44]">
                      Hệ Thống Đã Tiếp Nhận Hồ Sơ Đóng Góp
                    </h3>
                    <p className="text-xs text-[#3D3934] leading-relaxed">
                      {submissionReceipt.message}
                    </p>
                  </div>
                </div>

                <div className="border-t border-[#2E5A44]/20 pt-2.5 space-y-1 text-xs font-tabular">
                  <div className="flex items-center justify-between text-[#2E5A44]">
                    <span>MÃ TIẾP NHẬN:</span>
                    <strong className="tracking-wider text-sm">{submissionReceipt.id}</strong>
                  </div>
                  <div className="flex items-center justify-between text-[#6E675F] text-[11px]">
                    <span>THỜI GIAN GHI NHẬN:</span>
                    <span>{new Date(submissionReceipt.submittedAt).toLocaleString('vi-VN')}</span>
                  </div>
                </div>

                <p className="text-[11px] text-[#6E675F] italic border-t border-[#141312]/10 pt-2">
                  * Mọi đóng góp đều được xem xét và đối chiếu độc lập với hiện vật bảo tàng cùng thư tịch cổ trước khi cập nhật dữ liệu.
                </p>

                <div className="pt-2">
                  <button
                    type="button"
                    onClick={handleResetForm}
                    className="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-tabular uppercase border border-[#0D0C0B] text-[#0D0C0B] hover:bg-[#0D0C0B] hover:text-[#FAF7F0] transition-colors cursor-pointer"
                  >
                    <Send className="w-3.5 h-3.5" />
                    <span>Gửi góp ý khác</span>
                  </button>
                </div>
              </div>
            ) : (
              <form onSubmit={handleSubmitContribution} className="space-y-4" noValidate>
                {/* Server Error Banner (giữ nguyên form content khi gặp lỗi) */}
                {serverError && (
                  <div
                    role="alert"
                    className="border border-[#9E2A1C]/40 bg-[#9E2A1C]/10 p-3 text-xs text-[#9E2A1C] flex items-start gap-2"
                  >
                    <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" />
                    <span>{serverError}</span>
                  </div>
                )}

                {/* Field 1: Target (Bắt buộc) */}
                <div className="space-y-1">
                  <label
                    htmlFor="report-target"
                    className="block text-[11px] font-tabular tracking-wider uppercase text-[#0D0C0B] font-medium"
                  >
                    Mục trang phục / Nội dung cần góp ý <span className="text-[#9E2A1C]">*</span>
                  </label>
                  <input
                    id="report-target"
                    type="text"
                    list={datalistId}
                    value={target}
                    onChange={(e) => {
                      setTarget(e.target.value);
                      if (formErrors.target) {
                        setFormErrors((prev) => ({ ...prev, target: undefined }));
                      }
                    }}
                    placeholder="Tên trang phục, mã G008, phụ kiện A001 hoặc nội dung cần góp ý…"
                    className={`w-full bg-[#FAF7F0] border ${
                      formErrors.target
                        ? 'border-[#9E2A1C] focus:border-[#9E2A1C]'
                        : 'border-[#141312]/30 focus:border-[#9E2A1C]'
                    } px-3 py-2 text-xs sm:text-sm text-[#0D0C0B] placeholder:text-[#8C8479] focus:outline-none transition-colors`}
                    aria-required="true"
                    aria-invalid={Boolean(formErrors.target)}
                    aria-describedby={formErrors.target ? 'report-target-error' : undefined}
                    disabled={isSubmitting}
                  />
                  <datalist id={datalistId}>
                    {suggestions.map((sug, i) => (
                      <option key={i} value={sug} />
                    ))}
                  </datalist>
                  {formErrors.target && (
                    <p id="report-target-error" className="text-[11px] text-[#9E2A1C]">
                      {formErrors.target}
                    </p>
                  )}
                </div>

                {/* Field 2: Detail (Bắt buộc) */}
                <div className="space-y-1">
                  <div className="flex items-center justify-between">
                    <label
                      htmlFor="report-detail"
                      className="block text-[11px] font-tabular tracking-wider uppercase text-[#0D0C0B] font-medium"
                    >
                      Chi tiết đính chính &amp; dẫn chứng đối chiếu <span className="text-[#9E2A1C]">*</span>
                    </label>
                    <span className="text-[10px] font-tabular text-[#6E675F]">
                      {detail.length} / 5.000 ký tự
                    </span>
                  </div>
                  <textarea
                    id="report-detail"
                    rows={4}
                    value={detail}
                    maxLength={5000}
                    onChange={(e) => {
                      setDetail(e.target.value);
                      if (formErrors.detail) {
                        setFormErrors((prev) => ({ ...prev, detail: undefined }));
                      }
                    }}
                    placeholder="Mô tả thông tin cần xem xét, điểm chưa chính xác, lý do và căn cứ đối chiếu…"
                    className={`w-full bg-[#FAF7F0] border ${
                      formErrors.detail
                        ? 'border-[#9E2A1C] focus:border-[#9E2A1C]'
                        : 'border-[#141312]/30 focus:border-[#9E2A1C]'
                    } px-3 py-2 text-xs sm:text-sm text-[#0D0C0B] placeholder:text-[#8C8479] focus:outline-none transition-colors`}
                    aria-required="true"
                    aria-invalid={Boolean(formErrors.detail)}
                    aria-describedby={formErrors.detail ? 'report-detail-error' : 'report-detail-hint'}
                    disabled={isSubmitting}
                  />
                  {formErrors.detail ? (
                    <p id="report-detail-error" className="text-[11px] text-[#9E2A1C]">
                      {formErrors.detail}
                    </p>
                  ) : (
                    <p id="report-detail-hint" className="text-[10.5px] text-[#6E675F]">
                      Nếu có thể, hãy nêu nội dung hiện tại, nội dung đề xuất sửa và nguồn đối chiếu.
                    </p>
                  )}
                </div>

                {/* Field 3: Source Reference (Không bắt buộc) */}
                <div className="space-y-1">
                  <label
                    htmlFor="report-source-ref"
                    className="block text-[11px] font-tabular tracking-wider uppercase text-[#0D0C0B] font-medium"
                  >
                    Nguồn tham khảo / Đường dẫn đối chiếu (không bắt buộc)
                  </label>
                  <input
                    id="report-source-ref"
                    type="text"
                    value={sourceReference}
                    maxLength={1000}
                    onChange={(e) => {
                      setSourceReference(e.target.value);
                      if (formErrors.sourceReference) {
                        setFormErrors((prev) => ({ ...prev, sourceReference: undefined }));
                      }
                    }}
                    placeholder="URL bài nghiên cứu, tên sách, tác giả, nhà xuất bản hoặc số trang…"
                    className={`w-full bg-[#FAF7F0] border ${
                      formErrors.sourceReference
                        ? 'border-[#9E2A1C] focus:border-[#9E2A1C]'
                        : 'border-[#141312]/30 focus:border-[#9E2A1C]'
                    } px-3 py-2 text-xs sm:text-sm text-[#0D0C0B] placeholder:text-[#8C8479] focus:outline-none transition-colors`}
                    aria-invalid={Boolean(formErrors.sourceReference)}
                    aria-describedby={formErrors.sourceReference ? 'report-source-error' : 'report-source-hint'}
                    disabled={isSubmitting}
                  />
                  {formErrors.sourceReference ? (
                    <p id="report-source-error" className="text-[11px] text-[#9E2A1C]">
                      {formErrors.sourceReference}
                    </p>
                  ) : (
                    <p id="report-source-hint" className="text-[10.5px] text-[#6E675F]">
                      Bạn có thể ghi đường dẫn trực tuyến hoặc tên sách, số trang và tư liệu in nếu không có liên kết web.
                    </p>
                  )}
                </div>

                {/* Field 4: Contact Email (Không bắt buộc, CHÍNH XÁC placeholder: nguyenvana@gmail.com) */}
                <div className="space-y-1">
                  <label
                    htmlFor="report-email"
                    className="block text-[11px] font-tabular tracking-wider uppercase text-[#0D0C0B] font-medium"
                  >
                    Email liên hệ (không bắt buộc)
                  </label>
                  <input
                    id="report-email"
                    type="email"
                    value={contactEmail}
                    maxLength={200}
                    onChange={(e) => {
                      setContactEmail(e.target.value);
                      if (formErrors.contactEmail) {
                        setFormErrors((prev) => ({ ...prev, contactEmail: undefined }));
                      }
                    }}
                    placeholder="nguyenvana@gmail.com"
                    className={`w-full bg-[#FAF7F0] border ${
                      formErrors.contactEmail
                        ? 'border-[#9E2A1C] focus:border-[#9E2A1C]'
                        : 'border-[#141312]/30 focus:border-[#9E2A1C]'
                    } px-3 py-2 text-xs sm:text-sm text-[#0D0C0B] placeholder:text-[#8C8479] focus:outline-none transition-colors`}
                    aria-invalid={Boolean(formErrors.contactEmail)}
                    aria-describedby={formErrors.contactEmail ? 'report-email-error' : 'report-email-hint'}
                    disabled={isSubmitting}
                  />
                  {formErrors.contactEmail ? (
                    <p id="report-email-error" className="text-[11px] text-[#9E2A1C]">
                      {formErrors.contactEmail}
                    </p>
                  ) : (
                    <p id="report-email-hint" className="text-[10.5px] text-[#6E675F]">
                      Chỉ sử dụng khi nhóm biên tập cần trao đổi thêm về nguồn tư liệu. Email không hiển thị công khai.
                    </p>
                  )}
                </div>

                {/* Submit Action */}
                <div className="pt-2 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                  <MagneticButton
                    type="submit"
                    variant="primary"
                    disabled={isSubmitting}
                    className="w-full sm:w-auto px-6 py-3 text-xs font-medium tracking-[0.14em] uppercase disabled:opacity-60 cursor-pointer flex items-center justify-center gap-2"
                  >
                    {isSubmitting ? (
                      <>
                        <Loader2 className="w-4 h-4 animate-spin" />
                        <span>Đang gửi đóng góp...</span>
                      </>
                    ) : (
                      <>
                        <Send className="w-3.5 h-3.5" />
                        <span>Gửi thông tin đóng góp</span>
                      </>
                    )}
                  </MagneticButton>

                  <div className="flex items-center gap-1.5 text-[11px] text-[#6E675F]">
                    <ShieldCheck className="w-3.5 h-3.5 text-[#2E5A44]" />
                    <span>Lưu trữ bảo mật &amp; đối chiếu độc lập</span>
                  </div>
                </div>
              </form>
            )}
          </SectionEntrance>
        </div>
      </div>

      {/* 6. Lưu ý dữ liệu & Audit (PDF Audit) - Collapsible Accordion & Responsive */}
      <SectionEntrance showTopRule={true} className="space-y-4 pt-4">
        <div className="border-b border-[#0D0C0B] pb-3 flex flex-col sm:flex-row sm:items-end justify-between gap-3">
          <div>
            <p className="font-tabular text-xs text-[#9E2A1C] font-semibold">/06</p>
            <h2 className="font-raven text-2xl sm:text-3xl font-medium text-[#0D0C0B] uppercase mt-0.5">
              Lưu Ý Dữ Liệu &amp; Audit ({PDF_AUDIT_ITEMS.length} Mục Hiệu Đính)
            </h2>
          </div>

          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={() => setIsAuditTableOpen((prev) => !prev)}
              className="inline-flex items-center gap-2 px-3 py-1.5 text-xs font-tabular uppercase border border-[#0D0C0B] bg-[#FAF7F0] text-[#0D0C0B] hover:bg-[#0D0C0B] hover:text-[#FAF7F0] transition-colors cursor-pointer"
              aria-expanded={isAuditTableOpen}
            >
              <span>{isAuditTableOpen ? 'Thu gọn bảng audit' : `Xem chi tiết (${PDF_AUDIT_ITEMS.length} mục)`}</span>
              {isAuditTableOpen ? (
                <ChevronUp className="w-3.5 h-3.5" />
              ) : (
                <ChevronDown className="w-3.5 h-3.5" />
              )}
            </button>
          </div>
        </div>

        <p className="text-xs text-[#6E675F] max-w-3xl leading-relaxed">
          Bảng đối chiếu minh bạch các nhận định từ bản thảo PDF cũ được hiệu
          đính theo tư liệu bảo tàng. Các hiệu đính này chỉ dùng để đảm bảo tính
          chính xác của dữ liệu, không tự ý suy diễn thêm tuyên bố lịch sử mới.
        </p>

        {/* Collapsible Content */}
        {isAuditTableOpen && (
          <div className="space-y-4 pt-2">
            {/* Priority filter for audit */}
            <div className="flex items-center justify-between text-xs">
              <span className="font-tabular text-[#6E675F]">
                LỌC MỨC ĐỘ:
              </span>
              <div className="flex items-center gap-1 font-tabular">
                {(['ALL', 'HIGH'] as const).map((pri) => (
                  <button
                    key={pri}
                    type="button"
                    onClick={() => setAuditPriorityFilter(pri)}
                    className={`px-2 py-0.5 uppercase cursor-pointer border text-[11px] transition-colors ${
                      auditPriorityFilter === pri
                        ? 'bg-[#0D0C0B] text-[#FAF7F0] border-[#0D0C0B] font-semibold'
                        : 'border-[#141312]/20 text-[#6E675F] hover:text-[#0D0C0B]'
                    }`}
                  >
                    {pri === 'ALL' ? `Tất cả (${PDF_AUDIT_ITEMS.length})` : 'Chỉ mức High'}
                  </button>
                ))}
              </div>
            </div>

            {/* Desktop Table View (>= 768px) */}
            <div className="hidden md:block border border-[#141312]/15 bg-[#FAF7F0] overflow-x-auto">
              <table className="w-full text-left text-xs divide-y divide-[#141312]/15">
                <thead className="bg-[#EAE6DD]/80 font-tabular uppercase text-[#6E675F] text-[11px]">
                  <tr>
                    <th className="py-3 px-4">Nhận định cũ</th>
                    <th className="py-3 px-4">Đánh giá</th>
                    <th className="py-3 px-4">Vấn đề cốt lõi</th>
                    <th className="py-3 px-4">Hiệu đính / Hành động</th>
                    <th className="py-3 px-4">Độ ưu tiên</th>
                    <th className="py-3 px-4">Nguồn dẫn</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-[#141312]/10 text-[#3D3934]">
                  {filteredAuditItems.map((item, idx) => (
                    <tr key={idx} className="hover:bg-[#EAE6DD]/40 transition-colors">
                      <td className="py-3 px-4 font-medium text-[#0D0C0B] max-w-[200px]">
                        &ldquo;{item.statement}&rdquo;
                      </td>
                      <td className="py-3 px-4 font-tabular text-[#9E2A1C] font-semibold whitespace-nowrap">
                        {item.assessment}
                      </td>
                      <td className="py-3 px-4 text-[#6E675F] max-w-[180px]">
                        {item.problem}
                      </td>
                      <td className="py-3 px-4 text-[#0D0C0B] font-medium max-w-[240px]">
                        {item.correction}
                      </td>
                      <td className="py-3 px-4 font-tabular">
                        <span
                          className={`px-1.5 py-0.5 text-[10px] font-semibold border ${
                            item.priority === 'HIGH'
                              ? 'border-[#9E2A1C]/30 bg-[#9E2A1C]/10 text-[#9E2A1C]'
                              : 'border-[#1E3A5F]/30 bg-[#1E3A5F]/10 text-[#1E3A5F]'
                          }`}
                        >
                          {item.priority}
                        </span>
                      </td>
                      <td className="py-3 px-4 font-tabular text-[#6E675F] whitespace-nowrap">
                        {item.source}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            {/* Mobile Card View (< 768px) - Eliminates wide table overflow */}
            <div className="md:hidden space-y-3">
              {filteredAuditItems.map((item, idx) => (
                <div
                  key={idx}
                  className="border border-[#141312]/15 bg-[#FAF7F0] p-3.5 text-xs space-y-2"
                >
                  <div className="flex items-start justify-between gap-2 border-b border-[#141312]/10 pb-2">
                    <span className="font-tabular font-bold text-[#9E2A1C]">
                      {item.assessment}
                    </span>
                    <div className="flex items-center gap-1.5 font-tabular">
                      <span
                        className={`px-1.5 py-0.5 text-[10px] font-semibold border ${
                          item.priority === 'HIGH'
                            ? 'border-[#9E2A1C]/30 bg-[#9E2A1C]/10 text-[#9E2A1C]'
                            : 'border-[#1E3A5F]/30 bg-[#1E3A5F]/10 text-[#1E3A5F]'
                        }`}
                      >
                        {item.priority}
                      </span>
                      <span className="text-[11px] text-[#6E675F]">{item.source}</span>
                    </div>
                  </div>

                  <p className="font-medium text-[#0D0C0B]">
                    <span className="text-[#6E675F] font-normal">Nhận định cũ:</span>{' '}
                    &ldquo;{item.statement}&rdquo;
                  </p>

                  <p className="text-[#6E675F]">
                    <strong className="text-[#3D3934]">Vấn đề:</strong> {item.problem}
                  </p>

                  <p className="text-[#0D0C0B] bg-[#EAE6DD]/40 p-2 rounded-sm border-l-2 border-[#9E2A1C]">
                    <strong className="text-[#9E2A1C]">Hiệu đính:</strong> {item.correction}
                  </p>
                </div>
              ))}
            </div>
          </div>
        )}
      </SectionEntrance>
    </div>
  );
};
