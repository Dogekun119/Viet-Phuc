import React, { useState } from 'react';
import { SavedUserOutfit } from '../../domain/types';
import {
  MagneticButton,
  SectionEntrance,
  SplitLineReveal,
} from '../motion/MotionPrimitives';

interface CompareScreenProps {
  savedOutfits: SavedUserOutfit[];
  onRemoveOutfit: (id: string) => void;
  onGoToBuilder: () => void;
}

export const CompareScreen: React.FC<CompareScreenProps> = ({
  savedOutfits,
  onRemoveOutfit,
  onGoToBuilder,
}) => {
  const [selectedOutfitIds, setSelectedOutfitIds] = useState<string[]>(() => {
    return savedOutfits.slice(0, 2).map((o) => o.id);
  });

  const toggleSelectForCompare = (id: string) => {
    if (selectedOutfitIds.includes(id)) {
      setSelectedOutfitIds((prev) => prev.filter((item) => item !== id));
    } else {
      if (selectedOutfitIds.length >= 2) {
        // Replace second or add
        setSelectedOutfitIds([selectedOutfitIds[0], id]);
      } else {
        setSelectedOutfitIds((prev) => [...prev, id]);
      }
    }
  };

  const comparedOutfits = savedOutfits.filter((o) =>
    selectedOutfitIds.includes(o.id)
  );

  return (
    <div className="space-y-12 pb-20">
      {/* Header */}
      <header className="pt-8 sm:pt-12 border-b border-[#141312]/15 pb-8 flex flex-col md:flex-row md:items-end justify-between gap-6">
        <div className="space-y-3">
          <div className="flex items-center gap-3 text-xs text-[#6E675F] font-tabular tracking-[0.16em] uppercase">
            <span>COMPARISON &amp; ARCHIVE</span>
            <span aria-hidden="true">·</span>
            <span>TỐI ĐA 2 BỘ PHỐI</span>
          </div>
          <SplitLineReveal
            as="h1"
            lines={['So Bộ & Cất Giữ']}
            className="font-raven text-4xl sm:text-6xl font-semibold text-[#0D0C0B] uppercase tracking-wider leading-none"
          />
        </div>
        <div className="flex items-center gap-3">
          <MagneticButton
            type="button"
            variant="outline"
            onClick={onGoToBuilder}
            className="px-5 py-3 text-xs uppercase tracking-wider"
          >
            + Tạo Bộ Phối Mới
          </MagneticButton>
        </div>
      </header>

      {/* Comparison Area (Side-by-side) */}
      <SectionEntrance showTopRule={false} className="space-y-6">
        <div className="border-b border-[#0D0C0B] pb-3 flex items-baseline justify-between">
          <h2 className="font-raven text-2xl font-medium text-[#0D0C0B] uppercase">
            Bảng So Sánh Đối Chiếu ({comparedOutfits.length}/2)
          </h2>
          <span className="font-tabular text-xs text-[#6E675F]">
            SIDE-BY-SIDE MATRIX
          </span>
        </div>

        {comparedOutfits.length === 0 ? (
          <div className="p-12 text-center border border-dashed border-[#141312]/20 bg-[#F6F4EF]/40 space-y-3">
            <p className="font-raven text-xl text-[#0D0C0B]">
              Chưa có bộ phối nào được chọn để so sánh.
            </p>
            <p className="text-xs text-[#6E675F]">
              Hãy lưu các bộ phối từ Outfit Builder hoặc tick chọn các bộ đã lưu
              bên dưới để đặt cạnh nhau so sánh.
            </p>
            <MagneticButton
              type="button"
              variant="primary"
              onClick={onGoToBuilder}
              className="mt-2 px-6 py-3 text-xs uppercase tracking-wider"
            >
              Đến Outfit Builder &rarr;
            </MagneticButton>
          </div>
        ) : comparedOutfits.length === 1 ? (
          <div className="space-y-6">
            <div className="p-4 bg-[#C89B3C]/10 border border-[#C89B3C]/30 text-xs text-[#8C6219]">
              Bạn đã chọn 1 bộ. Hãy tick chọn thêm 1 bộ nữa trong danh sách Cất
              Giữ bên dưới để hiển thị so sánh đối chiếu 2 cột.
            </div>
            <div className="max-w-md mx-auto">
              <OutfitCompareColumn
                outfit={comparedOutfits[0]}
                onDeselect={() => toggleSelectForCompare(comparedOutfits[0].id)}
              />
            </div>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 items-start">
            <OutfitCompareColumn
              outfit={comparedOutfits[0]}
              onDeselect={() => toggleSelectForCompare(comparedOutfits[0].id)}
            />
            <OutfitCompareColumn
              outfit={comparedOutfits[1]}
              onDeselect={() => toggleSelectForCompare(comparedOutfits[1].id)}
            />
          </div>
        )}
      </SectionEntrance>

      {/* Saved Outfits Drawer / List */}
      <SectionEntrance showTopRule={false} className="space-y-6 pt-6">
        <div className="border-b border-[#0D0C0B] pb-3 flex items-baseline justify-between">
          <h2 className="font-raven text-2xl font-medium text-[#0D0C0B] uppercase">
            Kho Cất Giữ Bộ Phối ({savedOutfits.length})
          </h2>
          <span className="font-tabular text-xs text-[#6E675F]">
            SAVED LOOKS
          </span>
        </div>

        {savedOutfits.length === 0 ? (
          <div className="p-8 text-center border border-[#141312]/15 bg-[#F6F4EF]/40 text-xs text-[#6E675F]">
            Chưa có bộ phối nào được lưu vào máy. Hãy thử phối đồ tại màn hình
            Outfit Builder rồi nhấn &ldquo;Lưu Bộ Phối&rdquo;.
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {savedOutfits.map((outfit) => {
              const isSelected = selectedOutfitIds.includes(outfit.id);
              return (
                <div
                  key={outfit.id}
                  className={`p-5 border transition-all flex flex-col justify-between space-y-4 ${
                    isSelected
                      ? 'border-[#0D0C0B] bg-[#F6F4EF] ring-1 ring-[#0D0C0B]'
                      : 'border-[#141312]/15 bg-[#F6F4EF]/60 hover:bg-[#F6F4EF]'
                  }`}
                >
                  <div className="space-y-3">
                    <div className="flex items-center justify-between text-xs font-tabular">
                      <span className="text-[#6E675F]">{outfit.createdAt}</span>
                      <span className="uppercase font-semibold text-[10px] px-2 py-0.5 border border-[#141312]/20">
                        {outfit.evaluation.label}
                      </span>
                    </div>

                    <h3 className="font-raven text-lg font-medium text-[#0D0C0B]">
                      {outfit.name}
                    </h3>

                    <div className="text-xs text-[#3D3934] space-y-1">
                      <p className="font-medium">
                        Gồm {outfit.items.length} món:
                      </p>
                      <ul className="list-disc list-inside space-y-0.5 text-[#6E675F] text-[11px]">
                        {outfit.items.map((item, idx) => (
                          <li key={idx} className="truncate">
                            {item.name} ({item.category})
                          </li>
                        ))}
                      </ul>
                    </div>
                  </div>

                  <div className="pt-3 border-t border-[#141312]/10 flex items-center justify-between gap-2 text-xs">
                    <button
                      type="button"
                      onClick={() => toggleSelectForCompare(outfit.id)}
                      className={`px-3 py-1.5 uppercase font-tabular tracking-wider cursor-pointer border ${
                        isSelected
                          ? 'bg-[#0D0C0B] text-[#F7F4EE] border-[#0D0C0B]'
                          : 'border-[#141312]/30 text-[#0D0C0B] hover:border-[#0D0C0B]'
                      }`}
                    >
                      {isSelected ? '✓ Đang so sánh' : '+ Chọn so sánh'}
                    </button>
                    <button
                      type="button"
                      onClick={() => onRemoveOutfit(outfit.id)}
                      className="text-[#9E2A1C] hover:underline cursor-pointer text-[11px]"
                    >
                      Xóa bộ
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </SectionEntrance>
    </div>
  );
};

const OutfitCompareColumn: React.FC<{
  outfit: SavedUserOutfit;
  onDeselect: () => void;
}> = ({ outfit, onDeselect }) => {
  return (
    <div className="p-6 border border-[#0D0C0B] bg-[#F6F4EF] space-y-6">
      <div className="flex items-start justify-between gap-3 border-b border-[#141312]/15 pb-4">
        <div>
          <span className="font-tabular text-xs text-[#6E675F] block">
            {outfit.createdAt}
          </span>
          <h3 className="font-raven text-2xl font-semibold text-[#0D0C0B] uppercase">
            {outfit.name}
          </h3>
        </div>
        <button
          type="button"
          onClick={onDeselect}
          className="text-xs text-[#9E2A1C] font-tabular uppercase hover:underline cursor-pointer"
        >
          [Bỏ chọn]
        </button>
      </div>

      {/* Evaluation Badge */}
      <div className="space-y-2 p-3 bg-[#EAE6DD]/50 border border-[#141312]/15">
        <span className="font-tabular text-xs uppercase font-semibold text-[#9E2A1C]">
          ĐÁNH GIÁ: {outfit.evaluation.label}
        </span>
        <p className="text-xs text-[#3D3934] leading-relaxed">
          {outfit.evaluation.summary}
        </p>
      </div>

      {/* Layer-by-layer breakdown */}
      <div className="space-y-3">
        <p className="text-xs font-tabular uppercase tracking-wider text-[#6E675F]">
          Cấu trúc các lớp ({outfit.items.length}):
        </p>
        <div className="divide-y divide-[#141312]/15 border border-[#141312]/15 bg-white/40">
          {outfit.items.map((item, idx) => (
            <div
              key={idx}
              className="p-3 text-xs flex items-center justify-between gap-2"
            >
              <div>
                <span className="font-tabular text-[10px] text-[#9E2A1C] block">
                  LỚP {idx + 1} · {item.category}
                </span>
                <span className="font-medium text-[#0D0C0B]">{item.name}</span>
              </div>
              <span className="font-tabular text-[10px] text-[#6E675F]">
                {item.evidenceLevel}
              </span>
            </div>
          ))}
        </div>
      </div>

      {/* Warnings & Unmet conditions */}
      {outfit.evaluation.warnings.length > 0 && (
        <div className="p-3 bg-[#9E2A1C]/5 border-l-2 border-[#9E2A1C] space-y-1 text-xs">
          <p className="font-semibold text-[#9E2A1C]">Cảnh báo:</p>
          <ul className="list-disc list-inside text-[#3D3934]">
            {outfit.evaluation.warnings.map((w, idx) => (
              <li key={idx}>{w}</li>
            ))}
          </ul>
        </div>
      )}

      {/* Source IDs */}
      {outfit.evaluation.sourceIds.length > 0 && (
        <div className="text-xs font-tabular text-[#6E675F] space-x-1 pt-2 border-t border-[#141312]/10">
          <span>Nguồn dẫn:</span>
          {outfit.evaluation.sourceIds.map((s) => (
            <span
              key={s}
              className="px-1.5 py-0.5 bg-[#EAE6DD] text-[#9E2A1C] font-semibold"
            >
              {s}
            </span>
          ))}
        </div>
      )}
    </div>
  );
};
