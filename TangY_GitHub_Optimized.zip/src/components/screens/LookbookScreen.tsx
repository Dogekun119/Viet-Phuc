import React, { useState } from 'react';
import { SavedUserOutfit, ImageAsset, EditorialType } from '../../domain/types';
import { IMAGE_ASSETS } from '../../domain/dataAdapter';
import {
  MagneticButton,
  SectionEntrance,
  SplitLineReveal,
} from '../motion/MotionPrimitives';
import {
  X,
  Maximize2,
  Sparkles,
  Camera,
  Archive,
  Lock,
  ExternalLink,
  Info,
  CheckCircle2,
} from 'lucide-react';

interface LookbookScreenProps {
  savedOutfits: SavedUserOutfit[];
  onGoToBuilder: () => void;
}

export const LookbookScreen: React.FC<LookbookScreenProps> = ({
  savedOutfits,
  onGoToBuilder,
}) => {
  // Derive all lookbook assets from the canonical assets registry
  const lookbookAssets = IMAGE_ASSETS.filter((a) => a.kind === 'lookbook');

  // Filter state for editorial registry
  const [activeFilter, setActiveFilter] = useState<'ALL' | EditorialType>('ALL');
  const [selectedAsset, setSelectedAsset] = useState<ImageAsset | null>(null);

  // Counts by editorial classification
  const studioEditorialCount = lookbookAssets.filter(
    (a) => a.editorialType === 'STUDIO_EDITORIAL'
  ).length;
  const aiConceptCount = lookbookAssets.filter(
    (a) => a.editorialType === 'AI_CONCEPT'
  ).length;
  const artifactCount = lookbookAssets.filter(
    (a) => a.editorialType === 'HISTORICAL_ARTIFACT'
  ).length;

  const filteredAssets =
    activeFilter === 'ALL'
      ? lookbookAssets
      : lookbookAssets.filter((a) => a.editorialType === activeFilter);

  // Helper for badge styling based on Phase 3 classification
  const getEditorialTypeBadge = (type?: EditorialType) => {
    switch (type) {
      case 'HISTORICAL_ARTIFACT':
        return {
          label: 'TƯ LIỆU HIỆN VẬT',
          badgeClass:
            'bg-[#2E5A44]/10 text-[#2E5A44] border-[#2E5A44]/30 font-semibold',
          subLabel: 'Ảnh chụp hiện vật bảo tàng thực tế',
          icon: <Archive className="w-3 h-3 text-[#2E5A44]" />,
        };
      case 'AI_CONCEPT':
        return {
          label: 'CONCEPT ẢNH AI',
          badgeClass:
            'bg-[#A63D2F]/10 text-[#A63D2F] border-[#A63D2F]/30 font-semibold',
          subLabel: 'Tạo sinh AI · Trực quan hóa phối phục',
          icon: <Sparkles className="w-3 h-3 text-[#A63D2F]" />,
        };
      case 'STUDIO_EDITORIAL':
      default:
        return {
          label: 'STUDIO EDITORIAL',
          badgeClass:
            'bg-[#1E3A5F]/10 text-[#1E3A5F] border-[#1E3A5F]/30 font-semibold',
          subLabel: 'Bộ ảnh sáng tạo / tư liệu studio',
          icon: <Camera className="w-3 h-3 text-[#1E3A5F]" />,
        };
    }
  };

  return (
    <div className="space-y-16 pb-24">
      {/* Header */}
      <header className="pt-8 sm:pt-12 border-b border-[#141312]/15 pb-8 space-y-4">
        <div className="flex items-center gap-3 text-xs text-[#6E675F] font-tabular tracking-[0.16em] uppercase">
          <span>EDITORIAL ARCHIVE</span>
          <span aria-hidden="true">·</span>
          <span>LOOKBOOK &amp; VISUAL REGISTRY</span>
        </div>
        <SplitLineReveal
          as="h1"
          lines={['Tàng Y Lookbook']}
          className="font-raven text-5xl sm:text-7xl font-semibold text-[#0D0C0B] uppercase leading-none"
        />
        <div className="max-w-3xl space-y-2 pt-1 text-xs text-[#6E675F] leading-relaxed">
          <p>
            Không gian lưu trữ hình ảnh biên tập, tư liệu hiện vật và các bộ phối phục
            trang truyền thống. Mọi hình ảnh hiển thị đều được ánh xạ trực tiếp từ{' '}
            <code className="font-tabular bg-[#EAE6DD] px-1 py-0.5 text-[#0D0C0B]">
              src/data/assets.json
            </code>{' '}
            và được phân tầng minh bạch theo nguồn gốc.
          </p>
          <div className="flex flex-wrap items-center gap-4 pt-2 text-[11px] text-[#3D3934]">
            <span className="inline-flex items-center gap-1.5">
              <span className="w-2 h-2 rounded-full bg-[#1E3A5F]" />
              <strong>Studio Editorial:</strong> Ảnh bộ sưu tập thời trang cổ phong
            </span>
            <span className="inline-flex items-center gap-1.5">
              <span className="w-2 h-2 rounded-full bg-[#A63D2F]" />
              <strong>Concept Ảnh AI:</strong> Mô phỏng trực quan xếp lớp (không xem là hiện vật bảo tàng)
            </span>
            <span className="inline-flex items-center gap-1.5">
              <span className="w-2 h-2 rounded-full bg-[#2E5A44]" />
              <strong>Tư liệu Hiện vật:</strong> Ảnh chụp bảo tàng khảo chứng thực tế
            </span>
          </div>
        </div>
      </header>

      {/* SECTION 1: LOOKBOOK EDITORIAL REGISTRY */}
      <SectionEntrance showTopRule={false} className="space-y-8">
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-4 border-b border-[#0D0C0B] pb-4">
          <div>
            <h2 className="font-raven text-2xl sm:text-3xl font-medium text-[#0D0C0B] uppercase">
              Hình Ảnh Biên Tập Đã Map ({lookbookAssets.length})
            </h2>
            <p className="text-xs text-[#6E675F] mt-1">
              Phân loại kiểm định nguồn gốc tư liệu hình ảnh và quy chuẩn phom dáng
            </p>
          </div>

          {/* Filter Tabs */}
          <div className="flex flex-wrap items-center gap-1.5 p-1 bg-[#EAE6DD]/70 border border-[#141312]/15 text-xs">
            <button
              type="button"
              onClick={() => setActiveFilter('ALL')}
              className={`px-3 py-1.5 transition-colors font-tabular tracking-wider uppercase text-[11px] ${
                activeFilter === 'ALL'
                  ? 'bg-[#0D0C0B] text-[#F6F4EF] font-medium'
                  : 'text-[#6E675F] hover:text-[#0D0C0B]'
              }`}
            >
              Tất cả ({lookbookAssets.length})
            </button>
            <button
              type="button"
              onClick={() => setActiveFilter('STUDIO_EDITORIAL')}
              className={`px-3 py-1.5 transition-colors font-tabular tracking-wider uppercase text-[11px] ${
                activeFilter === 'STUDIO_EDITORIAL'
                  ? 'bg-[#1E3A5F] text-[#F6F4EF] font-medium'
                  : 'text-[#6E675F] hover:text-[#0D0C0B]'
              }`}
            >
              Studio Editorial ({studioEditorialCount})
            </button>
            <button
              type="button"
              onClick={() => setActiveFilter('AI_CONCEPT')}
              className={`px-3 py-1.5 transition-colors font-tabular tracking-wider uppercase text-[11px] ${
                activeFilter === 'AI_CONCEPT'
                  ? 'bg-[#A63D2F] text-[#F6F4EF] font-medium'
                  : 'text-[#6E675F] hover:text-[#0D0C0B]'
              }`}
            >
              Concept AI ({aiConceptCount})
            </button>
            <button
              type="button"
              onClick={() => setActiveFilter('HISTORICAL_ARTIFACT')}
              className={`px-3 py-1.5 transition-colors font-tabular tracking-wider uppercase text-[11px] ${
                activeFilter === 'HISTORICAL_ARTIFACT'
                  ? 'bg-[#2E5A44] text-[#F6F4EF] font-medium'
                  : 'text-[#6E675F] hover:text-[#0D0C0B]'
              }`}
            >
              Tư Liệu Hiện Vật ({artifactCount})
            </button>
          </div>
        </div>

        {/* Gallery Grid */}
        {filteredAssets.length === 0 ? (
          <div className="p-12 text-center border border-dashed border-[#141312]/20 bg-[#F6F4EF]/40 space-y-3">
            <p className="font-raven text-xl text-[#0D0C0B]">
              Không có hình ảnh nào trong phân nhóm này.
            </p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {filteredAssets.map((asset) => {
              const badge = getEditorialTypeBadge(asset.editorialType);
              const isFullBody =
                asset.framing === 'FULL_BODY' || (!asset.framing && asset.aspectRatio === '3:4');
              const isSilhouette = asset.framing === 'SILHOUETTE' || asset.aspectRatio === '16:9';

              return (
                <article
                  key={asset.id}
                  className="group border border-[#141312]/15 bg-[#F6F4EF] p-4 flex flex-col justify-between transition-shadow hover:shadow-md"
                >
                  <div className="space-y-4">
                    {/* Visual Stage with adaptive framing preserving full garment */}
                    <div
                      className={`relative overflow-hidden bg-[#EAE6DD] border border-[#141312]/10 cursor-pointer ${
                        isFullBody
                          ? 'aspect-[3/4]'
                          : isSilhouette
                          ? 'aspect-[16/10]'
                          : 'aspect-[4/3]'
                      }`}
                      onClick={() => setSelectedAsset(asset)}
                    >
                      <img
                        src={asset.src}
                        alt={asset.alt}
                        loading="lazy"
                        className={`w-full h-full transition-transform duration-500 ease-out group-hover:scale-[1.02] ${
                          isFullBody
                            ? 'object-contain object-center sm:object-cover sm:object-top'
                            : 'object-cover object-center'
                        }`}
                      />
                      {/* Zoom hint overlay */}
                      <button
                        type="button"
                        onClick={(e) => {
                          e.stopPropagation();
                          setSelectedAsset(asset);
                        }}
                        className="absolute bottom-2 right-2 p-2 bg-[#0D0C0B]/70 text-[#F6F4EF] backdrop-blur-xs opacity-0 group-hover:opacity-100 transition-opacity text-xs flex items-center gap-1"
                        aria-label="Phóng to hình ảnh"
                      >
                        <Maximize2 className="w-3.5 h-3.5" />
                        <span className="text-[10px] font-tabular uppercase tracking-wider">
                          Xem chi tiết
                        </span>
                      </button>

                      {/* Top Badges */}
                      <div className="absolute top-2 left-2 flex flex-col gap-1 pointer-events-none">
                        <span
                          className={`inline-flex items-center gap-1 px-2 py-0.5 text-[9px] uppercase tracking-wider border backdrop-blur-md ${badge.badgeClass}`}
                        >
                          {badge.icon}
                          {badge.label}
                        </span>
                      </div>
                    </div>

                    {/* Metadata Header */}
                    <div className="space-y-2">
                      <div className="flex items-center justify-between text-[11px] font-tabular">
                        <span className="text-[#9E2A1C] font-semibold">
                          [{asset.id}]
                        </span>
                        <span className="text-[#6E675F] text-[10px]">
                          {asset.dimensions || 'High-Res'} · {asset.aspectRatio || '3:4'}
                        </span>
                      </div>

                      <h3 className="font-raven text-lg text-[#0D0C0B] font-medium leading-snug">
                        {asset.garmentName || asset.alt}
                      </h3>

                      {asset.provenanceNote && (
                        <p className="text-xs text-[#4A453F] leading-relaxed line-clamp-3">
                          {asset.provenanceNote}
                        </p>
                      )}
                    </div>
                  </div>

                  {/* Metadata Footer */}
                  <div className="pt-4 mt-4 border-t border-[#141312]/10 space-y-1.5 text-[11px] text-[#6E675F]">
                    {asset.credit && (
                      <p className="truncate">
                        <strong className="text-[#3D3934]">Nguồn:</strong> {asset.credit}
                      </p>
                    )}
                    {asset.license && (
                      <p className="truncate">
                        <strong className="text-[#3D3934]">Bản quyền:</strong> {asset.license}
                      </p>
                    )}
                  </div>
                </article>
              );
            })}
          </div>
        )}
      </SectionEntrance>

      {/* SECTION 2: PRIVATE SAVED USER OUTFITS (CÁ NHÂN RIÊNG TƯ) */}
      <SectionEntrance showTopRule={false} className="space-y-6 pt-6">
        <div className="border-b border-[#0D0C0B] pb-3 flex flex-col sm:flex-row sm:items-baseline justify-between gap-2">
          <div>
            <div className="flex items-center gap-2">
              <Lock className="w-4 h-4 text-[#9E2A1C]" />
              <h2 className="font-raven text-2xl font-medium text-[#0D0C0B] uppercase">
                Bộ Phối Riêng Tư Của Bạn ({savedOutfits.length})
              </h2>
            </div>
            <p className="text-xs text-[#6E675F] mt-0.5">
              Lưu trữ cục bộ trên trình duyệt thiết bị này (Private Local Storage) — Hoàn toàn riêng tư, không công khai lên máy chủ
            </p>
          </div>
          <span className="font-tabular text-xs text-[#6E675F]">
            PRIVATE LOCAL PRESETS
          </span>
        </div>

        {savedOutfits.length === 0 ? (
          <div className="p-10 text-center border border-[#141312]/15 bg-[#F6F4EF]/40 space-y-3">
            <p className="text-sm text-[#3D3934]">
              Chưa có bộ phối nào được lưu trong kho dữ liệu cục bộ của bạn.
            </p>
            <p className="text-xs text-[#6E675F] max-w-md mx-auto">
              Sử dụng tính năng Phối Phục (Outfit Builder) để tạo tổ hợp trang phục cá nhân và lưu trữ an toàn trên thiết bị của bạn.
            </p>
            <div className="pt-2">
              <MagneticButton
                type="button"
                variant="primary"
                onClick={onGoToBuilder}
                className="px-6 py-3 text-xs uppercase tracking-wider"
              >
                Tạo bộ phối đầu tiên &rarr;
              </MagneticButton>
            </div>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {savedOutfits.map((outfit) => (
              <div
                key={outfit.id}
                className="p-5 border border-[#141312]/15 bg-[#F6F4EF] space-y-4"
              >
                <div className="flex items-center justify-between text-xs font-tabular">
                  <span className="text-[#6E675F]">{outfit.createdAt}</span>
                  <span className="uppercase text-[10px] font-semibold px-2 py-0.5 border border-[#141312]/20 bg-[#EAE6DD]">
                    {outfit.evaluation.label}
                  </span>
                </div>
                <h3 className="font-raven text-lg font-medium text-[#0D0C0B]">
                  {outfit.name}
                </h3>
                <div className="text-xs text-[#6E675F] space-y-0.5">
                  <p>Số lớp y phục: {outfit.items.length}</p>
                  <p className="truncate">
                    Thành phần: {outfit.items.map((i) => i.name).join(', ')}
                  </p>
                </div>
                <div className="pt-2 border-t border-[#141312]/10 text-xs text-[#3D3934]">
                  <p className="line-clamp-2 italic">{outfit.evaluation.summary}</p>
                </div>
              </div>
            ))}
          </div>
        )}
      </SectionEntrance>

      {/* MODAL FOR EXPANDED ASSET INSPECTION */}
      {selectedAsset && (
        <div
          role="dialog"
          aria-modal="true"
          className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-6 bg-[#0D0C0B]/85 backdrop-blur-sm"
          onClick={() => setSelectedAsset(null)}
        >
          <div
            className="relative w-full max-w-4xl bg-[#F6F4EF] border border-[#141312]/20 shadow-2xl max-h-[92vh] flex flex-col md:flex-row overflow-hidden"
            onClick={(e) => e.stopPropagation()}
          >
            {/* Close Button */}
            <button
              type="button"
              onClick={() => setSelectedAsset(null)}
              className="absolute top-3 right-3 z-10 p-2 bg-[#0D0C0B] text-[#F6F4EF] hover:bg-[#9E2A1C] transition-colors"
              aria-label="Đóng bảng xem"
            >
              <X className="w-5 h-5" />
            </button>

            {/* Image Stage */}
            <div className="w-full md:w-3/5 bg-[#EAE6DD] flex items-center justify-center p-4 sm:p-8 border-b md:border-b-0 md:border-r border-[#141312]/15 overflow-hidden">
              <img
                src={selectedAsset.src}
                alt={selectedAsset.alt}
                className="max-h-[70vh] w-auto max-w-full object-contain shadow-md"
              />
            </div>

            {/* Detailed Metadata Sheet */}
            <div className="w-full md:w-2/5 p-6 overflow-y-auto space-y-5 flex flex-col justify-between">
              <div className="space-y-4">
                <div className="space-y-1">
                  <span className="text-[11px] font-tabular text-[#9E2A1C] font-semibold">
                    [{selectedAsset.id}] · {selectedAsset.recordId}
                  </span>
                  <h3 className="font-raven text-2xl font-medium text-[#0D0C0B] leading-tight">
                    {selectedAsset.garmentName || selectedAsset.alt}
                  </h3>
                </div>

                {/* Editorial Classification Tag */}
                <div className="p-3 border border-[#141312]/15 bg-[#EAE6DD]/50 space-y-1.5">
                  <div className="flex items-center gap-2">
                    {getEditorialTypeBadge(selectedAsset.editorialType).icon}
                    <span className="font-tabular font-semibold text-xs tracking-wider uppercase text-[#0D0C0B]">
                      {getEditorialTypeBadge(selectedAsset.editorialType).label}
                    </span>
                  </div>
                  <p className="text-xs text-[#6E675F]">
                    {getEditorialTypeBadge(selectedAsset.editorialType).subLabel}
                  </p>
                </div>

                {/* Provenance note */}
                {selectedAsset.provenanceNote && (
                  <div className="space-y-1">
                    <h4 className="text-[11px] font-tabular uppercase tracking-wider text-[#3D3934] font-medium">
                      Ghi Chú Khảo Cứu &amp; Nguồn Gốc:
                    </h4>
                    <p className="text-xs text-[#4A453F] leading-relaxed bg-white/60 p-3 border border-[#141312]/10">
                      {selectedAsset.provenanceNote}
                    </p>
                  </div>
                )}

                {/* Technical Specs */}
                <div className="text-xs text-[#6E675F] space-y-2 border-t border-[#141312]/10 pt-3">
                  <div className="grid grid-cols-2 gap-2">
                    <div>
                      <span className="block text-[10px] text-[#8C8377] uppercase font-tabular">
                        Độ phân giải:
                      </span>
                      <strong className="text-[#0D0C0B]">
                        {selectedAsset.dimensions || '896 × 1200 px'}
                      </strong>
                    </div>
                    <div>
                      <span className="block text-[10px] text-[#8C8377] uppercase font-tabular">
                        Tỉ lệ khung hình:
                      </span>
                      <strong className="text-[#0D0C0B]">
                        {selectedAsset.aspectRatio || '3:4'}
                      </strong>
                    </div>
                  </div>

                  <div>
                    <span className="block text-[10px] text-[#8C8377] uppercase font-tabular">
                      Nguồn cấp dữ liệu:
                    </span>
                    <strong className="text-[#0D0C0B]">
                      {selectedAsset.credit || 'Studio Tàng Y Các'}
                    </strong>
                  </div>

                  <div>
                    <span className="block text-[10px] text-[#8C8377] uppercase font-tabular">
                      Loại giấy phép:
                    </span>
                    <strong className="text-[#0D0C0B]">
                      {selectedAsset.license || 'Editorial Archive License'}
                    </strong>
                  </div>
                </div>
              </div>

              <div className="pt-4 border-t border-[#141312]/15">
                <button
                  type="button"
                  onClick={() => setSelectedAsset(null)}
                  className="w-full py-2.5 bg-[#0D0C0B] text-[#F6F4EF] text-xs uppercase tracking-wider hover:bg-[#9E2A1C] transition-colors"
                >
                  Đóng cửa sổ xem
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
