import React, { useState, useRef, useEffect } from 'react';
import {
  Sparkles,
  Send,
  X,
  ChevronRight,
  AlertTriangle,
  Layers,
  Gift,
  BookOpen,
  ArrowUpRight,
  RotateCcw,
  Clock,
  Shirt,
  Info,
} from 'lucide-react';
import { Item } from '../../domain/types';
import {
  ChatMessage,
  OutfitRecommendation,
  GiftSuggestion,
} from '../../domain/advisorEngine';
import {
  sendAdvisorMessage,
  getInitialAdvisorMessage,
} from '../../services/geminiAdvisor';
import { MagneticButton } from '../motion/MotionPrimitives';
import { getCanonicalEntityImage } from '../../domain/canonicalData';

interface AdvisorDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  onApplyOutfitToBuilder: (items: Item[]) => void;
  onViewItemDetail: (item: Item) => void;
}

export const AdvisorDrawer: React.FC<AdvisorDrawerProps> = ({
  isOpen,
  onClose,
  onApplyOutfitToBuilder,
  onViewItemDetail,
}) => {
  const [messages, setMessages] = useState<ChatMessage[]>(() => [
    getInitialAdvisorMessage(),
  ]);
  const [inputText, setInputText] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [selectedCity, setSelectedCity] = useState('');

  const messagesEndRef = useRef<HTMLDivElement | null>(null);
  const inputRef = useRef<HTMLInputElement | null>(null);

  // Auto-scroll to bottom of thread
  useEffect(() => {
    if (isOpen) {
      messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
      inputRef.current?.focus();
    }
  }, [isOpen, messages, isLoading]);

  // Close on Escape key
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape' && isOpen) {
        onClose();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, onClose]);

  const handleSendMessage = async (textToSend?: string) => {
    const text = (textToSend || inputText).trim();
    if (!text || isLoading) return;

    const userMsg: ChatMessage = {
      id: `msg_user_${Date.now()}`,
      role: 'user',
      text,
      timestamp: new Date().toLocaleTimeString('vi-VN', {
        hour: '2-digit',
        minute: '2-digit',
      }),
    };

    setMessages((prev) => [...prev, userMsg]);
    setInputText('');
    setIsLoading(true);

    try {
      const history = messages.map((m) => ({
        role: m.role,
        text: m.text,
      }));

      const response = await sendAdvisorMessage({
        message: text,
        history,
        location: selectedCity || undefined,
      });

      const modelMsg: ChatMessage = {
        id: `msg_model_${Date.now()}`,
        role: 'model',
        text: response.message,
        timestamp: new Date().toLocaleTimeString('vi-VN', {
          hour: '2-digit',
          minute: '2-digit',
        }),
        recommendations: response.recommendations,
        giftSuggestions: response.giftSuggestions,
        quickActions: response.quickActions,
        dateContext: response.dateContext,
        sourcesCited: response.sourcesCited,
      };

      setMessages((prev) => [...prev, modelMsg]);
    } catch (err) {
      console.error('Advisor error:', err);
    } finally {
      setIsLoading(false);
    }
  };

  const handleResetChat = () => {
    setMessages([getInitialAdvisorMessage()]);
    setInputText('');
  };

  const getCompatibilityBadge = (status: string) => {
    switch (status) {
      case 'AUTHENTIC':
        return {
          label: '✓ Chuẩn mực xác thực',
          bg: 'bg-[#1C4D2E]/10 text-[#1C4D2E] border-[#1C4D2E]/30',
        };
      case 'HISTORICALLY_SUPPORTED':
        return {
          label: '✓ Phù hợp tư liệu',
          bg: 'bg-[#1E3A8A]/10 text-[#1E3A8A] border-[#1E3A8A]/30',
        };
      case 'CONTEXTUAL_MODERN_REMIX':
        return {
          label: '△ Cách tân đương đại',
          bg: 'bg-[#B45309]/10 text-[#B45309] border-[#B45309]/30',
        };
      case 'UNCERTAIN':
        return {
          label: '◇ Cần thêm tư liệu',
          bg: 'bg-[#854D0E]/10 text-[#854D0E] border-[#854D0E]/30',
        };
      case 'CULTURAL_MISMATCH':
        return {
          label: '⚠ Lệch chuẩn văn hóa',
          bg: 'bg-[#991B1B]/10 text-[#991B1B] border-[#991B1B]/30',
        };
      default:
        return {
          label: '✓ Khảo cứu Tàng Y',
          bg: 'bg-[#171717]/10 text-[#171717] border-[#171717]/20',
        };
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 overflow-hidden bg-black/40 backdrop-blur-xs flex justify-end animate-backdrop-fade">
      <div
        role="dialog"
        aria-modal="true"
        aria-label="Cố Vấn Tàng Y - Occasion Advisor"
        className="relative w-full max-w-[620px] bg-[#FBF9F5] h-full shadow-2xl flex flex-col border-l border-[#141312]/15 text-[#171717] animate-drawer-slide"
      >
        {/* Drawer Header */}
        <header className="px-6 py-4.5 border-b border-[#141312]/15 bg-[#F4F1EA] flex items-center justify-between shrink-0">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-full bg-[#A63D2F] text-white flex items-center justify-center font-raven text-sm font-bold shadow-2xs">
              藏
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="font-raven text-lg font-semibold tracking-wider text-[#171717]">
                  Cố Vấn Tàng Y
                </h2>
                <span className="text-[10px] font-mono tracking-wider px-2 py-0.5 rounded-full bg-[#A63D2F]/10 text-[#A63D2F] font-medium border border-[#A63D2F]/20">
                  GEMINI 3.8 FLASH
                </span>
              </div>
              <p className="text-xs text-[#6E675F] -mt-0.5">
                Cố vấn mặc y phục truyền thống Việt Nam theo kế hoạch hôm nay
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={handleResetChat}
              title="Khởi động lại cuộc trò chuyện"
              className="p-2 text-[#6E675F] hover:text-[#171717] hover:bg-black/5 rounded-full transition-colors cursor-pointer"
            >
              <RotateCcw className="w-4 h-4" />
            </button>
            <button
              type="button"
              onClick={onClose}
              aria-label="Đóng bảng cố vấn"
              className="p-2 text-[#6E675F] hover:text-[#171717] hover:bg-black/5 rounded-full transition-colors cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </header>

        {/* Location selector strip (Optional filter) */}
        <div className="px-6 py-2 bg-[#EFECE5]/70 border-b border-[#141312]/10 flex items-center justify-between text-xs text-[#6E675F]">
          <div className="flex items-center gap-2">
            <span className="font-mono uppercase text-[10px] tracking-wider text-[#A63D2F]">
              Địa điểm tùy chọn:
            </span>
            <div className="flex items-center gap-1.5 overflow-x-auto py-0.5">
              {['Hà Nội', 'Huế', 'TP. Hồ Chí Minh', 'Hội An'].map((city) => (
                <button
                  key={city}
                  type="button"
                  onClick={() => setSelectedCity(selectedCity === city ? '' : city)}
                  className={`px-2 py-0.5 rounded text-[11px] transition-colors cursor-pointer ${
                    selectedCity === city
                      ? 'bg-[#171717] text-[#FBF9F5] font-medium'
                      : 'bg-white/80 hover:bg-white text-[#4A4641] border border-[#141312]/10'
                  }`}
                >
                  {city}
                </button>
              ))}
            </div>
          </div>
          <span className="hidden sm:inline font-mono text-[10px] text-[#8C857B]">
            {new Date().toLocaleDateString('vi-VN', { day: '2-digit', month: '2-digit' })}
          </span>
        </div>

        {/* Message Thread (Scrollable) */}
        <div className="flex-1 overflow-y-auto px-6 py-5 space-y-6">
          {messages.map((msg) => {
            const isUser = msg.role === 'user';

            return (
              <div
                key={msg.id}
                className={`flex flex-col ${isUser ? 'items-end' : 'items-start'}`}
              >
                {/* Avatar & Label */}
                <div
                  className={`flex items-center gap-2 mb-1.5 text-[11px] text-[#6E675F] ${
                    isUser ? 'flex-row-reverse' : ''
                  }`}
                >
                  <span className="font-medium">
                    {isUser ? 'Bạn' : 'Cố Vấn Tàng Y'}
                  </span>
                  <span className="font-mono text-[10px] text-[#9E9689]">
                    {msg.timestamp}
                  </span>
                </div>

                {/* Message Bubble */}
                <div
                  className={`max-w-[92%] rounded-2xl p-4 sm:p-5 text-sm leading-relaxed ${
                    isUser
                      ? 'bg-[#171717] text-[#FBF9F5] rounded-tr-xs'
                      : 'bg-[#F4F1EA] text-[#171717] border border-[#141312]/10 rounded-tl-xs shadow-2xs'
                  }`}
                >
                  <p className="whitespace-pre-line">{msg.text}</p>

                  {/* Sources Cited */}
                  {msg.sourcesCited && msg.sourcesCited.length > 0 && (
                    <div className="mt-3 pt-3 border-t border-[#141312]/10 text-xs text-[#5C564E]">
                      <div className="flex items-center gap-1.5 font-medium text-[#171717] mb-1.5">
                        <BookOpen className="w-3.5 h-3.5 text-[#A63D2F]" />
                        <span>Nguồn tư liệu đối chiếu:</span>
                      </div>
                      <div className="space-y-1 font-mono text-[11px]">
                        {msg.sourcesCited.map((s) => (
                          <div key={s.id} className="flex items-start gap-1.5">
                            <span className="text-[#A63D2F] font-bold">[{s.id}]</span>
                            <span>
                              {s.title} — <em>{s.institution}</em>
                            </span>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}

                  {/* Recommendations Cards */}
                  {msg.recommendations && msg.recommendations.length > 0 && (
                    <div className="mt-4 pt-3 border-t border-[#141312]/15 space-y-4">
                      <div className="flex items-center justify-between">
                        <span className="font-raven text-xs font-semibold uppercase tracking-wider text-[#A63D2F]">
                          Phương án trang phục tuyển chọn ({msg.recommendations.length})
                        </span>
                        <span className="text-[10px] font-mono text-[#77736B]">
                          Canonical Registry
                        </span>
                      </div>

                      {msg.recommendations.map((rec, idx) => {
                        const badge = getCompatibilityBadge(
                          rec.culturalEvidenceStatus || rec.evaluation.label
                        );

                        return (
                          <div
                            key={rec.id}
                            className="bg-white rounded-xl border border-[#141312]/15 p-4 shadow-2xs transition-all hover:border-[#A63D2F]/40"
                          >
                            {/* Card Top Title & Compatibility Badge */}
                            <div className="flex items-start justify-between gap-3 mb-2">
                              <div>
                                <span className="text-[10px] font-mono font-medium text-[#A63D2F] uppercase tracking-wider">
                                  Phương án {idx + 1}
                                </span>
                                <h3 className="font-raven text-base font-semibold text-[#171717] leading-snug">
                                  {rec.title}
                                </h3>
                              </div>
                              <span
                                className={`text-[10px] font-medium px-2 py-0.5 rounded-full border whitespace-nowrap ${badge.bg}`}
                              >
                                {badge.label}
                              </span>
                            </div>

                            {/* Canonical Garments in this outfit */}
                            <div className="my-3 p-2.5 rounded-lg bg-[#FAF8F5] border border-[#141312]/10">
                              <span className="text-[10px] font-mono uppercase text-[#6E675F] tracking-wider block mb-1.5">
                                Các món trong tổ hợp y phục:
                              </span>
                              <div className="flex flex-wrap gap-1.5">
                                {rec.items.map((item) => {
                                  const img = getCanonicalEntityImage(item.id, item.name);
                                  return (
                                    <button
                                      key={item.id}
                                      type="button"
                                      onClick={() => {
                                        onViewItemDetail(item);
                                      }}
                                      title={`Xem chi tiết ${item.name}`}
                                      className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-md bg-white border border-[#141312]/15 text-xs text-[#171717] hover:border-[#A63D2F] hover:bg-[#A63D2F]/5 transition-colors cursor-pointer group"
                                    >
                                      {img.src ? (
                                        <img
                                          src={img.src}
                                          alt={item.name}
                                          className="w-4 h-4 rounded-full object-cover shrink-0"
                                        />
                                      ) : (
                                        <Shirt className="w-3.5 h-3.5 text-[#A63D2F]" />
                                      )}
                                      <span className="font-medium group-hover:text-[#A63D2F]">
                                        {item.name}
                                      </span>
                                      <span className="font-mono text-[9px] text-[#8C857B]">
                                        [{item.id}]
                                      </span>
                                    </button>
                                  );
                                })}
                              </div>
                            </div>

                            {/* Why it suits */}
                            <div className="text-xs text-[#3D3A35] space-y-2 mb-3">
                              <p>
                                <strong className="text-[#171717]">Vì sao phù hợp: </strong>
                                {rec.whySuits}
                              </p>
                              {rec.stylingColorNotes && (
                                <p>
                                  <strong className="text-[#171717]">Phối màu &amp; phụ kiện: </strong>
                                  {rec.stylingColorNotes}
                                </p>
                              )}
                              {rec.comfortNotes && (
                                <p className="text-[#6E675F]">
                                  <Clock className="w-3 h-3 inline mr-1 text-[#8C857B]" />
                                  <span>{rec.comfortNotes}</span>
                                </p>
                              )}
                              {rec.warnings && (
                                <div className="flex items-start gap-1.5 text-[11px] text-[#991B1B] bg-[#991B1B]/5 p-2 rounded border border-[#991B1B]/20">
                                  <AlertTriangle className="w-3.5 h-3.5 shrink-0 mt-0.5" />
                                  <span>{rec.warnings}</span>
                                </div>
                              )}
                            </div>

                            {/* Action: Apply Outfit to OutfitBuilderScreen */}
                            <div className="pt-2 border-t border-[#141312]/10 flex items-center justify-between gap-3">
                              <span className="text-[11px] text-[#8C857B]">
                                {rec.items.length} món chuẩn
                              </span>
                              <button
                                type="button"
                                onClick={() => {
                                  onApplyOutfitToBuilder(rec.items);
                                  onClose();
                                }}
                                className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-md bg-[#171717] hover:bg-[#A63D2F] text-white text-xs font-medium tracking-wide transition-colors cursor-pointer group"
                              >
                                <Layers className="w-3.5 h-3.5 text-[#C8A97E] group-hover:text-white" />
                                <span>Phối bộ này trên Ma-nơ-canh</span>
                                <ChevronRight className="w-3.5 h-3.5" />
                              </button>
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  )}

                  {/* Gift Suggestions Cards */}
                  {msg.giftSuggestions && msg.giftSuggestions.length > 0 && (
                    <div className="mt-4 pt-3 border-t border-[#141312]/15 space-y-3">
                      <div className="flex items-center gap-2 text-xs font-raven font-semibold text-[#A63D2F] uppercase tracking-wider">
                        <Gift className="w-4 h-4" />
                        <span>Gợi ý quà tặng văn hóa ý nghĩa ({msg.giftSuggestions.length})</span>
                      </div>

                      <div className="space-y-2.5">
                        {msg.giftSuggestions.map((gift) => (
                          <div
                            key={gift.id}
                            className="bg-white rounded-lg border border-[#141312]/15 p-3.5 shadow-2xs"
                          >
                            <div className="flex items-start justify-between gap-2 mb-1">
                              <h4 className="font-raven font-semibold text-sm text-[#171717]">
                                {gift.name}
                              </h4>
                              <span className="text-[10px] font-mono px-2 py-0.5 bg-[#FAF8F5] border border-[#141312]/10 text-[#6E675F] rounded">
                                {gift.budgetLevel}
                              </span>
                            </div>

                            <p className="text-xs text-[#3D3A35] mb-2 leading-relaxed">
                              <strong>Ý nghĩa: </strong>
                              {gift.culturalMeaning}
                            </p>

                            <div className="text-[11px] text-[#6E675F] space-y-1">
                              <p>
                                <strong>Đối tượng phù hợp: </strong>
                                {gift.suitableFor}
                              </p>
                              {gift.notes && (
                                <p className="italic text-[#8C857B]">
                                  * {gift.notes}
                                </p>
                              )}
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}
                </div>

                {/* Quick actions for this turn */}
                {msg.quickActions && msg.quickActions.length > 0 && !isUser && (
                  <div className="mt-3 flex flex-wrap gap-1.5 max-w-[92%]">
                    {msg.quickActions.map((action, aIdx) => (
                      <button
                        key={aIdx}
                        type="button"
                        onClick={() => handleSendMessage(action)}
                        disabled={isLoading}
                        className="px-2.5 py-1 text-xs rounded-full bg-white hover:bg-[#FAF8F5] text-[#4A4641] hover:text-[#171717] border border-[#141312]/15 shadow-2xs transition-all cursor-pointer hover:border-[#A63D2F]/50 flex items-center gap-1 group"
                      >
                        <Sparkles className="w-3 h-3 text-[#A63D2F] group-hover:scale-110 transition-transform" />
                        <span>{action}</span>
                      </button>
                    ))}
                  </div>
                )}
              </div>
            );
          })}

          {/* Typing Indicator */}
          {isLoading && (
            <div className="flex items-center gap-2 text-xs text-[#6E675F] bg-[#F4F1EA] px-4 py-2.5 rounded-full w-fit border border-[#141312]/10 animate-pulse">
              <Sparkles className="w-3.5 h-3.5 text-[#A63D2F]" />
              <span>Cố Vấn Tàng Y đang khảo cứu phương án trang phục...</span>
            </div>
          )}

          <div ref={messagesEndRef} />
        </div>

        {/* Common Quick Actions Bar */}
        <div className="px-6 py-2 bg-[#F4F1EA] border-t border-[#141312]/10 overflow-x-auto flex items-center gap-2 shrink-0">
          <span className="text-[10px] font-mono text-[#8C857B] uppercase tracking-wider shrink-0">
            Hỏi nhanh:
          </span>
          {[
            'Gợi ý trang phục hôm nay',
            'Tìm đồ đi chụp ảnh di tích',
            'Trang phục dự đám cưới',
            'Đồ thoải mái dạo phố cà phê',
            'Gợi ý quà tặng văn hóa',
            'Giải thích nguồn tư liệu',
          ].map((prompt, i) => (
            <button
              key={i}
              type="button"
              onClick={() => handleSendMessage(prompt)}
              disabled={isLoading}
              className="px-2.5 py-1 rounded-full text-xs whitespace-nowrap bg-white hover:bg-[#FAF8F5] text-[#3D3A35] hover:text-[#171717] border border-[#141312]/15 shadow-2xs transition-colors cursor-pointer"
            >
              {prompt}
            </button>
          ))}
        </div>

        {/* Input Bar */}
        <footer className="p-4 sm:p-5 bg-white border-t border-[#141312]/15 shrink-0">
          <form
            onSubmit={(e) => {
              e.preventDefault();
              handleSendMessage();
            }}
            className="flex items-center gap-2"
          >
            <input
              ref={inputRef}
              type="text"
              value={inputText}
              onChange={(e) => setInputText(e.target.value)}
              placeholder="Nhập kế hoạch hôm nay (vd: đi trường, chụp ảnh Văn Miếu, đi cưới)..."
              disabled={isLoading}
              className="flex-1 px-4 py-2.5 text-sm rounded-lg bg-[#FAF8F5] border border-[#141312]/20 focus:outline-none focus:border-[#A63D2F] focus:bg-white transition-colors"
            />
            <button
              type="submit"
              disabled={!inputText.trim() || isLoading}
              className="px-4 py-2.5 rounded-lg bg-[#171717] hover:bg-[#A63D2F] disabled:bg-[#D5D0C7] text-white transition-colors cursor-pointer disabled:cursor-not-allowed flex items-center gap-1.5 font-medium text-xs uppercase tracking-wider"
            >
              <span>Gửi</span>
              <Send className="w-3.5 h-3.5" />
            </button>
          </form>
          <div className="mt-2 text-[11px] text-[#8C857B] flex items-center justify-between">
            <span>Dữ liệu đối chiếu từ 42 trang phục chuẩn mực của Tàng Y</span>
            <span>Khảo cứu di sản · Không tạo đồ ảo</span>
          </div>
        </footer>
      </div>
    </div>
  );
};
