import React from 'react';
import { ScreenId } from '../types';
import { MagneticButton } from './motion/MotionPrimitives';

interface NavbarProps {
  currentScreen: ScreenId;
  onNavigate: (screen: ScreenId) => void;
  savedCount: number;
  compareCount: number;
  onOpenAdvisor?: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  currentScreen,
  onNavigate,
  savedCount,
  compareCount,
  onOpenAdvisor,
}) => {
  const isDarkHero = currentScreen === 'khoi-dau';

  const navItems: { id: ScreenId; label: string; badgeCount?: number }[] = [
    { id: 'tu-ao-xua', label: 'Tủ Áo Xưa' },
    { id: 'phoi-phuc', label: 'Phối Phục' },
    {
      id: 'so-phoi',
      label: 'So Bộ & Cất Giữ',
      badgeCount: savedCount + compareCount,
    },
    { id: 'lookbook', label: 'Lookbook' },
    { id: 'nguon-loi-nhan', label: 'Nguồn & Lời Nhắn' },
  ];

  return (
    <header
      className={`sticky top-0 z-50 backdrop-blur-md border-b transition-colors duration-300 ${
        isDarkHero
          ? 'bg-[#070706]/85 border-[#F3EFE6]/12 text-[#F3EFE6]'
          : 'bg-[#F6F4EF]/90 border-[#141312]/15 text-[#0D0C0B]'
      }`}
    >
      <div className="max-w-[1440px] mx-auto px-6 sm:px-10 h-20 flex items-center justify-between gap-6">
        {/* Zone 1: Tàng Y / Việt Phục Remix Brand Wordmark */}
        <button
          type="button"
          onClick={() => onNavigate('khoi-dau')}
          className="flex items-center gap-2.5 text-left cursor-pointer group shrink-0"
        >
          <div className="flex flex-col">
            <div className="flex items-center gap-1.5">
              <span
                className={`font-raven text-2xl sm:text-[26px] font-semibold tracking-[0.08em] uppercase ${
                  isDarkHero ? 'text-[#F4F1EA]' : 'text-[#171717]'
                }`}
              >
                Tàng Y
              </span>
              <span className="w-5 h-5 bg-[#A63D2F] text-white text-[11px] font-raven flex items-center justify-center shadow-2xs font-bold leading-none">
                藏
              </span>
            </div>
            <span
              className={`text-[9px] font-mono tracking-[0.22em] uppercase -mt-0.5 ${
                isDarkHero ? 'text-[#9E9689]' : 'text-[#77736B]'
              }`}
            >
              Việt Phục Remix
            </span>
          </div>
        </button>

        {/* Zone 2: 4 clean text navigation links */}
        <nav
          aria-label="Điều hướng chính"
          className="hidden md:flex items-center gap-10"
        >
          {navItems.map((item) => {
            const isActive =
              currentScreen === item.id ||
              (item.id === 'tu-ao-xua' && currentScreen === 'chuyen-ao');
            return (
              <button
                key={item.id}
                type="button"
                onClick={() => onNavigate(item.id)}
                className={`group relative py-1.5 text-sm font-medium tracking-wide transition-colors duration-200 cursor-pointer whitespace-nowrap shrink-0 ${
                  isDarkHero
                    ? isActive
                      ? 'text-[#F3EFE6]'
                      : 'text-[#9E9689] hover:text-[#F3EFE6]'
                    : isActive
                    ? 'text-[#0D0C0B]'
                    : 'text-[#6E675F] hover:text-[#0D0C0B]'
                }`}
              >
                <span>{item.label}</span>
                {item.badgeCount !== undefined && item.badgeCount > 0 && (
                  <span
                    className={`ml-1.5 font-tabular text-xs ${
                      isDarkHero ? 'text-[#C8A97E]' : 'text-[#9E2A1C]'
                    }`}
                  >
                    [{savedCount}/{compareCount}]
                  </span>
                )}
                <span
                  className={`absolute bottom-0 left-0 right-0 h-[1.5px] transition-transform duration-300 ease-out origin-left ${
                    isDarkHero ? 'bg-[#C8A97E]' : 'bg-[#171717]'
                  } ${
                    isActive
                      ? 'scale-x-100 !bg-[#A63D2F]'
                      : 'scale-x-0 group-hover:scale-x-100'
                  }`}
                />
              </button>
            );
          })}
        </nav>

        {/* Zone 3: Actions */}
        <div className="flex items-center gap-2.5">
          {onOpenAdvisor && (
            <button
              type="button"
              onClick={onOpenAdvisor}
              className={`inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-medium tracking-wider rounded-sm transition-all duration-200 cursor-pointer border ${
                isDarkHero
                  ? 'border-[#C8A97E]/30 bg-[#C8A97E]/10 text-[#C8A97E] hover:bg-[#C8A97E]/20'
                  : 'border-[#A63D2F]/30 bg-[#A63D2F]/5 text-[#A63D2F] hover:bg-[#A63D2F]/15'
              }`}
            >
              <span className="w-3.5 h-3.5 rounded-full bg-[#A63D2F] text-white text-[9px] font-raven font-bold flex items-center justify-center">
                藏
              </span>
              <span>Cố Vấn Y Phục</span>
            </button>
          )}

          <MagneticButton
            type="button"
            variant="primary"
            onClick={() => onNavigate('phoi-phuc')}
            className={`px-5 py-2.5 text-xs font-medium tracking-wider uppercase ${
              isDarkHero
                ? '!bg-[#F3EFE6] !text-[#070706] !border-[#F3EFE6] hover:!bg-[#9E2A1C] hover:!text-[#F3EFE6] hover:!border-[#9E2A1C]'
                : ''
            }`}
          >
            Bắt đầu phối
          </MagneticButton>
        </div>
      </div>

      {/* Compact mobile navigation strip */}
      <nav
        aria-label="Điều hướng di động"
        className={`md:hidden flex items-center justify-between px-6 py-2.5 border-t overflow-x-auto gap-5 ${
          isDarkHero
            ? 'border-[#F3EFE6]/10 bg-[#0D0C0B] text-[#F3EFE6]'
            : 'border-[#141312]/10 bg-[#EFECE5] text-[#0D0C0B]'
        }`}
      >
        {onOpenAdvisor && (
          <button
            type="button"
            onClick={onOpenAdvisor}
            className={`text-xs font-semibold py-0.5 whitespace-nowrap shrink-0 cursor-pointer flex items-center gap-1 ${
              isDarkHero ? 'text-[#C8A97E]' : 'text-[#A63D2F]'
            }`}
          >
            <span className="w-3.5 h-3.5 rounded-full bg-[#A63D2F] text-white text-[8px] font-raven font-bold flex items-center justify-center">
              藏
            </span>
            <span>Cố Vấn</span>
          </button>
        )}
        {navItems.map((item) => {
          const isActive =
            currentScreen === item.id ||
            (item.id === 'tu-ao-xua' && currentScreen === 'chuyen-ao');
          return (
            <button
              key={item.id}
              type="button"
              onClick={() => onNavigate(item.id)}
              className={`text-xs font-medium py-0.5 whitespace-nowrap shrink-0 cursor-pointer transition-colors duration-150 ${
                isActive
                  ? isDarkHero
                    ? 'text-[#C8A97E] underline underline-offset-4'
                    : 'text-[#9E2A1C] underline underline-offset-4'
                  : isDarkHero
                  ? 'text-[#9E9689] hover:text-[#F3EFE6]'
                  : 'text-[#6E675F] hover:text-[#0D0C0B]'
              }`}
            >
              {item.label}
              {item.badgeCount !== undefined && item.badgeCount > 0 && (
                <span className="ml-1 font-tabular">({savedCount})</span>
              )}
            </button>
          );
        })}
      </nav>
    </header>
  );
};
