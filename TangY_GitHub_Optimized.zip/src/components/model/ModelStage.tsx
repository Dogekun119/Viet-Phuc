import React from 'react';
import { ModelGender } from '../../domain/types';
import femaleBaseModelImage from '../../assets/images/female_base_model_1791456212298.jpg';
import maleBaseModelImage from '../../assets/images/male_base_model_1791456224566.jpg';
import { Sparkles, AlertCircle, RefreshCw } from 'lucide-react';
import {
  GARMENT_LAYER_ORDER,
  GarmentLayerType,
  LAYER_Z_INDEX_MAP,
  GarmentPlacement,
  GarmentLayerData,
} from '../../domain/garmentLayers';

export {
  GARMENT_LAYER_ORDER,
  type GarmentLayerType,
  LAYER_Z_INDEX_MAP,
  type GarmentPlacement,
  type GarmentLayerData,
};

export interface BaseModelProps {
  gender: ModelGender;
}

/**
 * BaseModel
 * Supports exactly TWO base models:
 * - female (full-body, front-facing, neutral undergarment base layer)
 * - male (full-body, front-facing, neutral undergarment base layer, identical scale & framing)
 *
 * Shows full body, centered, preserves 3:4 aspect ratio, with clean ivory background
 * and subtle 200–400ms transition (duration-300) when switching models.
 */
export const BaseModel: React.FC<BaseModelProps> = ({ gender }) => {
  return (
    <div className="relative w-full h-full overflow-hidden bg-[#EFECE5]">
      {/* Female Base Model */}
      <div
        className={`absolute inset-0 w-full h-full transition-opacity duration-300 ease-in-out ${
          gender === 'female'
            ? 'opacity-100 z-1 pointer-events-auto'
            : 'opacity-0 z-0 pointer-events-none'
        }`}
        aria-hidden={gender !== 'female'}
      >
        <img
          src={femaleBaseModelImage}
          alt="Người mẫu Việt phục Nữ"
          className="w-full h-full object-contain object-center"
          loading="eager"
          referrerPolicy="no-referrer"
        />
      </div>

      {/* Male Base Model */}
      <div
        className={`absolute inset-0 w-full h-full transition-opacity duration-300 ease-in-out ${
          gender === 'male'
            ? 'opacity-100 z-1 pointer-events-auto'
            : 'opacity-0 z-0 pointer-events-none'
        }`}
        aria-hidden={gender !== 'male'}
      >
        <img
          src={maleBaseModelImage}
          alt="Người mẫu Việt phục Nam"
          className="w-full h-full object-contain object-center"
          loading="eager"
          referrerPolicy="no-referrer"
        />
      </div>
    </div>
  );
};

export interface ModelStageProps {
  selectedModelGender: ModelGender;
  layers?: GarmentLayerData[];
  tryOnImageUrl?: string | null;
  isGenerating?: boolean;
  hasError?: boolean;
  errorMessage?: string;
  onRetry?: () => void;
  className?: string;
  children?: React.ReactNode;
}

/**
 * ModelStage
 * 
 * New photorealistic rendering flow:
 * - Displays the base model or the photorealistic AI try-on image as the main visual result.
 * - Flat cartoon SVG stickers are omitted from final display.
 * - Shows dedicated loading shimmer while generating.
 * - Shows retry action if generation encounters errors.
 */
export const ModelStage: React.FC<ModelStageProps> = ({
  selectedModelGender,
  tryOnImageUrl,
  isGenerating = false,
  hasError = false,
  errorMessage,
  onRetry,
  className = '',
  children,
}) => {
  return (
    <div
      className={`relative w-full aspect-[3/4.4] sm:aspect-[3/4.2] border border-[#141312]/15 bg-[#EFECE5] overflow-hidden shadow-sm select-none ${className}`}
    >
      {/* 1. Main Visual: Photorealistic Try-On Image OR Base Model */}
      {tryOnImageUrl ? (
        <div className="absolute inset-0 w-full h-full bg-[#EFECE5] z-5 flex items-center justify-center">
          <img
            src={tryOnImageUrl}
            alt="Kết quả thử phục trang trên người mẫu"
            className="w-full h-full object-contain object-center transition-opacity duration-500 ease-out"
            referrerPolicy="no-referrer"
          />
          {/* Subtle Photorealistic Badge */}
          <div className="absolute top-3 right-3 px-2 py-0.5 bg-[#171717]/80 backdrop-blur-xs text-[#F4F1EA] text-[9px] font-tabular uppercase tracking-wider z-20 border border-[#F4F1EA]/20 flex items-center gap-1">
            <Sparkles className="w-2.5 h-2.5 text-[#C8A97E]" />
            <span>ẢNH THỰC TẾ · AI TRY-ON</span>
          </div>
          {/* Transparent Educational Disclaimer */}
          <div className="absolute bottom-2.5 inset-x-3 text-center pointer-events-none z-20">
            <span className="px-2 py-0.5 bg-[#0E0C0A]/70 backdrop-blur-xs text-[#F4F1EA]/90 text-[8.5px] font-tabular uppercase tracking-widest border border-[#F4F1EA]/15 inline-block">
              MINH HỌA AI · KHÔNG PHẢI ẢNH TƯ LIỆU LỊCH SỬ
            </span>
          </div>
        </div>
      ) : (
        <BaseModel gender={selectedModelGender} />
      )}

      {/* 2. Loading State Overlay */}
      {isGenerating && (
        <div className="absolute inset-0 bg-[#0E0C0A]/70 backdrop-blur-xs z-30 flex flex-col items-center justify-center p-6 text-center text-[#F4F1EA] space-y-3 animate-fadeIn">
          <div className="relative">
            <div className="w-12 h-12 border-2 border-[#C8A97E] border-t-transparent rounded-full animate-spin" />
            <Sparkles className="w-5 h-5 text-[#C8A97E] absolute inset-0 m-auto" />
          </div>
          <div className="space-y-1">
            <p className="font-raven text-sm tracking-wider uppercase text-[#F4F1EA]">
              Đang kiến tạo phối phục chân thực
            </p>
            <p className="text-[11px] font-mono text-[#C8A97E] max-w-xs">
              Mô hình đang tổng hợp các lớp vải, nếp gấp, phom dáng và ánh sáng phòng chụp...
            </p>
          </div>
        </div>
      )}

      {/* 3. Error / Retry State Overlay */}
      {hasError && !isGenerating && (
        <div className="absolute top-12 inset-x-4 p-3 bg-[#991B1B]/90 backdrop-blur-xs text-white rounded border border-white/20 z-30 shadow-lg flex items-center justify-between text-xs animate-fadeIn">
          <div className="flex items-center gap-2">
            <AlertCircle className="w-4 h-4 shrink-0 text-amber-300" />
            <span className="line-clamp-3 text-[11.5px] leading-relaxed">
              {errorMessage || 'Không thể tạo ảnh phối phục lúc này.'}
            </span>
          </div>
          {onRetry && (
            <button
              type="button"
              onClick={onRetry}
              className="px-2.5 py-1 bg-white text-[#991B1B] text-[11px] font-medium rounded hover:bg-white/90 shrink-0 cursor-pointer flex items-center gap-1 shadow-xs ml-2"
            >
              <RefreshCw className="w-3 h-3" />
              <span>Thử lại</span>
            </button>
          )}
        </div>
      )}

      {/* Gentle Archival Vignette */}
      <div className="absolute inset-0 pointer-events-none bg-gradient-to-t from-[#141312]/30 via-transparent to-transparent opacity-60 z-16" />

      {/* Discreet Gender Mode Badge */}
      <div className="absolute top-3 left-3 px-2 py-0.5 bg-[#141312]/75 backdrop-blur-xs text-[#F4F1EA] text-[10px] font-tabular uppercase tracking-wider z-20">
        Dáng {selectedModelGender === 'female' ? 'Nữ' : 'Nam'}
      </div>

      {/* Overlays / Layer Indicators (Passed from parent) */}
      {children}
    </div>
  );
};
