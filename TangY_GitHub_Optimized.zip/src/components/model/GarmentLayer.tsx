import React from 'react';
import {
  GarmentLayerType,
  LAYER_Z_INDEX_MAP,
} from '../../domain/garmentLayers';

export interface GarmentLayerProps {
  itemId: string;
  asset: string;
  layerType: GarmentLayerType;
  x?: number;
  y?: number;
  scale?: number;
  rotation?: number;
  zIndex?: number;
  visible?: boolean;
  className?: string;
  alt?: string;
}

/**
 * Reusable GarmentLayer component
 *
 * Renders a single transparent clothing asset inside ModelStage.
 * Supports:
 * - itemId
 * - asset (image/asset URL)
 * - layerType (inner | main | outer | lower | accessory)
 * - x (px offset)
 * - y (px offset)
 * - scale (scale factor)
 * - rotation (degrees)
 * - zIndex (centralized z-index)
 * - visible (visibility toggle)
 *
 * Uses absolute positioning sharing the exact same coordinate system
 * as the base model inside ModelStage.
 */
export const GarmentLayer: React.FC<GarmentLayerProps> = ({
  itemId,
  asset,
  layerType,
  x = 0,
  y = 0,
  scale = 1,
  rotation = 0,
  zIndex,
  visible = true,
  className = '',
  alt,
}) => {
  if (!visible) return null;

  const resolvedZIndex = zIndex ?? LAYER_Z_INDEX_MAP[layerType];

  return (
    <div
      id={`garment-layer-${layerType}-${itemId}`}
      data-item-id={itemId}
      data-layer-type={layerType}
      className={`absolute inset-0 w-full h-full pointer-events-none transition-transform duration-300 ease-out select-none ${className}`}
      style={{
        zIndex: resolvedZIndex,
        transform: `translate(${x}px, ${y}px) scale(${scale}) rotate(${rotation}deg)`,
        transformOrigin: '50% 50%',
      }}
      aria-hidden="true"
    >
      <img
        src={asset}
        alt={alt || `Lớp trang phục ${layerType} (${itemId})`}
        className="w-full h-full object-contain object-center pointer-events-none"
        draggable={false}
        loading="eager"
      />
    </div>
  );
};

export default GarmentLayer;
