import React from 'react';
import { ScreenId } from '../types';
import lotusHeritageBg from '../assets/images/lotus_heritage_background.svg';

export const LOTUS_HERITAGE_BACKGROUND_ASSET = lotusHeritageBg;

export interface GlobalLotusBackgroundProps {
  screen: ScreenId;
  className?: string;
}

/**
 * Global Lotus Heritage Background System
 *
 * Implements the unified Vietnamese heritage background:
 * - Uses the shared lotus heritage background image asset.
 * - Displays authentic lotus artwork and decorative linework framing the edges.
 * - Center area remains visually quiet so the model, garment cards, and typography
 *   are crisp, unobstructed, and effortlessly readable.
 * - Responsive across mobile, tablet, and desktop without visible repetition.
 * - Subtle opacity/contrast treatment tuned per page without layout shift.
 * - Preserves delicate archival paper tooth overlay.
 */
export const GlobalLotusBackground: React.FC<GlobalLotusBackgroundProps> = ({
  screen,
  className = '',
}) => {
  const isDarkHome = screen === 'khoi-dau';

  // Screen-specific subtle opacity and blending:
  // - Dark runway hero (khoi-dau): subtle warm gold/amber tone over deep dark palette (opacity ~0.08)
  // - Phoi Phuc (outfit builder): gentle framing around the model canvas and wardrobe (opacity ~0.14)
  // - Catalog & Detail pages: quiet, archival contrast ensuring maximum readability of cards and text (opacity ~0.10)
  const getScreenOpacityClass = () => {
    switch (screen) {
      case 'khoi-dau':
        return 'opacity-[0.08] lg:opacity-[0.10] invert brightness-150 contrast-125 mix-blend-screen';
      case 'phoi-phuc':
        return 'opacity-[0.13] sm:opacity-[0.15] lg:opacity-[0.16] mix-blend-multiply text-[#3E362F]';
      case 'tu-ao-xua':
        return 'opacity-[0.09] sm:opacity-[0.11] lg:opacity-[0.12] mix-blend-multiply text-[#3E362F]';
      case 'chuyen-ao':
        return 'opacity-[0.08] sm:opacity-[0.10] lg:opacity-[0.11] mix-blend-multiply text-[#3E362F]';
      case 'lookbook':
        return 'opacity-[0.07] sm:opacity-[0.09] lg:opacity-[0.10] mix-blend-multiply text-[#3E362F]';
      case 'nguon-loi-nhan':
        return 'opacity-[0.10] sm:opacity-[0.12] lg:opacity-[0.13] mix-blend-multiply text-[#3E362F]';
      case 'so-phoi':
        return 'opacity-[0.09] sm:opacity-[0.11] lg:opacity-[0.12] mix-blend-multiply text-[#3E362F]';
      default:
        return 'opacity-[0.10] mix-blend-multiply text-[#3E362F]';
    }
  };

  return (
    <div
      className={`fixed inset-0 pointer-events-none select-none z-0 overflow-hidden ${className}`}
      aria-hidden="true"
    >
      {/* =====================================================================
          1. ARCHIVAL PAPER TEXTURE OVERLAY
          Delicate, tactile tooth of Vietnamese handmade paper (giấy dó / giấy điệp).
          Ultra-low opacity (0.018) provides depth without visual noise.
      ===================================================================== */}
      <svg
        className="absolute inset-0 w-full h-full opacity-[0.018] mix-blend-multiply pointer-events-none"
        xmlns="http://www.w3.org/2000/svg"
      >
        <filter id="vietnamese-paper-grain" x="0%" y="0%" width="100%" height="100%">
          <feTurbulence
            type="fractalNoise"
            baseFrequency="0.04"
            numOctaves="3"
            stitchTiles="stitch"
          />
          <feColorMatrix type="saturate" values="0" />
        </filter>
        <rect width="100%" height="100%" filter="url(#vietnamese-paper-grain)" />
      </svg>

      {/* =====================================================================
          2. SHARED LOTUS HERITAGE BACKGROUND IMAGE ASSET
          - Full original artwork preserved with edge-framing lotus & decorative lines
          - Visually quiet center area ensures content legibility
          - Responsive: object-cover with centered alignment, no visible repeating
          - Transitions smoothly (700ms) between screen navigations
      ===================================================================== */}
      <img
        src={lotusHeritageBg}
        alt=""
        aria-hidden="true"
        className={`absolute inset-0 w-full h-full object-cover object-center pointer-events-none select-none transition-opacity duration-700 ease-out ${getScreenOpacityClass()}`}
      />
    </div>
  );
};
