import React, { useEffect, useRef } from 'react';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import Lenis from 'lenis';

gsap.registerPlugin(ScrollTrigger);

export function prefersReducedMotion(): boolean {
  if (typeof window === 'undefined') return false;
  return window.matchMedia('(prefers-reduced-motion: reduce)').matches;
}

/**
 * Initializes Lenis smooth scrolling synchronized with GSAP ScrollTrigger.
 * Automatically disabled if the user prefers reduced motion.
 */
export function useLenisSmoothScroll(activeKey?: string) {
  const lenisRef = useRef<Lenis | null>(null);

  useEffect(() => {
    if (prefersReducedMotion()) return;

    const lenis = new Lenis({
      duration: 1.15,
      easing: (t: number) => Math.min(1, 1.001 - Math.pow(2, -10 * t)),
      smoothWheel: true,
    });
    lenisRef.current = lenis;

    lenis.on('scroll', ScrollTrigger.update);

    const updateTicker = (time: number) => {
      lenis.raf(time * 1000);
    };

    gsap.ticker.add(updateTicker);
    gsap.ticker.lagSmoothing(0);

    return () => {
      gsap.ticker.remove(updateTicker);
      lenis.destroy();
      lenisRef.current = null;
    };
  }, []);

  useEffect(() => {
    if (lenisRef.current) {
      lenisRef.current.scrollTo(0, { immediate: true });
    } else {
      window.scrollTo({ top: 0 });
    }
    const timer = setTimeout(() => {
      ScrollTrigger.refresh();
    }, 80);
    return () => clearTimeout(timer);
  }, [activeKey]);
}

/**
 * Line-by-line masked text reveal powered by GSAP + ScrollTrigger.
 */
interface SplitLineRevealProps {
  lines: string[];
  as?: 'h1' | 'h2' | 'h3' | 'div' | 'p';
  className?: string;
  lineClassName?: string;
  delay?: number;
}

export const SplitLineReveal: React.FC<SplitLineRevealProps> = ({
  lines,
  as: Tag = 'h2',
  className = '',
  lineClassName = '',
  delay = 0,
}) => {
  const containerRef = useRef<HTMLElement | null>(null);

  useEffect(() => {
    const el = containerRef.current;
    if (!el || prefersReducedMotion()) return;

    const lineInners = el.querySelectorAll('.gsap-line-inner');
    const ctx = gsap.context(() => {
      gsap.fromTo(
        lineInners,
        { yPercent: 108, opacity: 0 },
        {
          yPercent: 0,
          opacity: 1,
          duration: 0.85,
          stagger: 0.09,
          delay,
          ease: 'power3.out',
          scrollTrigger: {
            trigger: el,
            start: 'top 88%',
            once: true,
          },
        }
      );
    }, el);

    return () => ctx.revert();
  }, [lines, delay]);

  return (
    <Tag
      ref={containerRef as React.RefObject<any>}
      className={className}
    >
      {lines.map((line, i) => (
        <span key={i} className="block overflow-hidden pb-[0.08em]">
          <span
            className={`gsap-line-inner block will-change-transform ${lineClassName}`}
          >
            {line}
          </span>
        </span>
      ))}
    </Tag>
  );
};

/**
 * Deliberate section entrance with animated horizontal architectural rule.
 */
interface SectionEntranceProps {
  children: React.ReactNode;
  className?: string;
  showTopRule?: boolean;
}

export const SectionEntrance: React.FC<SectionEntranceProps> = ({
  children,
  className = '',
  showTopRule = true,
}) => {
  const sectionRef = useRef<HTMLElement | null>(null);
  const ruleRef = useRef<HTMLDivElement | null>(null);
  const contentRef = useRef<HTMLDivElement | null>(null);

  useEffect(() => {
    const el = sectionRef.current;
    if (!el || prefersReducedMotion()) return;

    const ctx = gsap.context(() => {
      if (ruleRef.current) {
        gsap.fromTo(
          ruleRef.current,
          { scaleX: 0, transformOrigin: 'left center' },
          {
            scaleX: 1,
            duration: 1.05,
            ease: 'power3.inOut',
            scrollTrigger: {
              trigger: el,
              start: 'top 88%',
              once: true,
            },
          }
        );
      }

      if (contentRef.current) {
        gsap.fromTo(
          contentRef.current,
          { y: 28, opacity: 0 },
          {
            y: 0,
            opacity: 1,
            duration: 0.8,
            ease: 'power3.out',
            scrollTrigger: {
              trigger: el,
              start: 'top 86%',
              once: true,
            },
          }
        );
      }
    }, el);

    return () => ctx.revert();
  }, []);

  return (
    <section ref={sectionRef} className={className}>
      {showTopRule && (
        <div
          ref={ruleRef}
          className="w-full h-[1px] bg-[#141312]/20 mb-10 sm:mb-14 will-change-transform"
        />
      )}
      <div ref={contentRef} className="will-change-transform">
        {children}
      </div>
    </section>
  );
};

/**
 * Physical magnetic button using GSAP quickTo (weighted, non-bouncy).
 */
interface MagneticButtonProps
  extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  strength?: number;
  variant?: 'primary' | 'outline' | 'minimal';
}

export const MagneticButton: React.FC<MagneticButtonProps> = ({
  children,
  className = '',
  strength = 0.22,
  variant = 'primary',
  disabled,
  ...props
}) => {
  const btnRef = useRef<HTMLButtonElement | null>(null);

  useEffect(() => {
    const btn = btnRef.current;
    if (!btn || disabled || prefersReducedMotion()) return;

    const xTo = gsap.quickTo(btn, 'x', {
      duration: 0.35,
      ease: 'power3.out',
    });
    const yTo = gsap.quickTo(btn, 'y', {
      duration: 0.35,
      ease: 'power3.out',
    });

    const handleMove = (e: MouseEvent) => {
      const rect = btn.getBoundingClientRect();
      const relX = e.clientX - (rect.left + rect.width / 2);
      const relY = e.clientY - (rect.top + rect.height / 2);
      xTo(relX * strength);
      yTo(relY * strength);
    };

    const handleLeave = () => {
      xTo(0);
      yTo(0);
    };

    btn.addEventListener('mousemove', handleMove);
    btn.addEventListener('mouseleave', handleLeave);

    return () => {
      btn.removeEventListener('mousemove', handleMove);
      btn.removeEventListener('mouseleave', handleLeave);
    };
  }, [strength, disabled]);

  const variantClasses =
    variant === 'primary'
      ? 'bg-[#0D0C0B] text-[#F6F4EF] hover:bg-[#9E2A1C] border border-[#0D0C0B] hover:border-[#9E2A1C]'
      : variant === 'outline'
      ? 'bg-transparent text-[#0D0C0B] border border-[#0D0C0B] hover:bg-[#0D0C0B] hover:text-[#F6F4EF]'
      : 'bg-transparent text-[#0D0C0B] hover:text-[#9E2A1C]';

  return (
    <button
      ref={btnRef}
      disabled={disabled}
      className={`relative inline-flex items-center justify-center transition-colors duration-200 cursor-pointer whitespace-nowrap select-none will-change-transform ${variantClasses} ${
        disabled ? 'opacity-40 pointer-events-none' : ''
      } ${className}`}
      {...props}
    >
      {children}
    </button>
  );
};
