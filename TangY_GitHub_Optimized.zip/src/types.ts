export type ScreenId =
  | 'khoi-dau'
  | 'tu-ao-xua'
  | 'chuyen-ao'
  | 'phoi-phuc'
  | 'so-phoi'
  | 'lookbook'
  | 'nguon-loi-nhan';

export type EntryPath = 'dip-le' | 'vung-mien' | 'gu-rieng';

export interface Costume {
  id: string;
  ten: string;
  vung: string;
  dip: string;
  moTa: string;
  nguonGoc: string;
  yNghia: string;
  phuKien: string[];
  nguon: string[];
  daKiemChung: boolean;
  vungMienGroups?: string[];
  dipMacGroups?: string[];
  masterGarmentId?: string;
  evidenceLevel?:
    | 'VERIFIED'
    | 'CONSISTENT'
    | 'REMIX'
    | 'UNCERTAIN'
    | 'CONTESTED'
    | 'MISMATCH'
    | (string & {});
  auditStatus?: string;
  sourceIds?: string[];
  period?: string[];
  audience?: string[];
  context?: string[];
  isCoreKinhScope?: boolean;
  isStatusSystem?: boolean;
  researchNotes?: string;
}

export interface RemixedOutfit {
  id: string;
  costumeId: string;
  costumeName: string;
  tenAo: string; // Tương thích ngược với Sổ Phối
  loiVao: string;
  suKienHoacTieuChi: string;
  occasion: string;
  region: string;
  color: string;
  colorHex: string;
  accessories: string[];
  style: string;
  culturalStatus: 'on' | 'can-luu-y' | 'da-kiem-chung' | 'dang-cho-danh-gia';
  mauChuDao: string;
  phuKien: string;
  phongCach: string;
  trangThaiGiuNep: 'on' | 'can-luu-y';
  thoiGianLuu: string;
  whyItWorks?: string;
  colorHarmony?: {
    score: number;
    level: string;
    primaryColor: string;
    primaryHex: string;
    secondaryColors: string[];
    explanation: string;
    suggestions: string[];
  };
  culturalCheck?: {
    score: number;
    status: 'green' | 'yellow' | 'red';
    label: string;
    category: 'truyen-thong' | 'cach-tan' | 'can-luu-y';
    reasons: string[];
    suggestions: string[];
  };
  stylistAdvice?: {
    title: string;
    outfitDescription: string;
    whyItWorks: string;
    colorAdvice: string;
    accessoryAdvice: string;
    styleAdvice: string;
    culturalNote: string;
  };
}
