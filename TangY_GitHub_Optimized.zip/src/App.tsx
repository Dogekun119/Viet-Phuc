import React, { useEffect, useRef, useState } from 'react';
import gsap from 'gsap';
import { ScreenId } from './types';
import { Item, SavedUserOutfit } from './domain/types';
import { ALL_ITEMS } from './domain/dataAdapter';
import { Navbar } from './components/Navbar';
import { KhoiDauScreen } from './components/screens/KhoiDauScreen';
import { CatalogScreen } from './components/screens/CatalogScreen';
import { ItemDetailScreen } from './components/screens/ItemDetailScreen';
import { OutfitBuilderScreen } from './components/screens/OutfitBuilderScreen';
import { CompareScreen } from './components/screens/CompareScreen';
import { LookbookScreen } from './components/screens/LookbookScreen';
import { NguonVaLoiNhanScreen } from './components/screens/NguonVaLoiNhanScreen';
import { GlobalLotusBackground } from './components/GlobalLotusBackground';
import { AdvisorDrawer } from './components/advisor/AdvisorDrawer';
import {
  prefersReducedMotion,
  useLenisSmoothScroll,
} from './components/motion/MotionPrimitives';

const STORAGE_KEY = 'viet_phuc_master_saved_outfits';

export default function App() {
  const [currentScreen, setCurrentScreen] = useState<ScreenId>('khoi-dau');
  const [selectedItemForDetail, setSelectedItemForDetail] = useState<Item>(
    ALL_ITEMS[0] || ({} as Item)
  );
  const [builderItems, setBuilderItems] = useState<Item[]>([]);
  const [isAdvisorOpen, setIsAdvisorOpen] = useState(false);

  // Persistent storage for saved user outfits
  const [savedOutfits, setSavedOutfits] = useState<SavedUserOutfit[]>(() => {
    try {
      const stored = localStorage.getItem(STORAGE_KEY);
      if (stored) {
        return JSON.parse(stored);
      }
    } catch {
      // Ignore parse errors
    }
    return [];
  });

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(savedOutfits));
    } catch {
      // Ignore quota errors
    }
  }, [savedOutfits]);

  const screenWrapperRef = useRef<HTMLElement | null>(null);

  // Initialize Lenis smooth scrolling synchronized with screen id
  useLenisSmoothScroll(`${currentScreen}-${selectedItemForDetail.id}`);

  // Page entrance transition on screen change
  useEffect(() => {
    const el = screenWrapperRef.current;
    if (!el || prefersReducedMotion()) return;

    const ctx = gsap.context(() => {
      gsap.fromTo(
        el,
        { opacity: 0 },
        {
          opacity: 1,
          duration: 0.45,
          ease: 'power2.out',
          clearProps: 'transform',
        }
      );
    }, el);

    return () => ctx.revert();
  }, [currentScreen, selectedItemForDetail.id]);

  const handleNavigate = (screen: ScreenId) => {
    setCurrentScreen(screen);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleSelectItemDetail = (item: Item) => {
    setSelectedItemForDetail(item);
    setCurrentScreen('chuyen-ao');
  };

  const handleAddItemToBuilder = (item: Item) => {
    setBuilderItems((prev) => {
      if (prev.some((i) => i.id === item.id)) return prev;
      return [...prev, item];
    });
    setCurrentScreen('phoi-phuc');
  };

  const handleSaveOutfit = (outfit: SavedUserOutfit) => {
    setSavedOutfits((prev) => [outfit, ...prev.filter((o) => o.id !== outfit.id)]);
  };

  const handleRemoveOutfit = (id: string) => {
    setSavedOutfits((prev) => prev.filter((o) => o.id !== id));
  };

  const handleCompareOutfit = (outfit: SavedUserOutfit) => {
    handleSaveOutfit(outfit);
    setCurrentScreen('so-phoi');
  };

  const handleOpenAdvisor = () => {
    setIsAdvisorOpen(true);
  };

  const handleCloseAdvisor = () => {
    setIsAdvisorOpen(false);
  };

  const handleApplyOutfitToBuilder = (items: Item[]) => {
    setBuilderItems(items);
    setCurrentScreen('phoi-phuc');
    setIsAdvisorOpen(false);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const isHomeRunway = currentScreen === 'khoi-dau';

  return (
    <div className="min-h-screen font-body flex flex-col bg-[#F4F1EA] text-[#171717] transition-colors duration-300 relative">
      {/* Global Lotus Botanical & Archival Paper Atmosphere */}
      <GlobalLotusBackground screen={currentScreen} />

      <Navbar
        currentScreen={currentScreen}
        onNavigate={handleNavigate}
        savedCount={savedOutfits.length}
        compareCount={Math.min(2, savedOutfits.length)}
        onOpenAdvisor={handleOpenAdvisor}
      />

      <main
        ref={screenWrapperRef}
        className={`relative z-10 ${
          isHomeRunway
            ? 'flex-1 w-full'
            : 'flex-1 max-w-[1440px] w-full mx-auto px-6 sm:px-10 py-6'
        }`}
      >
        {currentScreen === 'khoi-dau' && (
          <KhoiDauScreen
            onNavigate={handleNavigate}
            onStartRemixWithEntry={() => handleNavigate('phoi-phuc')}
            onOpenAdvisor={handleOpenAdvisor}
          />
        )}

        {currentScreen === 'tu-ao-xua' && (
          <CatalogScreen
            onSelectItemDetail={handleSelectItemDetail}
            onAddItemToBuilder={handleAddItemToBuilder}
          />
        )}

        {currentScreen === 'chuyen-ao' && (
          <ItemDetailScreen
            item={selectedItemForDetail}
            onBackToCatalog={() => handleNavigate('tu-ao-xua')}
            onUseInBuilder={handleAddItemToBuilder}
          />
        )}

        {currentScreen === 'phoi-phuc' && (
          <OutfitBuilderScreen
            initialSelectedItems={builderItems}
            onSaveOutfit={handleSaveOutfit}
            onCompareOutfit={handleCompareOutfit}
            onViewItemDetail={handleSelectItemDetail}
            onOpenAdvisor={handleOpenAdvisor}
          />
        )}

        {currentScreen === 'so-phoi' && (
          <CompareScreen
            savedOutfits={savedOutfits}
            onRemoveOutfit={handleRemoveOutfit}
            onGoToBuilder={() => handleNavigate('phoi-phuc')}
          />
        )}

        {currentScreen === 'lookbook' && (
          <LookbookScreen
            savedOutfits={savedOutfits}
            onGoToBuilder={() => handleNavigate('phoi-phuc')}
          />
        )}

        {currentScreen === 'nguon-loi-nhan' && <NguonVaLoiNhanScreen />}
      </main>

      {/* Floating Occasion Advisor Launcher Button */}
      <div className="fixed bottom-6 right-6 z-40">
        <button
          type="button"
          onClick={handleOpenAdvisor}
          className="group flex items-center gap-2.5 px-4 py-2.5 rounded-full bg-[#171717] hover:bg-[#A63D2F] text-[#FBF9F5] shadow-xl hover:shadow-2xl transition-all duration-300 cursor-pointer border border-[#C8A97E]/30"
          title="Mở Cố Vấn Tàng Y (Việt Phục Occasion Advisor)"
        >
          <span className="w-5 h-5 rounded-full bg-[#A63D2F] group-hover:bg-white text-white group-hover:text-[#A63D2F] text-[10px] font-raven font-bold flex items-center justify-center transition-colors">
            藏
          </span>
          <span className="font-raven text-xs uppercase tracking-wider font-medium">
            Hôm nay mặc gì?
          </span>
        </button>
      </div>

      {/* Tàng Y Occasion Advisor Drawer */}
      <AdvisorDrawer
        isOpen={isAdvisorOpen}
        onClose={handleCloseAdvisor}
        onApplyOutfitToBuilder={handleApplyOutfitToBuilder}
        onViewItemDetail={handleSelectItemDetail}
      />

      <footer className="border-t py-12 px-6 sm:px-10 relative z-10 border-[#141312]/15 bg-[#EFECE5]/80 text-[#6E675F] mt-16">
        <div className="max-w-[1440px] mx-auto flex flex-col sm:flex-row items-start sm:items-center justify-between gap-6 text-xs">
          <div className="flex items-center gap-3">
            <span className="font-raven text-xl font-semibold tracking-wider uppercase text-[#171717]">
              Tàng Y
            </span>
            <span className="w-4 h-4 bg-[#A63D2F] text-white text-[9px] font-raven flex items-center justify-center font-bold">
              藏
            </span>
            <span aria-hidden="true">·</span>
            <span>Việt Phục Remix — Digital Archive &amp; Cultural Architecture</span>
          </div>
          <div className="flex flex-wrap items-center gap-6 uppercase tracking-wider font-medium">
            <button
              type="button"
              onClick={() => handleNavigate('tu-ao-xua')}
              className="transition-colors duration-200 cursor-pointer hover:text-[#0D0C0B]"
            >
              Tủ Áo Xưa
            </button>
            <button
              type="button"
              onClick={() => handleNavigate('phoi-phuc')}
              className="transition-colors duration-200 cursor-pointer hover:text-[#0D0C0B]"
            >
              Phối Phục
            </button>
            <button
              type="button"
              onClick={() => handleNavigate('so-phoi')}
              className="transition-colors duration-200 cursor-pointer hover:text-[#0D0C0B]"
            >
              So Bộ &amp; Cất Giữ
            </button>
            <button
              type="button"
              onClick={() => handleNavigate('lookbook')}
              className="transition-colors duration-200 cursor-pointer hover:text-[#0D0C0B]"
            >
              Lookbook
            </button>
            <button
              type="button"
              onClick={() => handleNavigate('nguon-loi-nhan')}
              className="transition-colors duration-200 cursor-pointer hover:text-[#0D0C0B]"
            >
              Nguồn &amp; Lời Nhắn
            </button>
          </div>
        </div>
      </footer>
    </div>
  );
}
