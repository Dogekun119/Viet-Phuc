import { GoogleGenAI } from '@google/genai';

export interface GeminiStylistInput {
  costume: {
    id: string;
    name: string;
    description: string;
    origin: string;
    meaning: string;
    accessories: string[];
    sources: string[];
  };
  context: {
    occasion: string;
    region: string;
    contextStyle: string;
  };
  remix: {
    color: string;
    colorHex: string;
    accessories: string[];
    style: string;
  };
  colorHarmony: {
    score: number;
    level: string;
    explanation: string;
    suggestions: string[];
  };
  culturalCheck: {
    score: number;
    status: 'green' | 'yellow' | 'red';
    label: string;
    category: 'truyen-thong' | 'cach-tan' | 'can-luu-y';
    reasons: string[];
    suggestions: string[];
  };
}

export interface StylistAdviceOutput {
  title: string;
  outfitDescription: string;
  whyItWorks: string;
  colorAdvice: string;
  accessoryAdvice: string;
  styleAdvice: string;
  culturalNote: string;
}

/**
 * Đọc API key từ biến môi trường của project một cách an toàn, không hard-code.
 */
function getGeminiApiKey(): string {
  try {
    if (typeof import.meta !== 'undefined' && (import.meta as any).env) {
      const vKey = (import.meta as any).env.VITE_GEMINI_API_KEY || (import.meta as any).env.GEMINI_API_KEY;
      if (vKey) return vKey;
    }
  } catch {
    // Không làm gián đoạn runtime
  }

  try {
    if (typeof process !== 'undefined' && process.env) {
      const pKey = process.env.VITE_GEMINI_API_KEY || process.env.GEMINI_API_KEY;
      if (pKey) return pKey;
    }
  } catch {
    // Không làm gián đoạn runtime
  }

  return '';
}

/**
 * FALLBACK LOCAL: Trả về lời tư vấn chuyên sâu dựa trên dữ liệu hiện có
 * khi không có API key hoặc kết nối mạng bị gián đoạn.
 */
export function getFallbackStylistAdvice(input: GeminiStylistInput): StylistAdviceOutput {
  const { costume, context, remix, colorHarmony, culturalCheck } = input;

  const isGreen = culturalCheck.status === 'green';
  const isRed = culturalCheck.status === 'red';
  const isCachTan = culturalCheck.category === 'cach-tan';

  const title = `${costume.name} ${remix.style} · Sắc ${remix.color} (${context.occasion})`;

  const outfitDescription = `Bộ phối ${costume.name} trong gam sắc ${remix.color.toLowerCase()} (${remix.colorHex}), định hình theo phong cách ${remix.style.toLowerCase()}, hướng đến bối cảnh ${context.occasion.toLowerCase()} tại ${context.region}.`;

  let whyItWorks = '';
  if (isGreen) {
    whyItWorks = `Phom dáng ${costume.name} kết hợp cùng sắc ${remix.color.toLowerCase()} tạo nên tổng thể trang nhã, đúng tinh thần trang phục. ${colorHarmony.explanation}`;
  } else if (isRed) {
    whyItWorks = `Tổ hợp mang đậm tính thể nghiệm cá nhân, tuy nhiên đang có sự lệch pha rõ rệt giữa phom dáng và bối cảnh quy ước. Cần điều chỉnh để đạt độ cân bằng mỹ cảm.`;
  } else {
    whyItWorks = `Tổ hợp thể hiện nét sáng tạo mới mẻ khi đưa tinh thần ${remix.style.toLowerCase()} vào ${costume.name}. ${colorHarmony.explanation}`;
  }

  const colorAdvice = `Sắc ${remix.color} đóng vai trò chủ đạo đạt mức "${colorHarmony.level}" (${colorHarmony.score}/100). ${
    colorHarmony.suggestions.length > 0
      ? colorHarmony.suggestions[0]
      : 'Nên kết hợp cùng các chi tiết phụ mang sắc thái trung tính để làm dịu tổng thể.'
  }`;

  let accessoryAdvice = '';
  if (remix.accessories.length > 0) {
    accessoryAdvice = `Phụ kiện đang chọn: ${remix.accessories.join(', ').toLowerCase()}. ${
      culturalCheck.suggestions.length > 0
        ? culturalCheck.suggestions[0]
        : 'Số lượng phụ kiện vừa vặn, giữ được sự thanh thoát cho dáng áo.'
    }`;
  } else {
    accessoryAdvice = `Hiện chưa phối kèm phụ kiện. Với dáng ${costume.name}, bạn có thể điểm xuyết thêm 1 món đặc trưng như ${
      costume.accessories[0] || 'kiềng bạc hoặc nón lá'
    } để tăng điểm nhấn thị giác.`;
  }

  let styleAdvice = '';
  if (isCachTan) {
    styleAdvice = `Phong cách ${remix.style} mang lại làn gió trẻ trung, phóng khoáng cho ${costume.name}. Đây là lối phối cách tân đương đại, không nên xem như một bộ phục dựng nguyên bản.`;
  } else {
    styleAdvice = `Phong cách ${remix.style} nhấn mạnh sự chuẩn mực, trang nghiêm và nét tao nhã truyền thống vốn có của ${costume.name}.`;
  }

  let culturalNote = '';
  if (isRed) {
    culturalNote = `CẢNH BÁO VĂN HÓA: Tổ hợp đang có sự xung đột quy thức (${culturalCheck.reasons.join('; ')}). Cultural Check khuyến nghị điều chỉnh lại phụ kiện hoặc bối cảnh để tôn trọng giá trị truyền thống.`;
  } else if (culturalCheck.status === 'yellow') {
    culturalNote = `LƯU Ý VĂN HÓA: ${culturalCheck.reasons[0] || 'Bộ phối mang tính thử nghiệm, cần lưu ý khi xuất hiện tại các không gian nghi lễ cổ truyền.'}`;
  } else {
    culturalNote = `LƯU Ý VĂN HÓA: Bộ phối phù hợp với bối cảnh ${context.occasion} và giữ được đặc điểm nhận diện cốt lõi của ${costume.name}.`;
  }

  return {
    title,
    outfitDescription,
    whyItWorks,
    colorAdvice,
    accessoryAdvice,
    styleAdvice,
    culturalNote,
  };
}

/**
 * GỌI GEMINI AI STYLIST
 * 
 * - Sử dụng @google/genai SDK
 * - Tuân thủ system instructions nghiêm ngặt (không bịa lịch sử, không quyết định đúng sai văn hóa)
 * - Tự động fallback nếu không có API key hoặc gặp lỗi mạng/parse.
 */
export async function getGeminiStylistAdvice(
  input: GeminiStylistInput
): Promise<StylistAdviceOutput> {
  const apiKey = getGeminiApiKey();

  // Nếu không có API key, sử dụng ngay fallback local mượt mà
  if (!apiKey) {
    return getFallbackStylistAdvice(input);
  }

  try {
    const ai = new GoogleGenAI({ apiKey });

    const systemInstruction = `Bạn là AI Stylist cho ứng dụng Việt Phục Remix (Tàng Y Các).
Nhiệm vụ của bạn là tư vấn phối đồ hiện đại dựa trên dữ liệu người dùng cung cấp.

QUY TẮC BẮT BUỘC:
1. Chỉ sử dụng thông tin được cung cấp trong input.
2. Không tự bịa lịch sử, nguồn gốc, niên đại hoặc ý nghĩa văn hóa.
3. Không tạo nguồn tư liệu giả hay liên kết giả.
4. Không tự xác nhận một bộ phối là "đúng lịch sử".
5. Không thay thế Cultural Check. Cultural Check (RULE-BASED) là nguồn đánh giá văn hóa chính.
6. Nếu Cultural Check là "cách tân", phải giữ cách diễn đạt rằng đây là phối cách tân, không phải phục dựng nguyên bản.
7. Nếu Cultural Check là "cần lưu ý" hoặc "cần điều chỉnh", phải ưu tiên cảnh báo rõ điểm cần lưu ý và không khuyến khích giữ nguyên tổ hợp.
8. Nếu Cultural Check là "phù hợp", hãy tập trung tối ưu thẩm mỹ, màu sắc, phụ kiện và phong cách.
9. Viết ngắn gọn, dễ hiểu bằng tiếng Việt chuẩn mực, thanh lịch.
10. Không dùng ngôn ngữ quá quảng cáo hoặc phóng đại.
11. BẮT BUỘC trả về DUY NHẤT một chuỗi JSON hợp lệ tuân thủ schema, không bọc markdown hay thêm bất kỳ văn bản nào ngoài JSON.`;

    const promptText = `Dữ liệu phối trang phục của người dùng:
${JSON.stringify(input, null, 2)}

Hãy đóng vai trò AI Stylist và trả về JSON theo schema:
{
  "title": "Tiêu đề ngắn gọn cho bộ phối",
  "outfitDescription": "Mô tả tổng quan bộ phối",
  "whyItWorks": "Lý giải vì sao bộ phối này hợp từ góc nhìn thẩm mỹ",
  "colorAdvice": "Lời khuyên về màu sắc chủ đạo và màu bổ trợ",
  "accessoryAdvice": "Lời khuyên về cách chọn hoặc tiết chế phụ kiện",
  "styleAdvice": "Lời khuyên về phong cách thể hiện",
  "culturalNote": "Lưu ý văn hóa dựa trên kết quả Cultural Check"
}`;

    const response = await ai.models.generateContent({
      model: 'gemini-3.8-flash',
      contents: promptText,
      config: {
        systemInstruction,
        responseMimeType: 'application/json',
      },
    });

    const responseText = response.text?.trim() || '';
    if (!responseText) {
      return getFallbackStylistAdvice(input);
    }

    // Làm sạch trường hợp model bọc json trong ```json ... ```
    let cleanJson = responseText;
    if (cleanJson.startsWith('```')) {
      cleanJson = cleanJson.replace(/^```(?:json)?\s*/i, '').replace(/\s*```$/, '');
    }

    const parsed = JSON.parse(cleanJson) as StylistAdviceOutput;

    // Kiểm tra tính hợp lệ của các trường bắt buộc
    if (
      parsed.title &&
      parsed.outfitDescription &&
      parsed.whyItWorks &&
      parsed.colorAdvice &&
      parsed.accessoryAdvice &&
      parsed.styleAdvice &&
      parsed.culturalNote
    ) {
      return parsed;
    }

    return getFallbackStylistAdvice(input);
  } catch (error) {
    console.warn('Gemini Stylist error, using local fallback advice:', error);
    return getFallbackStylistAdvice(input);
  }
}
