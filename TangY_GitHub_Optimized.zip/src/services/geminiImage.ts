import { Item, OutfitEvaluation } from '../domain/types';
import { CANONICAL_ENTITIES_MAP } from '../domain/canonicalData';

export type GenerationMode =
  | 'single_item_try_on'
  | 'reference_image_edit'
  | 'complete_outfit_try_on';

export interface ImageGenerationRequest {
  requestId: string;
  mode: GenerationMode;
  gender: 'female' | 'male';
  selectedItemIds: string[];
  referenceItemId?: string;
  customPrompt?: string;
  prompt?: string;
  outfitTitle?: string;
  evaluation?: OutfitEvaluation;
  evaluationSummary?: string;
  compatibilityConstraints?: string[];
}

export interface ImageGenerationResult {
  ok: boolean;
  imageUrl?: string;
  label: string;
  disclaimer: string;
  promptUsed: string;
  serviceUsed: string;
  isFallback: boolean;
  mode: GenerationMode;
  requestId: string;
  error?: string;
  errorType?: string;
}

/**
 * Tra cứu file ảnh tham chiếu đã xác thực cho từng thực thể
 */
export const VERIFIED_REFERENCE_ASSET_MAP: Record<string, string> = {
  G001: 'tu_ao_ao_giao_linh_1791540421433.jpg',
  G002: 'tu_ao_truc_linh_1791590575147.jpg',
  G003: 'tu_ao_doi_kham_1791590587462.jpg',
  G006: 'tu_ao_vien_linh_1791590597639.jpg',
  G007: 'ao_tu_dien_1791596749479.jpg',
  G008: 'tu_ao_ao_ngu_than_1791540362301.jpg',
  G009: 'tu_ao_ao_tac_1791590607100.jpg',
  G010: 'tu_ao_ao_tu_than_1791540316824.jpg',
  G011: 'tu_ao_yem_dao_1791590619474.jpg',
  G012: 'tu_ao_vay_dup_1791591661475.jpg',
  G013: 'tu_ao_quan_trang_1791591672868.jpg',
  G014: 'tu_ao_quan_la_toa_1791593055198.jpg',
  G015: 'tu_ao_kho_dan_gian_1791593067158.jpg',
  G016: 'tu_ao_bo_phuc_1791591685057.jpg',
  G017: 'tu_ao_bo_tu_1791592305808.jpg',
  G018: 'tu_ao_ao_nhat_binh_1791540457083.jpg',
  G019: 'ao_menh_phu_1791596761598.jpg',
  G020: 'tu_ao_mang_bao_1791592317711.jpg',
  G021: 'tu_ao_mang_lan_1791593078866.jpg',
  G022: 'tu_ao_long_bao_1791541769402.jpg',
  G023: 'tu_ao_hoang_bao_1791591697522.jpg',
  G024: 'tu_ao_con_phuc_1791593088539.jpg',
  G025: 'tu_ao_phuong_phuc_1791591709330.jpg',
  G028: 'tu_ao_ao_ba_ba_1791540391970.jpg',
  G030: 'tu_ao_ao_dai_1791540293823.jpg',
  G031: 'tu_ao_khan_xep_1791591919738.jpg',
  G032: 'tu_ao_khan_vanh_day_1791541857698.jpg',
  G033: 'tu_ao_khan_mo_qua_1791591931180.jpg',
  G034: 'tu_ao_khan_ran_1791541960369.jpg',
  G035: 'tu_ao_non_la_1791591940904.jpg',
  G036: 'tu_ao_non_ba_tam_1791541813772.jpg',
  G037: 'tu_ao_non_thung_1791593237981.jpg',
  G038: 'tu_ao_non_bai_tho_1791592327797.jpg',
  G039: 'tu_ao_mu_canh_chuon_1791591950697.jpg',
  G040: 'tu_ao_van_kien_1791592339952.jpg',
  G041: 'tu_ao_tram_cai_toc_1791593137036.jpg',
  G042: 'tu_ao_dai_that_lung_1791593101752.jpg',
  G043: 'tu_ao_day_ruot_tuong_1791593147548.jpg',
  G044: 'tu_ao_the_hot_quan_1791593160009.jpg',
  G045: 'tu_ao_hia_quan_1791592350888.jpg',
  G046: 'tu_ao_hai_theu_1791541907877.jpg',
  G047: 'tu_ao_guoc_moc_1791591962889.jpg',
  A011: 'tu_ao_quat_lua_co_1791593170321.jpg',
  A012: 'tu_ao_the_bai_quan_1791593182172.jpg',
};

/**
 * Kiểm tra xem một item có phải phụ kiện không
 */
export function isAccessoryItem(item: Item | { id: string; name?: string; category?: string }): boolean {
  const id = item.id;
  const name = (item.name || '').toLowerCase();
  const cat = (item.category || '').toLowerCase();

  // Headwear, belts, jewelry, handheld, footwear are accessories
  if (
    [
      'G031', 'G032', 'G033', 'G034', 'G035', 'G036', 'G037', 'G038', 'G039',
      'G040', 'G041', 'G042', 'G043', 'G044', 'G045', 'G046', 'G047',
      'A011', 'A012',
    ].includes(id)
  ) {
    return true;
  }

  return (
    cat.includes('phụ kiện') ||
    cat.includes('khăn') ||
    cat.includes('nón') ||
    cat.includes('mũ') ||
    cat.includes('thắt lưng') ||
    cat.includes('giày') ||
    cat.includes('guốc') ||
    name.includes('khăn') ||
    name.includes('nón') ||
    name.includes('mũ') ||
    name.includes('thắt lưng') ||
    name.includes('đai') ||
    name.includes('trâm') ||
    name.includes('quạt') ||
    name.includes('hài') ||
    name.includes('guốc') ||
    name.includes('hia') ||
    name.includes('thẻ bài')
  );
}

/**
 * Xác định phân loại vai trò cấu trúc của y phục
 */
export function getItemStructuralRole(item: Item | { id: string; name?: string }): string {
  const id = item.id;
  const name = (item.name || '').toLowerCase();
  if (['G011'].includes(id) || name.includes('yếm')) return 'inner_undergarment';
  if (['G012'].includes(id) || name.includes('váy')) return 'lower_skirt';
  if (['G013', 'G014', 'G015'].includes(id) || name.includes('quần') || name.includes('khố')) return 'lower_trousers';
  if (['G031', 'G032', 'G033', 'G034', 'G035', 'G036', 'G037', 'G038', 'G039'].includes(id)) return 'headwear';
  if (['G042', 'G043'].includes(id) || name.includes('thắt lưng') || name.includes('đai')) return 'belt';
  if (['G045', 'G046', 'G047'].includes(id) || name.includes('hài') || name.includes('guốc') || name.includes('hia')) return 'footwear';
  if (['G040'].includes(id) || name.includes('vân kiên')) return 'collar_cape';
  if (['G017'].includes(id) || name.includes('bổ tử')) return 'rank_badge';
  if (['G041'].includes(id) || name.includes('trâm')) return 'hairpin';
  if (['A011'].includes(id) || name.includes('quạt')) return 'handheld_fan';
  return 'main_garment';
}

/**
 * 1. Single Item Prompt Builder:
 * Bảo tồn tuyệt đối y phục đơn lẻ hoặc phụ kiện đơn lẻ được chọn.
 * KHÔNG tự ý bịa thêm một bộ cổ phục hoàn chỉnh khi người dùng chỉ chọn một món.
 */
export function buildSingleItemPrompt(
  item: Item,
  gender: 'female' | 'male'
): string {
  const isFemale = gender === 'female';
  const modelGenderText = isFemale
    ? 'adult Vietnamese female model with dark hair tied in a clean natural bun, calm poised posture, standing full-body facing camera'
    : 'adult Vietnamese male model with natural dark hair, standing upright dignified posture, full-body facing camera';

  const isAccessory = isAccessoryItem(item);
  const role = getItemStructuralRole(item);

  // Lấy dữ liệu khảo cứu chi tiết từ canonical entity nếu có
  const canonical = CANONICAL_ENTITIES_MAP.get(`CANON_${item.id}`) || CANONICAL_ENTITIES_MAP.get(item.id);
  const construction = canonical?.constructionNotes || item.construction || '';
  const period = (canonical?.periods && canonical.periods.length > 0 ? canonical.periods[0] : item.period?.[0]) || 'Việt Nam truyền thống';

  if (isAccessory) {
    let placementInstruction = '';
    if (role === 'headwear') {
      placementInstruction = `The model is wearing ONLY the traditional Vietnamese headwear: ${item.name} correctly fitted on the head.`;
    } else if (role === 'belt') {
      placementInstruction = `The model is wearing ONLY the traditional Vietnamese sash / belt: ${item.name} neatly tied around the waist.`;
    } else if (role === 'footwear') {
      placementInstruction = `The model is wearing ONLY the traditional Vietnamese footwear: ${item.name} clearly visible on the feet.`;
    } else if (role === 'handheld_fan') {
      placementInstruction = `The model is holding ONLY the traditional Vietnamese folding fan: ${item.name} elegantly in one hand.`;
    } else if (role === 'hairpin') {
      placementInstruction = `The model is wearing ONLY the traditional hairpin: ${item.name} delicately secured in the hair bun.`;
    } else {
      placementInstruction = `The model is wearing ONLY the single traditional item: ${item.name} positioned authentically.`;
    }

    return `High-end photorealistic studio photograph of the ${modelGenderText}.
SINGLE ACCESSORY FOCUS:
${placementInstruction}
Historical period / context: ${period}.
${construction ? `Item construction details: ${construction}` : ''}

STRICT CONSTRAINTS FOR SINGLE-ITEM ACCESSORY:
- PRESERVE NEUTRAL BASE MODEL: The model must wear a neutral, plain, unobtrusive ivory/light grey modern minimalist base shirt and trousers.
- DO NOT INVENT A FULL COSTUME: Absolutely do NOT generate a complete traditional ceremonial robe, dragon robe, Áo Bà Ba, Áo Nhật Bình, or Áo Tứ Thân merely because an accessory (${item.name}) was selected.
- NO UNSELECTED ACCESSORIES: Do NOT add unselected jewelry, extra hats, cloaks, scarves, or fans.
- POSITION & VISIBILITY: Make the selected accessory ${item.name} clearly visible with sharp authentic texture and craftsmanship matching the reference image.
- LIGHTING & BACKGROUND: Clean warm ivory archival studio backdrop, soft diffused fashion lighting.`;
  }

  // Single Garment Case (e.g. Áo Giao Lĩnh, Áo Tứ Thân, Áo Nhật Bình, Áo Bà Ba...)
  let silhouetteNotes = '';
  const lowerName = item.name.toLowerCase();
  if (lowerName.includes('giao lĩnh')) {
    silhouetteNotes = 'Cross-collared robe (giao lĩnh) where the left lapel crosses over the right, wide sleeves with authentic historic drape, loose graceful silhouette.';
  } else if (lowerName.includes('tứ thân')) {
    silhouetteNotes = 'Traditional Northern Vietnamese four-panel tunic (áo tứ thân) with open front showing a neutral underlayer, graceful natural drape down to calves.';
  } else if (lowerName.includes('nhật bình')) {
    silhouetteNotes = 'Rectangular-collared royal robe (áo nhật bình) with distinctive rectangular embroidered neckband, wide sleeves with five-color bands, dignified straight cut.';
  } else if (lowerName.includes('ngũ thân')) {
    silhouetteNotes = 'Five-panel standing collar tunic (áo ngũ thân lập lĩnh) with 5 buttons along right closure, fitted or loose traditional cut, knee to calf length.';
  } else if (lowerName.includes('tấc')) {
    silhouetteNotes = 'Ceremonial wide-sleeved five-panel robe (áo tấc) with standing collar and signature wide flowing sleeves measuring one tấc, formal drape.';
  } else if (lowerName.includes('bà ba')) {
    silhouetteNotes = 'Southern Vietnamese Áo Bà Ba tunic with modest curved neckline, front button closure, side slit hems, clean casual drape.';
  } else if (lowerName.includes('dài')) {
    silhouetteNotes = 'Traditional Vietnamese Áo Dài with standing collar, side button closure, two flowing floor-length panels.';
  }

  return `High-end photorealistic editorial studio photograph of the ${modelGenderText}.
SINGLE GARMENT MODE:
The model is wearing ONLY the specific traditional Vietnamese garment: "${item.name}".
Historical context: ${period}.
${silhouetteNotes ? `Silhouette & Cut: ${silhouetteNotes}` : ''}
${construction ? `Construction specifications: ${construction}` : ''}

STRICT CONSTRAINTS FOR SINGLE GARMENT:
- ACCURATE GARMENT FIDELITY: Faithfully render "${item.name}" matching the exact cut, collar style, sleeve width, closure, and fabric texture from the reference image.
- NEUTRAL MODEST BASE LAYER ONLY: Use only an unobtrusive, plain neutral white/ivory base undergarment and straight trousers for modesty. Do NOT treat this base layer as another historical outer costume.
- DO NOT ADD UNSELECTED CLOTHING: Do NOT add unselected outer coats, unselected hats (nón lá, khăn vành), unselected sashes, unselected jewelry, or unselected embroidered patches.
- DO NOT SUBSTITUTE GARMENT: Do NOT replace "${item.name}" with a generic costume, Chinese Hanfu, or Japanese Kimono.
- BACKGROUND: Neutral warm archival studio backdrop, soft natural shadows.`;
}

/**
 * 2. Reference Image Edit Prompt Builder:
 * Sinh ảnh trực tiếp từ tư liệu tham chiếu của một hiện vật và prompt người dùng.
 */
export function buildReferenceImageEditPrompt(
  item: Item,
  customPrompt?: string,
  gender?: 'female' | 'male'
): string {
  const canonical = CANONICAL_ENTITIES_MAP.get(`CANON_${item.id}`) || CANONICAL_ENTITIES_MAP.get(item.id);
  const construction = canonical?.constructionNotes || item.construction || '';
  const period = (canonical?.periods && canonical.periods.length > 0 ? canonical.periods[0] : item.period?.[0]) || 'Việt Nam truyền thống';

  const userDirective = customPrompt?.trim()
    ? `USER EDITORIAL DIRECTIVE: ${customPrompt.trim()}`
    : 'Produce an ultra-high fidelity, photorealistic archival visualization of this exact garment.';

  return `Masterpiece editorial photograph based strictly on the provided reference artifact of "${item.name}".
${userDirective}

GARMENT SPECIFICATIONS:
- Garment Name: ${item.name} (${canonical?.canonicalNameVi || item.name})
- Historical Period: ${period}
- Construction & Fabric: ${construction || 'Traditional Vietnamese weave and cut matching the reference'}

FIDELITY & EDITING RULES:
- STRICT REFERENCE FIDELITY: Accurately reproduce the collar cut, seam construction, textile texture (silk/brocade/gauze), and silhouette shown in the reference image.
- REALISTIC TEXTILES: Natural fabric draping, authentic weave details, soft creases at joints, realistic lighting reflections.
- NO UNRELATED FANTASY ELEMENTS: Strictly avoid fantasy costumes, non-Vietnamese traditional features, or generic synthetic anime styles.
- Professional archival museum lighting and presentation.`;
}

/**
 * 3. Complete Outfit Try-On Prompt Builder:
 * Sinh ảnh cho bộ phối hoàn chỉnh đã chọn từ Outfit Builder.
 */
export function buildCompleteOutfitPrompt(
  selectedItems: Item[],
  evaluation: OutfitEvaluation | undefined,
  gender: 'female' | 'male',
  outfitTitle: string
): string {
  const isFemale = gender === 'female';
  const modelGenderText = isFemale
    ? 'adult Vietnamese female model with dark hair tied back in natural gentle bun, calm graceful posture, standing full-body facing camera'
    : 'adult Vietnamese male model with short dark hair, standing upright dignified posture, full-body facing camera';

  // Sắp xếp thứ tự lớp: Nội y -> Áo ngoài -> Thân dưới -> Khăn/Nón -> Thắt lưng -> Phụ kiện -> Giày dép
  const innerItems = selectedItems.filter((i) => getItemStructuralRole(i) === 'inner_undergarment');
  const outerItems = selectedItems.filter((i) => getItemStructuralRole(i) === 'main_garment' || getItemStructuralRole(i) === 'collar_cape' || getItemStructuralRole(i) === 'rank_badge');
  const lowerItems = selectedItems.filter((i) => getItemStructuralRole(i) === 'lower_skirt' || getItemStructuralRole(i) === 'lower_trousers');
  const headItems = selectedItems.filter((i) => getItemStructuralRole(i) === 'headwear');
  const beltItems = selectedItems.filter((i) => getItemStructuralRole(i) === 'belt');
  const footItems = selectedItems.filter((i) => getItemStructuralRole(i) === 'footwear');
  const otherAccs = selectedItems.filter((i) =>
    !innerItems.includes(i) &&
    !outerItems.includes(i) &&
    !lowerItems.includes(i) &&
    !headItems.includes(i) &&
    !beltItems.includes(i) &&
    !footItems.includes(i)
  );

  const layerList: string[] = [];
  if (innerItems.length > 0) {
    layerList.push(`• LỚP TRONG (INNER BASE): ${innerItems.map((i) => i.name).join(', ')}`);
  }
  if (outerItems.length > 0) {
    layerList.push(`• ÁO CHÍNH / ÁO NGOÀI (MAIN ROBES): ${outerItems.map((i) => i.name).join(', ')}`);
  }
  if (lowerItems.length > 0) {
    layerList.push(`• THÂN DƯỚI (LOWER BODY): ${lowerItems.map((i) => i.name).join(', ')}`);
  }
  if (headItems.length > 0) {
    layerList.push(`• KHĂN / NÓN (HEADWEAR): ${headItems.map((i) => i.name).join(', ')}`);
  }
  if (beltItems.length > 0) {
    layerList.push(`• THẮT LƯNG (WAIST SASH): ${beltItems.map((i) => i.name).join(', ')}`);
  }
  if (footItems.length > 0) {
    layerList.push(`• GIÀY / GUỐC (FOOTWEAR): ${footItems.map((i) => i.name).join(', ')}`);
  }
  if (otherAccs.length > 0) {
    layerList.push(`• PHỤ KIỆN (ACCESSORIES): ${otherAccs.map((i) => i.name).join(', ')}`);
  }

  // Compatibility & Cultural Constraints
  const warnings = evaluation?.warnings || [];
  const evalNotes = evaluation?.summary ? `Cultural styling context: ${evaluation.summary}` : '';

  return `High-end photorealistic editorial studio photograph of the ${modelGenderText}.
COMPLETE OUTFIT ENSEMBLE: "${outfitTitle}"
The model is wearing the coordinated authentic Vietnamese traditional outfit composed of these EXACT selected layers:
${layerList.join('\n')}

${evalNotes}
${warnings.length > 0 ? `Historical accuracy notes to respect: ${warnings.join('; ')}` : ''}

CRITICAL FIDELITY REQUIREMENTS:
- PRESERVE EVERY SELECTED ITEM: Render each chosen item in its proper historical position and layering role.
- DO NOT ADD UNSELECTED ITEMS: Absolutely do NOT add random headpieces, scarves, robes, or weapons that were not selected.
- NO CULTURAL SUBSTITUTION: Keep Vietnamese traditional construction (Áo Giao Lĩnh, Áo Tứ Thân, Áo Ngũ Thân, Áo Nhật Bình). Do NOT convert to Chinese Hanfu or Japanese Kimono.
- TEXTILE QUALITY: Natural drape, authentic silk/linen folds, realistic fabric sheen, shadows between overlapping garment layers.
- BACKGROUND: Neutral warm ivory studio background with soft museum-quality lighting.`;
}

/**
 * Bộ sinh cache key xác định cho mọi yêu cầu
 */
export function buildImageCacheKey(params: {
  mode: GenerationMode;
  gender: 'female' | 'male';
  itemIds: string[];
  customPrompt?: string;
  referenceItemId?: string;
}): string {
  const sortedIds = [...params.itemIds].sort().join(',');
  const promptPart = (params.customPrompt || '').trim().slice(0, 80);
  const refPart = params.referenceItemId || '';
  return `${params.mode}:${params.gender}:${sortedIds}:${refPart}:${promptPart}`;
}

// Client-side cache lưu trữ kết quả theo cache key
const imageResultCache = new Map<string, ImageGenerationResult>();

/**
 * Xóa toàn bộ client cache (dùng cho tests hoặc khi reset)
 */
export function clearImageResultCache(): void {
  imageResultCache.clear();
}

/**
 * Thực hiện yêu cầu sinh ảnh thống nhất hỗ trợ cả 3 chế độ:
 * - `single_item_try_on`
 * - `reference_image_edit`
 * - `complete_outfit_try_on`
 */
export async function generateUnifiedImage(
  req: ImageGenerationRequest
): Promise<ImageGenerationResult> {
  const disclaimer = 'MINH HỌA AI · KHÔNG PHẢI ẢNH TƯ LIỆU LỊCH SỬ';
  const label =
    req.mode === 'reference_image_edit'
      ? 'MINH HỌA AI TẠO & CHỈNH ẢNH'
      : req.mode === 'single_item_try_on'
      ? 'MINH HỌA AI THỬ TRANG PHỤC ĐƠN MÓN'
      : 'MINH HỌA AI THỬ PHỐI BỘ TRÊN NGƯỜI';

  // 1. Kiểm tra tính hợp lệ của danh sách món đồ
  if (!req.selectedItemIds || req.selectedItemIds.length === 0) {
    if (!req.referenceItemId) {
      return {
        ok: false,
        label,
        disclaimer,
        promptUsed: '',
        serviceUsed: 'none',
        isFallback: false,
        mode: req.mode,
        requestId: req.requestId,
        error: 'Vui lòng chọn ít nhất một trang phục trước khi yêu cầu tạo ảnh.',
      };
    }
  }

  // 2. Kiểm tra Cache
  const cacheKey = buildImageCacheKey({
    mode: req.mode,
    gender: req.gender,
    itemIds: req.selectedItemIds,
    customPrompt: req.customPrompt,
    referenceItemId: req.referenceItemId,
  });

  if (imageResultCache.has(cacheKey)) {
    const cached = imageResultCache.get(cacheKey)!;
    // Đảm bảo requestId phản ánh đúng request hiện tại
    return {
      ...cached,
      requestId: req.requestId,
    };
  }

  // 3. Xây dựng prompt động dựa trên mode và dữ liệu thực tế
  let prompt = req.prompt || '';
  if (!prompt) {
    if (req.mode === 'single_item_try_on') {
      const singleId = req.selectedItemIds[0] || req.referenceItemId;
      const canonical = CANONICAL_ENTITIES_MAP.get(`CANON_${singleId}`) || CANONICAL_ENTITIES_MAP.get(singleId!);
      const itemObj: Item = canonical?.asItem || ({ id: singleId!, name: canonical?.canonicalNameVi || singleId! } as Item);
      prompt = buildSingleItemPrompt(itemObj, req.gender);
    } else if (req.mode === 'reference_image_edit') {
      const refId = req.referenceItemId || req.selectedItemIds[0];
      const canonical = CANONICAL_ENTITIES_MAP.get(`CANON_${refId}`) || CANONICAL_ENTITIES_MAP.get(refId!);
      const itemObj: Item = canonical?.asItem || ({ id: refId!, name: canonical?.canonicalNameVi || refId! } as Item);
      prompt = buildReferenceImageEditPrompt(itemObj, req.customPrompt, req.gender);
    } else {
      // Complete outfit
      const items = req.selectedItemIds
        .map((id) => CANONICAL_ENTITIES_MAP.get(`CANON_${id}`)?.asItem || CANONICAL_ENTITIES_MAP.get(id)?.asItem)
        .filter((i): i is Item => Boolean(i));
      prompt = buildCompleteOutfitPrompt(items, req.evaluation, req.gender, req.outfitTitle || 'Việt Phục');
    }
  }

  // 4. Gửi yêu cầu đến backend proxy /api/try-on
  try {
    const response = await fetch('/api/try-on', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        requestId: req.requestId,
        mode: req.mode,
        gender: req.gender,
        selectedItemIds: req.selectedItemIds,
        referenceItemId: req.referenceItemId,
        customPrompt: req.customPrompt,
        outfitTitle: req.outfitTitle,
        prompt,
      }),
    });

    const data = await response.json().catch(() => null);

    if (response.ok && data && data.ok && data.imageUrl) {
      const result: ImageGenerationResult = {
        ok: true,
        imageUrl: data.imageUrl,
        label,
        disclaimer,
        promptUsed: prompt,
        serviceUsed: data.serviceUsed || 'gemini-3.1-flash-lite-image (Nano Banana)',
        isFallback: Boolean(data.isFallback),
        mode: req.mode,
        requestId: req.requestId,
      };
      // Lưu kết quả vào cache
      imageResultCache.set(cacheKey, result);
      return result;
    }

    // Xử lý lỗi một cách trung thực và rõ ràng
    const errorMessage =
      data?.error ||
      (response.status === 429
        ? 'Dịch vụ tạo ảnh hiện đã vượt hạn mức yêu cầu (Quota Exceeded). Vui lòng thử lại sau.'
        : 'Dịch vụ tạo ảnh không thể hoàn thành yêu cầu lúc này. Vui lòng bấm "Thử lại".');

    return {
      ok: false,
      label,
      disclaimer,
      promptUsed: prompt,
      serviceUsed: data?.serviceUsed || 'gemini-3.1-flash-lite-image',
      isFallback: false,
      mode: req.mode,
      requestId: req.requestId,
      error: errorMessage,
      errorType: data?.errorType || (response.status === 429 ? 'QUOTA_EXCEEDED' : 'API_ERROR'),
    };
  } catch (err: any) {
    console.warn('Backend /api/try-on request failed:', err);
    return {
      ok: false,
      label,
      disclaimer,
      promptUsed: prompt,
      serviceUsed: 'none',
      isFallback: false,
      mode: req.mode,
      requestId: req.requestId,
      error: 'Không thể kết nối đến máy chủ tạo ảnh. Vui lòng kiểm tra kết nối và bấm "Thử lại".',
      errorType: 'NETWORK_ERROR',
    };
  }
}
