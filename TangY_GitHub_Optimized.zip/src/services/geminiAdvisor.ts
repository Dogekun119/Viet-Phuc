/**
 * GEMINI VIỆT PHỤC OCCASION ADVISOR SERVICE (CLIENT-SIDE)
 * 
 * - Gửi tin nhắn đa lượt đến backend proxy `/api/advisor/chat`
 * - Không để lộ API key ra phía browser/client
 * - Tự động fallback sang advisorEngine local nếu server bị gián đoạn
 * - Đảm bảo trải nghiệm tức thì, không bao giờ crash hay gián đoạn
 */

import {
  AdvisorResponse,
  ChatMessage,
  generateAdvisorResponse,
  resolveRecommendation,
  OutfitRecommendation,
} from '../domain/advisorEngine';

export interface SendMessageOptions {
  message: string;
  history?: Array<{ role: 'user' | 'model'; text: string }>;
  userDate?: string;
  location?: string;
}

export async function sendAdvisorMessage(
  options: SendMessageOptions
): Promise<AdvisorResponse> {
  const { message, history = [], userDate, location } = options;

  const localDate =
    userDate ||
    new Date().toLocaleDateString('vi-VN', {
      weekday: 'long',
      day: '2-digit',
      month: '2-digit',
      year: 'numeric',
    });

  try {
    const response = await fetch('/api/advisor/chat', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        message,
        history: history.slice(-6),
        userDate: localDate,
        location,
      }),
    });

    if (response.ok) {
      const data = await response.json();
      if (data && data.ok && data.data && typeof data.data.message === 'string') {
        const advData = data.data as AdvisorResponse;

        // Đảm bảo các khuyến nghị đã được resolve đầy đủ
        if (Array.isArray(advData.recommendations)) {
          advData.recommendations = advData.recommendations
            .map((r: any) => resolveRecommendation(r))
            .filter((r): r is OutfitRecommendation => Boolean(r));
        }

        return advData;
      }
    }
  } catch (error) {
    console.warn('Backend advisor route unavailable, using local advisor engine:', error);
  }

  // Fallback an toàn, tức thì từ advisorEngine
  return generateAdvisorResponse(message, localDate, location);
}

/**
 * Khởi tạo tin nhắn chào ban đầu của Cố Vấn Tàng Y
 */
export function getInitialAdvisorMessage(): ChatMessage {
  const localDate = new Date().toLocaleDateString('vi-VN', {
    weekday: 'long',
    day: '2-digit',
    month: '2-digit',
    year: 'numeric',
  });

  const initialResponse = generateAdvisorResponse('', localDate);

  return {
    id: `msg_init_${Date.now()}`,
    role: 'model',
    text: initialResponse.message,
    timestamp: new Date().toLocaleTimeString('vi-VN', { hour: '2-digit', minute: '2-digit' }),
    recommendations: initialResponse.recommendations,
    quickActions: initialResponse.quickActions,
    dateContext: localDate,
  };
}
