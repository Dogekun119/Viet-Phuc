import { ModelGender, Item, OutfitEvaluation } from '../domain/types';
import { GarmentLayerData, GARMENT_LAYER_ORDER } from '../domain/garmentLayers';
import femaleBaseModelImage from '../assets/images/female_base_model_1791456212298.jpg';
import maleBaseModelImage from '../assets/images/male_base_model_1791456224566.jpg';

export interface ShareCompositionParams {
  gender: ModelGender;
  layers: GarmentLayerData[];
  selectedItems: Item[];
  outfitTitle: string;
  outfitSubLayers: string;
  evaluation: OutfitEvaluation;
  shortExplanation: string;
  statusLabel: string;
  statusColorHex?: string;
  tryOnImageUrl?: string | null;
}

export interface ShareCompositionResult {
  success: boolean;
  method: 'native_file_share' | 'native_link_share' | 'download';
  blob: Blob;
  dataUrl: string;
  filename: string;
  aborted?: boolean;
  message: string;
}

/**
 * Loads an image with timeout and CORS/SVG handling to prevent canvas hangs
 */
function loadImage(src: string, timeoutMs = 4000): Promise<HTMLImageElement | null> {
  return new Promise((resolve) => {
    let resolved = false;
    const timer = setTimeout(() => {
      if (!resolved) {
        resolved = true;
        resolve(null);
      }
    }, timeoutMs);

    const img = new Image();
    img.crossOrigin = 'anonymous';

    img.onload = () => {
      if (!resolved) {
        resolved = true;
        clearTimeout(timer);
        resolve(img);
      }
    };

    img.onerror = () => {
      // If SVG fails due to 100% dimensions, fetch and parse explicit dimensions
      if (src.endsWith('.svg') || src.includes('.svg?')) {
        fetch(src)
          .then((r) => r.text())
          .then((svgText) => {
            const fixedSvg = svgText.replace(
              /<svg([^>]*)width="100%"\s*height="100%"/i,
              '<svg$1width="896" height="1200"'
            );
            const blob = new Blob([fixedSvg], { type: 'image/svg+xml' });
            const blobUrl = URL.createObjectURL(blob);
            const fallbackImg = new Image();
            fallbackImg.onload = () => {
              URL.revokeObjectURL(blobUrl);
              if (!resolved) {
                resolved = true;
                clearTimeout(timer);
                resolve(fallbackImg);
              }
            };
            fallbackImg.onerror = () => {
              URL.revokeObjectURL(blobUrl);
              if (!resolved) {
                resolved = true;
                clearTimeout(timer);
                resolve(null);
              }
            };
            fallbackImg.src = blobUrl;
          })
          .catch(() => {
            if (!resolved) {
              resolved = true;
              clearTimeout(timer);
              resolve(null);
            }
          });
      } else {
        if (!resolved) {
          resolved = true;
          clearTimeout(timer);
          resolve(null);
        }
      }
    };

    img.src = src;
  });
}

/**
 * Helper to wrap text cleanly within canvas
 */
function wrapText(
  ctx: CanvasRenderingContext2D,
  text: string,
  x: number,
  y: number,
  maxWidth: number,
  lineHeight: number,
  maxLines = 4
): number {
  const words = text.split(' ');
  let line = '';
  let currentY = y;
  let lineCount = 0;

  for (let n = 0; n < words.length; n++) {
    const testLine = line + words[n] + ' ';
    const metrics = ctx.measureText(testLine);
    const testWidth = metrics.width;
    if (testWidth > maxWidth && n > 0) {
      lineCount++;
      if (lineCount >= maxLines) {
        ctx.fillText(line.trim() + '...', x, currentY);
        return currentY + lineHeight;
      }
      ctx.fillText(line.trim(), x, currentY);
      line = words[n] + ' ';
      currentY += lineHeight;
    } else {
      line = testLine;
    }
  }
  ctx.fillText(line.trim(), x, currentY);
  return currentY + lineHeight;
}

/**
 * Renders an archival composition specimen image on HTML5 Canvas
 */
export async function generateOutfitCompositionCanvas(
  params: ShareCompositionParams
): Promise<{ blob: Blob; dataUrl: string; filename: string }> {
  const width = 1080;
  const height = 1520;

  const canvas = document.createElement('canvas');
  canvas.width = width;
  canvas.height = height;
  const ctx = canvas.getContext('2d');

  if (!ctx) {
    throw new Error('Canvas context 2D not supported');
  }

  // 1. Background Parchment
  ctx.fillStyle = '#F5F2EB';
  ctx.fillRect(0, 0, width, height);

  // Subtle vintage gradient background
  const bgGrad = ctx.createLinearGradient(0, 0, width, height);
  bgGrad.addColorStop(0, 'rgba(255, 255, 255, 0.45)');
  bgGrad.addColorStop(0.5, 'rgba(244, 241, 234, 0.2)');
  bgGrad.addColorStop(1, 'rgba(225, 218, 204, 0.5)');
  ctx.fillStyle = bgGrad;
  ctx.fillRect(0, 0, width, height);

  // 2. Archival Double Border
  ctx.strokeStyle = '#141312';
  ctx.lineWidth = 1.5;
  ctx.strokeRect(28, 28, width - 56, height - 56);

  ctx.strokeStyle = '#9E2A1C';
  ctx.lineWidth = 1;
  ctx.strokeRect(36, 36, width - 72, height - 72);

  // Corner '+' crosses
  const cornerSize = 10;
  const drawCornerCross = (cx: number, cy: number) => {
    ctx.strokeStyle = '#9E2A1C';
    ctx.lineWidth = 1.5;
    ctx.beginPath();
    ctx.moveTo(cx - cornerSize, cy);
    ctx.lineTo(cx + cornerSize, cy);
    ctx.moveTo(cx, cy - cornerSize);
    ctx.lineTo(cx, cy + cornerSize);
    ctx.stroke();
  };
  drawCornerCross(36, 36);
  drawCornerCross(width - 36, 36);
  drawCornerCross(36, height - 36);
  drawCornerCross(width - 36, height - 36);

  // 3. Top Archival Header
  // Crimson Seal Box [ 藏 ]
  ctx.fillStyle = '#9E2A1C';
  ctx.fillRect(56, 56, 44, 44);
  ctx.fillStyle = '#FFFFFF';
  ctx.font = 'bold 24px "Cormorant Garamond", Georgia, serif';
  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';
  ctx.fillText('藏', 78, 78);

  // Top header text
  ctx.textAlign = 'left';
  ctx.textBaseline = 'alphabetic';
  ctx.fillStyle = '#141312';
  ctx.font = 'bold 16px "Cormorant Garamond", Georgia, serif';
  ctx.fillText('TÀNG Y · CỔ PHỤC REMIX', 114, 75);

  ctx.fillStyle = '#6E675F';
  ctx.font = '500 11px "JetBrains Mono", monospace';
  ctx.fillText('HỒ SƠ PHỐI PHỤC DI SẢN · ARCHIVAL SPECIMEN', 114, 94);

  // Top-Right Metadata
  ctx.textAlign = 'right';
  ctx.fillStyle = '#9E2A1C';
  ctx.font = '600 12px "JetBrains Mono", monospace';
  ctx.fillText(
    `DÁNG ${params.gender === 'female' ? 'NỮ' : 'NAM'} · ${params.selectedItems.length} MÓN`,
    width - 56,
    75
  );

  const todayStr = new Date().toLocaleDateString('vi-VN', {
    day: '2-digit',
    month: '2-digit',
    year: 'numeric',
  });
  ctx.fillStyle = '#8A8177';
  ctx.font = '11px "JetBrains Mono", monospace';
  ctx.fillText(`MÃ BẢN: VP-${Date.now().toString().slice(-6)} · ${todayStr}`, width - 56, 94);

  // Header separator line
  ctx.strokeStyle = 'rgba(20, 19, 18, 0.15)';
  ctx.lineWidth = 1;
  ctx.beginPath();
  ctx.moveTo(56, 115);
  ctx.lineTo(width - 56, 115);
  ctx.stroke();

  // 4. Outfit Title & Cultural Status
  ctx.textAlign = 'left';
  ctx.fillStyle = '#0D0C0B';
  ctx.font = '600 32px "Cormorant Garamond", Georgia, serif';
  const cleanTitle = (params.outfitTitle || 'BỘ PHỐI TRANG PHỤC').toUpperCase();
  ctx.fillText(cleanTitle, 56, 155);

  // Status Badge
  const statusColor = params.statusColorHex || '#2E5A44';
  const statusLabel = params.statusLabel || 'XÁC THỰC';

  // Dot
  ctx.fillStyle = statusColor;
  ctx.beginPath();
  ctx.arc(62, 182, 5, 0, Math.PI * 2);
  ctx.fill();

  ctx.fillStyle = statusColor;
  ctx.font = 'bold 12px "JetBrains Mono", monospace';
  ctx.fillText(statusLabel.toUpperCase(), 74, 186);

  // Sub-layers summary text
  ctx.fillStyle = '#6E675F';
  ctx.font = 'italic 13px "Be Vietnam Pro", sans-serif';
  const summarySub = params.outfitSubLayers || 'Tổ hợp y phục truyền thống';
  ctx.fillText(summarySub.slice(0, 85) + (summarySub.length > 85 ? '...' : ''), 240, 186);

  // 5. Stage Box (Mannequin & Garment Layers)
  const stageX = 56;
  const stageY = 205;
  const stageW = width - 112; // 968px
  const stageH = 880;

  ctx.fillStyle = '#EFECE5';
  ctx.fillRect(stageX, stageY, stageW, stageH);

  ctx.strokeStyle = 'rgba(20, 19, 18, 0.2)';
  ctx.lineWidth = 1;
  ctx.strokeRect(stageX, stageY, stageW, stageH);

  // Stage watermark / coordinates
  ctx.fillStyle = 'rgba(20, 19, 18, 0.08)';
  ctx.font = 'bold 120px "Cormorant Garamond", Georgia, serif';
  ctx.textAlign = 'center';
  ctx.fillText('藏', stageX + stageW / 2, stageY + stageH / 2 + 40);

  // Model Stage Canvas Area (Center)
  const modelW = 580;
  const modelH = 850;
  const modelX = stageX + (stageW - modelW) / 2;
  const modelY = stageY + (stageH - modelH) / 2;

  // If photorealistic AI Try-On image is available, render it directly as the centerpiece
  let drewTryOnImage = false;
  if (params.tryOnImageUrl) {
    try {
      const tryOnImg = await loadImage(params.tryOnImageUrl);
      if (tryOnImg) {
        ctx.drawImage(tryOnImg, modelX, modelY, modelW, modelH);
        drewTryOnImage = true;
      }
    } catch {
      drewTryOnImage = false;
    }
  }

  // Otherwise, render Base Model
  if (!drewTryOnImage) {
    const baseModelSrc =
      params.gender === 'female' ? femaleBaseModelImage : maleBaseModelImage;
    const baseModelImg = await loadImage(baseModelSrc);
    if (baseModelImg) {
      ctx.drawImage(baseModelImg, modelX, modelY, modelW, modelH);
    }
  }

  // Stage Subtle Vignette Overlay
  const vignette = ctx.createLinearGradient(
    stageX,
    stageY + stageH - 120,
    stageX,
    stageY + stageH
  );
  vignette.addColorStop(0, 'rgba(20, 19, 18, 0)');
  vignette.addColorStop(1, 'rgba(20, 19, 18, 0.45)');
  ctx.fillStyle = vignette;
  ctx.fillRect(stageX, stageY, stageW, stageH);

  // Stage Mannequin Label at Bottom Left
  ctx.textAlign = 'left';
  ctx.fillStyle = '#F5F2EB';
  ctx.font = '500 12px "JetBrains Mono", monospace';
  ctx.fillText('1:1 MANNEQUIN COMPOSITION', stageX + 16, stageY + stageH - 16);

  ctx.textAlign = 'right';
  ctx.fillText('TÀNG Y ARCHIVE ENGINE', stageX + stageW - 16, stageY + stageH - 16);

  // 6. Lower Info Section: Equipped Items Grid & Cultural Note
  const infoY = stageY + stageH + 24;

  // Section subtitle
  ctx.textAlign = 'left';
  ctx.fillStyle = '#6E675F';
  ctx.font = '600 11px "JetBrains Mono", monospace';
  ctx.fillText('DANH MỤC THÀNH PHẦN Y PHỤC TRANG BỊ:', 56, infoY);

  // Items Tags (draw chips)
  let tagX = 56;
  let tagY = infoY + 12;
  ctx.font = '500 12px "Be Vietnam Pro", sans-serif';

  const categoryLabels: Record<string, string> = {
    OUTER: 'Áo ngoài',
    UNDER: 'Lớp trong',
    LOWER: 'Thân dưới',
    HEAD: 'Khăn/Nón',
    BELT: 'Thắt lưng',
    ACC: 'Phụ kiện',
    FOOT: 'Giày/Hài',
  };

  params.selectedItems.slice(0, 6).forEach((item) => {
    const text = `✦ ${item.name}`;
    const textWidth = ctx.measureText(text).width;
    const chipW = textWidth + 18;

    if (tagX + chipW > width - 56) {
      tagX = 56;
      tagY += 28;
    }

    // Chip background
    ctx.fillStyle = '#FFFFFF';
    ctx.fillRect(tagX, tagY, chipW, 22);
    ctx.strokeStyle = 'rgba(20, 19, 18, 0.15)';
    ctx.lineWidth = 1;
    ctx.strokeRect(tagX, tagY, chipW, 22);

    ctx.fillStyle = '#0D0C0B';
    ctx.textAlign = 'left';
    ctx.fillText(text, tagX + 8, tagY + 15);

    tagX += chipW + 8;
  });

  // Cultural Assessment Quote Box
  const quoteY = tagY + 42;
  const quoteBoxH = 110;
  ctx.fillStyle = 'rgba(255, 255, 255, 0.65)';
  ctx.fillRect(56, quoteY, width - 112, quoteBoxH);
  ctx.strokeStyle = 'rgba(20, 19, 18, 0.12)';
  ctx.strokeRect(56, quoteY, width - 112, quoteBoxH);

  // Left red bar accent
  ctx.fillStyle = '#9E2A1C';
  ctx.fillRect(56, quoteY, 4, quoteBoxH);

  // Assessment text
  ctx.fillStyle = '#9E2A1C';
  ctx.font = '600 11px "JetBrains Mono", monospace';
  ctx.fillText('KHẢO CHỨNG VĂN HÓA & NGUỒN TƯ LIỆU:', 72, quoteY + 22);

  ctx.fillStyle = '#2D2926';
  ctx.font = 'italic 12px "Be Vietnam Pro", sans-serif';
  const explanation =
    params.shortExplanation ||
    'Tổ hợp y phục này đã được đối chiếu dựa trên quy chuẩn tư liệu văn hóa và lịch sử y phục truyền thống Việt Nam.';
  wrapText(ctx, `"${explanation}"`, 72, quoteY + 44, width - 150, 18, 3);

  // 7. Bottom Footnote & Watermark
  const footerY = height - 48;
  ctx.strokeStyle = 'rgba(20, 19, 18, 0.15)';
  ctx.lineWidth = 1;
  ctx.beginPath();
  ctx.moveTo(56, footerY - 14);
  ctx.lineTo(width - 56, footerY - 14);
  ctx.stroke();

  ctx.fillStyle = '#6E675F';
  ctx.font = '11px "JetBrains Mono", monospace';
  ctx.textAlign = 'left';
  ctx.fillText('TÀNG Y (CỔ PHỤC REMIX) · THƯ VIỆN Y PHỤC VIỆT NAM', 56, footerY);

  ctx.textAlign = 'right';
  ctx.fillText('DI SẢN TRANG PHỤC VIỆT · TỰ HÀO BẢN SẮC', width - 56, footerY);

  // Convert to Blob
  return new Promise((resolve, reject) => {
    canvas.toBlob(
      (blob) => {
        if (!blob) {
          reject(new Error('Canvas export toBlob failed'));
          return;
        }
        const dataUrl = canvas.toDataURL('image/png');
        const slug = cleanTitle
          .toLowerCase()
          .replace(/[^a-z0-9]/g, '-')
          .replace(/-+/g, '-')
          .slice(0, 30);
        const filename = `tang-y-phoi-phuc-${slug}-${Date.now().toString().slice(-4)}.png`;
        resolve({ blob, dataUrl, filename });
      },
      'image/png',
      0.95
    );
  });
}

/**
 * Triggers direct browser file download for a blob
 */
export function triggerBlobDownload(blob: Blob, filename: string): void {
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  setTimeout(() => URL.revokeObjectURL(url), 2000);
}

/**
 * Exports composition and triggers native browser share dialog with fallback
 */
export async function exportAndShareOutfitComposition(
  params: ShareCompositionParams
): Promise<ShareCompositionResult> {
  // 1. Generate the composition image
  const { blob, dataUrl, filename } = await generateOutfitCompositionCanvas(params);
  const file = new File([blob], filename, { type: 'image/png' });

  const shareTitle = `Tàng Y — Bộ phối ${params.outfitTitle}`;
  const shareText = `Khám phá bộ phối ${params.outfitTitle} (${params.gender === 'female' ? 'Dáng Nữ' : 'Dáng Nam'}) — Đánh giá: ${params.statusLabel} trên Tàng Y · Việt Phục Remix.`;

  // 2. Attempt Web Share API with File payload
  if (typeof navigator !== 'undefined' && typeof navigator.share === 'function') {
    // Check if navigator.canShare supports files
    let canShareFiles = false;
    try {
      if (typeof navigator.canShare === 'function') {
        canShareFiles = navigator.canShare({ files: [file] });
      }
    } catch {
      canShareFiles = false;
    }

    if (canShareFiles) {
      try {
        await navigator.share({
          title: shareTitle,
          text: shareText,
          files: [file],
        });
        return {
          success: true,
          method: 'native_file_share',
          blob,
          dataUrl,
          filename,
          message: 'Đã mở hộp thoại chia sẻ của trình duyệt!',
        };
      } catch (err: unknown) {
        const error = err as { name?: string; message?: string };
        if (error.name === 'AbortError') {
          return {
            success: false,
            aborted: true,
            method: 'native_file_share',
            blob,
            dataUrl,
            filename,
            message: 'Đã đóng hộp thoại chia sẻ.',
          };
        }
        // If file sharing failed due to OS or permission, continue to link share / download
      }
    }

    // Fallback: Web share with URL and text (common for desktop Safari or browsers not accepting files)
    try {
      await navigator.share({
        title: shareTitle,
        text: shareText,
        url: window.location.href,
      });
      // Also download the image card so user gets the visual file
      triggerBlobDownload(blob, filename);
      return {
        success: true,
        method: 'native_link_share',
        blob,
        dataUrl,
        filename,
        message: 'Đã chia sẻ qua trình duyệt và lưu ảnh về thiết bị!',
      };
    } catch (err: unknown) {
      const error = err as { name?: string };
      if (error.name === 'AbortError') {
        return {
          success: false,
          aborted: true,
          method: 'native_link_share',
          blob,
          dataUrl,
          filename,
          message: 'Đã đóng hộp thoại chia sẻ.',
        };
      }
      // If native share threw other errors, fallback to direct download
    }
  }

  // 3. Fallback for browsers without navigator.share (Desktop Chrome, Firefox, embedded iframes)
  triggerBlobDownload(blob, filename);

  // Try copying title and link to clipboard
  try {
    if (navigator.clipboard && navigator.clipboard.writeText) {
      await navigator.clipboard.writeText(`${shareTitle}\n${window.location.href}`);
    }
  } catch {
    // Ignore clipboard failures
  }

  return {
    success: true,
    method: 'download',
    blob,
    dataUrl,
    filename,
    message: 'Đã xuất và tải ảnh phối phục chất lượng cao về thiết bị!',
  };
}
