export const HERO_EDITORIAL_IMAGE =
  '/src/assets/images/viet_phuc_hero_1791386826418.jpg';

export const LOTUS_HERITAGE_BACKGROUND_IMAGE =
  '/src/assets/images/lotus_heritage_background.svg';

export const AODAI_TURNTABLE_FRAMES = {
  deg000: '/src/assets/images/aodai_crimson_000_front_1790733528782.jpg',
  deg045: '/src/assets/images/aodai_crimson_045_angle_1790733592728.jpg',
  deg090: '/src/assets/images/aodai_crimson_090_profile_1790733542351.jpg',
  deg135: '/src/assets/images/aodai_crimson_135_angle_1790733603499.jpg',
  deg180: '/src/assets/images/aodai_crimson_180_back_1790733553336.jpg',
  deg270: '/src/assets/images/aodai_crimson_270_profile_1790733562764.jpg',
};

export const CARD_TU_AO_IMAGE =
  '/src/assets/images/tu_ao_rack_1791389727571.jpg';

export const CARD_PHOI_PHUC_IMAGE =
  '/src/assets/images/phoi_phuc_woman_1791389738675.jpg';

export const CARD_TU_LIEU_IMAGE =
  '/src/assets/images/tu_lieu_desk_1791389751352.jpg';

export interface CostumeVisualMeta {
  accessionCode: string;
  imageUrl: string;
  silhouetteType:
    | 'ao-dai'
    | 'ao-tu-than'
    | 'ao-ngu-than'
    | 'ao-ba-ba'
    | 'ao-giao-linh'
    | 'ao-nhat-binh';
  defaultToneHex: string;
  secondaryToneHex: string;
  structuralNote: string;
}

export const COSTUME_VISUALS: Record<string, CostumeVisualMeta> = {
  'ao-dai': {
    accessionCode: 'ARC.VP.01',
    imageUrl: '/src/assets/images/tu_ao_ao_dai_1791540293823.jpg',
    silhouetteType: 'ao-dai',
    defaultToneHex: '#8C2D19',
    secondaryToneHex: '#E8E2D5',
    structuralNote: 'Phom dáng tà suông · Cổ đứng lập lĩnh · Quần lụa ngà',
  },
  'ao-tu-than': {
    accessionCode: 'ARC.VP.02',
    imageUrl: '/src/assets/images/tu_ao_ao_tu_than_1791540316824.jpg',
    silhouetteType: 'ao-tu-than',
    defaultToneHex: '#6E473B',
    secondaryToneHex: '#C28B38',
    structuralNote: 'Bốn tà phân lớp · Yếm đào · Dải bao xanh · Váy đụp',
  },
  'ao-ngu-than': {
    accessionCode: 'ARC.VP.03',
    imageUrl: '/src/assets/images/tu_ao_ao_ngu_than_1791540362301.jpg',
    silhouetteType: 'ao-ngu-than',
    defaultToneHex: '#1E3A5F',
    secondaryToneHex: '#D8CFC2',
    structuralNote: 'Năm thân nối sống · Ngũ khuy nẹp hữu · Quần trắng',
  },
  'ao-ba-ba': {
    accessionCode: 'ARC.VP.04',
    imageUrl: '/src/assets/images/tu_ao_ao_ba_ba_1791540391970.jpg',
    silhouetteType: 'ao-ba-ba',
    defaultToneHex: '#5C4033',
    secondaryToneHex: '#E5DEC9',
    structuralNote: 'Thân ngắn xẻ tà hông · Khăn rằn · Quần lụa đen',
  },
  'ao-giao-linh': {
    accessionCode: 'ARC.VP.05',
    imageUrl: '/src/assets/images/tu_ao_ao_giao_linh_1791540421433.jpg',
    silhouetteType: 'ao-giao-linh',
    defaultToneHex: '#2E5A44',
    secondaryToneHex: '#D6CEBF',
    structuralNote: 'Vạt chéo giao cổ · Tay thụng · Dải thắt lưng · Thường xếp ly',
  },
  'ao-nhat-binh': {
    accessionCode: 'ARC.VP.06',
    imageUrl: '/src/assets/images/tu_ao_ao_nhat_binh_1791540457083.jpg',
    silhouetteType: 'ao-nhat-binh',
    defaultToneHex: '#9A3412',
    secondaryToneHex: '#C28B38',
    structuralNote: 'Cổ vuông đối khâm · Dải ngũ sắc cửa tay · Phượng hoàng thêu chỉ vàng',
  },
};

export interface StudioPaletteOption {
  id: string;
  label: string;
  hex: string;
  accentHex: string;
}

export const STUDIO_COLOR_PALETTES: StudioPaletteOption[] = [
  {
    id: 'color-1',
    label: 'Đỏ chu sa & Lụa ngà',
    hex: '#8C2D19',
    accentHex: '#D9C3B0',
  },
  {
    id: 'color-2',
    label: 'Xanh chàm & Lĩnh trắng',
    hex: '#1E3A5F',
    accentHex: '#CBD5E1',
  },
  {
    id: 'color-3',
    label: 'Xanh ngọc bích & Cốm non',
    hex: '#2E5A44',
    accentHex: '#D1DEC9',
  },
  {
    id: 'color-4',
    label: 'Nâu sồng & Vàng hoa hiên',
    hex: '#6E473B',
    accentHex: '#E5DEC9',
  },
];
