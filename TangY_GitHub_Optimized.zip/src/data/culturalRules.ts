/**
 * HỆ THỐNG KIỂM TRA VĂN HÓA "GIỮ NẾP" (CULTURAL CHECK ENGINE)
 * 
 * Hoàn toàn DETERMINISTIC - dựa trên các rule cố định và minh bạch.
 * Không dùng AI / Gemini, không tự bịa lịch sử.
 * Đánh giá mức độ phù hợp của TỔ HỢP ĐANG PHỐI (không chứng nhận lịch sử tuyệt đối).
 */

export interface CulturalRule {
  id: string;
  costumeId: string; // 'ao-dai' | 'ao-tu-than' | 'ao-ngu-than' | 'ao-ba-ba' | 'ao-giao-linh' | 'ao-nhat-binh' | '*'
  type: 'compatible' | 'caution' | 'avoid';
  target: 'region' | 'occasion' | 'accessory' | 'style';
  condition: (ctx: CulturalContext) => boolean;
  scoreDelta: number;
  message: string;
  suggestion?: string;
  categoryImpact?: 'truyen-thong' | 'cach-tan' | 'can-luu-y';
}

export interface CulturalContext {
  costumeId: string;
  occasion: string;
  region: string;
  accessories: string[];
  style: string;
}

export interface CulturalFitResult {
  score: number;
  status: 'green' | 'yellow' | 'red';
  label: string;
  category: 'truyen-thong' | 'cach-tan' | 'can-luu-y';
  reasons: string[];
  suggestions: string[];
}

export const CULTURAL_RULES: CulturalRule[] = [
  // ==========================================
  // 1. VÙNG MIỀN (REGION RULES)
  // ==========================================
  {
    id: 'region-tu-than-bac-bo',
    costumeId: 'ao-tu-than',
    type: 'compatible',
    target: 'region',
    condition: (ctx) => ctx.region.includes('Bắc Bộ'),
    scoreDelta: 15,
    message: 'Áo tứ thân gắn bó sâu sắc với không gian văn hóa Bắc Bộ và cái nôi Kinh Bắc.',
  },
  {
    id: 'region-tu-than-nam-bo',
    costumeId: 'ao-tu-than',
    type: 'caution',
    target: 'region',
    condition: (ctx) => ctx.region.includes('Nam Bộ'),
    scoreDelta: -10,
    categoryImpact: 'can-luu-y',
    message: 'Áo tứ thân là trang phục đặc trưng Bắc Bộ, hiếm khi xuất hiện trong đời sống truyền thống bản địa Nam Bộ.',
    suggestion: 'Nếu muốn thể hiện chất phương Nam, Áo bà ba là lựa chọn nguyên bản hơn.',
  },
  {
    id: 'region-ba-ba-nam-bo',
    costumeId: 'ao-ba-ba',
    type: 'compatible',
    target: 'region',
    condition: (ctx) => ctx.region.includes('Nam Bộ'),
    scoreDelta: 15,
    message: 'Áo bà ba gắn liền máu thịt với đồng bằng sông Cửu Long và đời sống miệt vườn phương Nam.',
  },
  {
    id: 'region-ba-ba-bac-bo',
    costumeId: 'ao-ba-ba',
    type: 'caution',
    target: 'region',
    condition: (ctx) => ctx.region.includes('Bắc Bộ'),
    scoreDelta: -5,
    categoryImpact: 'cach-tan',
    message: 'Áo bà ba khi diện ở bối cảnh Bắc Bộ mang tính giao lưu văn hóa đương đại nhiều hơn là bối cảnh gốc.',
  },
  {
    id: 'region-nhat-binh-hue',
    costumeId: 'ao-nhat-binh',
    type: 'compatible',
    target: 'region',
    condition: (ctx) => ctx.region.includes('Huế') || ctx.region.includes('Miền Trung'),
    scoreDelta: 15,
    message: 'Áo nhật bình là phẩm phục tiêu biểu của hoàng tộc và quý tộc triều Nguyễn tại Cố đô Huế.',
  },
  {
    id: 'region-ao-dai-toan-quoc',
    costumeId: 'ao-dai',
    type: 'compatible',
    target: 'region',
    condition: () => true,
    scoreDelta: 12,
    message: 'Áo dài mang tính biểu trưng toàn quốc, hài hòa với bối cảnh văn hóa của cả ba miền.',
  },
  {
    id: 'region-ngu-than-toan-quoc',
    costumeId: 'ao-ngu-than',
    type: 'compatible',
    target: 'region',
    condition: () => true,
    scoreDelta: 12,
    message: 'Áo ngũ thân từng là quốc phục được chuẩn hóa trên toàn lãnh thổ từ thời vua Minh Mạng.',
  },
  {
    id: 'region-giao-linh-bac-kinh-ky',
    costumeId: 'ao-giao-linh',
    type: 'compatible',
    target: 'region',
    condition: (ctx) => ctx.region.includes('Bắc Bộ') || ctx.region.includes('Toàn quốc'),
    scoreDelta: 12,
    message: 'Áo giao lĩnh là cổ phục Đại Việt thời Lý - Trần - Lê, tiêu biểu tại chốn kinh kỳ Thăng Long xưa.',
  },

  // ==========================================
  // 2. DỊP MẶC (OCCASION RULES)
  // ==========================================
  {
    id: 'occasion-nhat-binh-cung-dinh-cuoi',
    costumeId: 'ao-nhat-binh',
    type: 'compatible',
    target: 'occasion',
    condition: (ctx) =>
      ctx.occasion.includes('Cưới hỏi') || ctx.occasion.includes('Lễ Tết'),
    scoreDelta: 14,
    message: 'Áo nhật bình rất trang trọng và phù hợp với nghi lễ cưới hỏi cổ truyền hoặc đại lễ tôn nghiêm.',
  },
  {
    id: 'occasion-nhat-binh-dao-pho',
    costumeId: 'ao-nhat-binh',
    type: 'caution',
    target: 'occasion',
    condition: (ctx) => ctx.occasion.includes('Đời thường'),
    scoreDelta: -16,
    categoryImpact: 'can-luu-y',
    message: 'Nhật bình là phẩm phục cung đình trang trọng, mặc dạo phố đời thường dễ làm mất đi tính trang nghiêm của trang phục.',
    suggestion: 'Nên dành Áo nhật bình cho đám cưới cổ truyền hoặc sự kiện phục dựng văn hóa.',
  },
  {
    id: 'occasion-tu-than-le-hoi',
    costumeId: 'ao-tu-than',
    type: 'compatible',
    target: 'occasion',
    condition: (ctx) =>
      ctx.occasion.includes('Lễ hội') || ctx.occasion.includes('Lễ Tết'),
    scoreDelta: 14,
    message: 'Áo tứ thân là linh hồn của các hội làng xuân Kinh Bắc và sinh hoạt dân gian.',
  },
  {
    id: 'occasion-ba-ba-doi-thuong',
    costumeId: 'ao-ba-ba',
    type: 'compatible',
    target: 'occasion',
    condition: (ctx) =>
      ctx.occasion.includes('Đời thường') || ctx.occasion.includes('Lễ hội'),
    scoreDelta: 14,
    message: 'Áo bà ba sinh ra từ đời sống lao động, vô cùng thoải mái và hòa hợp với sinh hoạt đời thường.',
  },
  {
    id: 'occasion-giao-linh-dao-pho',
    costumeId: 'ao-giao-linh',
    type: 'caution',
    target: 'occasion',
    condition: (ctx) => ctx.occasion.includes('Đời thường'),
    scoreDelta: -8,
    categoryImpact: 'can-luu-y',
    message: 'Áo giao lĩnh với vạt giao chéo và tay áo thụng rộng mang tính lễ phục cổ xưa, ít thuận tiện khi dạo phố.',
  },
  {
    id: 'occasion-ao-dai-hoc-duong-cuoi',
    costumeId: 'ao-dai',
    type: 'compatible',
    target: 'occasion',
    condition: (ctx) =>
      ctx.occasion.includes('Kỷ yếu') ||
      ctx.occasion.includes('Cưới hỏi') ||
      ctx.occasion.includes('Lễ Tết'),
    scoreDelta: 14,
    message: 'Áo dài là chuẩn mực kinh điển cho ngày cưới, lễ tốt nghiệp học đường và ngày Tết cổ truyền.',
  },

  // ==========================================
  // 3. PHỤ KIỆN (ACCESSORY RULES)
  // ==========================================
  {
    id: 'acc-tu-than-kinh-dien',
    costumeId: 'ao-tu-than',
    type: 'compatible',
    target: 'accessory',
    condition: (ctx) =>
      ctx.accessories.some(
        (a) =>
          a.includes('mỏ quạ') || a.includes('quai thao') || a.includes('dải bao')
      ),
    scoreDelta: 12,
    message: 'Khăn mỏ quạ, nón quai thao hoặc dải bao là những phụ kiện kinh điển hoàn thiện dáng dấp áo tứ thân.',
  },
  {
    id: 'acc-tu-than-khan-ran-clash',
    costumeId: 'ao-tu-than',
    type: 'avoid',
    target: 'accessory',
    condition: (ctx) =>
      ctx.accessories.some((a) => a.includes('Khăn rằn')),
    scoreDelta: -18,
    categoryImpact: 'can-luu-y',
    message: 'Khăn rằn là phụ kiện đặc thù sông nước Nam Bộ, không hòa hợp với quy thức của áo tứ thân Bắc Bộ.',
    suggestion: 'Thay khăn rằn bằng khăn mỏ quạ hoặc nón quai thao.',
  },
  {
    id: 'acc-ba-ba-kinh-dien',
    costumeId: 'ao-ba-ba',
    type: 'compatible',
    target: 'accessory',
    condition: (ctx) =>
      ctx.accessories.some(
        (a) => a.includes('Khăn rằn') || a.includes('Nón lá') || a.includes('giỏ mây')
      ),
    scoreDelta: 14,
    message: 'Khăn rằn và nón lá là cặp phụ kiện mộc mạc tôn vinh trọn vẹn nét đẹp của người dân Nam Bộ.',
  },
  {
    id: 'acc-ba-ba-quai-thao-clash',
    costumeId: 'ao-ba-ba',
    type: 'avoid',
    target: 'accessory',
    condition: (ctx) =>
      ctx.accessories.some((a) => a.includes('quai thao')),
    scoreDelta: -16,
    categoryImpact: 'can-luu-y',
    message: 'Nón quai thao thuộc không gian văn hóa Quan họ Kinh Bắc, cọc cạch khi đi cùng áo bà ba.',
    suggestion: 'Chọn nón lá truyền thống hoặc khăn rằn Nam Bộ.',
  },
  {
    id: 'acc-ba-ba-mo-qua-clash',
    costumeId: 'ao-ba-ba',
    type: 'avoid',
    target: 'accessory',
    condition: (ctx) =>
      ctx.accessories.some((a) => a.includes('mỏ quạ')),
    scoreDelta: -14,
    categoryImpact: 'can-luu-y',
    message: 'Khăn mỏ quạ mang dấu ấn phụ nữ đồng bằng sông Hồng, không xuất hiện trong quy thức áo bà ba.',
    suggestion: 'Nên dùng khăn rằn Nam Bộ kẻ ca-rô.',
  },
  {
    id: 'acc-nhat-binh-tram-ngoc-hoang-gia',
    costumeId: 'ao-nhat-binh',
    type: 'compatible',
    target: 'accessory',
    condition: (ctx) =>
      ctx.accessories.some(
        (a) =>
          a.includes('Trâm') ||
          a.includes('ngọc') ||
          a.includes('Kiềng') ||
          a.includes('cung đình')
      ),
    scoreDelta: 12,
    message: 'Trang sức kim hoàn, ngọc bội hoặc trâm cài tóc tôn vinh khí chất quyền quý của áo nhật bình.',
  },
  {
    id: 'acc-nhat-binh-khan-ran-clash',
    costumeId: 'ao-nhat-binh',
    type: 'avoid',
    target: 'accessory',
    condition: (ctx) =>
      ctx.accessories.some((a) => a.includes('Khăn rằn')),
    scoreDelta: -20,
    categoryImpact: 'can-luu-y',
    message: 'Khăn rằn dân dã đối nghịch hoàn toàn với tính chất phẩm phục cung đình tôn nghiêm của áo nhật bình.',
    suggestion: 'Bỏ khăn rằn, có thể dùng khăn vành dây hoặc kiềng chạm khắc hoàng gia.',
  },
  {
    id: 'acc-ngu-than-khan-dong',
    costumeId: 'ao-ngu-than',
    type: 'compatible',
    target: 'accessory',
    condition: (ctx) =>
      ctx.accessories.some((a) => a.includes('khăn xếp') || a.includes('khăn đóng')),
    scoreDelta: 12,
    message: 'Khăn đóng/khăn xếp là thành phần cốt lõi tạo nên phong thái trang trọng của áo ngũ thân.',
  },
  {
    id: 'acc-giao-linh-that-lung-ngoc',
    costumeId: 'ao-giao-linh',
    type: 'compatible',
    target: 'accessory',
    condition: (ctx) =>
      ctx.accessories.some((a) => a.includes('Thắt lưng') || a.includes('ngọc')),
    scoreDelta: 12,
    message: 'Dải thắt lưng vải buông và ngọc bội giữ đúng tinh thần nho nhã cổ phong thời Lý - Trần - Lê.',
  },
  {
    id: 'acc-ao-dai-kinh-dien',
    costumeId: 'ao-dai',
    type: 'compatible',
    target: 'accessory',
    condition: (ctx) =>
      ctx.accessories.some(
        (a) =>
          a.includes('Nón lá') ||
          a.includes('khăn xếp') ||
          a.includes('ngọc trai') ||
          a.includes('Kiềng')
      ),
    scoreDelta: 10,
    message: 'Phụ kiện truyền thống tôn vinh nét thanh nhã, kín đáo của tà áo dài.',
  },

  // ==========================================
  // 4. PHONG CÁCH (STYLE RULES)
  // ==========================================
  {
    id: 'style-truyen-thong',
    costumeId: '*',
    type: 'compatible',
    target: 'style',
    condition: (ctx) => ctx.style === 'Truyền thống' || ctx.style === 'Cổ điển',
    scoreDelta: 8,
    categoryImpact: 'truyen-thong',
    message: 'Bộ phối hướng đến vẻ đẹp mực thước và giá trị thẩm mỹ cổ điển.',
  },
  {
    id: 'style-gen-z',
    costumeId: '*',
    type: 'compatible',
    target: 'style',
    condition: (ctx) => ctx.style === 'Gen Z',
    scoreDelta: 4,
    categoryImpact: 'cach-tan',
    message: 'Phong cách Gen Z mang tinh thần sáng tạo trẻ trung, tạo điểm nhấn mới mẻ cho trang phục. Đây là phối cách tân, không phải phục dựng nguyên bản.',
    suggestion: 'Khi diện bộ phối cách tân, nên nêu rõ tinh thần sáng tạo để người xem không nhầm lẫn với quy chuẩn cổ phục nguyên bản.',
  },
  {
    id: 'style-toi-gian',
    costumeId: '*',
    type: 'compatible',
    target: 'style',
    condition: (ctx) => ctx.style === 'Tối giản',
    scoreDelta: 6,
    categoryImpact: 'cach-tan',
    message: 'Lối phối tối giản lược bỏ các chi tiết phụ trợ, hướng sự tập trung vào phom dáng và chất liệu lụa.',
  },
];

/**
 * HÀM TÍNH TOÁN ĐỘ PHÙ HỢP VĂN HÓA (CALCULATE CULTURAL FIT)
 * 
 * Input: costumeId, occasion, region, accessories, style
 * Output: { score, status, label, category, reasons, suggestions }
 */
export function calculateCulturalFit(
  costumeId: string,
  occasion: string,
  region: string,
  accessories: string[] = [],
  style: string = 'Thanh lịch'
): CulturalFitResult {
  const ctx: CulturalContext = {
    costumeId,
    occasion,
    region,
    accessories,
    style,
  };

  // Lọc các rule áp dụng cho costume hiện tại hoặc rule chung '*'
  const applicableRules = CULTURAL_RULES.filter(
    (rule) => rule.costumeId === costumeId || rule.costumeId === '*'
  );

  // Nếu không tìm thấy rule nào liên quan (phòng ngừa tình huống dữ liệu lạ)
  if (applicableRules.length === 0) {
    return {
      score: 50,
      status: 'yellow',
      label: 'Cần xác minh thêm',
      category: 'can-luu-y',
      reasons: ['Chưa có đủ rule để đánh giá chắc chắn tổ hợp này.'],
      suggestions: [
        'Vui lòng tham khảo thêm các tài liệu nghiên cứu trang phục để có thêm cơ sở đánh giá.',
      ],
    };
  }

  // Điểm cơ sở
  let rawScore = 60;
  const reasons: string[] = [];
  const suggestions: string[] = [];
  let hasClash = false;
  let isCachTan = style === 'Gen Z' || style === 'Tối giản';

  for (const rule of applicableRules) {
    if (rule.condition(ctx)) {
      rawScore += rule.scoreDelta;
      if (rule.message) {
        reasons.push(rule.message);
      }
      if (rule.suggestion) {
        suggestions.push(rule.suggestion);
      }
      if (rule.type === 'avoid' || rule.categoryImpact === 'can-luu-y') {
        hasClash = true;
      }
      if (rule.categoryImpact === 'cach-tan') {
        isCachTan = true;
      }
    }
  }

  // Giới hạn điểm [0, 100]
  const score = Math.max(0, Math.min(100, Math.round(rawScore)));

  // Phân loại danh mục
  let category: 'truyen-thong' | 'cach-tan' | 'can-luu-y' = 'truyen-thong';
  if (hasClash || score < 50) {
    category = 'can-luu-y';
  } else if (isCachTan) {
    category = 'cach-tan';
  } else {
    category = 'truyen-thong';
  }

  // Phân cấp trạng thái theo yêu cầu:
  // 90-100: Phù hợp (green)
  // 70-89: Phù hợp, có lưu ý nhẹ (green/yellow)
  // 40-69: Cần lưu ý (yellow)
  // 0-39: Cần điều chỉnh (red)
  let status: 'green' | 'yellow' | 'red' = 'green';
  let label = 'Phù hợp';

  if (score >= 90) {
    status = 'green';
    label = 'Phù hợp';
  } else if (score >= 70) {
    if (category === 'can-luu-y') {
      status = 'yellow';
      label = 'Cần lưu ý';
    } else {
      status = 'green';
      label = 'Phù hợp (có lưu ý)';
    }
  } else if (score >= 40) {
    status = 'yellow';
    label = 'Cần lưu ý';
  } else {
    status = 'red';
    label = 'Cần điều chỉnh';
  }

  // Đảm bảo luôn có ít nhất 1 reason giải thích rõ ràng
  if (reasons.length === 0) {
    reasons.push(
      'Tổ hợp trang phục, bối cảnh và phụ kiện hiện ở mức cơ bản, chưa phát hiện sự xung đột quy thức rõ rệt.'
    );
  }

  return {
    score,
    status,
    label,
    category,
    reasons,
    suggestions,
  };
}
