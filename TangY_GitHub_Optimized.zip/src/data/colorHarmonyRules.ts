/**
 * BỘ QUY TẮC HÒA SẮC (COLOR HARMONY ENGINE) CHO TÀNG Y CÁC / VIỆT PHỤC REMIX
 * 
 * Hoàn toàn deterministic - không sử dụng AI / Gemini hay ngẫu nhiên (random).
 * Dựa trên mỹ học y phục truyền thống Việt Nam, nguyên lý ngũ sắc và tỷ lệ phối đương đại.
 */

export interface ColorHarmonyRule {
  id: string;
  name: string;
  hex: string;
  accentHex: string;
  nhomMau: 'Nóng' | 'Ấm' | 'Lạnh' | 'Trung tính' | 'Mộc mạc';
  secondaryColors: string[];
  contrastColors: string[];
  traditionalMeaning: string;
  costumeSynergies: Record<string, number>;
  styleSynergies: Record<string, number>;
}

export interface ColorHarmonyResult {
  score: number;
  level: string;
  primaryColor: string;
  primaryHex: string;
  secondaryColors: string[];
  explanation: string;
  suggestions: string[];
}

export const COLOR_HARMONY_RULES: Record<string, ColorHarmonyRule> = {
  do: {
    id: 'do',
    name: 'Đỏ',
    hex: '#8C2D19',
    accentHex: '#E8D5C4',
    nhomMau: 'Nóng',
    secondaryColors: ['Vàng', 'Trắng', 'Đen'],
    contrastColors: ['Xanh', 'Xanh lá'],
    traditionalMeaning:
      'Sắc đỏ chu sa tượng trưng cho hỷ sự, thịnh vượng, quyền quý và sinh khí dồi dào trong cung đình và lễ hội cổ truyền.',
    costumeSynergies: {
      'ao-nhat-binh': 20,
      'ao-dai': 16,
      'ao-giao-linh': 14,
      'ao-ngu-than': 12,
      'ao-tu-than': 10,
      'ao-ba-ba': 4,
    },
    styleSynergies: {
      'Truyền thống': 10,
      'Cổ điển': 9,
      'Thanh lịch': 7,
      'Gen Z': 7,
      'Tối giản': 3,
    },
  },
  vang: {
    id: 'vang',
    name: 'Vàng',
    hex: '#C89B3C',
    accentHex: '#F6E8C3',
    nhomMau: 'Ấm',
    secondaryColors: ['Đỏ', 'Trắng', 'Nâu'],
    contrastColors: ['Xanh', 'Tím'],
    traditionalMeaning:
      'Sắc vàng hoàng yến tượng trưng cho sự tôn quý, vương giả, rực rỡ và ấm no trong quan niệm thẩm mỹ Á Đông.',
    costumeSynergies: {
      'ao-nhat-binh': 19,
      'ao-dai': 16,
      'ao-ngu-than': 15,
      'ao-giao-linh': 13,
      'ao-tu-than': 8,
      'ao-ba-ba': 4,
    },
    styleSynergies: {
      'Truyền thống': 10,
      'Cổ điển': 9,
      'Thanh lịch': 7,
      'Gen Z': 8,
      'Tối giản': 3,
    },
  },
  xanh: {
    id: 'xanh',
    name: 'Xanh',
    hex: '#1E3A5F',
    accentHex: '#CBD5E1',
    nhomMau: 'Lạnh',
    secondaryColors: ['Trắng', 'Đen', 'Vàng'],
    contrastColors: ['Đỏ', 'Hồng'],
    traditionalMeaning:
      'Sắc lam chàm mang chiều sâu thâm trầm, điềm đạm, biểu trưng cho sự an hòa, trí tuệ và phong thái nho nhã.',
    costumeSynergies: {
      'ao-ngu-than': 18,
      'ao-dai': 17,
      'ao-giao-linh': 16,
      'ao-nhat-binh': 14,
      'ao-tu-than': 10,
      'ao-ba-ba': 9,
    },
    styleSynergies: {
      'Thanh lịch': 10,
      'Cổ điển': 9,
      'Truyền thống': 9,
      'Tối giản': 8,
      'Gen Z': 6,
    },
  },
  trang: {
    id: 'trang',
    name: 'Trắng',
    hex: '#F4F0E8',
    accentHex: '#D6CEBF',
    nhomMau: 'Trung tính',
    secondaryColors: ['Đen', 'Đỏ', 'Xanh'],
    contrastColors: ['Đen', 'Đỏ'],
    traditionalMeaning:
      'Sắc trắng lụa ngà tôn vinh vẻ đẹp thuần khiết, tinh khôi, mực thước của học đường và sự tao nhã truyền thống.',
    costumeSynergies: {
      'ao-dai': 20,
      'ao-giao-linh': 16,
      'ao-ngu-than': 15,
      'ao-ba-ba': 14,
      'ao-nhat-binh': 10,
      'ao-tu-than': 8,
    },
    styleSynergies: {
      'Tối giản': 10,
      'Thanh lịch': 10,
      'Gen Z': 8,
      'Truyền thống': 7,
      'Cổ điển': 7,
    },
  },
  den: {
    id: 'den',
    name: 'Đen',
    hex: '#1A1918',
    accentHex: '#A8A29E',
    nhomMau: 'Trung tính',
    secondaryColors: ['Trắng', 'Đỏ', 'Vàng'],
    contrastColors: ['Trắng', 'Hồng'],
    traditionalMeaning:
      'Sắc mun tuyền trang nghiêm, đĩnh đạc, chững chạc và tạo chiều sâu huyền bí, tôn vinh phom dáng suông rộng cổ truyền.',
    costumeSynergies: {
      'ao-ngu-than': 19,
      'ao-tu-than': 17,
      'ao-ba-ba': 16,
      'ao-giao-linh': 15,
      'ao-dai': 13,
      'ao-nhat-binh': 8,
    },
    styleSynergies: {
      'Cổ điển': 10,
      'Tối giản': 10,
      'Truyền thống': 9,
      'Thanh lịch': 8,
      'Gen Z': 7,
    },
  },
  hong: {
    id: 'hong',
    name: 'Hồng',
    hex: '#C26D82',
    accentHex: '#F5D7DF',
    nhomMau: 'Ấm',
    secondaryColors: ['Trắng', 'Xanh lá', 'Xanh'],
    contrastColors: ['Xanh lá', 'Đen'],
    traditionalMeaning:
      'Sắc hồng cánh sen thanh tân, e ấp, biểu trưng cho vẻ đẹp đoan trang, duyên dáng và tươi mới của nữ giới Việt.',
    costumeSynergies: {
      'ao-tu-than': 18,
      'ao-dai': 17,
      'ao-ba-ba': 13,
      'ao-nhat-binh': 10,
      'ao-ngu-than': 8,
      'ao-giao-linh': 6,
    },
    styleSynergies: {
      'Thanh lịch': 10,
      'Gen Z': 10,
      'Truyền thống': 7,
      'Cổ điển': 6,
      'Tối giản': 5,
    },
  },
  tim: {
    id: 'tim',
    name: 'Tím',
    hex: '#633B5B',
    accentHex: '#E2D3E0',
    nhomMau: 'Lạnh',
    secondaryColors: ['Trắng', 'Hồng', 'Vàng'],
    contrastColors: ['Vàng', 'Xanh lá'],
    traditionalMeaning:
      'Sắc tím hoa cà Cố đô Huế mang đậm chất thơ, biểu trưng cho lòng thủy chung, kín đáo, sâu lắng và nét đài các cung đình.',
    costumeSynergies: {
      'ao-dai': 19,
      'ao-nhat-binh': 17,
      'ao-ngu-than': 14,
      'ao-giao-linh': 10,
      'ao-tu-than': 7,
      'ao-ba-ba': 6,
    },
    styleSynergies: {
      'Cổ điển': 10,
      'Thanh lịch': 9,
      'Truyền thống': 8,
      'Gen Z': 7,
      'Tối giản': 5,
    },
  },
  nau: {
    id: 'nau',
    name: 'Nâu',
    hex: '#5C4033',
    accentHex: '#DECFC5',
    nhomMau: 'Mộc mạc',
    secondaryColors: ['Đen', 'Trắng', 'Vàng'],
    contrastColors: ['Hồng', 'Xanh'],
    traditionalMeaning:
      'Sắc nâu sồng phù sa mộc mạc, đậm chất cần lao, chân chất và gắn bó máu thịt với đời sống làng quê thôn dã.',
    costumeSynergies: {
      'ao-tu-than': 20,
      'ao-ba-ba': 20,
      'ao-ngu-than': 13,
      'ao-dai': 8,
      'ao-giao-linh': 8,
      'ao-nhat-binh': 2,
    },
    styleSynergies: {
      'Truyền thống': 10,
      'Cổ điển': 9,
      'Tối giản': 8,
      'Thanh lịch': 6,
      'Gen Z': 6,
    },
  },
  'xanh-la': {
    id: 'xanh-la',
    name: 'Xanh lá',
    hex: '#2E5A44',
    accentHex: '#D1DEC9',
    nhomMau: 'Mộc mạc',
    secondaryColors: ['Vàng', 'Trắng', 'Hồng'],
    contrastColors: ['Đỏ', 'Hồng'],
    traditionalMeaning:
      'Sắc xanh ngọc lục dạt dào sức sống tự nhiên, gợi nhắc màu xanh cây cỏ, miệt vườn trù phú và tinh thần thanh tân.',
    costumeSynergies: {
      'ao-ba-ba': 17,
      'ao-dai': 15,
      'ao-tu-than': 13,
      'ao-ngu-than': 11,
      'ao-giao-linh': 10,
      'ao-nhat-binh': 8,
    },
    styleSynergies: {
      'Gen Z': 10,
      'Thanh lịch': 8,
      'Tối giản': 7,
      'Truyền thống': 7,
      'Cổ điển': 6,
    },
  },
};

/**
 * Tra cứu quy tắc màu dựa trên ID hoặc Tên tiếng Việt của màu
 */
function findRule(colorInput: string): ColorHarmonyRule {
  if (!colorInput) return COLOR_HARMONY_RULES['do'];

  const normalized = colorInput.trim().toLowerCase();

  // Tra theo ID trực tiếp
  if (COLOR_HARMONY_RULES[normalized]) {
    return COLOR_HARMONY_RULES[normalized];
  }

  // Tra theo tên tiếng Việt
  const found = Object.values(COLOR_HARMONY_RULES).find(
    (r) =>
      r.name.toLowerCase() === normalized ||
      r.id.toLowerCase() === normalized
  );

  return found || COLOR_HARMONY_RULES['do'];
}

/**
 * TÍNH TOÁN ĐIỂM HÒA SẮC (DETERMINISTIC RULE-BASED LOGIC)
 * 
 * Thang điểm 0 - 100:
 * - 90 - 100: "Hòa sắc xuất sắc"
 * - 75 - 89:  "Hòa sắc tốt"
 * - 60 - 74:  "Có thể cân bằng"
 * - 0 - 59:   "Cần điều chỉnh"
 */
export function calculateColorHarmony(
  costumeId: string,
  color: string,
  accessories: string[] = [],
  style: string = 'Thanh lịch'
): ColorHarmonyResult {
  const rule = findRule(color);

  // 1. Điểm cơ sở
  let rawScore = 65;

  // 2. Điểm tương thích giữa Màu và Trang phục (từ +2 đến +20)
  const costumeBonus = rule.costumeSynergies[costumeId] ?? 10;
  rawScore += costumeBonus;

  // 3. Điểm tương thích giữa Màu và Phong cách (từ +3 đến +10)
  const styleBonus = rule.styleSynergies[style] ?? 7;
  rawScore += styleBonus;

  // 4. Điểm phụ kiện tương tác với hòa sắc
  let accessoryBonus = 0;
  const accCount = accessories.length;

  if (accCount === 0) {
    if (style === 'Tối giản') {
      accessoryBonus += 4; // Tối giản không phụ kiện rất hài hòa
    } else {
      accessoryBonus -= 3; // Thiếu phụ kiện điểm xuyết ở lối phối thông thường
    }
  } else if (accCount >= 1 && accCount <= 3) {
    accessoryBonus += 5; // Số lượng phụ kiện lý tưởng

    // Thưởng phụ kiện có tính kinh điển
    accessories.forEach((acc) => {
      const lower = acc.toLowerCase();
      if (
        (lower.includes('ngọc') || lower.includes('kiềng')) &&
        (rule.id === 'do' || rule.id === 'trang' || rule.id === 'xanh' || rule.id === 'vang')
      ) {
        accessoryBonus += 2;
      }
      if (
        (lower.includes('rằn') || lower.includes('nón lá')) &&
        (rule.id === 'nau' || rule.id === 'den' || rule.id === 'xanh-la')
      ) {
        accessoryBonus += 2;
      }
      if (
        (lower.includes('quai thao') || lower.includes('mỏ quạ')) &&
        (rule.id === 'nau' || rule.id === 'den' || rule.id === 'hong')
      ) {
        accessoryBonus += 2;
      }
    });
  } else {
    // Quá 3 phụ kiện
    if (costumeId === 'ao-nhat-binh' || style === 'Truyền thống') {
      accessoryBonus += 2; // Trang phục cung đình/truyền thống nhiều lớp vẫn đẹp
    } else {
      accessoryBonus -= 4; // Quá nhiều phụ kiện gây rối mắt
    }
  }

  rawScore += accessoryBonus;

  // Giới hạn điểm trong đoạn [0, 100]
  const score = Math.max(0, Math.min(100, Math.round(rawScore)));

  // 5. Xác định cấp độ đánh giá
  let level = 'Cần điều chỉnh';
  if (score >= 90) {
    level = 'Hòa sắc xuất sắc';
  } else if (score >= 75) {
    level = 'Hòa sắc tốt';
  } else if (score >= 60) {
    level = 'Có thể cân bằng';
  } else {
    level = 'Cần điều chỉnh';
  }

  // 6. Xây dựng diễn giải thẩm mỹ (Explanation)
  let explanation = '';
  if (score >= 90) {
    explanation = `${rule.traditionalMeaning} Sự phối hợp giữa tông ${rule.name} với dáng áo cùng phong cách "${style}" đạt độ cân bằng thị giác tuyệt đối, giữ trọn cốt cách truyền thống mà vẫn đượm hơi thở đương đại.`;
  } else if (score >= 75) {
    explanation = `${rule.traditionalMeaning} Tông ${rule.name} hòa quyện tốt với tinh thần "${style}", mang lại diện mạo trang nhã, nền nã và vừa vặn cho tổng thể trang phục.`;
  } else if (score >= 60) {
    explanation = `Tông ${rule.name} khi kết hợp cùng phom dáng này tạo nên nét thử nghiệm riêng biệt, tuy nhiên cần chú trọng độ tương phản của phụ kiện và màu lót để đạt sự hài hòa tối ưu.`;
  } else {
    explanation = `Tông ${rule.name} ít khi xuất hiện trong quy thức nguyên bản của trang phục này, dễ tạo cảm giác lệch tone về bối cảnh văn hóa nếu không được tiết chế cẩn trọng.`;
  }

  // 7. Xây dựng đề xuất cải thiện (Suggestions)
  const suggestions: string[] = [];
  const secondaryList = rule.secondaryColors.join(', ');

  if (score >= 90) {
    suggestions.push(
      'Bảng màu đã đạt tỷ lệ vàng trong mỹ cảm truyền thống.',
      `Có thể điểm xuyết thêm màu bổ trợ (${secondaryList}) ở dải viền hoặc trang sức để tăng chiều sâu.`
    );
  } else if (score >= 75) {
    suggestions.push(
      `Phối thêm phụ kiện mang sắc màu bổ trợ (${secondaryList}) để làm dịu sắc độ tổng thể.`,
      'Giữ số lượng phụ kiện từ 1 - 2 món để tôn vinh phom dáng áo nguyên bản.'
    );
  } else if (score >= 60) {
    suggestions.push(
      `Thử kết hợp quần lụa hoặc dải thắt lưng mang sắc bổ trợ: ${secondaryList}.`,
      'Chọn trang sức kim khí như kiềng bạc hoặc chuỗi ngọc trai để trung hòa sắc độ áo.'
    );
  } else {
    suggestions.push(
      `Xem xét chuyển sang các gam màu truyền thống ăn ý hơn như: ${rule.secondaryColors.slice(0, 2).join(' hoặc ')}.`,
      'Hạn chế phối phụ kiện có màu tương phản gay gắt để tránh phân mảnh bố cục thị giác.'
    );
  }

  return {
    score,
    level,
    primaryColor: rule.name,
    primaryHex: rule.hex,
    secondaryColors: rule.secondaryColors,
    explanation,
    suggestions,
  };
}
