/**
 * TÀNG Y — VIỆT PHỤC OCCASION ADVISOR ENGINE
 * 
 * Động cơ cố vấn y phục truyền thống Việt Nam:
 * - Trả lời câu hỏi: "Hôm nay tôi nên mặc gì?"
 * - Gợi ý 2–3 phương án thực tế từ danh mục CANONICAL_ENTITIES hoạt động.
 * - Tuyệt đối không gợi ý 5 trang phục đã loại khỏi catalog (G004, G005, G026, G027, G029).
 * - Tái sử dụng compatibilityEngine (evaluateOutfit) để thẩm định độ tương thích.
 * - Tư vấn quà tặng văn hóa ý nghĩa, phân định rõ thủ công đương đại với hiện vật cổ.
 */

import { ALL_ITEMS, ITEMS_MAP, RESEARCH_SOURCES_MAP } from './dataAdapter';
import { CANONICAL_ENTITIES, REMOVED_CANONICAL_IDS } from './canonicalData';
import { evaluateOutfit } from './compatibilityEngine';
import { Item, OutfitEvaluation } from './types';

export interface OutfitRecommendation {
  id: string;
  title: string;
  itemIds: string[];
  items: Item[];
  evaluation: OutfitEvaluation;
  whySuits: string;
  stylingColorNotes: string;
  comfortNotes: string;
  culturalEvidenceStatus: string;
  warnings?: string;
}

export interface GiftSuggestion {
  id: string;
  name: string;
  itemOrCategory?: string;
  canonicalItemId?: string;
  culturalMeaning: string;
  suitableFor: string;
  budgetLevel: string;
  notes: string;
}

export interface AdvisorQuickAction {
  label: string;
  prompt: string;
}

export interface AdvisorResponse {
  message: string;
  quickActions: string[];
  recommendations?: OutfitRecommendation[];
  giftSuggestions?: GiftSuggestion[];
  dateContext?: string;
  locationContext?: string;
  sourcesCited?: Array<{ id: string; title: string; institution: string }>;
}

export interface ChatMessage {
  id: string;
  role: 'user' | 'model';
  text: string;
  timestamp: string;
  recommendations?: OutfitRecommendation[];
  giftSuggestions?: GiftSuggestion[];
  quickActions?: string[];
  dateContext?: string;
  locationContext?: string;
  sourcesCited?: Array<{ id: string; title: string; institution: string }>;
}

// Active canonical entities map (only allowed items)
const ACTIVE_ITEMS_MAP: Map<string, Item> = new Map();
CANONICAL_ENTITIES.forEach((e) => {
  if (!REMOVED_CANONICAL_IDS.has(e.primaryRecordId)) {
    ACTIVE_ITEMS_MAP.set(e.primaryRecordId, e.asItem);
  }
});

/**
 * Thẩm định và chuyển đổi danh sách itemIds thành OutfitRecommendation hoàn chỉnh
 */
export function resolveRecommendation(rawRec: {
  id?: string;
  title: string;
  itemIds: string[];
  whySuits: string;
  stylingColorNotes: string;
  comfortNotes: string;
  culturalEvidenceStatus?: string;
  warnings?: string;
}): OutfitRecommendation | null {
  // Lọc chỉ giữ lại các item ID hợp lệ trong active catalog và không bị loại
  const validItems: Item[] = [];
  const validIds: string[] = [];

  for (const id of rawRec.itemIds) {
    if (REMOVED_CANONICAL_IDS.has(id)) {
      continue; // Tuyệt đối bỏ qua các món đã bị loại (G004, G005, G026, G027, G029)
    }
    const item = ACTIVE_ITEMS_MAP.get(id) || ITEMS_MAP.get(id);
    if (item && !REMOVED_CANONICAL_IDS.has(item.id)) {
      if (!validIds.includes(item.id)) {
        validIds.push(item.id);
        validItems.push(item);
      }
    }
  }

  if (validItems.length === 0) {
    return null;
  }

  // Chạy đánh giá tương thích hoàn toàn dữ liệu qua evaluateOutfit
  const evaluation = evaluateOutfit(validItems);

  return {
    id: rawRec.id || `rec_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`,
    title: rawRec.title,
    itemIds: validIds,
    items: validItems,
    evaluation,
    whySuits: rawRec.whySuits,
    stylingColorNotes: rawRec.stylingColorNotes,
    comfortNotes: rawRec.comfortNotes,
    culturalEvidenceStatus: rawRec.culturalEvidenceStatus || evaluation.label,
    warnings: rawRec.warnings || (evaluation.warnings.length > 0 ? evaluation.warnings.join('; ') : undefined),
  };
}

/**
 * 5 BỘ KHUYẾN NGHỊ MẪU CHUẨN MỰC THEO 5 BỐI CẢNH YÊU CẦU
 */

// 1. Sinh viên tham gia ngày hội văn hóa trường học
export const STUDENT_CULTURAL_EVENT_RECS = [
  {
    title: 'Áo Ngũ Thân Tay Chẽn Năng Động (Nam/Nữ)',
    itemIds: ['G008', 'G013', 'G031', 'G047'],
    whySuits: 'Phom dáng ngũ thân lịch thiệp, tay chẽn gọn gàng, kín đáo, cực kỳ phù hợp cho môi trường học đường và các hoạt động giao lưu văn hóa thanh niên.',
    stylingColorNotes: 'Khuyên chọn sắc xanh lam gốm, vàng mỡ gà hoặc trắng be; phối cùng khăn xếp đen/lam và guốc mộc thanh nhã.',
    comfortNotes: 'Tay áo may chẽn vừa vặn giúp cử động viết vẽ, giao tiếp dễ dàng; mặc thoải mái suốt 4–6 tiếng trong khuôn viên trường.',
    culturalEvidenceStatus: 'HISTORICALLY_SUPPORTED',
    warnings: 'Tránh chọn màu sắc quá phô trương hoặc vải lấp lánh phản quang; nên dùng vải lụa tơ, đũi hoặc thô tự nhiên.',
  },
  {
    title: 'Áo Tứ Thân Kinh Bắc Duyên Dáng (Nữ)',
    itemIds: ['G010', 'G011', 'G012', 'G042', 'G033'],
    whySuits: 'Mang đậm dấu ấn dân gian đồng bằng Bắc Bộ, phù hợp cho các tiết mục văn nghệ, gian hàng văn hóa hoặc ngày hội Việt phục học sinh - sinh viên.',
    stylingColorNotes: 'Áo tứ thân màu nâu trầm hoặc chàm nhẹ buông vạt, hé lộ yếm đào hoặc yếm hoa sen bên trong, thắt lưng lụa xanh/hồng buông rủ.',
    comfortNotes: 'Vạt áo buộc nhẹ trước bụng tạo độ ôm tự nhiên, váy đụp đen xòe rộng tiện bước đi.',
    culturalEvidenceStatus: 'HISTORICALLY_SUPPORTED',
    warnings: 'Lưu ý không ghép phụ kiện cung đình như Vân Kiên vào áo Tứ Thân để giữ vẹn nguyên tính dân gian.',
  },
  {
    title: 'Áo Bà Ba Nam Bộ Phóng Khoáng (Nam/Nữ)',
    itemIds: ['G028', 'G034', 'G047'],
    whySuits: 'Lựa chọn mộc mạc, gần gũi, năng động cho các hoạt động ngoại khóa, hội trại hay trò chơi dân gian tại trường.',
    stylingColorNotes: 'Gam màu đen, nâu đất hoặc tím than truyền thống; điểm xuyết chiếc khăn rằn sọc đen trắng quàng cổ.',
    comfortNotes: 'Chất vải mát, thấm hút mồ hôi tốt, độ bền cao, lý tưởng cho cả ngày hoạt động ngoài trời.',
    culturalEvidenceStatus: 'HISTORICALLY_SUPPORTED',
  },
];

// 2. Đi thăm di tích lịch sử và chụp ảnh lưu niệm
export const HERITAGE_VISIT_PHOTO_RECS = [
  {
    title: 'Áo Tấc Lễ Phục Trang Trọng (Nam/Nữ)',
    itemIds: ['G009', 'G013', 'G031', 'A011'],
    whySuits: 'Áo Tấc (áo ngũ thân tay thụng) là lễ phục chuẩn mực triều Nguyễn. Tà áo thụng rộng buông dài tạo độ bay bổng mỹ miều khi chụp ảnh tại các không gian cổ kính như Văn Miếu, Hoàng thành hay chùa chiền.',
    stylingColorNotes: 'Sắc đỏ điều, xanh thiên thanh hoặc vàng quý tộc; phối cùng quần trắng rộng sáng màu, khăn đóng chỉnh tề và quạt lụa cổ cầm tay.',
    comfortNotes: 'Tay thụng dài cần vén nhẹ khi thắp hương hay di chuyển qua lối hẹp; thích hợp dạo ngắm chụp ảnh từ 2–3 tiếng.',
    culturalEvidenceStatus: 'AUTHENTIC',
    warnings: 'Khi vào gian thờ tôn nghiêm, nên giữ tà áo buông thả trang trọng, tránh buộc vạt tùy tiện.',
  },
  {
    title: 'Áo Nhật Bình Cung Đình Huế (Nữ)',
    itemIds: ['G018', 'G013', 'G032', 'G046'],
    whySuits: 'Phẩm phục quý phái của mệnh phụ và hậu phi triều Nguyễn với dải cổ chữ nhật rực rỡ và dải ngũ sắc ngũ hành ở cổ tay, tôn lên vẻ đài các khi chụp ảnh tại di tích kiến trúc cổ.',
    stylingColorNotes: 'Hoa văn loan phượng trên nền vải gấm sa; phối cùng khăn vành dây quấn đều đặn và hài thêu hoa sen.',
    comfortNotes: 'Trang phục trang trọng nhiều lớp, nên chọn ngày thời tiết dịu mát và có người hỗ trợ chỉnh nếp áo khi lên hình.',
    culturalEvidenceStatus: 'AUTHENTIC',
    warnings: 'Áo Nhật Bình có quy thức hoa văn nghiêm ngặt; không nên tự ý phối cùng các phụ kiện ngoại lai.',
  },
  {
    title: 'Áo Giao Lĩnh Cổ Kính Thời Lê (Nam/Nữ)',
    itemIds: ['G001', 'G013', 'G047'],
    whySuits: 'Dáng áo vạt chéo giao lĩnh cổ kính thời Lý - Trần - Lê, tạo nên chiều sâu lịch sử độc đáo cho bộ ảnh tại các di chỉ khảo cổ hay đền đình cổ truyền.',
    stylingColorNotes: 'Gam màu trầm mộc như xám tro, nâu trà hoặc lam trầm để làm nổi bật đường nét vạt chéo thanh nhã.',
    comfortNotes: 'Phom dáng rộng rãi, thoáng mát, dễ chịu khi tản bộ thăm thú.',
    culturalEvidenceStatus: 'HISTORICALLY_SUPPORTED',
  },
];

// 3. Đi dự đám cưới
export const WEDDING_GUEST_RECS = [
  {
    title: 'Áo Ngũ Thân Tay Chẽn Lụa Gấm Nhã Nhặn (Nam/Nữ)',
    itemIds: ['G008', 'G013', 'G031', 'G046'],
    whySuits: 'Vừa đủ trang trọng để tôn trọng ngày vui của gia chủ, vừa giữ sự chừng mực thanh lịch, không lấn át trang phục của cô dâu chú rể.',
    stylingColorNotes: 'Gam màu tao nhã: hồng phấn, xanh ngọc, xanh rêu hoặc be vàng; dệt hoa văn chìm tinh tế, đi kèm hài thêu êm chân.',
    comfortNotes: 'Độ ôm vừa vặn, ngồi dự tiệc hay chúc rượu đều thoải mái, thanh thoát.',
    culturalEvidenceStatus: 'HISTORICALLY_SUPPORTED',
    warnings: 'Khách mời không nên chọn trang phục thêu rồng phượng đại lễ hay sắc đỏ rực nguyên cây để nhường tâm điểm cho đôi tân lang tân nương.',
  },
  {
    title: 'Áo Dài Dáng Xưa Lịch Thiệp (Nam/Nữ)',
    itemIds: ['G030', 'G047'],
    whySuits: 'Lựa chọn an toàn, phổ biến và tôn dáng cho mọi độ tuổi khi tham dự hôn lễ truyền thống hoặc tiệc cưới hiện đại.',
    stylingColorNotes: 'Màu phấn nhạt, xanh ngọc bích hoặc trắng kem điểm hoa văn tao nhã.',
    comfortNotes: 'Dễ dàng di chuyển, bước lên xe và đứng trò chuyện suốt buổi lễ.',
    culturalEvidenceStatus: 'HISTORICALLY_SUPPORTED',
  },
  {
    title: 'Áo Tấc Tơ Tằm Trẻ Trung (Nam/Nữ)',
    itemIds: ['G009', 'G013', 'G031'],
    whySuits: 'Dành cho khách mời thân thiết muốn thể hiện sự trân trọng đặc biệt với ngày trọng đại mang phong cách cổ truyền.',
    stylingColorNotes: 'Màu xanh lục nhạt, vàng mỡ gà hoặc lam nhạt, không trùng sắc đỏ đại lễ của cô dâu chú rể.',
    comfortNotes: 'Nên chọn chất liệu tơ tằm mềm rũ, nhẹ nhàng.',
    culturalEvidenceStatus: 'AUTHENTIC',
    warnings: 'TUYỆT ĐỐI KHÔNG mặc Long Bào (G022) hay Phượng Phục đại lễ khi đi dự cưới người khác.',
  },
];

// 4. Trang phục dạo phố, cà phê cuối tuần thoải mái
export const CASUAL_OUTING_RECS = [
  {
    title: 'Áo Bà Ba Cách Điệu Dạo Phố (Nam/Nữ)',
    itemIds: ['G028', 'G047', 'G034'],
    whySuits: 'Vẻ đẹp dung dị, tự nhiên, mang lại cảm giác thư thái tuyệt đối khi ngồi cà phê trò chuyện cùng bạn bè hay dạo phố đi bộ.',
    stylingColorNotes: 'Chất liệu lanh, đũi mộc mạc màu nâu đất, be hạt dẻ hoặc xanh pastel nhẹ nhàng.',
    comfortNotes: 'Cổ áo khoét tròn thoáng mát, xẻ tà hai bên hông tạo sự linh hoạt khi đứng ngồi.',
    culturalEvidenceStatus: 'HISTORICALLY_SUPPORTED',
  },
  {
    title: 'Áo Ngũ Thân Đũi Buông Nhẹ Nhàng (Nam/Nữ)',
    itemIds: ['G008', 'G013', 'G047'],
    whySuits: 'Phối kiểu thường phục thoải mái: áo ngũ thân tay chẽn may bằng vải đũi mềm buông nhẹ cùng quần ống rộng, không cần đội khăn xếp.',
    stylingColorNotes: 'Tông màu cát cháy, xám tro hoặc trắng ngà mộc mạc; kết hợp guốc mộc thanh âm lách cách đặc trưng.',
    comfortNotes: 'Mềm mại, thấm hút mồ hôi tốt, lý tưởng cho những buổi chiều thư giãn cuối tuần.',
    culturalEvidenceStatus: 'HISTORICALLY_SUPPORTED',
  },
];

// 5. Quà tặng văn hóa ý nghĩa
export const CULTURAL_GIFT_SUGGESTIONS: GiftSuggestion[] = [
  {
    id: 'gift_quat_lua',
    name: 'Quạt Lụa Vẽ Cổ Truyền (A011)',
    itemOrCategory: 'A011',
    canonicalItemId: 'A011',
    culturalMeaning: 'Biểu trưng cho phong thái nho nhã, tri thức và làn gió an lành, thanh tịnh trong mỹ học phương Đông.',
    suitableFor: 'Bạn bè quốc tế, đối tác ngoại giao, thầy cô giáo hoặc người yêu nghệ thuật truyền thống.',
    budgetLevel: 'Vừa phải (khoảng 250.000đ – 600.000đ tùy độ tinh xảo nan tre và nét vẽ)',
    notes: 'Món quà gọn nhẹ, dễ đóng hộp mang đi nước ngoài; giải thích rõ đây là sản phẩm thủ công mỹ nghệ đương đại lấy cảm hứng từ thư tịch cổ.',
  },
  {
    id: 'gift_khan_ran',
    name: 'Khăn Rằn Dệt Thủ Công Nam Bộ (G034)',
    itemOrCategory: 'G034',
    canonicalItemId: 'G034',
    culturalMeaning: 'Biểu tượng của tính cách chân phương, bền bỉ, ân tình và lòng hiếu khách của người dân phương Nam.',
    suitableFor: 'Bạn bè phương xa, khách du lịch, quà tặng tập thể hoặc thanh niên trẻ thích xê dịch.',
    budgetLevel: 'Tiết kiệm (khoảng 80.000đ – 180.000đ cho dòng dệt sợi bông tự nhiên)',
    notes: 'Có tính ứng dụng hàng ngày cao (che nắng, thấm mồ hôi, quàng cổ giữ ấm).',
  },
  {
    id: 'gift_non_bai_tho',
    name: 'Nón Bài Thơ Xứ Huế (G038)',
    itemOrCategory: 'G038',
    canonicalItemId: 'G038',
    culturalMeaning: 'Kết tinh nét thi vị, kín đáo của người con gái sông Hương; soi lên ánh sáng sẽ thấy ẩn hiện câu thơ và nhành trúc.',
    suitableFor: 'Phụ nữ, mẹ, cô giáo, người thân nữ giới nhân dịp kỷ niệm, sinh nhật hoặc 8/3.',
    budgetLevel: 'Hợp lý (khoảng 150.000đ – 350.000đ)',
    notes: 'Cần bảo quản nơi khô ráo, tránh va đập mạnh làm móp lá gân nón.',
  },
  {
    id: 'gift_tram_cai_toc',
    name: 'Trâm Cài Tóc Mỹ Nghệ (G041)',
    itemOrCategory: 'G041',
    canonicalItemId: 'G041',
    culturalMeaning: 'Món tín vật đài các, chúc cho vẻ đẹp đằm thắm, nhu thuận và duyên dáng theo thời gian.',
    suitableFor: 'Bạn gái, người yêu, bạn bè nữ thích búi tóc và diện trang phục truyền thống.',
    budgetLevel: 'Đa dạng (khoảng 150.000đ cho trâm gỗ khảm xà cừ đến 800.000đ cho trâm bạc chạm lộng)',
    notes: 'Được chế tác từ gỗ quý, sừng hoặc bạc mỹ nghệ đương đại.',
  },
  {
    id: 'gift_hai_theu',
    name: 'Hài Thêu Hoa Sen Truyền Thống (G046)',
    itemOrCategory: 'G046',
    canonicalItemId: 'G046',
    culturalMeaning: 'Biểu trưng cho từng bước chân nhẹ nhàng, thanh tao như đóa sen tinh khiết nở giữa đời thường.',
    suitableFor: 'Cô dâu trong lễ đính hôn, người thân diện lễ Tết hoặc diễn viên kịch hát truyền thống.',
    budgetLevel: 'Trung cao (khoảng 350.000đ – 750.000đ cho mũi hài thêu tay tỉ mỉ)',
    notes: 'Cần biết chính xác cỡ chân người nhận trước khi chọn đặt may.',
  },
];

/**
 * Phân tích câu hỏi người dùng và trả về phản hồi thông minh dựa trên dữ liệu chuẩn
 */
export function generateAdvisorResponse(
  userQuery: string,
  userDate?: string,
  _location?: string
): AdvisorResponse {
  const queryLower = (userQuery || '').toLowerCase();
  const dateStr = userDate || new Date().toLocaleDateString('vi-VN', {
    weekday: 'long',
    day: '2-digit',
    month: '2-digit',
    year: 'numeric',
  });

  // TÌNH HUỐNG 5: Quà tặng văn hóa (Gift Advisor) - loại trừ chụp ảnh lưu niệm
  const isGiftQuery =
    (queryLower.includes('quà') ||
      queryLower.includes('tặng') ||
      queryLower.includes('gift') ||
      queryLower.includes('mua kỷ niệm') ||
      queryLower.includes('đồ lưu niệm')) &&
    !queryLower.includes('chụp ảnh') &&
    !queryLower.includes('chụp hình');

  if (isGiftQuery) {
    return {
      message: `Chào bạn, gửi tặng một món quà mang phong vị văn hóa Việt Nam là cách rất tao nhã để trao gửi tâm tình. Dưới đây là các gợi ý quà tặng được chắt lọc từ di sản thủ công truyền thống:`,
      quickActions: [
        'Quà tặng cho bạn quốc tế',
        'Quà tặng ngân sách dưới 300k',
        'Gợi ý trang phục hôm nay',
        'Giải thích nguồn tư liệu',
      ],
      giftSuggestions: CULTURAL_GIFT_SUGGESTIONS,
      dateContext: dateStr,
      sourcesCited: [
        { id: 'S01', title: 'Ngàn Năm Áo Mũ', institution: 'Trần Quang Đức (NXB Thế Giới)' },
        { id: 'S03', title: 'Trang Phục Việt Nam', institution: 'Bạch Thái Bưởi / Viện Mỹ Thuật' },
      ],
    };
  }

  // TÌNH HUỐNG 1: Sinh viên / Trường học / Ngày hội văn hóa
  if (
    queryLower.includes('trường') ||
    queryLower.includes('sinh viên') ||
    queryLower.includes('học sinh') ||
    queryLower.includes('ngày hội') ||
    queryLower.includes('hội trại') ||
    queryLower.includes('clb') ||
    queryLower.includes('văn nghệ')
  ) {
    const resolvedRecs = STUDENT_CULTURAL_EVENT_RECS.map((r) => resolveRecommendation(r)).filter(
      (r): r is OutfitRecommendation => Boolean(r)
    );

    return {
      message: `Chào bạn! Tham gia ngày hội văn hóa tại trường học là dịp tuyệt vời để diện Việt Phục. Tiêu chí quan trọng nhất là lịch sự, chuẩn mực học đường nhưng vẫn thoải mái di chuyển và hoạt động suốt ngày dài (${dateStr}). Dưới đây là 3 phương án lý tưởng từ Tủ Áo Xưa:`,
      quickActions: [
        'Phối bộ Áo Ngũ Thân',
        'Phối bộ Áo Tứ Thân',
        'Tìm đồ đi chụp ảnh',
        'Gợi ý quà tặng',
      ],
      recommendations: resolvedRecs,
      dateContext: dateStr,
      sourcesCited: [
        { id: 'S01', title: 'Ngàn Năm Áo Mũ', institution: 'Trần Quang Đức (NXB Thế Giới)' },
        { id: 'S02', title: 'Đại Nam Thực Lục', institution: 'Quốc Sử Quán Triều Nguyễn' },
      ],
    };
  }

  // TÌNH HUỐNG 2: Đi thăm di tích lịch sử / chụp ảnh
  if (
    queryLower.includes('chụp ảnh') ||
    queryLower.includes('di tích') ||
    queryLower.includes('hoàng thành') ||
    queryLower.includes('văn miếu') ||
    queryLower.includes('huế') ||
    queryLower.includes('hội an') ||
    queryLower.includes('chùa') ||
    queryLower.includes('đền') ||
    queryLower.includes('tham quan') ||
    queryLower.includes('check in')
  ) {
    const resolvedRecs = HERITAGE_VISIT_PHOTO_RECS.map((r) => resolveRecommendation(r)).filter(
      (r): r is OutfitRecommendation => Boolean(r)
    );

    return {
      message: `Chào bạn! Khi đến thăm các không gian di tích lịch sử và chụp ảnh lưu niệm (${dateStr}), trang phục cần đạt sự tôn nghiêm nơi cửa di sản đồng thời tạo hiệu ứng thị giác thanh thoát, cổ kính trước ống kính:`,
      quickActions: [
        'Phối bộ Áo Tấc',
        'Phối bộ Áo Nhật Bình',
        'Gợi ý trang phục hôm nay',
        'Giải thích nguồn tư liệu',
      ],
      recommendations: resolvedRecs,
      dateContext: dateStr,
      sourcesCited: [
        { id: 'S01', title: 'Ngàn Năm Áo Mũ', institution: 'Trần Quang Đức (NXB Thế Giới)' },
        { id: 'S02', title: 'Khâm Định Đại Nam Hội Điển Sự Lệ', institution: 'Nội Các Triều Nguyễn' },
      ],
    };
  }

  // TÌNH HUỐNG 3: Đi dự đám cưới
  if (
    queryLower.includes('cưới') ||
    queryLower.includes('hôn lễ') ||
    queryLower.includes('tiệc cưới') ||
    queryLower.includes('ăn cưới') ||
    queryLower.includes('đám cưới')
  ) {
    const resolvedRecs = WEDDING_GUEST_RECS.map((r) => resolveRecommendation(r)).filter(
      (r): r is OutfitRecommendation => Boolean(r)
    );

    return {
      message: `Chào bạn! Đi dự đám cưới bằng trang phục truyền thống là một nghĩa cử rất trang trọng và đậm đà bản sắc. Nguyên tắc vàng cho khách mời là nhã nhặn, tôn nghiêm, tránh mặc sắc đỏ đại lễ rực rỡ để nhường tâm điểm cho cô dâu chú rể:`,
      quickActions: [
        'Phối bộ Áo Ngũ Thân lụa',
        'Phối bộ Áo Dài hiện đại',
        'Gợi ý quà tặng mừng cưới',
        'Giải thích nguồn tư liệu',
      ],
      recommendations: resolvedRecs,
      dateContext: dateStr,
      sourcesCited: [
        { id: 'S01', title: 'Ngàn Năm Áo Mũ', institution: 'Trần Quang Đức (NXB Thế Giới)' },
        { id: 'S04', title: 'Bảo tàng Lịch sử Quốc gia', institution: 'BTLSQG Việt Nam' },
      ],
    };
  }

  // TÌNH HUỐNG 4: Đi dạo phố / cà phê / dã ngoại cuối tuần thoải mái
  if (
    queryLower.includes('dạo phố') ||
    queryLower.includes('cà phê') ||
    queryLower.includes('cuối tuần') ||
    queryLower.includes('thoải mái') ||
    queryLower.includes('nhẹ nhàng') ||
    queryLower.includes('hôm nay') ||
    queryLower.includes('bình thường') ||
    queryLower.includes('casual')
  ) {
    const resolvedRecs = CASUAL_OUTING_RECS.map((r) => resolveRecommendation(r)).filter(
      (r): r is OutfitRecommendation => Boolean(r)
    );

    return {
      message: `Chào bạn! Cho những kế hoạch dạo phố, gặp gỡ bạn bè hay ngồi cà phê thư giãn (${dateStr}), chúng mình ưu tiên độ nhẹ mát, phom dáng bay bổng và cử động linh hoạt:`,
      quickActions: [
        'Phối bộ Áo Bà Ba',
        'Phối bộ Ngũ Thân vải đũi',
        'Tìm đồ đi chụp ảnh',
        'Gợi ý quà tặng',
      ],
      recommendations: resolvedRecs,
      dateContext: dateStr,
      sourcesCited: [
        { id: 'S01', title: 'Ngàn Năm Áo Mũ', institution: 'Trần Quang Đức' },
        { id: 'S03', title: 'Trang Phục Việt Nam', institution: 'Viện Mỹ Thuật' },
      ],
    };
  }

  // GIẢI THÍCH NGUỒN TƯ LIỆU
  if (
    queryLower.includes('nguồn') ||
    queryLower.includes('tư liệu') ||
    queryLower.includes('s01') ||
    queryLower.includes('s02') ||
    queryLower.includes('trần quang đức') ||
    queryLower.includes('bằng chứng') ||
    queryLower.includes('chứng cứ')
  ) {
    const sources = Object.values(RESEARCH_SOURCES_MAP).slice(0, 4);
    return {
      message: `Tàng Y xây dựng hệ thống quy thức và thẩm định y phục dựa trên các tài liệu khảo cứu lịch sử và hiện vật bảo tàng chính thống. Chúng mình tuyệt đối không dùng AI để tự phong "chuẩn mực lịch sử" mà luôn bám sát nguồn dẫn:`,
      quickActions: [
        'Gợi ý trang phục hôm nay',
        'Tìm đồ đi chụp ảnh',
        'Gợi ý quà tặng',
        'Phối bộ này',
      ],
      sourcesCited: sources.map((s) => ({
        id: s.id,
        title: s.title,
        institution: s.institution,
      })),
      dateContext: dateStr,
    };
  }

  // MẶC ĐỊNH: Chào hỏi và hỏi ngắn gọn nhu cầu (Primary User Journey)
  const defaultRecs = STUDENT_CULTURAL_EVENT_RECS.slice(0, 2).map((r) => resolveRecommendation(r)).filter(
    (r): r is OutfitRecommendation => Boolean(r)
  );

  return {
    message: `Chào bạn! Hôm nay (${dateStr}), bạn đang có kế hoạch đi đâu hay tham dự sự kiện gì? Bạn có thể chia sẻ ngắn gọn:
• Dịp tham dự (ngày hội trường, đi chùa/di tích, đám cưới, dạo phố, chụp ảnh...)
• Phong cách mong muốn (thanh nhã, truyền thống cổ điển hay cách tân trẻ trung)
• Giới hạn cần lưu ý (thời gian mặc, thời tiết, độ thoải mái di chuyển)

Hoặc chọn nhanh một trong các gợi ý dưới đây để Tàng Y tư vấn ngay nhé:`,
    quickActions: [
      'Gợi ý trang phục hôm nay',
      'Tìm đồ đi chụp ảnh di tích',
      'Trang phục dự đám cưới',
      'Đồ thoải mái dạo phố cà phê',
      'Gợi ý quà tặng văn hóa',
    ],
    recommendations: defaultRecs,
    dateContext: dateStr,
  };
}
