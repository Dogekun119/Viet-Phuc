/**
 * CANONICAL ENTITY LAYER
 * Tách biệt thực thể chuẩn (Canonical Entity) khỏi bản ghi rải rác.
 * Giải quyết triệt để vấn đề duplicate (Hia, Hài, Guốc Mộc, Bổ Tử, Vân Kiên, Đai...)
 * Tích hợp nguồn gốc hình ảnh (Image Provenance) và phân tầng nghiên cứu (Curated vs Research).
 */

import rawResearchData from '../data/Viet_Phuc_Master_Research_v1.json';
import { Item, EvidenceLevel } from './types';
import type { ModelGender, ItemGenderScope } from './types';
import {
  CANONICAL_ASSET_REGISTRY_V3,
  AssetClassification,
} from '../data/canonicalAssetRegistry';

export type { ModelGender, ItemGenderScope };

export type CanonicalObjectType =
  | 'GARMENT'
  | 'ACCESSORY'
  | 'FOOTWEAR'
  | 'HEADWEAR'
  | 'COMPONENT';

export type BrowseCategory =
  | 'ALL'
  | 'AO'
  | 'AO_TRONG'
  | 'AO_NGOAI'
  | 'QUAN_VAY'
  | 'GIAY_DEP'
  | 'KHAN_NON'
  | 'PHU_KIEN';

export type ResearchStatus =
  | 'CURATED_CATALOG' // Main verified & well-supported catalog
  | 'NEEDS_VERIFICATION' // Historical reference but needs verification
  | 'CONTESTED_UNCERTAIN' // Debated taxonomy / reconstruction
  | 'OUT_OF_CORE'; // Out of core Kinh scope (e.g. Áo Chàm)

export type ImageProvenanceType =
  | 'DOCUMENTED_OBJECT' // photograph of an actual documented museum/object collection item
  | 'HISTORICAL_IMAGE' // historical photograph, painting, drawing, postcard
  | 'RECONSTRUCTION' // modern historical reconstruction
  | 'RESEARCH_PLATE' // archival research plate
  | 'ILLUSTRATION' // interpretive drawing / illustration
  | 'NO_VERIFIED_IMAGE'; // no reliable visual source available

export type ImageStatusLabelVi =
  | '✓ Ảnh hiện vật'
  | '✓ Ảnh tư liệu lịch sử'
  | '△ Ảnh phục dựng'
  | '◇ Bản vẽ khảo cứu'
  | '△ Hình minh họa'
  | '⚠ Chưa có ảnh xác thực';

export interface ImageProvenance {
  src?: string;
  alt?: string;
  imageType: ImageProvenanceType;
  imageStatusLabelVi: ImageStatusLabelVi;
  assetStatus?: AssetClassification;
  assetFilename?: string;
  sourceInstitution?: string;
  sourcePageUrl?: string;
  creator?: string;
  license?: string;
  verificationNote?: string;
}

export interface CanonicalVariant {
  id: string;
  name: string;
  note: string;
  sourceIds?: string[];
}

export interface CanonicalSource {
  id: string;
  name: string;
  institution?: string;
  type?: string;
  url?: string;
}

export interface CanonicalEntity {
  canonicalId: string;
  primaryRecordId: string;
  mergedRecordIds: string[];
  canonicalNameVi: string;
  aliases: string[];
  objectType: CanonicalObjectType;
  browseCategory: BrowseCategory;
  browseCategoryLabel: string;
  originalTaxonomy: string;
  variants: CanonicalVariant[];

  // Disentangled taxonomy dimensions
  periods: string[];
  geographicRegions: string[];
  locations: string[];
  socialContext: string[];
  gender: string[];
  genderScope: ItemGenderScope;
  contexts: string[];

  constructionNotes: string;
  layerRole: string;
  warnings: string;
  researchNotes: string;

  evidenceStatus: EvidenceLevel;
  evidenceLabelVi: string;
  researchStatus: ResearchStatus;
  researchStatusLabelVi: string;

  sourceIds: string[];
  sources: CanonicalSource[];
  image: ImageProvenance;

  // Bridge to original Item interface for compatibility
  asItem: Item;
}

// Map research sources map from JSON
const SOURCES_LIST = (rawResearchData.SOURCES || []) as Array<{
  id: string;
  title: string;
  institution: string;
  type: string;
  usedFor: string;
  url: string;
}>;

const SOURCES_MAP: Record<string, CanonicalSource> = SOURCES_LIST.reduce(
  (acc, s) => {
    acc[s.id] = {
      id: s.id,
      name: s.title,
      institution: s.institution,
      type: s.type,
      url: s.url,
    };
    return acc;
  },
  {} as Record<string, CanonicalSource>
);

function getSources(ids: string[] = []): CanonicalSource[] {
  return ids.map((id) => SOURCES_MAP[id] || { id, name: `Tư liệu ${id}` });
}

// Convert Evidence Level to Vietnamese label
export function getEvidenceLabelVi(level: string | undefined): string {
  if (!level) return 'Chưa đủ tư liệu';
  const u = level.toUpperCase();
  if (u.includes('VERIFIED')) return 'Đã kiểm chứng';
  if (u.includes('STRONG')) return 'Có cơ sở mạnh';
  if (u.includes('CONSISTENT')) return 'Phù hợp bối cảnh lịch sử';
  if (u.includes('CONTESTED')) return 'Có tranh luận tư liệu';
  return 'Chưa đủ tư liệu';
}

/**
 * DETERMINISTIC GENDER SCOPE DETERMINATION
 * Dựa trên tài liệu Master Research v1:
 * - female: Chỉ dành riêng cho nữ (Áo Tứ Thân, Yếm, Váy, Nhật Bình, Áo Mệnh Phụ, Phượng Phục, Khăn Vành Dây, Khăn Mỏ Quạ, Nón Ba Tầm, Nón Thúng, Nón Bài Thơ, Trâm, Dây Ruột Tượng)
 * - male: Chỉ dành riêng cho nam (Áo Tứ Điên, Quần Lá Tọa, Khố, Bổ Phục, Bổ Tử, Mãng Bào, Mãng Lan, Long Bào, Hoàng Bào, Cổn Phục, Áo Thâm, Mũ Cánh Chuồn, Hốt, Hia, Thẻ Bài)
 * - unknown: Chưa đủ tư liệu xác minh (Áo Cổ Thìa G004)
 * - unisex: Trang phục chung / dùng cho cả nam & nữ qua các thời kỳ
 */
export function determineGenderScope(
  id: string,
  _name: string = '',
  _category: string = '',
  audience: string[] = []
): ItemGenderScope {
  // Explicit female items based on master research
  if (
    [
      'G010', 'G011', 'G012', 'G018', 'G019', 'G025',
      'G032', 'G033', 'G036', 'G037', 'G038', 'G041', 'G043',
    ].includes(id)
  ) {
    return 'female';
  }

  // Explicit male items based on master research
  if (
    [
      'G007', 'G014', 'G015', 'G016', 'G017', 'G020',
      'G021', 'G022', 'G023', 'G024', 'G026', 'G039',
      'G044', 'G045', 'A012',
    ].includes(id)
  ) {
    return 'male';
  }

  // Items with unknown / under-verification audience
  if (id === 'G004' || audience.includes('Cần xác minh')) {
    return 'unknown';
  }

  // All other canonical entities are unisex (worn by both men and women across history or shared accessories)
  return 'unisex';
}

/**
 * Checks whether an item or canonical entity is compatible with a chosen ModelGender filter.
 * - ModelGender 'female': accepts 'female', 'unisex', and 'unknown'
 * - ModelGender 'male': accepts 'male', 'unisex', and 'unknown'
 */
function isCanonicalEntity(item: Item | CanonicalEntity): item is CanonicalEntity {
  return 'canonicalId' in item;
}

export function isItemCompatibleWithGender(
  item: Item | CanonicalEntity,
  modelGender: ModelGender
): boolean {
  let scope: ItemGenderScope = 'unisex';
  if (item.genderScope) {
    scope = item.genderScope;
  } else if (isCanonicalEntity(item)) {
    scope = determineGenderScope(item.primaryRecordId, item.canonicalNameVi, item.originalTaxonomy);
  } else {
    scope = determineGenderScope(item.id, item.name, item.category || '');
  }

  if (scope === 'unisex' || scope === 'unknown') return true;
  return scope === modelGender;
}

// Canonical Asset Provenance Resolver (Version 3)
export function getCanonicalEntityImage(
  id: string,
  name: string
): ImageProvenance {
  const assetEntry = CANONICAL_ASSET_REGISTRY_V3[id];
  if (!assetEntry) {
    return {
      imageType: 'NO_VERIFIED_IMAGE',
      imageStatusLabelVi: '⚠ Chưa có ảnh xác thực',
      verificationNote: 'Đang nghiên cứu tư liệu hình ảnh hiện vật bảo tàng.',
    };
  }

  const imageType: ImageProvenanceType =
    assetEntry.assetStatus === 'TƯ LIỆU'
      ? 'DOCUMENTED_OBJECT'
      : assetEntry.assetStatus === 'PHỤC DỰNG'
      ? 'RECONSTRUCTION'
      : 'RESEARCH_PLATE';

  const imageStatusLabelVi: ImageStatusLabelVi =
    assetEntry.assetStatus === 'TƯ LIỆU'
      ? '✓ Ảnh hiện vật'
      : assetEntry.assetStatus === 'PHỤC DỰNG'
      ? '△ Ảnh phục dựng'
      : '◇ Bản vẽ khảo cứu';

  return {
    src: assetEntry.src,
    alt: `${name} · ${assetEntry.assetStatus} · ${assetEntry.sourceInstitution}`,
    imageType,
    imageStatusLabelVi,
    assetStatus: assetEntry.assetStatus,
    assetFilename: assetEntry.asset,
    sourceInstitution: assetEntry.sourceInstitution,
    license: assetEntry.license,
    verificationNote: assetEntry.verificationNote,
  };
}

export function getBrowseCategoryLabel(cat: BrowseCategory): string {
  switch (cat) {
    case 'AO':
      return 'Áo';
    case 'AO_TRONG':
      return 'Áo trong';
    case 'AO_NGOAI':
      return 'Áo ngoài';
    case 'QUAN_VAY':
      return 'Quần & Váy';
    case 'GIAY_DEP':
      return 'Giày & Dép';
    case 'KHAN_NON':
      return 'Khăn & Nón';
    case 'PHU_KIEN':
      return 'Phụ kiện';
    default:
      return 'Tất cả';
  }
}

export function getResearchStatusLabelVi(status: ResearchStatus): string {
  switch (status) {
    case 'CURATED_CATALOG':
      return 'Tủ Áo tuyển chọn';
    case 'NEEDS_VERIFICATION':
      return 'Hồ sơ đang xác minh';
    case 'CONTESTED_UNCERTAIN':
      return 'Hồ sơ tranh luận học thuật';
    case 'OUT_OF_CORE':
      return 'Ngoài phạm vi Kinh phục';
  }
}

// Build Canonical Entities
function buildCanonicalEntities(): {
  entities: CanonicalEntity[];
  archivedEntities: CanonicalEntity[];
} {
  const rawGarments = (rawResearchData.MASTER_GARMENTS || []) as Array<{
    id: string;
    name: string;
    aliases?: string[];
    category?: string;
    period?: string[];
    audience?: string[];
    region?: string[];
    context?: string[];
    auditStatus?: string;
    evidenceLevel?: string;
    constructionNotes?: string;
    layerCompatibility?: string;
    warnings?: string;
    researchNotes?: string;
    sourceIds?: string[];
  }>;

  const rawAccessories = (rawResearchData.ACCESSORIES || []) as Array<{
    id: string;
    name: string;
    taxonomy?: string;
    status?: string;
    periodContext?: string;
    userRole?: string;
    compatibilityLogic?: string;
    evidence?: string;
    source?: string;
  }>;

  const entities: CanonicalEntity[] = [];
  const archivedEntities: CanonicalEntity[] = [];

  // Five garments explicitly removed from active catalog per historical/curation directive:
  // G004: Áo Cổ Thìa, G005: Áo Bán Tí, G026: Áo Thâm, G027: Áo Cánh, G029: Áo Chàm
  const REMOVED_ITEM_IDS = new Set(['G004', 'G005', 'G026', 'G027', 'G029']);

  // 1. Process Master Garments and merge overlapping accessories
  rawGarments.forEach((g) => {
    const gid = g.id;
    let mergedRecordIds = [gid];
    const variants: CanonicalVariant[] = [];
    let browseCategory: BrowseCategory = 'AO';
    let objectType: CanonicalObjectType = 'GARMENT';
    let researchStatus: ResearchStatus = 'CURATED_CATALOG';

    // Disentangle taxonomy dimensions
    let periods: string[] = g.period || [];
    let geographicRegions: string[] = [];
    let locations: string[] = [];
    let socialContext: string[] = [];
    let gender: string[] = [];
    let contexts: string[] = g.context || [];

    // Analyze region and audience tags
    (g.region || []).forEach((r) => {
      if (['Bắc Bộ', 'Trung Bộ', 'Nam Bộ', 'Toàn quốc', 'Đàng Ngoài', 'Đàng Trong'].includes(r)) {
        geographicRegions.push(r);
      } else if (['Huế', 'Kinh kỳ', 'Kinh Bắc', 'Đồng bằng sông Hồng'].includes(r)) {
        locations.push(r);
      } else if (['Cung đình', 'Hoàng cung', 'Nông thôn'].includes(r)) {
        contexts.push(r);
      }
    });

    (g.audience || []).forEach((aud) => {
      if (['Nam', 'Nữ'].includes(aud)) {
        gender.push(aud);
      } else {
        socialContext.push(aud);
      }
    });

    // Determine Browse Category & Object Type
    const nameLower = g.name.toLowerCase();
    const catLower = (g.category || '').toLowerCase();

    if (
      catLower.includes('khăn') ||
      catLower.includes('nón') ||
      catLower.includes('mũ') ||
      nameLower.includes('khăn') ||
      nameLower.includes('nón') ||
      nameLower.includes('mũ')
    ) {
      browseCategory = 'KHAN_NON';
      objectType = 'HEADWEAR';
    } else if (
      catLower.includes('giày') ||
      catLower.includes('footwear') ||
      nameLower.includes('hài') ||
      nameLower.includes('hia') ||
      nameLower.includes('guốc')
    ) {
      browseCategory = 'GIAY_DEP';
      objectType = 'FOOTWEAR';
    } else if (
      catLower.includes('thân dưới') ||
      nameLower.includes('váy') ||
      nameLower.includes('quần') ||
      nameLower.includes('khố') ||
      nameLower.includes('xiêm')
    ) {
      browseCategory = 'QUAN_VAY';
      objectType = 'GARMENT';
    } else if (
      catLower.includes('nội y') ||
      catLower.includes('lớp trong') ||
      nameLower.includes('yếm') ||
      nameLower.includes('áo lót')
    ) {
      browseCategory = 'AO_TRONG';
      objectType = 'GARMENT';
    } else if (
      catLower.includes('áo khoác') ||
      catLower.includes('cung đình') ||
      catLower.includes('áo lễ') ||
      catLower.includes('phục phẩm') ||
      catLower.includes('hệ phục trang') ||
      catLower.includes('phục trang nữ cung đình') ||
      nameLower.includes('long bào') ||
      nameLower.includes('hoàng bào') ||
      nameLower.includes('cổn phục') ||
      nameLower.includes('mãng bào') ||
      nameLower.includes('mãng lan') ||
      nameLower.includes('nhật bình') ||
      nameLower.includes('bổ phục') ||
      nameLower.includes('áo tấc') ||
      nameLower.includes('phượng phục') ||
      nameLower.includes('áo mệnh phụ')
    ) {
      browseCategory = 'AO_NGOAI';
      objectType = 'GARMENT';
    } else if (
      nameLower.startsWith('áo') ||
      catLower.includes('áo thân trên') ||
      catLower.includes('áo bốn vạt') ||
      catLower.includes('áo tay ngắn') ||
      catLower.includes('áo dân gian') ||
      catLower.includes('áo dài')
    ) {
      browseCategory = 'AO';
      objectType = 'GARMENT';
    } else {
      browseCategory = 'PHU_KIEN';
      objectType = 'ACCESSORY';
    }

    // Handle deduplication and merging with corresponding accessories
    if (gid === 'G017') {
      // Bổ Tử (G017 + A002)
      mergedRecordIds = ['G017', 'A002'];
      objectType = 'COMPONENT';
      browseCategory = 'PHU_KIEN';
      variants.push(
        {
          id: 'bo_tu_van',
          name: 'Bổ tử Quan Văn',
          note: 'Thêu chim (Hạc, Cò, Trĩ, Nhạn...) biểu thị văn trị theo 9 phẩm trật.',
          sourceIds: ['S01', 'S02'],
        },
        {
          id: 'bo_tu_vo',
          name: 'Bổ tử Quan Võ',
          note: 'Thêu thú (Kỳ lân, Sư tử, Hổ, Báo...) biểu thị võ công theo phẩm hàm.',
          sourceIds: ['S01', 'S02'],
        }
      );
    } else if (gid === 'G040') {
      // Vân Kiên (G040 + A001)
      mergedRecordIds = ['G040', 'A001'];
      objectType = 'ACCESSORY';
      browseCategory = 'PHU_KIEN';
    } else if (gid === 'G041') {
      // Trâm (G041 + A006)
      mergedRecordIds = ['G041', 'A006'];
      objectType = 'ACCESSORY';
      browseCategory = 'PHU_KIEN';
      variants.push(
        { id: 'tram_ngoc', name: 'Trâm ngọc', note: 'Trâm ngọc bích quý tộc, hoàng cung.' },
        { id: 'tram_bac', name: 'Trâm bạc / trâm gỗ', note: 'Trâm bạc hoa thị hoặc gỗ chạm dân gian.' }
      );
    } else if (gid === 'G042') {
      // Đai / Thắt lưng (G042 + A003 + A004 + A013)
      mergedRecordIds = ['G042', 'A003', 'A004', 'A013'];
      objectType = 'ACCESSORY';
      browseCategory = 'PHU_KIEN';
      contexts = ['Cung đình', 'Dân gian', 'Lễ hội', 'Đời thường'];
      periods = ['Nhiều thời kỳ', 'Nhiều giai đoạn', 'Dân gian'];
      variants.push(
        {
          id: 'dai_ngoc_cung_dinh',
          name: 'Ngọc đai / Đai phẩm phục',
          note: 'Đai cứng nạm ngọc, đồi mồi biểu thị phẩm trật đại triều triều Nguyễn (A013/A003).',
          sourceIds: ['S02'],
        },
        {
          id: 'that_lung_lua',
          name: 'Thắt lưng lụa / Dải bao',
          note: 'Dải lụa mềm thắt giữ vạt áo tứ thân hoặc ngũ thân dân dã (A004).',
          sourceIds: ['S04'],
        }
      );
    } else if (gid === 'G043') {
      // Dây Ruột Tượng (G043 + A005)
      mergedRecordIds = ['G043', 'A005'];
      objectType = 'ACCESSORY';
      browseCategory = 'PHU_KIEN';
    } else if (gid === 'G044') {
      // Hốt (G044 + A007)
      mergedRecordIds = ['G044', 'A007'];
      objectType = 'ACCESSORY';
      browseCategory = 'PHU_KIEN';
    } else if (gid === 'G045') {
      // Hia (G045 + A008)
      mergedRecordIds = ['G045', 'A008'];
      objectType = 'FOOTWEAR';
      browseCategory = 'GIAY_DEP';
    } else if (gid === 'G046') {
      // Hài (G046 + A009)
      mergedRecordIds = ['G046', 'A009'];
      objectType = 'FOOTWEAR';
      browseCategory = 'GIAY_DEP';
      variants.push(
        { id: 'hai_mom_nhai', name: 'Hài mõm nhái cung đình', note: 'Hài mũi cong thêu kim tuyến triều Nguyễn.' },
        { id: 'hai_theu_nu', name: 'Hài thêu hoa dân gian', note: 'Hài lụa thêu hoa trang nhã nữ lưu.' }
      );
    } else if (gid === 'G047') {
      // Guốc Mộc (G047 + A010)
      mergedRecordIds = ['G047', 'A010'];
      objectType = 'FOOTWEAR';
      browseCategory = 'GIAY_DEP';
    }

    // Determine Research Status
    if (gid === 'G029') {
      researchStatus = 'OUT_OF_CORE'; // Áo Chàm is out of core Kinh scope
    } else if (['G002', 'G007', 'G036', 'G037'].includes(gid)) {
      researchStatus = 'CONTESTED_UNCERTAIN';
    } else if (['G004', 'G005', 'G019'].includes(gid)) {
      researchStatus = 'NEEDS_VERIFICATION';
    } else {
      researchStatus = 'CURATED_CATALOG';
    }

    // Determine Image Provenance via Canonical Asset System Version 3
    const image: ImageProvenance = getCanonicalEntityImage(gid, g.name);

    const evidenceLevel: EvidenceLevel = (g.evidenceLevel as EvidenceLevel) || 'UNCERTAIN';

    const genderScope: ItemGenderScope = determineGenderScope(
      gid,
      g.name,
      g.category || '',
      g.audience || []
    );

    const asItem: Item = {
      id: gid,
      name: g.name,
      aliases: g.aliases || [],
      category: g.category || 'Khác',
      period: periods,
      region: geographicRegions,
      gender: gender.length > 0 ? gender : ['Nam', 'Nữ'],
      genderScope,
      context: contexts,
      construction: g.constructionNotes || '',
      layerRole: [browseCategory],
      evidenceLevel,
      culturalNotes: g.researchNotes || '',
      sourceIds: g.sourceIds || [],
      auditStatus: g.auditStatus || 'CORE',
      warnings: g.warnings || '',
      raw: g,
    };

    const entityObj: CanonicalEntity = {
      canonicalId: `CANON_${gid}`,
      primaryRecordId: gid,
      mergedRecordIds,
      canonicalNameVi: g.name,
      aliases: g.aliases || [],
      objectType,
      browseCategory,
      browseCategoryLabel: getBrowseCategoryLabel(browseCategory),
      originalTaxonomy: g.category || 'Khác',
      variants,
      periods,
      geographicRegions: geographicRegions.length > 0 ? geographicRegions : ['Toàn quốc'],
      locations,
      socialContext,
      gender: gender.length > 0 ? gender : ['Cả hai'],
      genderScope,
      contexts,
      constructionNotes: g.constructionNotes || '',
      layerRole: g.layerCompatibility || '',
      warnings: g.warnings || '',
      researchNotes: g.researchNotes || '',
      evidenceStatus: evidenceLevel,
      evidenceLabelVi: getEvidenceLabelVi(evidenceLevel),
      researchStatus,
      researchStatusLabelVi: getResearchStatusLabelVi(researchStatus),
      sourceIds: g.sourceIds || [],
      sources: getSources(g.sourceIds || []),
      image,
      asItem,
    };

    if (REMOVED_ITEM_IDS.has(gid)) {
      archivedEntities.push(entityObj);
    } else {
      entities.push(entityObj);
    }
  });

  // 2. Add remaining unique accessories from rawAccessories (A011 Quạt, A012 Thẻ bài)
  // Note: A001-A010 & A013 are already merged into G017, G040-G047, G042!
  const uniqueAccessories = rawAccessories.filter((a) => ['A011', 'A012'].includes(a.id));

  uniqueAccessories.forEach((a) => {
    const aid = a.id;
    let researchStatus: ResearchStatus = aid === 'A012' ? 'NEEDS_VERIFICATION' : 'CURATED_CATALOG';
    const evidenceLevel: EvidenceLevel = (a.evidence as EvidenceLevel) || 'CONSISTENT';

    const genderScope: ItemGenderScope = determineGenderScope(
      aid,
      a.name,
      a.taxonomy || '',
      a.userRole ? [a.userRole] : []
    );

    const asItem: Item = {
      id: aid,
      name: a.name,
      aliases: [],
      category: a.taxonomy || 'Phụ kiện',
      period: a.periodContext ? [a.periodContext] : [],
      region: [],
      gender: a.userRole ? [a.userRole] : [],
      genderScope,
      context: a.periodContext ? [a.periodContext] : [],
      construction: a.compatibilityLogic || '',
      layerRole: ['Phụ kiện'],
      evidenceLevel,
      culturalNotes: a.compatibilityLogic || '',
      sourceIds: [],
      auditStatus: a.status || 'CORE',
      warnings: '',
      raw: a,
    };

    entities.push({
      canonicalId: `CANON_${aid}`,
      primaryRecordId: aid,
      mergedRecordIds: [aid],
      canonicalNameVi: a.name,
      aliases: [],
      objectType: 'ACCESSORY',
      browseCategory: 'PHU_KIEN',
      browseCategoryLabel: 'Phụ kiện',
      originalTaxonomy: a.taxonomy || 'Phụ kiện',
      variants: [],
      periods: a.periodContext ? [a.periodContext] : ['Nhiều thời kỳ'],
      geographicRegions: ['Toàn quốc'],
      locations: [],
      socialContext: a.userRole ? [a.userRole] : [],
      gender: ['Cả hai'],
      genderScope,
      contexts: a.periodContext ? [a.periodContext] : [],
      constructionNotes: a.compatibilityLogic || '',
      layerRole: a.compatibilityLogic || '',
      warnings: '',
      researchNotes: aid === 'A012' ? 'Cần xác định loại thẻ bài cụ thể trước khi lập quy thức.' : '',
      evidenceStatus: evidenceLevel,
      evidenceLabelVi: getEvidenceLabelVi(evidenceLevel),
      researchStatus,
      researchStatusLabelVi: getResearchStatusLabelVi(researchStatus),
      sourceIds: [],
      sources: [],
      image: getCanonicalEntityImage(aid, a.name),
      asItem,
    });
  });

  return { entities, archivedEntities };
}

// Canonical entities export
const { entities: builtEntities, archivedEntities: builtArchived } = buildCanonicalEntities();

export const REMOVED_CANONICAL_IDS = new Set(['G004', 'G005', 'G026', 'G027', 'G029']);

// Active Canonical Entities in wardrobe and styling: exactly 44 items
export const CANONICAL_ENTITIES: CanonicalEntity[] = builtEntities;

// Preserved research records outside the active catalog: exactly 5 items
export const ARCHIVED_RESEARCH_ENTITIES: CanonicalEntity[] = builtArchived;

export const CANONICAL_ENTITIES_MAP: Map<string, CanonicalEntity> = new Map(
  CANONICAL_ENTITIES.map((e) => [e.canonicalId, e])
);

// Curated vs Research Collections
export const CURATED_CATALOG_ENTITIES = CANONICAL_ENTITIES.filter(
  (e) => e.researchStatus === 'CURATED_CATALOG'
);

export const RESEARCH_COLLECTION_ENTITIES = CANONICAL_ENTITIES.filter(
  (e) => e.researchStatus !== 'CURATED_CATALOG'
);

// Statistics
export const CANONICAL_STATS = {
  totalCanonical: CANONICAL_ENTITIES.length,
  curatedCount: CURATED_CATALOG_ENTITIES.length,
  researchCount: RESEARCH_COLLECTION_ENTITIES.length,
  verifiedImageCount: CANONICAL_ENTITIES.filter(
    (e) => e.image.imageType !== 'NO_VERIFIED_IMAGE'
  ).length,
  pendingImageCount: CANONICAL_ENTITIES.filter(
    (e) => e.image.imageType === 'NO_VERIFIED_IMAGE'
  ).length,
};
