/**
 * TESTS CHO COMPATIBILITY ENGINE
 * 
 * Kiểm thử 4 điều kiện cốt lõi theo yêu cầu:
 * 1. Explicit mismatch thắng allow (ví dụ: Vân Kiên + Áo Tứ Thân => CULTURAL_MISMATCH)
 * 2. Thiếu condition cho Vân Kiên => INSUFFICIENT_DATA / context required
 * 3. Rule có sourceIds được phản ánh trên result
 * 4. Recommendations không xuất hiện khi không có rule
 */

import { ALL_ITEMS, ITEMS_MAP } from './dataAdapter';
import { evaluateOutfit, getRecommendedNextItems } from './compatibilityEngine';

export function runCompatibilityTests(): { passed: boolean; logs: string[] } {
  const logs: string[] = [];
  let allPassed = true;

  function assert(condition: boolean, testName: string) {
    if (condition) {
      logs.push(`✅ [PASS] ${testName}`);
    } else {
      logs.push(`❌ [FAIL] ${testName}`);
      allPassed = false;
    }
  }

  const tuThan = ITEMS_MAP.get('G010') || ALL_ITEMS.find((i) => i.name.includes('Tứ Thân'));
  const vanKien = ITEMS_MAP.get('G040') || ITEMS_MAP.get('A001') || ALL_ITEMS.find((i) => i.name.includes('Vân Kiên'));
  const yem = ITEMS_MAP.get('G011') || ALL_ITEMS.find((i) => i.name.includes('Yếm'));
  const vay = ITEMS_MAP.get('G012') || ALL_ITEMS.find((i) => i.name.includes('Váy'));
  const thatLung = ITEMS_MAP.get('A004') || ITEMS_MAP.get('G042');
  const boPhuc = ITEMS_MAP.get('G016');

  // Test 1: Explicit mismatch thắng allow (Vân kiên + Tứ thân => CULTURAL_MISMATCH)
  if (tuThan && vanKien) {
    const evalResult = evaluateOutfit([tuThan, vanKien]);
    assert(
      evalResult.label === 'CULTURAL_MISMATCH',
      'Test 1: Explicit mismatch thắng allow (Vân kiên + Áo Tứ thân => CULTURAL_MISMATCH)'
    );
  } else {
    logs.push('⚠️ [SKIP] Test 1: Không tìm thấy Tứ Thân hoặc Vân Kiên');
  }

  // Test 2: Thiếu condition cho Vân kiên => INSUFFICIENT_DATA / Context required
  if (vanKien) {
    // Vân Kiên với một item ngẫu nhiên không thuộc hoàng cung
    const randomItem = ALL_ITEMS.find((i) => i.id === 'G005' || i.id === 'G004');
    if (randomItem) {
      const evalResult = evaluateOutfit([vanKien, randomItem]);
      assert(
        evalResult.label === 'INSUFFICIENT_DATA' || evalResult.unmetConditions.length > 0,
        'Test 2: Thiếu condition cho Vân kiên => INSUFFICIENT_DATA / Context required'
      );
    }
  }

  // Test 3: Rule có source được hiện trên result
  if (tuThan && yem) {
    const evalResult = evaluateOutfit([tuThan, yem]);
    assert(
      evalResult.sourceIds.length > 0,
      'Test 3: Rule có source được hiển thị trên result (sourceIds non-empty)'
    );
  }

  // Test 4: Recommendations không xuất hiện khi không có rule
  const isolatedItem = ALL_ITEMS.find((i) => i.id === 'G015' || i.id === 'G029'); // Khố hoặc Áo Chàm
  if (isolatedItem) {
    const recs = getRecommendedNextItems([isolatedItem]);
    assert(
      recs.length === 0,
      'Test 4: Recommendations không xuất hiện khi không có rule đối ứng'
    );
  }

  return { passed: allPassed, logs };
}

// Chạy test nếu gọi trực tiếp
if (typeof process !== 'undefined' && process.argv && process.argv[1]?.includes('compatibilityEngine.test')) {
  const result = runCompatibilityTests();
  console.log(result.logs.join('\n'));
  if (!result.passed) {
    process.exit(1);
  }
}
