const yemLayerSvg = '/src/assets/models/garment_G011_yem.svg';
const tuThanLayerSvg = '/src/assets/models/garment_G010_tu_than.svg';
const giaoLinhLayerSvg = '/src/assets/models/garment_G001_giao_linh.svg';
import { Item } from './types';
import { CANONICAL_ENTITIES } from './canonicalData';

/**
 * Centralized garment layer ordering:
 * inner → main → outer → lower → accessory
 */
export const GARMENT_LAYER_ORDER = [
  'inner',
  'main',
  'outer',
  'lower',
  'accessory',
] as const;

export type GarmentLayerType = (typeof GARMENT_LAYER_ORDER)[number];

/**
 * Centralized z-index map preventing scattered z-index values across the codebase:
 * Base model is at z-0/z-1.
 * Layers are stacked predictably: inner (11) → main (12) → outer (13) → lower (14) → accessory (15).
 * Vignette is at z-16, badges & indicators at z-20.
 */
export const LAYER_Z_INDEX_MAP: Record<GarmentLayerType, number> = {
  inner: 11,
  main: 12,
  outer: 13,
  lower: 14,
  accessory: 15,
};

/**
 * Placement configuration for positioning a garment layer:
 * Uses the same absolute coordinate system as the base model.
 */
export interface GarmentPlacement {
  x: number;
  y: number;
  scale: number;
  rotation: number;
}

/**
 * Runtime garment layer data structure rendered inside GarmentLayerContainer
 */
export interface GarmentLayerData {
  itemId: string;
  asset: string;
  layerType: GarmentLayerType;
  placement: GarmentPlacement;
  visible?: boolean;
  zIndex?: number;
}

/**
 * Styling readiness status for canonical styling items:
 * - READY: Production-grade transparent layer asset available.
 * - PARTIAL: Prototype / transparent vector placeholder available for testing.
 * - CATALOG_ONLY: Curated item available in wardrobe/catalog, but no transparent layer asset yet.
 * - RESEARCH: Academic research in progress (contested, needs verification, or out of core scope).
 */
export type StylingReadiness =
  | 'READY'
  | 'PARTIAL'
  | 'CATALOG_ONLY'
  | 'RESEARCH';

/**
 * Canonical styling item configuration contract
 */
export interface CanonicalStylingItem {
  itemId: string;
  layerType: GarmentLayerType;
  asset: string | null;
  placement: GarmentPlacement;
  stylingReadiness: StylingReadiness;
}

/**
 * Default clean placement helper (centered, unscaled, upright)
 */
export const createDefaultPlacement = (): GarmentPlacement => ({
  x: 0,
  y: 0,
  scale: 1,
  rotation: 0,
});

/**
 * EXACT 49 CANONICAL STYLING ITEMS
 * Source of Truth: 47 MASTER_GARMENTS (G001 → G047) + A011 + A012.
 * NO raw 60-record inventory, NO duplicates of A001-A010 or A013.
 */
export const CANONICAL_STYLING_ITEMS: CanonicalStylingItem[] = [
  // 1. G001 Áo Giao Lĩnh (outer robe, transparent SVG asset)
  {
    itemId: 'G001',
    layerType: 'outer',
    asset: giaoLinhLayerSvg,
    placement: createDefaultPlacement(),
    stylingReadiness: 'READY',
  },
  // 2. G002 Áo Trực Lĩnh (main, contested research status)
  {
    itemId: 'G002',
    layerType: 'main',
    asset: null,
    placement: createDefaultPlacement(),
    stylingReadiness: 'RESEARCH',
  },
  // 3. G003 Áo Đối Khâm (outer robe)
  {
    itemId: 'G003',
    layerType: 'outer',
    asset: null,
    placement: createDefaultPlacement(),
    stylingReadiness: 'CATALOG_ONLY',
  },
  // 6. G006 Áo Viên Lĩnh (main)
  {
    itemId: 'G006',
    layerType: 'main',
    asset: null,
    placement: createDefaultPlacement(),
    stylingReadiness: 'CATALOG_ONLY',
  },
  // 7. G007 Áo Tứ Điên (main, contested research status)
  {
    itemId: 'G007',
    layerType: 'main',
    asset: null,
    placement: createDefaultPlacement(),
    stylingReadiness: 'RESEARCH',
  },
  // 8. G008 Áo Ngũ Thân tay chẽn (main)
  {
    itemId: 'G008',
    layerType: 'main',
    asset: null,
    placement: createDefaultPlacement(),
    stylingReadiness: 'CATALOG_ONLY',
  },
  // 9. G009 Áo Tấc (outer)
  {
    itemId: 'G009',
    layerType: 'outer',
    asset: null,
    placement: createDefaultPlacement(),
    stylingReadiness: 'CATALOG_ONLY',
  },
  // 10. G010 Áo Tứ Thân (outer robe, transparent SVG asset)
  {
    itemId: 'G010',
    layerType: 'outer',
    asset: tuThanLayerSvg,
    placement: createDefaultPlacement(),
    stylingReadiness: 'READY',
  },
  // 11. G011 Yếm (inner layer, transparent SVG asset)
  {
    itemId: 'G011',
    layerType: 'inner',
    asset: yemLayerSvg,
    placement: createDefaultPlacement(),
    stylingReadiness: 'READY',
  },
  // 12. G012 Váy (lower)
  {
    itemId: 'G012',
    layerType: 'lower',
    asset: null,
    placement: createDefaultPlacement(),
    stylingReadiness: 'CATALOG_ONLY',
  },
  // 13. G013 Quần ống rộng sáng màu (lower)
  {
    itemId: 'G013',
    layerType: 'lower',
    asset: null,
    placement: createDefaultPlacement(),
    stylingReadiness: 'CATALOG_ONLY',
  },
  // 14. G014 Quần Lá Tọa (lower)
  {
    itemId: 'G014',
    layerType: 'lower',
    asset: null,
    placement: createDefaultPlacement(),
    stylingReadiness: 'CATALOG_ONLY',
  },
  // 15. G015 Khố (lower)
  {
    itemId: 'G015',
    layerType: 'lower',
    asset: null,
    placement: createDefaultPlacement(),
    stylingReadiness: 'CATALOG_ONLY',
  },
  // 16. G016 Áo Bổ Phục (outer)
  {
    itemId: 'G016',
    layerType: 'outer',
    asset: null,
    placement: createDefaultPlacement(),
    stylingReadiness: 'CATALOG_ONLY',
  },
  // 17. G017 Bổ Tử (accessory)
  {
    itemId: 'G017',
    layerType: 'accessory',
    asset: null,
    placement: createDefaultPlacement(),
    stylingReadiness: 'CATALOG_ONLY',
  },
  // 18. G018 Áo Nhật Bình (outer)
  {
    itemId: 'G018',
    layerType: 'outer',
    asset: null,
    placement: createDefaultPlacement(),
    stylingReadiness: 'CATALOG_ONLY',
  },
  // 19. G019 Áo Mệnh Phụ (outer, needs verification)
  {
    itemId: 'G019',
    layerType: 'outer',
    asset: null,
    placement: createDefaultPlacement(),
    stylingReadiness: 'RESEARCH',
  },
  // 20. G020 Áo Mãng Bào (outer)
  {
    itemId: 'G020',
    layerType: 'outer',
    asset: null,
    placement: createDefaultPlacement(),
    stylingReadiness: 'CATALOG_ONLY',
  },
  // 21. G021 Mãng Lan (outer)
  {
    itemId: 'G021',
    layerType: 'outer',
    asset: null,
    placement: createDefaultPlacement(),
    stylingReadiness: 'CATALOG_ONLY',
  },
  // 22. G022 Long Bào (outer)
  {
    itemId: 'G022',
    layerType: 'outer',
    asset: null,
    placement: createDefaultPlacement(),
    stylingReadiness: 'CATALOG_ONLY',
  },
  // 23. G023 Hoàng Bào (outer)
  {
    itemId: 'G023',
    layerType: 'outer',
    asset: null,
    placement: createDefaultPlacement(),
    stylingReadiness: 'CATALOG_ONLY',
  },
  // 24. G024 Cổn Phục (outer)
  {
    itemId: 'G024',
    layerType: 'outer',
    asset: null,
    placement: createDefaultPlacement(),
    stylingReadiness: 'CATALOG_ONLY',
  },
  // 25. G025 Phượng phục / áo thêu phượng (outer)
  {
    itemId: 'G025',
    layerType: 'outer',
    asset: null,
    placement: createDefaultPlacement(),
    stylingReadiness: 'CATALOG_ONLY',
  },
  // 28. G028 Áo Bà Ba (main)
  {
    itemId: 'G028',
    layerType: 'main',
    asset: null,
    placement: createDefaultPlacement(),
    stylingReadiness: 'CATALOG_ONLY',
  },
  // 30. G030 Áo Dài hiện đại (main)
  {
    itemId: 'G030',
    layerType: 'main',
    asset: null,
    placement: createDefaultPlacement(),
    stylingReadiness: 'CATALOG_ONLY',
  },
  // 31. G031 Khăn Xếp / Khăn Đóng (accessory)
  {
    itemId: 'G031',
    layerType: 'accessory',
    asset: null,
    placement: createDefaultPlacement(),
    stylingReadiness: 'CATALOG_ONLY',
  },
  // 32. G032 Khăn Vành Dây (accessory)
  {
    itemId: 'G032',
    layerType: 'accessory',
    asset: null,
    placement: createDefaultPlacement(),
    stylingReadiness: 'CATALOG_ONLY',
  },
  // 33. G033 Khăn Mỏ Quạ (accessory)
  {
    itemId: 'G033',
    layerType: 'accessory',
    asset: null,
    placement: createDefaultPlacement(),
    stylingReadiness: 'CATALOG_ONLY',
  },
  // 34. G034 Khăn Rằn (accessory)
  {
    itemId: 'G034',
    layerType: 'accessory',
    asset: null,
    placement: createDefaultPlacement(),
    stylingReadiness: 'CATALOG_ONLY',
  },
  // 35. G035 Nón Lá (accessory)
  {
    itemId: 'G035',
    layerType: 'accessory',
    asset: null,
    placement: createDefaultPlacement(),
    stylingReadiness: 'CATALOG_ONLY',
  },
  // 36. G036 Nón Ba Tầm (accessory, contested research status)
  {
    itemId: 'G036',
    layerType: 'accessory',
    asset: null,
    placement: createDefaultPlacement(),
    stylingReadiness: 'RESEARCH',
  },
  // 37. G037 Nón Thúng / Thúng quai thao (accessory, contested research status)
  {
    itemId: 'G037',
    layerType: 'accessory',
    asset: null,
    placement: createDefaultPlacement(),
    stylingReadiness: 'RESEARCH',
  },
  // 38. G038 Nón Bài Thơ (accessory)
  {
    itemId: 'G038',
    layerType: 'accessory',
    asset: null,
    placement: createDefaultPlacement(),
    stylingReadiness: 'CATALOG_ONLY',
  },
  // 39. G039 Mũ Cánh Chuồn (accessory)
  {
    itemId: 'G039',
    layerType: 'accessory',
    asset: null,
    placement: createDefaultPlacement(),
    stylingReadiness: 'CATALOG_ONLY',
  },
  // 40. G040 Vân Kiên (accessory)
  {
    itemId: 'G040',
    layerType: 'accessory',
    asset: null,
    placement: createDefaultPlacement(),
    stylingReadiness: 'CATALOG_ONLY',
  },
  // 41. G041 Trâm (accessory)
  {
    itemId: 'G041',
    layerType: 'accessory',
    asset: null,
    placement: createDefaultPlacement(),
    stylingReadiness: 'CATALOG_ONLY',
  },
  // 42. G042 Đai / Thắt lưng (accessory)
  {
    itemId: 'G042',
    layerType: 'accessory',
    asset: null,
    placement: createDefaultPlacement(),
    stylingReadiness: 'CATALOG_ONLY',
  },
  // 43. G043 Dây Ruột Tượng (accessory)
  {
    itemId: 'G043',
    layerType: 'accessory',
    asset: null,
    placement: createDefaultPlacement(),
    stylingReadiness: 'CATALOG_ONLY',
  },
  // 44. G044 Hốt (accessory)
  {
    itemId: 'G044',
    layerType: 'accessory',
    asset: null,
    placement: createDefaultPlacement(),
    stylingReadiness: 'CATALOG_ONLY',
  },
  // 45. G045 Hia (accessory)
  {
    itemId: 'G045',
    layerType: 'accessory',
    asset: null,
    placement: createDefaultPlacement(),
    stylingReadiness: 'CATALOG_ONLY',
  },
  // 46. G046 Hài (accessory)
  {
    itemId: 'G046',
    layerType: 'accessory',
    asset: null,
    placement: createDefaultPlacement(),
    stylingReadiness: 'CATALOG_ONLY',
  },
  // 47. G047 Guốc Mộc (accessory)
  {
    itemId: 'G047',
    layerType: 'accessory',
    asset: null,
    placement: createDefaultPlacement(),
    stylingReadiness: 'CATALOG_ONLY',
  },
  // 48. A011 Quạt (accessory)
  {
    itemId: 'A011',
    layerType: 'accessory',
    asset: null,
    placement: createDefaultPlacement(),
    stylingReadiness: 'CATALOG_ONLY',
  },
  // 49. A012 Thẻ bài (accessory, needs verification)
  {
    itemId: 'A012',
    layerType: 'accessory',
    asset: null,
    placement: createDefaultPlacement(),
    stylingReadiness: 'RESEARCH',
  },
];

/**
 * Validates that styling items strictly adhere to the 49 canonical entities:
 * - Detects duplicate itemId
 * - Detects missing canonical item
 * - Detects unknown or duplicate merged items
 */
export function assertCanonicalStylingItems(
  items: CanonicalStylingItem[] = CANONICAL_STYLING_ITEMS
): void {
  const expectedCanonicalIds = CANONICAL_ENTITIES.map((e) => e.primaryRecordId);
  const seenIds = new Set<string>();
  const duplicateIds: string[] = [];
  const unknownIds: string[] = [];

  for (const item of items) {
    if (seenIds.has(item.itemId)) {
      duplicateIds.push(item.itemId);
    }
    seenIds.add(item.itemId);

    if (!expectedCanonicalIds.includes(item.itemId)) {
      unknownIds.push(item.itemId);
    }
  }

  const missingIds = expectedCanonicalIds.filter((id) => !seenIds.has(id));

  if (duplicateIds.length > 0 || unknownIds.length > 0 || missingIds.length > 0) {
    throw new Error(
      `assertCanonicalStylingItems failed! ` +
        `Duplicates: [${duplicateIds.join(', ')}], ` +
        `Unknown: [${unknownIds.join(', ')}], ` +
        `Missing: [${missingIds.join(', ')}]. ` +
        `Expected exactly ${expectedCanonicalIds.length} canonical items, received ${items.length}.`
    );
  }
}

// Execute assertion on module initialize to guarantee 100% integrity
assertCanonicalStylingItems();

/**
 * Fast O(1) canonical styling lookup map
 */
export const CANONICAL_STYLING_MAP: Map<string, CanonicalStylingItem> = new Map(
  CANONICAL_STYLING_ITEMS.map((item) => [item.itemId, item])
);

/**
 * Canonical styling statistics
 */
export const STYLING_STATS = {
  total: CANONICAL_STYLING_ITEMS.length,
  ready: CANONICAL_STYLING_ITEMS.filter((i) => i.stylingReadiness === 'READY').length,
  partial: CANONICAL_STYLING_ITEMS.filter((i) => i.stylingReadiness === 'PARTIAL').length,
  catalogOnly: CANONICAL_STYLING_ITEMS.filter((i) => i.stylingReadiness === 'CATALOG_ONLY').length,
  research: CANONICAL_STYLING_ITEMS.filter((i) => i.stylingReadiness === 'RESEARCH').length,
};

/**
 * Standard test outfit layers using transparent placeholder assets.
 */
export const TEST_OUTFIT_LAYERS: GarmentLayerData[] = [
  {
    itemId: 'G011',
    asset: yemLayerSvg,
    layerType: 'inner',
    placement: createDefaultPlacement(),
    visible: true,
  },
  {
    itemId: 'G010',
    asset: tuThanLayerSvg,
    layerType: 'outer',
    placement: createDefaultPlacement(),
    visible: true,
  },
];

/**
 * Resolves active garment layers from user-selected items.
 * Only items with READY or PARTIAL status and a valid visual asset become model layers.
 * Items without assets remain selectable without rendering blank/broken layers.
 */
export function resolveLayersForItems(
  items: Item[],
  enableTestPlaceholderIfEmpty = false
): GarmentLayerData[] {
  const result: GarmentLayerData[] = [];

  for (const item of items) {
    const styling = CANONICAL_STYLING_MAP.get(item.id);
    if (!styling) continue;

    if (
      (styling.stylingReadiness === 'READY' || styling.stylingReadiness === 'PARTIAL') &&
      styling.asset
    ) {
      result.push({
        itemId: styling.itemId,
        asset: styling.asset,
        layerType: styling.layerType,
        placement: { ...styling.placement },
        visible: true,
        zIndex: LAYER_Z_INDEX_MAP[styling.layerType],
      });
    }
  }

  if (result.length === 0 && enableTestPlaceholderIfEmpty) {
    return TEST_OUTFIT_LAYERS;
  }

  // Sort strictly by centralized rendering order: inner (11) → main (12) → outer (13) → lower (14) → accessory (15)
  result.sort((a, b) => {
    const zA = LAYER_Z_INDEX_MAP[a.layerType];
    const zB = LAYER_Z_INDEX_MAP[b.layerType];
    return zA - zB;
  });

  return result;
}

/**
 * Backward compatibility alias for legacy references
 */
export const SAMPLE_GARMENT_LAYER_REGISTRY: Record<string, GarmentLayerData> =
  Object.fromEntries(
    CANONICAL_STYLING_ITEMS.filter((i) => i.asset !== null).map((i) => [
      i.itemId,
      {
        itemId: i.itemId,
        asset: i.asset!,
        layerType: i.layerType,
        placement: i.placement,
        visible: true,
        zIndex: LAYER_Z_INDEX_MAP[i.layerType],
      },
    ])
  );
