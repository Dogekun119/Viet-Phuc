/**
 * TÀNG Y / VIỆT PHỤC REMIX — IMAGE GENERATION & TRY-ON PIPELINE DOMAIN
 * 
 * Handles input validation, asset mapping, prompt construction across the 3 modes,
 * Gemini API response parsing, error classification, and security sanitization.
 */

export type GenerationMode =
  | 'single_item_try_on'
  | 'reference_image_edit'
  | 'complete_outfit_try_on';

export interface TryOnRequestInput {
  requestId?: string;
  mode?: GenerationMode;
  gender?: 'female' | 'male';
  selectedItemIds?: string[];
  referenceItemId?: string;
  customPrompt?: string;
  prompt?: string;
  outfitTitle?: string;
}

/**
 * 44 Canonical entities verified asset mapping
 */
export const GARMENT_IMAGE_ASSET_MAP: Record<string, string> = {
  G001: 'tu_ao_ao_giao_linh_1791540421433.jpg',
  G002: 'tu_ao_truc_linh_1791590575147.jpg',
  G003: 'tu_ao_doi_kham_1791590587462.jpg',
  G006: 'tu_ao_vien_linh_1791590597639.jpg',
  G007: 'ao_tu_dien_1791596749479.jpg',
  G008: 'tu_ao_ao_ngu_than_1791540362301.jpg',
  G009: 'tu_ao_ao_tac_1791590607100.jpg',
  G010: 'tu_ao_ao_tu_than_1791540316824.jpg',
  G011: 'tu_ao_yem_dao_1791590619474.jpg',
  G012: 'tu_ao_vay_dup_1791591661475.jpg',
  G013: 'tu_ao_quan_trang_1791591672868.jpg',
  G014: 'tu_ao_quan_la_toa_1791593055198.jpg',
  G015: 'tu_ao_kho_dan_gian_1791593067158.jpg',
  G016: 'tu_ao_bo_phuc_1791591685057.jpg',
  G017: 'tu_ao_bo_tu_1791592305808.jpg',
  G018: 'tu_ao_ao_nhat_binh_1791540457083.jpg',
  G019: 'ao_menh_phu_1791596761598.jpg',
  G020: 'tu_ao_mang_bao_1791592317711.jpg',
  G021: 'tu_ao_mang_lan_1791593078866.jpg',
  G022: 'tu_ao_long_bao_1791541769402.jpg',
  G023: 'tu_ao_hoang_bao_1791591697522.jpg',
  G024: 'tu_ao_con_phuc_1791593088539.jpg',
  G025: 'tu_ao_phuong_phuc_1791591709330.jpg',
  G028: 'tu_ao_ao_ba_ba_1791540391970.jpg',
  G030: 'tu_ao_ao_dai_1791540293823.jpg',
  G031: 'tu_ao_khan_xep_1791591919738.jpg',
  G032: 'tu_ao_khan_vanh_day_1791541857698.jpg',
  G033: 'tu_ao_khan_mo_qua_1791591931180.jpg',
  G034: 'tu_ao_khan_ran_1791541960369.jpg',
  G035: 'tu_ao_non_la_1791591940904.jpg',
  G036: 'tu_ao_non_ba_tam_1791541813772.jpg',
  G037: 'tu_ao_non_thung_1791593237981.jpg',
  G038: 'tu_ao_non_bai_tho_1791592327797.jpg',
  G039: 'tu_ao_mu_canh_chuon_1791591950697.jpg',
  G040: 'tu_ao_van_kien_1791592339952.jpg',
  G041: 'tu_ao_tram_cai_toc_1791593137036.jpg',
  G042: 'tu_ao_dai_that_lung_1791593101752.jpg',
  G043: 'tu_ao_day_ruot_tuong_1791593147548.jpg',
  G044: 'tu_ao_the_hot_quan_1791593160009.jpg',
  G045: 'tu_ao_hia_quan_1791592350888.jpg',
  G046: 'tu_ao_hai_theu_1791541907877.jpg',
  G047: 'tu_ao_guoc_moc_1791591962889.jpg',
  A011: 'tu_ao_quat_lua_co_1791593170321.jpg',
  A012: 'tu_ao_the_bai_quan_1791593182172.jpg',
};

export const BASE_MODEL_ASSET_MAP = {
  female: 'female_base_model_1791456212298.jpg',
  male: 'male_base_model_1791456224566.jpg',
};

export interface ResolvedAsset {
  id: string;
  filename: string;
  mimeType: string;
}

export type TryOnValidationResult =
  | {
      valid: true;
      targetIds: string[];
      mode: GenerationMode;
      gender: 'female' | 'male';
      baseModelFilename: string;
      itemAssets: ResolvedAsset[];
    }
  | {
      valid: false;
      status: number;
      errorType:
        | 'NO_API_KEY'
        | 'MISSING_SELECTION'
        | 'MISSING_BASE_MODEL'
        | 'MISSING_REFERENCE_IMAGE';
      error: string;
    };

/**
 * Validates try-on input before any Gemini API call is made.
 * Verifies API key, base model availability, and each target item mapping + disk availability.
 */
export function validateTryOnInputs(
  input: TryOnRequestInput,
  apiKey: string | undefined,
  isAssetAvailable: (filename: string) => boolean
): TryOnValidationResult {
  // 1. Verify GEMINI_API_KEY is configured
  if (!apiKey || apiKey.trim() === '' || apiKey === 'MY_GEMINI_API_KEY') {
    return {
      valid: false,
      status: 503,
      errorType: 'NO_API_KEY',
      error:
        'Chưa cấu hình GEMINI_API_KEY trên máy chủ. Vui lòng thiết lập khóa API trong mục Settings > Secrets.',
    };
  }

  // 2. Validate selection
  const targetIds: string[] =
    Array.isArray(input.selectedItemIds) && input.selectedItemIds.length > 0
      ? input.selectedItemIds
      : input.referenceItemId
      ? [input.referenceItemId]
      : [];

  if (targetIds.length === 0) {
    return {
      valid: false,
      status: 400,
      errorType: 'MISSING_SELECTION',
      error: 'Vui lòng chọn ít nhất một trang phục hoặc phụ kiện trước khi yêu cầu tạo ảnh.',
    };
  }

  const gender = input.gender === 'male' ? 'male' : 'female';
  const baseModelFilename = BASE_MODEL_ASSET_MAP[gender];

  // 3. Verify base model image exists
  if (!isAssetAvailable(baseModelFilename)) {
    return {
      valid: false,
      status: 404,
      errorType: 'MISSING_BASE_MODEL',
      error: `Không tìm thấy tệp ảnh người mẫu cơ sở (${baseModelFilename}) trên hệ thống.`,
    };
  }

  // 4. Verify each selected item ID maps to the intended reference image and exists on disk
  const missingErrors: string[] = [];
  const resolvedAssets: ResolvedAsset[] = [];

  for (const id of targetIds) {
    const filename = GARMENT_IMAGE_ASSET_MAP[id];
    if (!filename) {
      missingErrors.push(`Mã trang phục "${id}" chưa có ánh xạ tệp tư liệu tham chiếu`);
      continue;
    }

    if (!isAssetAvailable(filename)) {
      missingErrors.push(
        `Không tìm thấy tệp tư liệu "${filename}" trên đĩa cho thực thể "${id}"`
      );
      continue;
    }

    const mimeType = filename.endsWith('.png') ? 'image/png' : 'image/jpeg';
    resolvedAssets.push({ id, filename, mimeType });
  }

  if (missingErrors.length > 0) {
    return {
      valid: false,
      status: 422,
      errorType: 'MISSING_REFERENCE_IMAGE',
      error: `Thiếu tư liệu hình ảnh tham chiếu bắt buộc: ${missingErrors.join('; ')}.`,
    };
  }

  const mode: GenerationMode =
    input.mode || (targetIds.length === 1 ? 'single_item_try_on' : 'complete_outfit_try_on');

  return {
    valid: true,
    targetIds,
    mode,
    gender,
    baseModelFilename,
    itemAssets: resolvedAssets,
  };
}

/**
 * Sanitizes an error message or log so that any sensitive API keys or auth tokens are redacted.
 */
export function sanitizeErrorMessage(message: string, apiKey?: string): string {
  let cleaned = String(message || '');
  if (apiKey && apiKey.length > 4) {
    cleaned = cleaned.split(apiKey).join('[REDACTED]');
  }
  // Also redact typical API key formats (e.g. AIzaSy...)
  cleaned = cleaned.replace(/AIza[0-9A-Za-z-_]{35}/g, '[REDACTED_API_KEY]');
  // Also redact bearer tokens
  cleaned = cleaned.replace(/Bearer\s+[A-Za-z0-9\-._~+/]+=*/gi, 'Bearer [REDACTED_TOKEN]');
  return cleaned;
}

export interface ClassifiedGeminiError {
  status: number;
  errorType:
    | 'PAID_PLAN_REQUIRED'
    | 'QUOTA_EXCEEDED'
    | 'INVALID_API_KEY'
    | 'MODEL_UNAVAILABLE'
    | 'NETWORK_TIMEOUT'
    | 'API_ERROR';
  messageVi: string;
  sanitizedDetails: string;
  isPaidPlanRequired?: boolean;
}

/**
 * Classifies Gemini SDK errors into stable errorTypes and appropriate HTTP statuses.
 * Never leaks the API key.
 */
export function classifyGeminiError(
  err: any,
  apiKey?: string
): ClassifiedGeminiError {
  const rawMsg = String(err?.message || err || '');
  const sanitized = sanitizeErrorMessage(rawMsg, apiKey);
  const lower = sanitized.toLowerCase();
  const statusCode = Number(err?.status || err?.statusCode || 0);
  const errorCode = String(err?.code || err?.error?.code || '');

  // 1. Quota / Rate limit errors
  const isQuota =
    statusCode === 429 ||
    errorCode === 'RESOURCE_EXHAUSTED' ||
    lower.includes('429') ||
    lower.includes('resource_exhausted') ||
    lower.includes('quota') ||
    lower.includes('rate limit') ||
    lower.includes('too many requests') ||
    lower.includes('limit exceeded');

  const isFreeTierZero =
    lower.includes('limit: 0') ||
    lower.includes('free_tier') ||
    lower.includes('plan and billing') ||
    lower.includes('billing details');

  if (isQuota) {
    if (isFreeTierZero) {
      return {
        status: 429,
        errorType: 'PAID_PLAN_REQUIRED',
        messageVi:
          'Mô hình tạo ảnh AI (gemini-3.1-flash-lite-image) yêu cầu khóa API trả phí (Paid API key / billing plan). Dự án hiện không có hạn mức miễn phí (limit: 0) cho mô hình này. Vui lòng thiết lập hoặc chọn khóa API trả phí trong mục Settings > Secrets.',
        sanitizedDetails: sanitized,
        isPaidPlanRequired: true,
      };
    }

    return {
      status: 429,
      errorType: 'QUOTA_EXCEEDED',
      messageVi:
        'Hạn mức tạo ảnh AI (Gemini Nano Banana) hiện đang chạm giới hạn hoặc tạm thời bận. Vui lòng bấm "Thử lại" sau giây lát.',
      sanitizedDetails: sanitized,
    };
  }

  // 2. Authentication / Permission errors
  const isAuth =
    statusCode === 401 ||
    statusCode === 403 ||
    errorCode === 'PERMISSION_DENIED' ||
    errorCode === 'UNAUTHENTICATED' ||
    lower.includes('api_key_invalid') ||
    lower.includes('api key not valid') ||
    lower.includes('permission_denied') ||
    lower.includes('unauthenticated') ||
    lower.includes('forbidden') ||
    lower.includes('unauthorized') ||
    lower.includes('invalid api key') ||
    lower.includes('key is invalid');

  if (isAuth) {
    return {
      status: 403,
      errorType: 'INVALID_API_KEY',
      messageVi:
        'Khóa API Gemini không hợp lệ hoặc không có quyền truy cập mô hình tạo ảnh. Vui lòng kiểm tra lại cấu hình API key trong Settings > Secrets.',
      sanitizedDetails: sanitized,
    };
  }

  // 3. Model unavailable / unsupported
  const isModelUnavailable =
    statusCode === 404 ||
    errorCode === 'NOT_FOUND' ||
    (lower.includes('model') &&
      (lower.includes('not found') ||
        lower.includes('not supported') ||
        lower.includes('not available') ||
        lower.includes('unsupported') ||
        lower.includes('does not exist')));

  if (isModelUnavailable) {
    return {
      status: 502,
      errorType: 'MODEL_UNAVAILABLE',
      messageVi:
        'Mô hình tạo ảnh (gemini-3.1-flash-lite-image) tạm thời không khả dụng. Vui lòng thử lại sau.',
      sanitizedDetails: sanitized,
    };
  }

  // 4. Network / Timeout errors
  const isNetwork =
    statusCode === 504 ||
    lower.includes('etimedout') ||
    lower.includes('econnreset') ||
    lower.includes('fetch failed') ||
    lower.includes('timeout') ||
    lower.includes('socket hang up') ||
    lower.includes('deadline_exceeded') ||
    lower.includes('network error');

  if (isNetwork) {
    return {
      status: 504,
      errorType: 'NETWORK_TIMEOUT',
      messageVi:
        'Kết nối mạng tới dịch vụ Gemini bị gián đoạn hoặc quá thời gian chờ. Vui lòng bấm "Thử lại".',
      sanitizedDetails: sanitized,
    };
  }

  // 5. General API error
  return {
    status: 502,
    errorType: 'API_ERROR',
    messageVi: `Lỗi kết nối dịch vụ tạo ảnh Gemini: ${sanitized || 'Yêu cầu không thành công'}. Vui lòng bấm "Thử lại".`,
    sanitizedDetails: sanitized,
  };
}

export type ExtractedGeminiResponse =
  | {
      ok: true;
      imageUrl: string;
      mimeType: string;
      base64Data: string;
    }
  | {
      ok: false;
      errorType: 'NO_IMAGE_DATA';
      returnedText: string;
    };

/**
 * Extracts inlineData image from Gemini generateContent response candidates.
 * If only text is returned, records safe diagnostic text and returns NO_IMAGE_DATA.
 */
export function extractGeminiImageResponse(response: any): ExtractedGeminiResponse {
  let foundImage: { data: string; mimeType: string } | null = null;
  let textParts: string[] = [];

  const candidates = response?.candidates;
  if (Array.isArray(candidates)) {
    for (const candidate of candidates) {
      const parts = candidate?.content?.parts;
      if (Array.isArray(parts)) {
        for (const part of parts) {
          if (part?.inlineData?.data) {
            foundImage = {
              data: part.inlineData.data,
              mimeType: part.inlineData.mimeType || 'image/jpeg',
            };
            break;
          } else if (part?.text) {
            textParts.push(part.text.trim());
          }
        }
      }
      if (foundImage) break;
    }
  }

  if (foundImage) {
    return {
      ok: true,
      imageUrl: `data:${foundImage.mimeType};base64,${foundImage.data}`,
      mimeType: foundImage.mimeType,
      base64Data: foundImage.data,
    };
  }

  return {
    ok: false,
    errorType: 'NO_IMAGE_DATA',
    returnedText: textParts.join(' ').trim(),
  };
}
