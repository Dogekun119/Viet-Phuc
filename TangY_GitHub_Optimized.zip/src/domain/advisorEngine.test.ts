/**
 * ACCEPTANCE TESTS — TÀNG Y VIỆT PHỤC OCCASION ADVISOR
 * 
 * Kiểm thử 5 kịch bản theo yêu cầu nghiệp vụ:
 * 1. A student attending a university cultural event.
 * 2. Someone visiting a heritage site and taking photographs.
 * 3. Someone attending a wedding.
 * 4. Someone seeking a comfortable outfit for a casual outing.
 * 5. Someone asking for a culturally appropriate gift.
 * 
 * Đồng thời xác minh:
 * - Mọi trang phục khuyến nghị đều nằm trong danh mục Active Catalog chuẩn (CANONICAL_ENTITIES).
 * - Tuyệt đối không chứa 5 trang phục bị loại (G004, G005, G026, G027, G029).
 * - Động cơ thẩm định tương thích (evaluateOutfit) tính toán chuẩn xác nhãn văn hóa.
 * - Các thuộc tính lý giải, phối màu, thoải mái và cảnh báo đều có đủ.
 */

import { generateAdvisorResponse, resolveRecommendation } from './advisorEngine';
import { CANONICAL_ENTITIES, REMOVED_CANONICAL_IDS } from './canonicalData';
import { ITEMS_MAP } from './dataAdapter';

export function runAdvisorAcceptanceTests(): { passed: boolean; logs: string[] } {
  const logs: string[] = [];
  let allPassed = true;

  function assert(condition: boolean, testName: string, detail?: string) {
    if (condition) {
      logs.push(`✅ [PASS] ${testName}`);
    } else {
      logs.push(`❌ [FAIL] ${testName}${detail ? ` -> ${detail}` : ''}`);
      allPassed = false;
    }
  }

  // Set of all active canonical IDs
  const activeCanonicalIds = new Set(CANONICAL_ENTITIES.map((e) => e.primaryRecordId));

  function verifyOutfitRecommendations(
    scenarioName: string,
    recs: any[] | undefined,
    expectedCountMin: number = 2
  ) {
    assert(
      Array.isArray(recs) && recs.length >= expectedCountMin,
      `${scenarioName}: Trả về ít nhất ${expectedCountMin} phương án khuyến nghị`,
      `Nhận được ${recs?.length || 0} phương án`
    );

    recs?.forEach((rec, idx) => {
      // 1. Kiểm tra không chứa item bị loại
      const containsBanned = rec.itemIds.some((id: string) => REMOVED_CANONICAL_IDS.has(id));
      assert(
        !containsBanned,
        `${scenarioName} - PA ${idx + 1}: Tuyệt đối KHÔNG chứa trang phục đã bị loại (G004, G005, G026, G027, G029)`
      );

      // 2. Kiểm tra mọi item đều tồn tại trong active catalog
      const allActive = rec.itemIds.every((id: string) => activeCanonicalIds.has(id) || ITEMS_MAP.has(id));
      assert(
        allActive,
        `${scenarioName} - PA ${idx + 1}: Tất cả item IDs đều là thực thể chuẩn hợp lệ: [${rec.itemIds.join(', ')}]`
      );

      // 3. Kiểm tra độ tương thích được evaluateOutfit tính toán
      assert(
        Boolean(rec.evaluation) && Boolean(rec.evaluation.label),
        `${scenarioName} - PA ${idx + 1}: Có kết quả thẩm định văn hóa từ evaluateOutfit (${rec.evaluation?.label})`
      );

      // 4. Kiểm tra có lý giải vì sao phù hợp
      assert(
        Boolean(rec.whySuits && rec.whySuits.length > 10),
        `${scenarioName} - PA ${idx + 1}: Có lý giải chi tiết vì sao phù hợp với bối cảnh`
      );

      // 5. Kiểm tra có lưu ý thoải mái / dress-code
      assert(
        Boolean(rec.comfortNotes),
        `${scenarioName} - PA ${idx + 1}: Có lưu ý về độ thoải mái, thời gian mặc hoặc vận động`
      );
    });
  }

  // SCENARIO 1: A student attending a university cultural event
  const resScenario1 = generateAdvisorResponse('Tôi là sinh viên cần trang phục tham gia ngày hội văn hóa ở trường đại học');
  verifyOutfitRecommendations('Kịch bản 1 (Sinh viên / Ngày hội trường)', resScenario1.recommendations, 2);

  // SCENARIO 2: Someone visiting a heritage site and taking photographs
  const resScenario2 = generateAdvisorResponse('Cuối tuần này mình đi thăm Hoàng thành và Văn Miếu chụp ảnh lưu niệm');
  verifyOutfitRecommendations('Kịch bản 2 (Di tích lịch sử / Chụp ảnh)', resScenario2.recommendations, 2);

  // SCENARIO 3: Someone attending a wedding
  const resScenario3 = generateAdvisorResponse('Mình sắp đi dự đám cưới người bạn thân, muốn mặc trang phục truyền thống lịch sự');
  verifyOutfitRecommendations('Kịch bản 3 (Dự đám cưới)', resScenario3.recommendations, 2);
  // Kiểm tra cảnh báo đám cưới
  const hasWeddingWarning = resScenario3.recommendations?.some((r) => r.warnings || r.stylingColorNotes.includes('đỏ'));
  assert(
    Boolean(hasWeddingWarning),
    'Kịch bản 3 (Dự đám cưới): Có lưu ý nhã nhặn, tránh lấn át cô dâu chú rể hoặc tránh trang phục đại lễ rực rỡ'
  );

  // SCENARIO 4: Someone seeking a comfortable outfit for a casual outing
  const resScenario4 = generateAdvisorResponse('Muốn tìm bộ đồ thoải mái nhẹ nhàng đi dạo phố cà phê với bạn bè');
  verifyOutfitRecommendations('Kịch bản 4 (Dạo phố / Cà phê thoải mái)', resScenario4.recommendations, 2);

  // SCENARIO 5: Someone asking for a culturally appropriate gift
  const resScenario5 = generateAdvisorResponse('Tôi muốn tìm quà tặng văn hóa ý nghĩa cho người bạn nước ngoài');
  assert(
    Array.isArray(resScenario5.giftSuggestions) && resScenario5.giftSuggestions.length >= 3,
    'Kịch bản 5 (Quà tặng văn hóa): Trả về ít nhất 3 gợi ý quà tặng truyền thống thực tế'
  );
  resScenario5.giftSuggestions?.forEach((gift, idx) => {
    assert(
      Boolean(gift.name && gift.culturalMeaning && gift.suitableFor),
      `Kịch bản 5 - Quà ${idx + 1} (${gift.name}): Có đầy đủ tên, ý nghĩa biểu trưng và đối tượng phù hợp`
    );
  });

  return { passed: allPassed, logs };
}

// Chạy test nếu gọi trực tiếp từ CLI
if (typeof process !== 'undefined' && process.argv && process.argv[1]?.includes('advisorEngine.test')) {
  const result = runAdvisorAcceptanceTests();
  console.log(result.logs.join('\n'));
  if (!result.passed) {
    process.exit(1);
  } else {
    console.log('\n🎉 ALL 5 ACCEPTANCE SCENARIOS PASSED WITH 100% SUCCESS!');
  }
}
