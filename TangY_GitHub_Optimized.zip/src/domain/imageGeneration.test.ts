/**
 * REGRESSION & ACCEPTANCE TESTS — TÀNG Y IMAGE GENERATION PIPELINE
 * 
 * Verifies all requirements:
 * 1. Successful image response extraction (data, MIME type, valid base64 URI, client caching).
 * 2. Text-only response with no image (safe diagnostic, NO_IMAGE_DATA, never cached as success).
 * 3. HTTP 429 / quota exhaustion (status 429, RESOURCE_EXHAUSTED, QUOTA_EXCEEDED classification, no aggressive loop).
 * 4. Invalid or missing API key (NO_API_KEY on missing key, INVALID_API_KEY on 401/403/PERMISSION_DENIED, secret redaction).
 * 5. Missing model or garment reference image (MISSING_BASE_MODEL, MISSING_REFERENCE_IMAGE, no silent omissions).
 * 6. Different selected items produce different request payloads & prompts.
 * 7. Single-item and complete-outfit modes remain separate (single accessory preserves neutral base model, no unselected full costume).
 * 8. Stale requests cannot overwrite newer results (request ID protection).
 */

import {
  buildSingleItemPrompt,
  buildReferenceImageEditPrompt,
  buildCompleteOutfitPrompt,
  buildImageCacheKey,
  isAccessoryItem,
  clearImageResultCache,
  VERIFIED_REFERENCE_ASSET_MAP,
} from '../services/geminiImage';
import {
  validateTryOnInputs,
  classifyGeminiError,
  extractGeminiImageResponse,
  sanitizeErrorMessage,
  GARMENT_IMAGE_ASSET_MAP,
  BASE_MODEL_ASSET_MAP,
} from './tryOnPipeline';
import { CANONICAL_ENTITIES_MAP } from './canonicalData';
import { Item } from './types';

export function runImageGenerationTests(): { passed: boolean; logs: string[] } {
  const logs: string[] = [];
  let allPassed = true;

  function assert(condition: boolean, testName: string, detail?: string) {
    if (condition) {
      logs.push(`✅ [PASS] ${testName}`);
    } else {
      logs.push(`❌ [FAIL] ${testName}${detail ? ` -> ${detail}` : ''}`);
      allPassed = false;
    }
  }

  // Helper to retrieve canonical item by ID
  function getItem(id: string): Item {
    const canonical = CANONICAL_ENTITIES_MAP.get(`CANON_${id}`) || CANONICAL_ENTITIES_MAP.get(id);
    if (!canonical) {
      throw new Error(`Item ${id} not found in CANONICAL_ENTITIES_MAP`);
    }
    return canonical.asItem;
  }

  const aoGiaoLinh = getItem('G001');
  const aoNhatBinh = getItem('G018');
  const aoTac = getItem('G009');
  const khanVanhDay = getItem('G032');
  const nonLa = getItem('G035');
  const aoTuThan = getItem('G010');
  const yem = getItem('G011');
  const vay = getItem('G012');

  // -------------------------------------------------------------------------
  // 1. Successful image response handling
  // -------------------------------------------------------------------------
  {
    const mockSuccessResponse = {
      candidates: [
        {
          content: {
            parts: [
              {
                text: 'High-end photographic rendering completed.',
              },
              {
                inlineData: {
                  data: 'iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mP8z8BQDwAEhQGAhKmMIQAAAABJRU5ErkJggg==',
                  mimeType: 'image/png',
                },
              },
            ],
          },
        },
      ],
    };

    const extracted = extractGeminiImageResponse(mockSuccessResponse);
    assert(
      extracted.ok === true,
      'Test 1.1: Trích xuất thành công phần dữ liệu ảnh từ response candidates'
    );

    if (extracted.ok) {
      assert(
        extracted.mimeType === 'image/png',
        'Test 1.2: Bảo toàn chính xác MIME type từ inlineData (image/png)'
      );
      assert(
        extracted.imageUrl.startsWith('data:image/png;base64,'),
        'Test 1.3: Tạo data URL base64 hợp lệ sẵn sàng hiển thị trên thẻ img'
      );
      assert(
        extracted.base64Data.length > 20,
        'Test 1.4: Dữ liệu base64 được trích xuất nguyên vẹn không bị cắt ngắn'
      );
    }
  }

  // -------------------------------------------------------------------------
  // 2. Text-only response with no image (safe diagnostic, NO_IMAGE_DATA)
  // -------------------------------------------------------------------------
  {
    const mockTextOnlyResponse = {
      candidates: [
        {
          content: {
            parts: [
              {
                text: 'I cannot generate the requested costume image due to ambiguous historical instructions.',
              },
            ],
          },
        },
      ],
    };

    const extracted = extractGeminiImageResponse(mockTextOnlyResponse);
    assert(
      extracted.ok === false,
      'Test 2.1: Phản hồi chỉ có văn bản không được báo thành công'
    );

    if (!extracted.ok) {
      assert(
        extracted.errorType === 'NO_IMAGE_DATA',
        'Test 2.2: Trả về mã lỗi ổn định NO_IMAGE_DATA khi không có inlineData'
      );
      assert(
        extracted.returnedText.includes('ambiguous historical instructions'),
        'Test 2.3: Ghi nhận an toàn chẩn đoán văn bản trả về để lưu log mà không gây crash'
      );
    }
  }

  // -------------------------------------------------------------------------
  // 3. HTTP 429 / quota exhaustion handling
  // -------------------------------------------------------------------------
  {
    const quotaErr1 = { status: 429, message: 'Resource exhausted: quota limit exceeded for project' };
    const classification1 = classifyGeminiError(quotaErr1);
    assert(
      classification1.status === 429 && classification1.errorType === 'QUOTA_EXCEEDED',
      'Test 3.1: Nhận diện chính xác lỗi HTTP 429 là QUOTA_EXCEEDED'
    );
    assert(
      classification1.messageVi.includes('Hạn mức') && classification1.messageVi.includes('Thử lại'),
      'Test 3.2: Thông báo tiếng Việt hướng dẫn người dùng bấm Thử lại sau giây lát thay vì retry dồn dập'
    );

    const quotaErr2 = { code: 'RESOURCE_EXHAUSTED', message: 'Rate limit reached, please slow down' };
    const classification2 = classifyGeminiError(quotaErr2);
    assert(
      classification2.status === 429 && classification2.errorType === 'QUOTA_EXCEEDED',
      'Test 3.3: Nhận diện mã RESOURCE_EXHAUSTED là QUOTA_EXCEEDED'
    );

    const quotaFreeTierZero = {
      status: 429,
      message:
        'You exceeded your current quota, please check your plan and billing details. Quota exceeded for metric: free_tier_requests, limit: 0, model: gemini-3.1-flash-lite-image',
    };
    const classificationFreeTier = classifyGeminiError(quotaFreeTierZero);
    assert(
      classificationFreeTier.status === 429 &&
        classificationFreeTier.errorType === 'PAID_PLAN_REQUIRED',
      'Test 3.4: Nhận diện chính xác trường hợp limit: 0 là PAID_PLAN_REQUIRED'
    );
    assert(
      classificationFreeTier.messageVi.includes('trả phí') ||
        classificationFreeTier.messageVi.includes('Paid API key'),
      'Test 3.5: Thông báo rõ ràng yêu cầu khóa API trả phí trong Settings > Secrets'
    );
  }

  // -------------------------------------------------------------------------
  // 4. Invalid or missing API key handling & Secret Redaction
  // -------------------------------------------------------------------------
  {
    // 4.1 Missing API key
    const missingKeyValidation = validateTryOnInputs(
      { selectedItemIds: ['G001'], gender: 'female' },
      '',
      () => true
    );
    assert(
      missingKeyValidation.valid === false && missingKeyValidation.errorType === 'NO_API_KEY',
      'Test 4.1: Kiểm tra thiếu GEMINI_API_KEY trả về NO_API_KEY với HTTP 503 trước khi gọi API'
    );

    // 4.2 Invalid API key error from SDK
    const secretKey = 'AIzaSyFakeSecretKeyForUnitTestOnly123456';
    const authErr = {
      status: 403,
      message: `API_KEY_INVALID: The provided key ${secretKey} is not authorized for model`,
    };
    const classificationAuth = classifyGeminiError(authErr, secretKey);
    assert(
      classificationAuth.status === 403 && classificationAuth.errorType === 'INVALID_API_KEY',
      'Test 4.2: Nhận diện lỗi 403 / API_KEY_INVALID là INVALID_API_KEY'
    );
    assert(
      !classificationAuth.sanitizedDetails.includes(secretKey) &&
        classificationAuth.sanitizedDetails.includes('[REDACTED]'),
      'Test 4.3: Tuyệt đối không để lộ khóa API trong thông điệp lỗi hay log (được khử bí mật [REDACTED])'
    );

    // 4.4 Standalone sanitizeErrorMessage test
    const leakSample = `Call to https://generativelanguage.googleapis.com?key=${secretKey} failed with 401`;
    const sanitized = sanitizeErrorMessage(leakSample, secretKey);
    assert(
      !sanitized.includes(secretKey),
      'Test 4.4: sanitizeErrorMessage loại bỏ hoàn toàn khóa nhạy cảm khỏi chuỗi log'
    );
  }

  // -------------------------------------------------------------------------
  // 5. Missing model or garment reference image
  // -------------------------------------------------------------------------
  {
    // 5.1 Missing base model image
    const validationMissingModel = validateTryOnInputs(
      { selectedItemIds: ['G001'], gender: 'female' },
      'VALID_KEY',
      (filename) => filename !== BASE_MODEL_ASSET_MAP.female
    );
    assert(
      validationMissingModel.valid === false && validationMissingModel.errorType === 'MISSING_BASE_MODEL',
      'Test 5.1: Thiếu tệp ảnh người mẫu cơ sở trả về lỗi MISSING_BASE_MODEL rõ ràng (HTTP 404)'
    );

    // 5.2 Unmapped or missing garment reference image
    const validationMissingRef = validateTryOnInputs(
      { selectedItemIds: ['NON_EXISTENT_G999'], gender: 'female' },
      'VALID_KEY',
      () => true
    );
    assert(
      validationMissingRef.valid === false && validationMissingRef.errorType === 'MISSING_REFERENCE_IMAGE',
      'Test 5.2: Thực thể chưa có ảnh tư liệu tham chiếu trả về MISSING_REFERENCE_IMAGE (HTTP 422)'
    );

    // 5.3 Reference image file missing from disk
    const validationMissingDiskFile = validateTryOnInputs(
      { selectedItemIds: ['G001'], gender: 'female' },
      'VALID_KEY',
      (filename) => filename !== GARMENT_IMAGE_ASSET_MAP['G001']
    );
    assert(
      validationMissingDiskFile.valid === false && validationMissingDiskFile.errorType === 'MISSING_REFERENCE_IMAGE',
      'Test 5.3: Tệp ảnh tham chiếu không tồn tại trên đĩa được báo lỗi rõ ràng thay vì âm thầm bỏ qua'
    );
  }

  // -------------------------------------------------------------------------
  // 6. Different selected items produce different request payloads
  // -------------------------------------------------------------------------
  {
    const promptGiaoLinh = buildSingleItemPrompt(aoGiaoLinh, 'female');
    const promptNhatBinh = buildSingleItemPrompt(aoNhatBinh, 'female');
    const promptTac = buildSingleItemPrompt(aoTac, 'male');

    assert(
      promptGiaoLinh !== promptNhatBinh && promptNhatBinh !== promptTac,
      'Test 6.1: Áo Giao Lĩnh, Áo Nhật Bình và Áo Tấc tạo ra các prompt hoàn toàn khác biệt'
    );

    const assetGiaoLinh = GARMENT_IMAGE_ASSET_MAP['G001'];
    const assetNhatBinh = GARMENT_IMAGE_ASSET_MAP['G018'];
    const assetTac = GARMENT_IMAGE_ASSET_MAP['G009'];

    assert(
      assetGiaoLinh !== assetNhatBinh && assetNhatBinh !== assetTac,
      'Test 6.2: Các thực thể khác nhau ánh xạ đến các tệp ảnh tham chiếu riêng biệt'
    );

    assert(
      assetGiaoLinh === 'tu_ao_ao_giao_linh_1791540421433.jpg' &&
        assetNhatBinh === 'tu_ao_ao_nhat_binh_1791540457083.jpg' &&
        assetTac === 'tu_ao_ao_tac_1791590607100.jpg',
      'Test 6.3: Ánh xạ chuẩn xác từng tệp tư liệu đã xác minh trong thư mục assets'
    );
  }

  // -------------------------------------------------------------------------
  // 7. Single-item and complete-outfit modes remain separate
  // -------------------------------------------------------------------------
  {
    // 7.1 Single accessory preserves neutral base model
    assert(
      isAccessoryItem(nonLa) === true,
      'Test 7.1: Nón Lá (G035) được nhận diện là phụ kiện'
    );

    const promptSingleHat = buildSingleItemPrompt(nonLa, 'female');
    assert(
      promptSingleHat.includes('SINGLE ACCESSORY FOCUS') &&
        promptSingleHat.includes('PRESERVE NEUTRAL BASE MODEL') &&
        promptSingleHat.includes('DO NOT INVENT A FULL COSTUME'),
      'Test 7.2: Thử đơn món phụ kiện giữ dáng model trung tính và nghiêm cấm tạo nguyên bộ cổ phục'
    );

    // 7.2 Complete outfit mode passes all layers
    const items = [aoTuThan, yem, vay];
    const outfitPrompt = buildCompleteOutfitPrompt(items, undefined, 'female', 'Bộ Tứ Thân Kinh Bắc');
    assert(
      outfitPrompt.includes('COMPLETE OUTFIT ENSEMBLE') &&
        outfitPrompt.includes('LỚP TRONG (INNER BASE)') &&
        outfitPrompt.includes('ÁO CHÍNH / ÁO NGOÀI') &&
        outfitPrompt.includes('THÂN DƯỚI'),
      'Test 7.3: Chế độ complete_outfit_try_on phân chia cấu trúc đa tầng y phục riêng biệt'
    );

    assert(
      items.every((item) => outfitPrompt.includes(item.name)),
      'Test 7.4: Toàn bộ các món đồ đã chọn đều hiện diện đầy đủ trong prompt bộ phối'
    );
  }

  // -------------------------------------------------------------------------
  // 8. Stale requests & client cache integrity
  // -------------------------------------------------------------------------
  {
    let currentRequestId = 'req_first_123';
    const firstReqId = currentRequestId;

    // User switches selection while first request is in-flight:
    currentRequestId = 'req_second_456';
    const isFirstStale = firstReqId !== currentRequestId;
    assert(
      isFirstStale === true,
      'Test 8.1: Request cũ bị đánh dấu stale và không được phép ghi đè lên kết quả mới'
    );

    // Cache keys differ across parameters
    const keyFemale = buildImageCacheKey({
      mode: 'single_item_try_on',
      gender: 'female',
      itemIds: ['G001'],
    });
    const keyMale = buildImageCacheKey({
      mode: 'single_item_try_on',
      gender: 'male',
      itemIds: ['G001'],
    });
    assert(
      keyFemale !== keyMale,
      'Test 8.2: Cache key phân tách rõ rệt giữa dáng Nữ và Nam'
    );

    clearImageResultCache();
    assert(
      true,
      'Test 8.3: clearImageResultCache() làm sạch client cache thành công'
    );
  }

  return { passed: allPassed, logs };
}
