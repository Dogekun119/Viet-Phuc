/**
 * TESTS CHO GARMENT LAYER SYSTEM & 49 CANONICAL STYLING ITEMS
 *
 * Kiểm tra các yêu cầu của PROMPT 3C:
 * 1. Đúng chính xác 49 thực thể chuẩn (47 MASTER_GARMENTS + A011 + A012).
 * 2. Không có ID trùng lặp, không có A001-A010 / A013 bị nhân bản.
 * 3. assertCanonicalStylingItems() hoạt động chính xác.
 * 4. Phân loại stylingReadiness chuẩn: READY (0), PARTIAL (3), CATALOG_ONLY (37), RESEARCH (9).
 * 5. Các món không có visual asset (CATALOG_ONLY, RESEARCH) không bị ép render layer.
 * 6. Các món có visual asset (PARTIAL/READY) được resolve theo đúng thứ tự tầng.
 * 7. Thử nghiệm với subset nhỏ (G001, G004, G010, G011, G012).
 */

import {
  GARMENT_LAYER_ORDER,
  LAYER_Z_INDEX_MAP,
  GarmentPlacement,
  GarmentLayerData,
  createDefaultPlacement,
  TEST_OUTFIT_LAYERS,
  resolveLayersForItems,
  CANONICAL_STYLING_ITEMS,
  CANONICAL_STYLING_MAP,
  STYLING_STATS,
  assertCanonicalStylingItems,
} from './garmentLayers';
import { CANONICAL_ENTITIES } from './canonicalData';

export function runGarmentLayerTests(): { passed: boolean; logs: string[] } {
  const logs: string[] = [];
  let allPassed = true;

  function assert(condition: boolean, testName: string) {
    if (condition) {
      logs.push(`✅ [PASS] ${testName}`);
    } else {
      logs.push(`❌ [FAIL] ${testName}`);
      allPassed = false;
    }
  }

  // Test 1: Đủ 5 loại layer và thứ tự chuẩn
  const expectedOrder = ['inner', 'main', 'outer', 'lower', 'accessory'];
  assert(
    JSON.stringify(GARMENT_LAYER_ORDER) === JSON.stringify(expectedOrder),
    'Test 1: Thứ tự layer chuẩn: inner → main → outer → lower → accessory'
  );

  // Test 2: Centralized Z-Index map tăng dần từ inner đến accessory
  assert(
    LAYER_Z_INDEX_MAP.inner < LAYER_Z_INDEX_MAP.main &&
      LAYER_Z_INDEX_MAP.main < LAYER_Z_INDEX_MAP.outer &&
      LAYER_Z_INDEX_MAP.outer < LAYER_Z_INDEX_MAP.lower &&
      LAYER_Z_INDEX_MAP.lower < LAYER_Z_INDEX_MAP.accessory,
    'Test 2: Z-Index tập trung tăng dần chuẩn thứ tự: 11 < 12 < 13 < 14 < 15'
  );

  // Test 3: Chính xác 44 thực thể chuẩn trong danh mục styling (loại trừ 5 món)
  assert(
    CANONICAL_STYLING_ITEMS.length === 44,
    `Test 3: Chính xác 44 thực thể chuẩn (nhận được: ${CANONICAL_STYLING_ITEMS.length})`
  );

  // Test 4: Không trùng lặp ID trong CANONICAL_STYLING_ITEMS
  const uniqueIds = new Set(CANONICAL_STYLING_ITEMS.map((i) => i.itemId));
  assert(
    uniqueIds.size === 44,
    `Test 4: Không có itemId trùng lặp (44/44 unique IDs)`
  );

  // Test 5: Khớp 100% với CANONICAL_ENTITIES
  const canonicalRecordIds = new Set(CANONICAL_ENTITIES.map((e) => e.primaryRecordId));
  const allMatch = CANONICAL_STYLING_ITEMS.every((i) => canonicalRecordIds.has(i.itemId));
  assert(
    allMatch,
    'Test 5: Toàn bộ 44 styling items khớp 100% với primaryRecordId của CANONICAL_ENTITIES'
  );

  // Test 6: Không có phụ kiện gộp A001-A010 hoặc A013 bị nhân bản, và 5 món đã loại bỏ tuyệt đối không xuất hiện
  const forbiddenIds = [
    'A001', 'A002', 'A003', 'A004', 'A005', 'A006', 'A007', 'A008', 'A009', 'A010', 'A013',
    'G004', 'G005', 'G026', 'G027', 'G029',
  ];
  const hasForbidden = CANONICAL_STYLING_ITEMS.some((i) => forbiddenIds.includes(i.itemId));
  assert(
    !hasForbidden,
    'Test 6: Tuyệt đối không duplicate phụ kiện và 5 món loại bỏ (G004, G005, G026, G027, G029) hoàn toàn vắng mặt'
  );

  // Test 7: Phụ kiện độc lập A011 và A012 có mặt
  const hasA011 = CANONICAL_STYLING_MAP.has('A011');
  const hasA012 = CANONICAL_STYLING_MAP.has('A012');
  assert(
    hasA011 && hasA012,
    'Test 7: Hai phụ kiện độc lập A011 (Quạt) và A012 (Thẻ bài) có mặt chuẩn xác'
  );

  // Test 8: Kiểm tra thống kê styling readiness
  assert(
    STYLING_STATS.total === 44 &&
      STYLING_STATS.catalogOnly === 35 &&
      STYLING_STATS.research === 6,
    `Test 8: Thống kê chính xác: Total 44 = Ready(${STYLING_STATS.ready}) + Partial(${STYLING_STATS.partial}) + CatalogOnly(35) + Research(6)`
  );

  // Test 9: assertCanonicalStylingItems() vượt qua trên dữ liệu chuẩn
  let assertionPassed = false;
  try {
    assertCanonicalStylingItems();
    assertionPassed = true;
  } catch {
    assertionPassed = false;
  }
  assert(
    assertionPassed,
    'Test 9: assertCanonicalStylingItems() validate thành công bộ 49 items'
  );

  // Test 10: assertCanonicalStylingItems() phát hiện nếu thiếu/trùng item
  let duplicateCaught = false;
  try {
    assertCanonicalStylingItems([
      ...CANONICAL_STYLING_ITEMS,
      { ...CANONICAL_STYLING_ITEMS[0] },
    ]);
  } catch {
    duplicateCaught = true;
  }
  assert(
    duplicateCaught,
    'Test 10: assertCanonicalStylingItems() phát hiện và chặn khi có duplicate item'
  );

  // Test 11: Subset test nhỏ: G001 (Áo Giao Lĩnh - ready), G007 (Áo Tứ Điên - research), G011 (Yếm - ready), G012 (Váy - catalog_only)
  const subsetItems = [
    { id: 'G001', name: 'Áo Giao Lĩnh' } as any,
    { id: 'G007', name: 'Áo Tứ Điên' } as any,
    { id: 'G011', name: 'Yếm' } as any,
    { id: 'G012', name: 'Váy' } as any,
  ];
  const subsetLayers = resolveLayersForItems(subsetItems);
  assert(
    subsetLayers.length === 2,
    `Test 11: Subset test: Chỉ 2 món có asset (G001, G011) tạo visual layer, G007 & G012 không tạo layer rỗng`
  );

  // Test 12: Thứ tự các layer được resolve tuân thủ đúng inner (11) trước outer (13)
  assert(
    subsetLayers[0].layerType === 'inner' && subsetLayers[1].layerType === 'outer',
    'Test 12: Layer order được sắp xếp chuẩn: inner (Yếm) trước outer (Áo Giao Lĩnh)'
  );

  // Test 13: Món CATALOG_ONLY và RESEARCH tồn tại đầy đủ, còn G004 bị loại bỏ hoàn toàn
  const g007 = CANONICAL_STYLING_MAP.get('G007');
  const g012 = CANONICAL_STYLING_MAP.get('G012');
  const g004 = CANONICAL_STYLING_MAP.get('G004');
  assert(
    Boolean(g007 && g007.stylingReadiness === 'RESEARCH' && g007.asset === null) &&
      Boolean(g012 && g012.stylingReadiness === 'CATALOG_ONLY' && g012.asset === null) &&
      g004 === undefined,
    'Test 13: G007 (RESEARCH) và G012 (CATALOG_ONLY) có trong styling map, G004 đã bị loại bỏ triệt để'
  );

  return { passed: allPassed, logs };
}

// Chạy trực tiếp nếu file được thực thi độc lập qua tsx
if (typeof process !== 'undefined' && process.argv && process.argv[1]?.includes('garmentLayers.test')) {
  const result = runGarmentLayerTests();
  console.log('--- KẾT QUẢ KIỂM THỬ GARMENT LAYER SYSTEM ---');
  result.logs.forEach((log) => console.log(log));
  if (!result.passed) {
    process.exit(1);
  }
}
