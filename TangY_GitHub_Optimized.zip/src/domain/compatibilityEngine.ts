/**
 * COMPATIBILITY & RECOMMENDATION ENGINE
 * 
 * Động cơ thẩm định tính phù hợp y phục hoàn toàn DETERMINISTIC & DATA-DRIVEN.
 * Không dùng LLM ở runtime để quyết định tính đúng sai lịch sử.
 * Tuân thủ tuyệt đối quy tắc: Mismatch > Modern Remix > Uncertain > Insufficient Data > Authentic.
 */

import { COMPATIBILITY_RULES, ITEMS_MAP } from './dataAdapter';
import { CompatibilityLabel, Item, OutfitEvaluation } from './types';

export interface EvaluatedPairResult {
  itemAId: string;
  itemBId: string;
  ruleId?: string;
  label: CompatibilityLabel;
  reason?: string;
  warning?: string;
  sourceIds: string[];
}

export function evaluateOutfit(selectedItems: Item[]): OutfitEvaluation {
  if (!selectedItems || selectedItems.length === 0) {
    return {
      label: 'INSUFFICIENT_DATA',
      summary: 'Chưa có trang phục nào trong bộ phối. Hãy chọn ít nhất một lớp trang phục chính.',
      evaluatedPairs: [],
      unmetConditions: ['Cần chọn ít nhất một trang phục thân trên hoặc bộ phục'],
      warnings: [],
      sourceIds: [],
    };
  }

  if (selectedItems.length === 1) {
    const single = selectedItems[0];
    return {
      label: 'INSUFFICIENT_DATA',
      summary: `Đã chọn ${single.name}. Cần thêm các lớp y phục (lớp lót, thân dưới, phụ kiện) để hoàn chỉnh tổ hợp.`,
      evaluatedPairs: [],
      unmetConditions: ['Cần thêm các thành phần liên đới để thẩm định tính đồng bộ'],
      warnings: single.warnings ? [single.warnings] : [],
      sourceIds: single.sourceIds || [],
    };
  }

  const evaluatedPairs: EvaluatedPairResult[] = [];
  const warningsSet = new Set<string>();
  const unmetConditionsSet = new Set<string>();
  const allSourceIds = new Set<string>();

  // Collect item IDs and categories for cross-checking
  const itemIds = new Set(selectedItems.map((i) => i.id));
  const hasVanKien = itemIds.has('G040') || itemIds.has('A001');
  const hasTuThan = itemIds.has('G010') || selectedItems.some((i) => i.name.includes('Tứ Thân'));
  const hasNguThan = itemIds.has('G008') || selectedItems.some((i) => i.name.includes('Ngũ Thân'));
  const hasAoTac = itemIds.has('G009') || selectedItems.some((i) => i.name.includes('Áo Tấc'));
  const hasBoPhuc = itemIds.has('G016') || selectedItems.some((i) => i.name.includes('Bổ Phục'));
  const hasLongBao = itemIds.has('G022') || selectedItems.some((i) => i.name.includes('Long Bào'));
  const hasNhatBinh = itemIds.has('G018') || selectedItems.some((i) => i.name.includes('Nhật Bình'));
  const hasBaBa = itemIds.has('G028') || selectedItems.some((i) => i.name.includes('Bà Ba'));
  const hasKhanRan = itemIds.has('G034') || selectedItems.some((i) => i.name.includes('Khăn Rằn'));
  const hasQuaiThao = itemIds.has('G036') || itemIds.has('G037') || selectedItems.some((i) => i.name.includes('Ba Tầm') || i.name.includes('Quai thao'));

  // 1. Evaluate each unique pair (Item A, Item B)
  for (let i = 0; i < selectedItems.length; i++) {
    for (let j = i + 1; j < selectedItems.length; j++) {
      const a = selectedItems[i];
      const b = selectedItems[j];

      // Add sources from individual items
      a.sourceIds?.forEach((s) => allSourceIds.add(s));
      b.sourceIds?.forEach((s) => allSourceIds.add(s));

      // Try finding an explicit rule matching A and B (bidirectional)
      const matchedRule = COMPATIBILITY_RULES.find(
        (r) =>
          (r.itemAId === a.id && r.itemBId === b.id) ||
          (r.itemAId === b.id && r.itemBId === a.id) ||
          (r.raw && typeof r.raw === 'object' && 'baseGarment' in r.raw && 'component' in r.raw &&
            (((r.raw as any).baseGarment.toLowerCase().includes(a.name.toLowerCase()) && (r.raw as any).component.toLowerCase().includes(b.name.toLowerCase())) ||
             ((r.raw as any).baseGarment.toLowerCase().includes(b.name.toLowerCase()) && (r.raw as any).component.toLowerCase().includes(a.name.toLowerCase()))))
      );

      if (matchedRule) {
        matchedRule.sourceIds?.forEach((s) => allSourceIds.add(s));
        if (matchedRule.warning) warningsSet.add(matchedRule.warning);

        evaluatedPairs.push({
          itemAId: a.id,
          itemBId: b.id,
          ruleId: matchedRule.id,
          label: matchedRule.label,
          reason: matchedRule.reason || `Phù hợp theo quy tắc ${matchedRule.id}`,
          warning: matchedRule.warning,
          sourceIds: matchedRule.sourceIds || [],
        });
        continue;
      }

      // 2. Special Domain Checks if no direct single rule
      // A. Vân Kiên Strict Constraint (A001 / G040)
      if ((a.id === 'G040' || a.id === 'A001' || b.id === 'G040' || b.id === 'A001')) {
        const other = a.id === 'G040' || a.id === 'A001' ? b : a;
        if (other.name.includes('Tứ Thân') || other.name.includes('Bà Ba')) {
          warningsSet.add('Vân kiên là chi tiết phẩm phục cung đình triều Nguyễn, xung đột hoàn toàn khi gắn vào trang phục dân gian.');
          evaluatedPairs.push({
            itemAId: a.id,
            itemBId: b.id,
            ruleId: 'R018',
            label: 'CULTURAL_MISMATCH',
            reason: 'Khác hệ phục trang: Vân kiên thuộc phẩm phục cung đình, không phải phụ kiện thời trang tự do.',
            warning: 'Cảnh báo cultural mismatch nghiêm trọng.',
            sourceIds: ['S01'],
          });
          continue;
        } else if (other.name.includes('Ngũ Thân') && !other.name.includes('Tấc')) {
          warningsSet.add('Vân kiên chỉ được ghi nhận trên một số phẩm phục/bổ phục cụ thể, không auto-enable cho mọi áo ngũ thân dân gian.');
          unmetConditionsSet.add('Cần chứng minh phẩm hàm quý tộc/quan chức để diện Vân kiên với áo ngũ thân.');
          evaluatedPairs.push({
            itemAId: a.id,
            itemBId: b.id,
            ruleId: 'R019',
            label: 'UNCERTAIN',
            reason: 'Chưa đủ bằng chứng phẩm hàm để cho phép Vân kiên đi cùng áo ngũ thân thường nhật.',
            warning: 'Cần xác định thêm bối cảnh phẩm cấp triều đình.',
            sourceIds: ['S01'],
          });
          continue;
        } else if (hasBoPhuc || hasAoTac) {
          evaluatedPairs.push({
            itemAId: a.id,
            itemBId: b.id,
            ruleId: 'R010',
            label: 'HISTORICALLY_SUPPORTED',
            reason: 'Vân kiên đi cùng áo thờ / bổ phục / áo tấc cung đình có hiện vật tại BTLSQG.',
            sourceIds: ['S01'],
          });
          continue;
        } else {
          unmetConditionsSet.add('Vân kiên đòi hỏi áo đi kèm phải là lễ phục cung đình triều Nguyễn và có phẩm trật xác định.');
          evaluatedPairs.push({
            itemAId: a.id,
            itemBId: b.id,
            label: 'INSUFFICIENT_DATA',
            reason: 'Cần xác định thêm bối cảnh: Vân kiên không phải trang sức tự do.',
            warning: 'Chỉ cho phép khi garment + period + rank + context khớp.',
            sourceIds: ['S01'],
          });
          continue;
        }
      }

      // B. Khăn Rằn + Áo Tứ Thân Clash
      if ((hasTuThan && (a.id === 'G034' || b.id === 'G034')) || (hasBaBa && (hasQuaiThao || a.id === 'G033' || b.id === 'G033'))) {
        warningsSet.add('Xung đột không gian văn hóa vùng miền: Khăn rằn Nam Bộ cọc cạch với áo Tứ thân Bắc Bộ.');
        evaluatedPairs.push({
          itemAId: a.id,
          itemBId: b.id,
          ruleId: 'R022',
          label: 'CULTURAL_MISMATCH',
          reason: 'Khác biệt vùng miền và không gian địa văn hóa lịch sử.',
          warning: 'Không nên ghép phụ kiện Nam Bộ vào áo truyền thống Kinh Bắc.',
          sourceIds: ['S03'],
        });
        continue;
      }

      // C. Cross-Period Mismatch (e.g. Lý-Trần with Nguyễn court official regalia)
      const periodsA = a.period || [];
      const periodsB = b.period || [];
      const isAncientOnlyA = periodsA.some((p) => p.includes('Lý') || p.includes('Trần') || p.includes('Đông Sơn')) && !periodsA.some((p) => p.includes('Nguyễn'));
      const isNguyenOnlyB = periodsB.some((p) => p.includes('Nguyễn')) && !periodsB.some((p) => p.includes('Lý') || p.includes('Trần'));

      if ((isAncientOnlyA && isNguyenOnlyB) || (periodsA.some((p) => p.includes('Nguyễn')) && periodsB.some((p) => p.includes('Lý') || p.includes('Trần')) && !periodsB.some((p) => p.includes('Nguyễn')))) {
        warningsSet.add(`Lệch triều đại và thời kỳ lịch sử giữa ${a.name} và ${b.name}.`);
        evaluatedPairs.push({
          itemAId: a.id,
          itemBId: b.id,
          ruleId: 'R022',
          label: 'CULTURAL_MISMATCH',
          reason: 'Khác biệt triều đại: Không ghép phụ kiện/cấu trúc của Nguyễn vào set Lý–Trần khi không có cơ sở.',
          warning: 'Hiển thị period mismatch.',
          sourceIds: ['S01', 'S02'],
        });
        continue;
      }

      // D. Neutral pairing / Default consistent if same broad region/context
      const sharedContext = a.context?.some((c) => b.context?.includes(c));
      const sharedPeriod = a.period?.some((p) => b.period?.includes(p));

      if (sharedPeriod || sharedContext) {
        evaluatedPairs.push({
          itemAId: a.id,
          itemBId: b.id,
          label: 'HISTORICALLY_SUPPORTED',
          reason: `Phù hợp về bối cảnh thời kỳ/không gian (${a.period?.[0] || 'truyền thống'}).`,
          sourceIds: [...(a.sourceIds || []), ...(b.sourceIds || [])],
        });
      } else {
        evaluatedPairs.push({
          itemAId: a.id,
          itemBId: b.id,
          label: 'INSUFFICIENT_DATA',
          reason: 'Chưa có quy tắc đối chiếu trực tiếp trong Master Research v1.',
          sourceIds: [],
        });
      }
    }
  }

  // 3. Layer Integrity Checks
  if (hasTuThan) {
    if (!itemIds.has('G011')) {
      unmetConditionsSet.add('Áo Tứ Thân truyền thống có Yếm (G011) là lớp trong cốt lõi.');
    }
    if (!itemIds.has('G012')) {
      unmetConditionsSet.add('Áo Tứ Thân truyền thống mặc cùng Váy đụp (G012) làm trang phục thân dưới.');
    }
    if (!itemIds.has('G042') && !itemIds.has('A004')) {
      unmetConditionsSet.add('Áo Tứ Thân cần Thắt lưng / Dải bao lụa (G042/A004) để giữ nếp vạt áo.');
    }
  }

  if (hasNguThan) {
    if (!itemIds.has('G013')) {
      unmetConditionsSet.add('Áo Ngũ Thân thường mặc cùng Quần ống rộng sáng màu (G013) theo nguồn Bảo tàng Phụ nữ Nam Bộ.');
    }
  }

  if (hasLongBao) {
    if (!itemIds.has('G044') && !itemIds.has('A007')) {
      unmetConditionsSet.add('Long bào đại triều nguyên bộ cần Hốt ngọc (G044/A007), Mũ Cửu Long, Đai và Hia.');
    }
  }

  // 4. Overall Label Determination (Conservative priority)
  let overallLabel: CompatibilityLabel = 'AUTHENTIC';

  const hasMismatch = evaluatedPairs.some((p) => p.label === 'CULTURAL_MISMATCH');
  const hasRemix = evaluatedPairs.some((p) => p.label === 'CONTEXTUAL_MODERN_REMIX');
  const hasUncertain = evaluatedPairs.some((p) => p.label === 'UNCERTAIN') || selectedItems.some((i) => i.evidenceLevel === 'UNCERTAIN' || i.evidenceLevel === 'CONTESTED');
  const hasInsufficient = evaluatedPairs.some((p) => p.label === 'INSUFFICIENT_DATA') || unmetConditionsSet.size > 0;

  if (hasMismatch) {
    overallLabel = 'CULTURAL_MISMATCH';
  } else if (hasRemix) {
    overallLabel = 'CONTEXTUAL_MODERN_REMIX';
  } else if (hasUncertain) {
    overallLabel = 'UNCERTAIN';
  } else if (hasInsufficient) {
    overallLabel = 'INSUFFICIENT_DATA';
  } else if (evaluatedPairs.every((p) => p.label === 'AUTHENTIC')) {
    overallLabel = 'AUTHENTIC';
  } else {
    overallLabel = 'HISTORICALLY_SUPPORTED';
  }

  // Summary generation based on findings
  let summary = '';
  switch (overallLabel) {
    case 'CULTURAL_MISMATCH':
      summary = 'Phát hiện sự không phù hợp rõ rệt về thời kỳ, quy chế phẩm hàm hoặc không gian văn hóa giữa các món đồ.';
      break;
    case 'CONTEXTUAL_MODERN_REMIX':
      summary = 'Bộ phối theo phong cách Hiện đại Hóa (Modern Remix). Mang tính sáng tạo cá nhân, không xem là phục dựng lịch sử nguyên bản.';
      break;
    case 'UNCERTAIN':
      summary = 'Tổ hợp chứa các thành phần đang trong quá trình tranh luận học thuật hoặc chưa đủ chứng cứ đối chiếu (ví dụ: Tứ Điên, nón Ba Tầm).';
      break;
    case 'INSUFFICIENT_DATA':
      summary = 'Tổ hợp còn thiếu một số lớp y phục cốt lõi hoặc bối cảnh cần thiết theo quy thức ghi nhận trong tư liệu.';
      break;
    case 'AUTHENTIC':
      summary = 'Tổ hợp y phục chuẩn mực, đầy đủ các lớp và chi tiết đã được xác thực qua tư liệu hiện vật bảo tàng.';
      break;
    case 'HISTORICALLY_SUPPORTED':
      summary = 'Tổ hợp hòa hợp và phù hợp với các nguồn tư liệu lịch sử hiện có.';
      break;
    default:
      summary = 'Đang thẩm định tổ hợp trang phục.';
  }

  return {
    label: overallLabel,
    summary,
    evaluatedPairs,
    unmetConditions: Array.from(unmetConditionsSet),
    warnings: Array.from(warningsSet),
    sourceIds: Array.from(allSourceIds),
  };
}

/**
 * Data-Driven Recommendations:
 * Chỉ gợi ý những món có quan hệ rule rõ ràng với các món đang chọn.
 * Nếu không có rule hỗ trợ -> trả về mảng rỗng (không bịa).
 */
export function getRecommendedNextItems(currentSelectedItems: Item[]): Item[] {
  if (!currentSelectedItems || currentSelectedItems.length === 0) return [];

  const currentIds = new Set(currentSelectedItems.map((i) => i.id));
  const candidateIds = new Set<string>();

  currentSelectedItems.forEach((item) => {
    COMPATIBILITY_RULES.forEach((rule) => {
      // Only positive recommendations
      if (
        rule.label === 'AUTHENTIC' ||
        rule.label === 'HISTORICALLY_SUPPORTED'
      ) {
        if (rule.itemAId === item.id && !currentIds.has(rule.itemBId)) {
          candidateIds.add(rule.itemBId);
        } else if (rule.itemBId === item.id && !currentIds.has(rule.itemAId)) {
          candidateIds.add(rule.itemAId);
        }
      }
    });
  });

  const recommended: Item[] = [];
  candidateIds.forEach((id) => {
    const item = ITEMS_MAP.get(id);
    if (item && !currentIds.has(item.id)) {
      recommended.push(item);
    }
  });

  return recommended;
}
