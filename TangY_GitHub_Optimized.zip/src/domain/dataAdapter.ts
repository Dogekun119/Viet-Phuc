/**
 * DATA ADAPTER MODULE
 * Đọc và chuẩn hóa dữ liệu từ Viet_Phuc_Master_Research_v1.json và assets.json
 * Không ghi đè hoặc đoán mò dữ liệu thiếu; giữ nguyên raw records.
 */

import rawResearchData from '../data/Viet_Phuc_Master_Research_v1.json';
import rawAssetData from '../data/assets.json';
import rawCommunityOutfits from '../data/communityOutfits.json';
import {
  AuditItem,
  CompatibilityLabel,
  CompatibilityRule,
  EvidenceLevel,
  ImageAsset,
  Item,
  PublicCommunityOutfit,
  ResearchQueueRecord,
  ResearchSourceItem,
} from './types';
import { determineGenderScope } from './canonicalData';

// Normalization helper for Evidence Level
export function normalizeEvidenceLevel(rawLevel: string | undefined): EvidenceLevel {
  if (!rawLevel) return 'UNKNOWN';
  const clean = rawLevel.trim().toUpperCase();
  if (clean.includes('VERIFIED')) return 'VERIFIED';
  if (clean.includes('STRONG')) return 'STRONGLY_SUPPORTED';
  if (clean.includes('CONSISTENT')) return 'HISTORICALLY_CONSISTENT';
  if (clean.includes('CONTESTED')) return 'CONTESTED';
  if (clean.includes('UNCERTAIN')) return 'UNCERTAIN';
  if (clean.includes('REMIX')) return 'REMIX';
  if (clean.includes('MISMATCH')) return 'MISMATCH';
  if (clean.includes('NEEDS_RESEARCH')) return 'NEEDS_RESEARCH';
  return 'UNKNOWN';
}

// Map Relationship Type to Compatibility Label
export function mapRelationToLabel(relationship: string | undefined): CompatibilityLabel {
  if (!relationship) return 'INSUFFICIENT_DATA';
  const rel = relationship.toUpperCase();
  if (rel.includes('MISMATCH')) return 'CULTURAL_MISMATCH';
  if (rel.includes('MODERN_REMIX') || rel.includes('REMIX')) return 'CONTEXTUAL_MODERN_REMIX';
  if (rel.includes('CORE_LAYER') || rel.includes('CORE_ACCESSORY') || rel.includes('CEREMONIAL_SET')) {
    return 'AUTHENTIC';
  }
  if (rel.includes('HISTORICAL_TEXT_SUPPORT') || rel.includes('LABOR_DAILY') || rel.includes('REGIONAL') || rel.includes('CONTEXTUAL') || rel.includes('CONDITIONAL') || rel.includes('CORE_COMPONENT')) {
    return 'HISTORICALLY_SUPPORTED';
  }
  return 'INSUFFICIENT_DATA';
}

// 1. Parse Image Assets
export const IMAGE_ASSETS: ImageAsset[] = (rawAssetData as ImageAsset[]) || [];

export function getImageAssetForRecord(recordId: string): ImageAsset | undefined {
  return IMAGE_ASSETS.find((asset) => asset.recordId === recordId);
}

// 1b. Parse Public Community Outfits
export const PUBLIC_COMMUNITY_OUTFITS: PublicCommunityOutfit[] =
  (rawCommunityOutfits as PublicCommunityOutfit[]) || [];

// 2. Parse Research Sources
export const RESEARCH_SOURCES: ResearchSourceItem[] =
  (rawResearchData.SOURCES as ResearchSourceItem[]) || [];

export const RESEARCH_SOURCES_MAP: Record<string, ResearchSourceItem> =
  RESEARCH_SOURCES.reduce((acc, src) => {
    acc[src.id] = src;
    return acc;
  }, {} as Record<string, ResearchSourceItem>);

// 3. Parse PDF Audit
export const PDF_AUDIT_ITEMS: AuditItem[] =
  (rawResearchData.PDF_AUDIT as AuditItem[]) || [];

// 4. Parse Research Queue
export const RESEARCH_QUEUE_ITEMS: ResearchQueueRecord[] =
  (rawResearchData.RESEARCH_QUEUE as ResearchQueueRecord[]) || [];

// 5. Parse Garments and normalize to Items
const rawGarments = (rawResearchData.MASTER_GARMENTS || []) as Array<{
  id: string;
  name: string;
  aliases?: string[];
  category?: string;
  period?: string[];
  audience?: string[];
  region?: string[];
  context?: string[];
  auditStatus?: string;
  evidenceLevel?: string;
  constructionNotes?: string;
  layerCompatibility?: string;
  warnings?: string;
  researchNotes?: string;
  sourceIds?: string[];
}>;

const GARMENT_ITEMS: Item[] = rawGarments.map((g, index) => {
  return {
    id: g.id || `G_${index + 1}`,
    name: g.name,
    aliases: g.aliases || [],
    category: g.category || 'Khác',
    period: g.period || [],
    region: g.region || [],
    gender: g.audience || [],
    genderScope: determineGenderScope(g.id || '', g.name, g.category || '', g.audience || []),
    context: g.context || [],
    construction: g.constructionNotes || '',
    layerRole: [g.category || 'Áo thân trên'],
    evidenceLevel: normalizeEvidenceLevel(g.evidenceLevel),
    culturalNotes: g.researchNotes || '',
    sourceIds: g.sourceIds || [],
    auditStatus: g.auditStatus || 'CORE',
    warnings: g.warnings || '',
    raw: g,
  };
});

// 6. Parse Accessories and normalize to Items
const rawAccessories = (rawResearchData.ACCESSORIES || []) as Array<{
  id: string;
  name: string;
  taxonomy?: string;
  status?: string;
  periodContext?: string;
  userRole?: string;
  compatibilityLogic?: string;
  evidence?: string;
  source?: string;
}>;

const ACCESSORY_ITEMS: Item[] = rawAccessories.map((a, index) => {
  const sources = a.source
    ? a.source
        .split(';')
        .map((s) => s.trim())
        .filter((s) => s.startsWith('S'))
    : [];

  return {
    id: a.id || `A_${index + 1}`,
    name: a.name,
    aliases: [],
    category: a.taxonomy || 'Phụ kiện',
    subcategory: a.taxonomy,
    period: a.periodContext ? [a.periodContext] : [],
    region: [],
    gender: a.userRole ? [a.userRole] : [],
    genderScope: determineGenderScope(a.id || '', a.name, a.taxonomy || '', a.userRole ? [a.userRole] : []),
    context: a.periodContext ? [a.periodContext] : [],
    construction: a.compatibilityLogic || '',
    layerRole: ['Phụ kiện'],
    evidenceLevel: normalizeEvidenceLevel(a.evidence),
    culturalNotes: a.compatibilityLogic || '',
    sourceIds: sources,
    auditStatus: a.status || 'CORE',
    warnings: '',
    raw: a,
  };
});

// All Items (Garments + Accessories)
export const ALL_ITEMS: Item[] = [...GARMENT_ITEMS, ...ACCESSORY_ITEMS];

export const ITEMS_MAP: Map<string, Item> = new Map(
  ALL_ITEMS.map((item) => [item.id, item])
);

// Name/Slug lookup for rules
export function findItemByNameOrAlias(query: string): Item | undefined {
  if (!query) return undefined;
  const q = query.toLowerCase().trim();
  return ALL_ITEMS.find((item) => {
    if (item.name.toLowerCase() === q) return true;
    if (item.id.toLowerCase() === q) return true;
    if (item.aliases?.some((a) => a.toLowerCase() === q)) return true;
    if (item.name.toLowerCase().includes(q) || q.includes(item.name.toLowerCase())) return true;
    return false;
  });
}

// 7. Parse Outfit Rules
const rawRules = (rawResearchData.OUTFIT_RULES || []) as Array<{
  id: string;
  baseGarment: string;
  baseGarmentSlug?: string;
  component: string;
  relationship: string;
  periodContext?: string;
  evidence?: string;
  confidence?: string;
  whyEvidence?: string;
  whatToWarnAbout?: string;
  webBehavior?: string;
  sourceIds?: string[];
}>;

export const COMPATIBILITY_RULES: CompatibilityRule[] = rawRules.map((r, index) => {
  const itemA = findItemByNameOrAlias(r.baseGarment);
  const itemB = findItemByNameOrAlias(r.component);

  return {
    id: r.id || `R_${index + 1}`,
    itemAId: itemA ? itemA.id : r.baseGarmentSlug || r.baseGarment,
    itemBId: itemB ? itemB.id : r.component,
    relationshipType: r.relationship,
    label: mapRelationToLabel(r.relationship),
    conditions: {
      period: r.periodContext ? [r.periodContext] : [],
      context: r.periodContext ? [r.periodContext] : [],
    },
    reason: r.whyEvidence || '',
    warning: r.whatToWarnAbout || '',
    evidenceLevel: normalizeEvidenceLevel(r.evidence),
    sourceIds: r.sourceIds || [],
    raw: r,
  };
});

// Dynamic Facet extraction (No empty facets rendered!)
export interface CatalogFacets {
  categories: string[];
  periods: string[];
  regions: string[];
  audiences: string[];
  contexts: string[];
  evidenceLevels: EvidenceLevel[];
}

export function extractActiveFacets(items: Item[] = ALL_ITEMS): CatalogFacets {
  const categories = new Set<string>();
  const periods = new Set<string>();
  const regions = new Set<string>();
  const audiences = new Set<string>();
  const contexts = new Set<string>();
  const evidenceLevels = new Set<EvidenceLevel>();

  items.forEach((item) => {
    if (item.category && item.category.trim()) {
      categories.add(item.category.trim());
    }
    item.period?.forEach((p) => {
      if (p.trim()) periods.add(p.trim());
    });
    item.region?.forEach((r) => {
      if (r.trim()) regions.add(r.trim());
    });
    item.gender?.forEach((g) => {
      if (g.trim()) audiences.add(g.trim());
    });
    item.context?.forEach((c) => {
      if (c.trim()) contexts.add(c.trim());
    });
    if (item.evidenceLevel) {
      evidenceLevels.add(item.evidenceLevel);
    }
  });

  return {
    categories: Array.from(categories).sort(),
    periods: Array.from(periods).sort(),
    regions: Array.from(regions).sort(),
    audiences: Array.from(audiences).sort(),
    contexts: Array.from(contexts).sort(),
    evidenceLevels: Array.from(evidenceLevels).sort(),
  };
}

export const ACTIVE_CATALOG_FACETS = extractActiveFacets(ALL_ITEMS);
