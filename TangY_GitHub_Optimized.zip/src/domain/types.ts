/**
 * VIỆT PHỤC REMIX — NORMALIZED DOMAIN TYPES
 * Tuân thủ nghiêm ngặt theo tài liệu Master Research v1
 */

export type EvidenceLevel =
  | 'VERIFIED'
  | 'STRONGLY_SUPPORTED'
  | 'HISTORICALLY_CONSISTENT'
  | 'UNCERTAIN'
  | 'NEEDS_RESEARCH'
  | 'UNKNOWN'
  | 'CONTESTED'
  | 'MISMATCH'
  | 'REMIX';

export type CompatibilityLabel =
  | 'AUTHENTIC'
  | 'HISTORICALLY_SUPPORTED'
  | 'CONTEXTUAL_MODERN_REMIX'
  | 'UNCERTAIN'
  | 'CULTURAL_MISMATCH'
  | 'OUT_OF_SCOPE'
  | 'INSUFFICIENT_DATA';

export type ModelGender = 'female' | 'male';

export type ItemGenderScope = 'female' | 'male' | 'unisex' | 'unknown';

export type EditorialType =
  | 'STUDIO_EDITORIAL'
  | 'AI_CONCEPT'
  | 'HISTORICAL_ARTIFACT';

export interface ImageAsset {
  id: string;
  recordId: string;
  kind: 'cover' | 'detail' | 'silhouette' | 'lookbook';
  src: string;
  alt: string;
  credit?: string;
  license?: string;
  sourceUrl?: string;
  editorialType?: EditorialType;
  editorialTypeLabel?: string;
  garmentName?: string;
  dimensions?: string;
  aspectRatio?: string;
  framing?: 'FULL_BODY' | 'PORTRAIT' | 'DETAIL' | 'SILHOUETTE' | 'STILL_LIFE';
  provenanceNote?: string;
  isVerifiedReconstruction?: boolean;
}

export interface PublicCommunityOutfit {
  id: string;
  name: string;
  contributor: string;
  contributorRole: string;
  items: string[];
  period: string;
  statusBadge: string;
  compatibilityLabel: CompatibilityLabel;
  culturalNote: string;
  createdAt: string;
}

export interface Item {
  id: string;
  name: string;
  aliases?: string[];
  category?: string;
  subcategory?: string;
  period?: string[];
  region?: string[];
  gender?: string[];
  genderScope?: ItemGenderScope;
  context?: string[];
  socialStatus?: string[];
  occasion?: string[];
  construction?: string;
  layerRole?: string[];
  evidenceLevel?: EvidenceLevel;
  culturalNotes?: string;
  sourceIds?: string[];
  auditStatus?: string;
  warnings?: string;
  raw: unknown;
}

export interface CompatibilityRule {
  id: string;
  itemAId: string;
  itemBId: string;
  relationshipType?: string;
  label: CompatibilityLabel;
  conditions?: {
    period?: string[];
    region?: string[];
    gender?: string[];
    context?: string[];
    socialStatus?: string[];
    occasion?: string[];
    layerOrder?: string[];
  };
  reason?: string;
  warning?: string;
  evidenceLevel?: EvidenceLevel;
  sourceIds?: string[];
  raw: unknown;
}

export interface OutfitEvaluation {
  label: CompatibilityLabel;
  summary: string;
  evaluatedPairs: Array<{
    itemAId: string;
    itemBId: string;
    ruleId?: string;
    label: CompatibilityLabel;
    reason?: string;
    warning?: string;
    sourceIds: string[];
  }>;
  unmetConditions: string[];
  warnings: string[];
  sourceIds: string[];
}

export interface ResearchSourceItem {
  id: string;
  title: string;
  institution: string;
  type: string;
  usedFor: string;
  url: string;
}

export interface AuditItem {
  statement: string;
  assessment: string;
  problem: string;
  correction: string;
  priority: string;
  source: string;
}

export interface ResearchQueueRecord {
  priority: 'P0' | 'P1';
  topic: string;
  whyUnresolved: string;
  whatToVerify: string;
  preferredSource: string;
  currentDecision: string;
}

export interface SavedUserOutfit {
  id: string;
  name: string;
  items: Item[];
  createdAt: string;
  evaluation: OutfitEvaluation;
  note?: string;
}

export interface UserContributionPayload {
  target: string;
  detail: string;
  sourceReference?: string;
  contactEmail?: string;
}

export interface UserContributionRecord {
  id: string;
  target: string;
  detail: string;
  sourceReference?: string;
  contactEmail?: string;
  submittedAt: string;
  status: 'pending' | 'reviewing' | 'resolved';
}
