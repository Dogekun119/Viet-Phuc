import express from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import fs from 'fs';
import { GoogleGenAI } from '@google/genai';
import {
  generateAdvisorResponse,
  resolveRecommendation,
} from './src/domain/advisorEngine.ts';
import {
  validateTryOnInputs,
  classifyGeminiError,
  extractGeminiImageResponse,
  GARMENT_IMAGE_ASSET_MAP,
  BASE_MODEL_ASSET_MAP,
} from './src/domain/tryOnPipeline.ts';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Dynamic Gemini SDK client factory with telemetry User-Agent header
function getGeminiClient(): { client: GoogleGenAI | null; apiKey: string } {
  const key = process.env.GEMINI_API_KEY || '';
  if (!key || key.trim() === '' || key === 'MY_GEMINI_API_KEY') {
    return { client: null, apiKey: '' };
  }
  return {
    client: new GoogleGenAI({
      apiKey: key,
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build',
        },
      },
    }),
    apiKey: key,
  };
}

async function startServer() {
  const app = express();
  const isProd = process.env.NODE_ENV === 'production';
  const PORT = isProd && process.env.PORT ? Number(process.env.PORT) : 3000;
  const distPath = path.resolve(__dirname, 'dist');

  app.use(express.json());
  app.use('/public/assets', express.static(path.resolve(__dirname, 'public/assets')));
  app.use('/assets', express.static(path.resolve(__dirname, 'public/assets')));

  // Health check endpoint for Cloud Run and monitoring
  app.get('/api/health', (_req, res) => {
    const { apiKey } = getGeminiClient();
    res.json({
      status: 'healthy',
      env: isProd ? 'production' : 'development',
      hasGeminiKey: Boolean(apiKey),
      timestamp: new Date().toISOString(),
    });
  });

  // Safe file storage and concurrency queue for user contributions
  const dataDir = path.resolve(__dirname, 'data');
  const contributionsFilePath = path.resolve(dataDir, 'contributions.json');
  let writeQueue: Promise<void> = Promise.resolve();

  // Basic in-memory rate limiting for spam prevention (max 10 submissions per 5 min per IP)
  const rateLimitMap = new Map<string, number[]>();

  // Reject public GET reads on /api/contributions to protect contributor privacy
  app.get('/api/contributions', (_req, res) => {
    return res.status(405).json({
      ok: false,
      error: 'Phương thức không được hỗ trợ. Không có quyền truy cập danh sách đóng góp.',
    });
  });

  app.post('/api/contributions', async (req, res) => {
    try {
      const clientIp =
        (req.headers['x-forwarded-for'] as string)?.split(',')[0]?.trim() ||
        req.socket.remoteAddress ||
        'unknown-ip';

      const now = Date.now();
      const windowMs = 5 * 60 * 1000; // 5 minutes
      const maxRequests = 10;

      const timestamps = (rateLimitMap.get(clientIp) || []).filter(
        (t) => now - t < windowMs
      );
      if (timestamps.length >= maxRequests) {
        return res.status(429).json({
          ok: false,
          error:
            'Bạn đã gửi quá nhiều yêu cầu trong thời gian ngắn. Vui lòng chờ vài phút trước khi gửi lại.',
        });
      }
      timestamps.push(now);
      rateLimitMap.set(clientIp, timestamps);

      const body = req.body;
      if (!body || typeof body !== 'object') {
        return res.status(400).json({
          ok: false,
          error: 'Dữ liệu gửi lên không đúng định dạng JSON.',
        });
      }

      const { target, detail, sourceReference, contactEmail } = body;

      // 1. Validate target (Required, 2 - 250 chars)
      if (typeof target !== 'string' || !target.trim()) {
        return res.status(400).json({
          ok: false,
          error: 'Vui lòng nhập mục trang phục hoặc nội dung cần góp ý.',
        });
      }
      const trimmedTarget = target.trim();
      if (trimmedTarget.length < 2 || trimmedTarget.length > 250) {
        return res.status(400).json({
          ok: false,
          error:
            'Mục trang phục cần góp ý phải có độ dài từ 2 đến 250 ký tự.',
        });
      }

      // 2. Validate detail (Required, 10 - 5000 chars)
      if (typeof detail !== 'string' || !detail.trim()) {
        return res.status(400).json({
          ok: false,
          error:
            'Vui lòng nhập chi tiết đính chính và dẫn chứng tham khảo (tối thiểu 10 ký tự).',
        });
      }
      const trimmedDetail = detail.trim();
      if (trimmedDetail.length < 10) {
        return res.status(400).json({
          ok: false,
          error:
            'Nội dung góp ý quá ngắn. Vui lòng mô tả chi tiết hơn (tối thiểu 10 ký tự).',
        });
      }
      if (trimmedDetail.length > 5000) {
        return res.status(400).json({
          ok: false,
          error:
            'Nội dung góp ý vượt quá giới hạn cho phép (tối đa 5.000 ký tự).',
        });
      }

      // 3. Validate sourceReference (Optional, max 1000 chars, validate URL if applicable)
      let trimmedSource = '';
      if (sourceReference !== undefined && sourceReference !== null) {
        if (typeof sourceReference !== 'string') {
          return res.status(400).json({
            ok: false,
            error: 'Nguồn tham khảo phải là chuỗi văn bản.',
          });
        }
        trimmedSource = sourceReference.trim();
        if (trimmedSource.length > 1000) {
          return res.status(400).json({
            ok: false,
            error: 'Nguồn tham khảo không được vượt quá 1.000 ký tự.',
          });
        }
        if (/^https?:\/\//i.test(trimmedSource)) {
          try {
            new URL(trimmedSource);
          } catch {
            return res.status(400).json({
              ok: false,
              error: 'Đường dẫn nguồn tham khảo không đúng định dạng URL hợp lệ.',
            });
          }
        }
      }

      // 4. Validate contactEmail (Optional, max 200 chars, validate format)
      let trimmedEmail = '';
      if (contactEmail !== undefined && contactEmail !== null) {
        if (typeof contactEmail !== 'string') {
          return res.status(400).json({
            ok: false,
            error: 'Email liên hệ phải là chuỗi văn bản.',
          });
        }
        trimmedEmail = contactEmail.trim();
        if (trimmedEmail.length > 0) {
          if (trimmedEmail.length > 200) {
            return res.status(400).json({
              ok: false,
              error: 'Địa chỉ email không được vượt quá 200 ký tự.',
            });
          }
          const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
          if (!emailRegex.test(trimmedEmail)) {
            return res.status(400).json({
              ok: false,
              error: 'Địa chỉ email không đúng định dạng. Vui lòng kiểm tra lại.',
            });
          }
        }
      }

      // Server-generated unique receipt code and timestamp
      const receiptId =
        'CP-' +
        Date.now().toString(36).toUpperCase() +
        '-' +
        Math.random().toString(36).substring(2, 6).toUpperCase();
      const submittedAt = new Date().toISOString();

      const newRecord = {
        id: receiptId,
        target: trimmedTarget,
        detail: trimmedDetail,
        sourceReference: trimmedSource || undefined,
        contactEmail: trimmedEmail || undefined,
        submittedAt,
        status: 'pending',
      };

      // Atomic sequential write into data/contributions.json
      await new Promise<void>((resolve, reject) => {
        writeQueue = writeQueue
          .then(async () => {
            if (!fs.existsSync(dataDir)) {
              fs.mkdirSync(dataDir, { recursive: true });
            }

            let existing: any[] = [];
            if (fs.existsSync(contributionsFilePath)) {
              try {
                const content = fs.readFileSync(contributionsFilePath, 'utf-8');
                existing = JSON.parse(content);
                if (!Array.isArray(existing)) {
                  existing = [];
                }
              } catch (parseErr) {
                console.warn(
                  'Could not parse existing contributions file, starting fresh array:',
                  parseErr
                );
                existing = [];
              }
            }

            existing.push(newRecord);
            const tempFilePath = `${contributionsFilePath}.${Date.now()}.tmp`;
            fs.writeFileSync(tempFilePath, JSON.stringify(existing, null, 2), 'utf-8');
            fs.renameSync(tempFilePath, contributionsFilePath);
            resolve();
          })
          .catch((writeErr) => {
            console.error('Failed to write contribution to disk:', writeErr);
            reject(writeErr);
          });
      });

      return res.status(201).json({
        ok: true,
        id: newRecord.id,
        submittedAt: newRecord.submittedAt,
        message: 'Đã tiếp nhận hồ sơ đóng góp thành công.',
      });
    } catch (err: any) {
      console.error('Server error handling contribution submission:', err);
      return res.status(500).json({
        ok: false,
        error:
          'Máy chủ tạm thời không thể lưu trữ đóng góp. Vui lòng thử lại sau giây lát.',
      });
    }
  });

  // TÀNG Y OCCASION ADVISOR MULTI-TURN CHAT ENDPOINT
  app.post('/api/advisor/chat', async (req, res) => {
    try {
      const { message, history = [], userDate, location } = req.body;
      const userMessage = (message || '').trim();

      const localDate =
        userDate ||
        new Date().toLocaleDateString('vi-VN', {
          weekday: 'long',
          day: '2-digit',
          month: '2-digit',
          year: 'numeric',
        });

      if (!userMessage) {
        const initial = generateAdvisorResponse('', localDate, location);
        return res.json({ ok: true, data: initial });
      }

      // If Gemini client is configured with API key, call gemini-3.8-flash
      const { client: geminiClient, apiKey: geminiApiKey } = getGeminiClient();
      if (geminiClient && geminiApiKey) {
        try {
          const systemInstruction = `Bạn là 'Cố Vấn Tàng Y' (Việt Phục Occasion & Heritage Advisor) — chuyên gia y phục truyền thống Việt Nam của dự án Tàng Y (Việt Phục Remix).

SỨ MỆNH:
Tư vấn trang phục truyền thống Việt Nam phù hợp nhất cho kế hoạch của người dùng hôm nay ('Hôm nay tôi nên mặc gì?') dựa trên bối cảnh, sự kiện, địa điểm, thời gian, phong cách và các giới hạn thực tế; hoặc tư vấn quà tặng văn hóa ý nghĩa.

DANH MỤC THỰC THỂ KHẢ DỤNG (CHỈ ĐƯỢC PHÉP KHUYẾN NGHỊ TỪ DANH SÁCH 42 TRANG PHỤC & PHỤ KIỆN CHUẨN NÀY):
- G001: Áo Giao Lĩnh (Lý, Trần, Lê, Nguyễn nghi lễ - Nam, Nữ)
- G002: Áo Trực Lĩnh (Lê Trung Hưng - Nam, Nữ)
- G003: Áo Đối Khâm (Lê Trung Hưng, Nguyễn - Nam, Nữ)
- G006: Áo Viên Lĩnh (Lý, Trần, Lê, Nguyễn - Nam, Nữ)
- G007: Áo Tứ Điên (Lý, Trần - Nam)
- G008: Áo Ngũ Thân tay chẽn (Nguyễn, Cận đại - Nam, Nữ)
- G009: Áo Tấc (Áo ngũ thân tay thụng, lễ phục trang trọng triều Nguyễn - Nam, Nữ)
- G010: Áo Tứ Thân (Bắc Bộ truyền thống - Nữ)
- G011: Yếm (Nội y truyền thống - Nữ)
- G012: Váy (Váy đụp dân gian Bắc Bộ - Nữ)
- G013: Quần ống rộng sáng màu / Quần trắng (Nguyễn, Cận đại - Nam, Nữ)
- G014: Quần Lá Tọa (Dân gian - Nam)
- G015: Khố (Cổ đại, Đông Sơn - Nam)
- G016: Áo Bổ Phục (Quan lại triều đình Nguyễn - Nam)
- G017: Bổ Tử (Phẩm phục quan lại Nguyễn)
- G018: Áo Nhật Bình (Hậu phi, công chúa, cung tần, mệnh phụ triều Nguyễn - Nữ)
- G019: Áo Mệnh Phụ (Phụ nữ phẩm trật triều Nguyễn - Nữ)
- G020: Áo Mãng Bào (Hoàng thân, quan lại cấp cao - Nam)
- G021: Mãng Lan (Hoàng tử, thái tử - Nam)
- G022: Long Bào (Hoàng đế/Vua triều Nguyễn - Nam)
- G023: Hoàng Bào (Hoàng đế/Vua triều Nguyễn - Nam)
- G024: Cổn Phục (Đại lễ tế giao Hoàng đế - Nam)
- G025: Phượng Phục (Hoàng hậu, công chúa triều Nguyễn - Nữ)
- G028: Áo Bà Ba (Nam Bộ, Cận đại & Hiện đại - Nam, Nữ)
- G030: Áo Dài hiện đại (Thế kỷ 20 - nay - Nam, Nữ)
- G031: Khăn Xếp / Khăn Đóng (Nguyễn, Cận đại - Nam, Nữ)
- G032: Khăn Vành Dây (Nữ cung đình, mệnh phụ Nguyễn - Nữ)
- G033: Khăn Mỏ Quạ (Bắc Bộ truyền thống - Nữ)
- G034: Khăn Rằn (Nam Bộ, Cận đại & Hiện đại - Nam, Nữ)
- G035: Nón Lá (Toàn quốc, nhiều thời kỳ - Nam, Nữ)
- G036: Nón Ba Tầm (Bắc Bộ truyền thống - Nữ)
- G037: Nón Thúng / Thúng quai thao (Quan họ Kinh Bắc - Nữ)
- G038: Nón Bài Thơ (Xứ Huế, Cận đại & Hiện đại - Nữ)
- G039: Mũ Cánh Chuồn (Quan lại triều đình - Nam)
- G040: Vân Kiên (Cung đình / phẩm phục quý tộc Nguyễn)
- G041: Trâm (Trâm cài tóc truyền thống - Nữ)
- G042: Đai / Thắt lưng (Dải lụa thắt lưng - Nam, Nữ)
- G043: Dây Ruột Tượng (Dân gian Bắc Bộ - Nữ)
- G044: Hốt (Quan lại / triều lễ Nguyễn - Nam)
- G045: Hia (Quan lại / đại lễ Nguyễn - Nam)
- G046: Hài (Hài thêu truyền thống - Nam, Nữ)
- G047: Guốc Mộc (Dân gian truyền thống - Nam, Nữ)
- A011: Quạt Lụa Cổ (Phụ kiện tao nhã, quà tặng văn hóa)
- A012: Thẻ Bài Quan (Triều đình)

TUYỆT ĐỐI KHÔNG KHUYẾN NGHỊ 5 TRANG PHỤC ĐÃ LOẠI KHỎI CATALOG HOẠT ĐỘNG:
- G004 (Áo Cổ Thìa)
- G005 (Áo Bán Tí)
- G026 (Áo Thâm)
- G027 (Áo Cánh)
- G029 (Áo Chàm)

QUY TẮC BẮT BUỘC VỀ VĂN HÓA VÀ LỊCH SỬ:
1. KHÔNG tự bịa trang phục, ID, nguồn gốc hoặc quy tắc lịch sử.
2. KHÔNG tự ý tuyên bố một bộ phối là 'đúng chuẩn lịch sử' (Authentic) nếu không có tư liệu đối chiếu. Hệ thống sử dụng 5 mức:
   - AUTHENTIC (Chuẩn mực tư liệu bảo tàng)
   - HISTORICALLY_SUPPORTED (Phù hợp bối cảnh lịch sử)
   - CONTEXTUAL_MODERN_REMIX (Cách tân đương đại có ý thức)
   - UNCERTAIN (Học giới còn tranh luận hoặc thiếu bằng chứng xác thực)
   - CULTURAL_MISMATCH (Xung đột không gian văn hóa, triều đại hoặc phẩm cấp)
3. Cảnh báo nghiêm cấm ghép sai quy thức:
   - TUYỆT ĐỐI KHÔNG ghép Vân Kiên (G040) vào Áo Tứ Thân (G010) hay Áo Bà Ba (G028). Vân Kiên là phẩm phục cung đình.
   - TUYỆT ĐỐI KHÔNG ghép Khăn Rằn Nam Bộ (G034) vào Áo Tứ Thân Kinh Bắc (G010).
   - KHÔNG ghép Mũ Cánh Chuồn (G039) hay Hốt (G044) vào trang phục dân gian thường nhật.
   - Long bào (G022) / Hoàng bào (G023) / Áo Nhật Bình đại lễ không dùng cho sự kiện thông thường.
4. KHÔNG nhầm lẫn việc lọc giới tính mô hình (model-gender) với tính phù hợp văn hóa.
5. Về ngày 'hôm nay' và địa điểm:
   - Dùng ngày địa phương do ứng dụng gửi tới nếu có: ${localDate}.
   - KHÔNG bịa thời tiết thời gian thực hay giờ mở cửa nếu không có dữ liệu thực tế. Chỉ hỏi thành phố/khu vực khi thực sự cần.
6. Khi người dùng hỏi về quà tặng:
   - Hỏi người nhận, dịp tặng và ngân sách nếu chưa rõ.
   - Gợi ý quà tặng thực tế, có ý nghĩa văn hóa chuẩn mực (Quạt lụa A011, Khăn rằn G034, Nón bài thơ G038, Trâm cài tóc G041, Hài thêu G046).
   - Phân biệt rõ quà thủ công đương đại lấy cảm hứng di sản với cổ vật/hiện vật gốc.
7. Khi gợi ý trang phục, hãy đưa ra 2–3 phương án phù hợp, mỗi phương án có:
   - title: Tên bộ phối
   - itemIds: Danh sách ID chuẩn xác thực thể (ví dụ: ['G008', 'G013', 'G031', 'G047'])
   - whySuits: Vì sao phù hợp với dịp và hoạt động người dùng dự định
   - stylingColorNotes: Gợi ý màu sắc và phối phụ kiện
   - comfortNotes: Lưu ý về độ thoải mái, thời gian mặc hoặc dress code
   - culturalEvidenceStatus: Mức độ tư liệu (AUTHENTIC, HISTORICALLY_SUPPORTED, CONTEXTUAL_MODERN_REMIX, UNCERTAIN)
   - warnings: Cảnh báo lưu ý văn hóa nếu có
8. Luôn trả về phản hồi DUY NHẤT bằng một chuỗi JSON hợp lệ không bọc markdown theo schema:
{
  "message": "Lời nhắn đối thoại thân thiện, nhã nhặn, súc tích",
  "quickActions": ["Gợi ý trang phục hôm nay", "Tìm đồ đi chụp ảnh", "Phối bộ này", "Giải thích nguồn tư liệu", "Gợi ý quà tặng"],
  "recommendations": [
    {
      "title": "Tên bộ phối",
      "itemIds": ["G008", "G013", "G031", "G047"],
      "whySuits": "Vì sao phù hợp",
      "stylingColorNotes": "Gợi ý phối màu",
      "comfortNotes": "Lưu ý di chuyển",
      "culturalEvidenceStatus": "HISTORICALLY_SUPPORTED",
      "warnings": ""
    }
  ],
  "giftSuggestions": [
    {
      "name": "Tên món quà",
      "itemOrCategory": "A011",
      "culturalMeaning": "Ý nghĩa biểu trưng",
      "suitableFor": "Đối tượng phù hợp",
      "budgetLevel": "Mức ngân sách",
      "notes": "Lưu ý văn hóa"
    }
  ]
}`;

          const formattedContents = [
            ...history.slice(-6).map((h: any) => ({
              role: h.role === 'model' ? 'model' : 'user',
              parts: [{ text: h.text }],
            })),
            {
              role: 'user',
              parts: [
                {
                  text: `Thời gian hiện tại: ${localDate}${location ? ` - Địa điểm: ${location}` : ''}. Câu hỏi của người dùng: "${userMessage}"`,
                },
              ],
            },
          ];

          const geminiResponse = await geminiClient.models.generateContent({
            model: 'gemini-3.8-flash',
            contents: formattedContents,
            config: {
              systemInstruction,
              responseMimeType: 'application/json',
              temperature: 0.7,
            },
          });

          const rawText = geminiResponse.text?.trim() || '';
          if (rawText) {
            let clean = rawText;
            if (clean.startsWith('```')) {
              clean = clean.replace(/^```(?:json)?\s*/i, '').replace(/\s*```$/, '');
            }
            const parsed = JSON.parse(clean);
            if (parsed && typeof parsed.message === 'string') {
              if (Array.isArray(parsed.recommendations)) {
                parsed.recommendations = parsed.recommendations
                  .map((r: any) => resolveRecommendation(r))
                  .filter(Boolean);
              }

              parsed.dateContext = localDate;
              return res.json({ ok: true, data: parsed });
            }
          }
        } catch (apiError) {
          console.warn('Gemini generateContent error, switching to deterministic advisor:', apiError);
        }
      }

      // Local Deterministic Advisor Fallback (100% catalog integrity)
      const fallback = generateAdvisorResponse(userMessage, localDate, location);
      return res.json({ ok: true, data: fallback });
    } catch (err: any) {
      console.error('Advisor chat server error:', err);
      const fallback = generateAdvisorResponse(
        req.body?.message || '',
        req.body?.userDate,
        req.body?.location
      );
      return res.json({ ok: true, data: fallback });
    }
  });

  // UNIFIED IMAGE GENERATION ENDPOINT (Supporting single_item_try_on, reference_image_edit, complete_outfit_try_on)
  app.post('/api/try-on', async (req, res) => {
    const requestId = req.body?.requestId || `req_${Date.now()}`;
    const mode = req.body?.mode || 'complete_outfit_try_on';

    try {
      const publicAssetsDir = path.resolve(__dirname, 'public/assets');
      const srcAssetsDir = path.resolve(__dirname, 'src/assets/images');

      function resolveAssetBuffer(filename: string): Buffer | null {
        const p1 = path.resolve(publicAssetsDir, filename);
        if (fs.existsSync(p1)) return fs.readFileSync(p1);
        const p2 = path.resolve(srcAssetsDir, filename);
        if (fs.existsSync(p2)) return fs.readFileSync(p2);
        return null;
      }

      function isAssetAvailable(filename: string): boolean {
        return Boolean(resolveAssetBuffer(filename));
      }

      const { client: geminiClient, apiKey: geminiApiKey } = getGeminiClient();

      // 1. Validate inputs before calling Gemini
      const validation = validateTryOnInputs(req.body, geminiApiKey, isAssetAvailable);
      if (!validation.valid) {
        return res.status(validation.status).json({
          ok: false,
          requestId,
          mode,
          error: validation.error,
          errorType: validation.errorType,
        });
      }

      // 2. Assemble image inputs: base model + selected reference images
      const imageParts: Array<{
        inlineData: {
          data: string;
          mimeType: string;
        };
      }> = [];

      // Include base model for single_item_try_on and complete_outfit_try_on (or reference_image_edit if requested)
      const shouldIncludeBaseModel =
        validation.mode !== 'reference_image_edit' ||
        Boolean(req.body.includeBaseModel);

      if (shouldIncludeBaseModel) {
        const baseBuffer = resolveAssetBuffer(validation.baseModelFilename);
        if (baseBuffer) {
          imageParts.push({
            inlineData: {
              data: baseBuffer.toString('base64'),
              mimeType: 'image/jpeg',
            },
          });
        }
      }

      // Include loaded garment reference images
      for (const asset of validation.itemAssets) {
        const buf = resolveAssetBuffer(asset.filename);
        if (buf) {
          imageParts.push({
            inlineData: {
              data: buf.toString('base64'),
              mimeType: asset.mimeType,
            },
          });
        }
      }

      // 3. Resolve effective prompt preserving the 3 modes
      const userPrompt = (req.body.prompt || req.body.customPrompt || '').trim();
      let effectivePrompt = userPrompt;
      if (!effectivePrompt) {
        if (validation.mode === 'single_item_try_on') {
          const singleId = validation.targetIds[0];
          const isAccessory = [
            'G031', 'G032', 'G033', 'G034', 'G035', 'G036', 'G037', 'G038', 'G039',
            'G040', 'G041', 'G042', 'G043', 'G044', 'G045', 'G046', 'G047',
            'A011', 'A012',
          ].includes(singleId);

          if (isAccessory) {
            effectivePrompt = `High-end photorealistic studio photograph of the model wearing ONLY the single traditional accessory (${singleId}).
PRESERVE NEUTRAL BASE MODEL: The model must wear a neutral, plain, unobtrusive ivory/light grey modern minimalist base shirt and trousers.
DO NOT INVENT A FULL COSTUME: Absolutely do NOT generate a complete traditional ceremonial robe, dragon robe, Áo Bà Ba, Áo Nhật Bình, or Áo Tứ Thân merely because an accessory was selected.
NO UNSELECTED ACCESSORIES: Do NOT add unselected jewelry, extra hats, cloaks, scarves, or fans.
Position the selected accessory accurately matching the reference image. Clean warm ivory archival studio backdrop.`;
          } else {
            effectivePrompt = `High-end photorealistic studio photograph of the model wearing the specific traditional Vietnamese garment (${singleId}).
Faithfully render the cut, collar style, sleeve width, and fabric texture matching the reference image.
Neutral modest plain underlayer and straight trousers for modesty only. Do NOT add unselected outer coats, sashes, or hats.`;
          }
        } else if (validation.mode === 'reference_image_edit') {
          effectivePrompt = `Masterpiece editorial photograph based strictly on the provided reference artifact of (${validation.targetIds[0]}).
Accurately reproduce the collar cut, seam construction, textile texture, and silhouette shown in the reference image. Professional archival museum presentation.`;
        } else {
          effectivePrompt = `High-end photorealistic editorial studio photograph of the model wearing complete coordinated traditional Vietnamese outfit (${req.body.outfitTitle || 'Việt Phục'}).
Faithfully incorporate all selected garment layers: ${validation.targetIds.join(', ')}.
Maintain authentic Vietnamese traditional construction. Neutral warm ivory studio background with soft lighting.`;
        }
      }

      // 4. Call Gemini generateContent explicitly requesting image output
      try {
        const response = await geminiClient!.models.generateContent({
          model: 'gemini-3.1-flash-lite-image',
          contents: {
            parts: [
              ...imageParts,
              {
                text: effectivePrompt,
              },
            ],
          },
          config: {
            responseModalities: ['TEXT', 'IMAGE'],
          },
        });

        // 5. Handle all API outcomes explicitly
        const extracted = extractGeminiImageResponse(response);
        if (extracted.ok) {
          return res.json({
            ok: true,
            requestId,
            mode: validation.mode,
            imageUrl: extracted.imageUrl,
            serviceUsed: 'gemini-3.1-flash-lite-image (Nano Banana)',
            isFallback: false,
          });
        }

        // When only text is returned, log safe diagnostic and return NO_IMAGE_DATA
        const safeDiagnostic = extracted.returnedText
          ? extracted.returnedText.substring(0, 300)
          : 'Không có phản hồi từ mô hình';
        console.warn(`[try-on] Gemini model returned text only without image data. Diagnostic: ${safeDiagnostic}`);

        return res.status(502).json({
          ok: false,
          requestId,
          mode: validation.mode,
          error: 'Mô hình tạo ảnh không trả về phần dữ liệu hình ảnh (chỉ phản hồi văn bản). Vui lòng bấm "Thử lại".',
          errorType: 'NO_IMAGE_DATA',
          diagnostic: safeDiagnostic,
        });
      } catch (apiErr: any) {
        // Safe error classification without leaking API keys
        const classified = classifyGeminiError(apiErr, geminiApiKey);
        if (classified.errorType === 'PAID_PLAN_REQUIRED' || classified.errorType === 'QUOTA_EXCEEDED') {
          console.info(`[try-on] Quota status (${classified.status}, ${classified.errorType})`);
        } else {
          console.warn(`[try-on] Notice: ${classified.errorType} (status=${classified.status}): ${classified.sanitizedDetails}`);
        }

        return res.status(classified.status).json({
          ok: false,
          requestId,
          mode: validation.mode,
          error: classified.messageVi,
          errorType: classified.errorType,
        });
      }
    } catch (err: any) {
      console.error('Try-on server exception:', err);
      return res.status(500).json({
        ok: false,
        requestId,
        mode,
        error: 'Lỗi máy chủ trong quá trình xử lý yêu cầu tạo ảnh: ' + (err?.message || 'Lỗi không xác định'),
        errorType: 'SERVER_ERROR',
      });
    }
  });

  if (isProd && fs.existsSync(distPath)) {
    // Production mode: Serve pre-built static files from dist
    app.use(express.static(distPath));

    app.get('*', (_req, res) => {
      const indexPath = path.resolve(distPath, 'index.html');
      if (fs.existsSync(indexPath)) {
        res.sendFile(indexPath);
      } else {
        res.status(404).send('Application build not found. Run npm run build first.');
      }
    });
  } else {
    // Development mode: Mount Vite dev middleware
    const { createServer } = await import('vite');
    const vite = await createServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Server listening on http://0.0.0.0:${PORT} (${isProd ? 'production' : 'development'})`);
  });
}

startServer().catch((err) => {
  console.error('Failed to start server:', err);
  process.exit(1);
});
