# VIỆT PHỤC REMIX — MASTER RESEARCH v1
**Kiến trúc Catalog & Outfit Builder có trách nhiệm văn hóa cho Trang phục Kinh Việt**

Ứng dụng web được phát triển dựa trên bộ tư liệu khảo cứu chuẩn hóa **Viet_Phuc_Master_Research_v1.json**, phục vụ tra cứu, phối đồ theo lớp và cảnh báo sự không phù hợp về mặt lịch sử/văn hóa.

---

## 1. NGUYÊN TẮC CỐT LÕI
- **"AI có thể sáng tạo phong cách, nhưng không được sáng tạo sự thật văn hóa."**
- **Không suy diễn ngoài nguồn**: Mọi quy tắc và phán đoán đều bắt nguồn từ tư liệu hiện vật bảo tàng (Bảo tàng Lịch sử Quốc gia, Bảo tàng Phụ nữ Nam Bộ, Bảo tàng Cổ vật Cung đình Huế...) hoặc thư tịch chính thống.
- **Bảo lưu trạng thái bất định**: Các trường hợp đang tranh luận học thuật (như Tứ Điên, phân biệt nón Ba Tầm vs Quai Thao, hệ phân loại Trực lĩnh) được giữ nguyên nhãn `CONTESTED` hoặc `UNCERTAIN`, tuyệt đối không ép thành chân lý duy nhất.
- **Không dùng ảnh AI làm tư liệu lịch sử**: Hệ thống chỉ hiển thị ảnh do quản trị viên cung cấp qua `assets.json`, khi chưa có ảnh sẽ hiển thị placeholder trang nhã.

---

## 2. HƯỚNG DẪN QUẢN TRỊ & THAY THẾ DỮ LIỆU

### A. Thay thế tệp dữ liệu nghiên cứu (`Viet_Phuc_Master_Research_v1.json`)
- Vị trí tệp: `src/data/Viet_Phuc_Master_Research_v1.json`
- Module `src/domain/dataAdapter.ts` tự động đọc các bảng:
  - `README`: Tuyên ngôn, phạm vi, mức độ chứng cứ.
  - `MASTER_GARMENTS` (G001 - G047): Hồ sơ 47 dạng thức trang phục.
  - `OUTFIT_RULES` (R001 - R022): 22 quy tắc tương thích cốt lõi.
  - `ACCESSORIES` (A001 - A013): 13 phụ kiện đối chiếu.
  - `PDF_AUDIT`: 14 mục hiệu đính từ bản thảo cũ.
  - `SOURCES` (S01 - S10): 10 nguồn tư liệu gốc có liên kết.
  - `RESEARCH_QUEUE`: Các chủ đề P0 và P1 đang tiếp tục khảo cứu.

### B. Ánh xạ hình ảnh thực tế (`assets.json`)
- Vị trí tệp: `src/data/assets.json`
- Cấu trúc bản ghi:
```json
{
  "id": "IMG_G001_COVER",
  "recordId": "G001",
  "kind": "cover",
  "src": "/src/assets/images/costume_ao_giao_linh_nhat_binh_1790686952621.jpg",
  "alt": "Minh họa phom dáng Áo Giao Lĩnh cổ chéo truyền thống",
  "credit": "Tư liệu nghiên cứu Tàng Y Các",
  "license": "Editorial Archive Use"
}
```
- Các loại `kind`:
  - `"cover"`: Ảnh đại diện hiện vật trong Catalog.
  - `"detail"`: Ảnh cận cảnh chất liệu / hoa văn.
  - `"silhouette"`: Ảnh phom dáng cắt bóng.
  - `"lookbook"`: Ảnh bộ phối trưng bày trong Lookbook.

---

## 3. CÁC MÀN HÌNH CHÍNH
1. **Khởi Đầu (Explore)**: Giới thiệu tôn chỉ, phạm vi Kinh phục và khuyến cáo học thuật nổi bật.
2. **Tủ Áo Xưa (Catalog)**: Tra cứu 47 hiện vật & 13 phụ kiện với bộ lọc động không rỗng (chỉ hiển thị facet thực tế có trong data).
3. **Chuyện Áo (Item Detail)**: Hồ sơ chi tiết từng hiện vật (cấu trúc đã xác minh, layer có cơ sở, cảnh báo, trích dẫn nguồn S01–S10 và các quy tắc R001–R022 liên quan).
4. **Phối Phục (Outfit Builder)**: Xếp lớp y phục (Nội y &rarr; Áo chính &rarr; Áo khoác &rarr; Thân dưới &rarr; Khăn/Nón/Mũ &rarr; Phụ kiện &rarr; Giày/dép). Tự động thẩm định bằng Compatibility Engine deterministic và đưa ra gợi ý phối tiếp có căn cứ.
5. **So Bộ & Cất Giữ (Compare Outfits)**: So sánh đối chiếu tối đa 2 bộ phối cạnh nhau và quản lý danh sách bộ phối đã lưu trong máy.
6. **Lookbook**: Trưng bày các ảnh biên tập đã đăng ký trong `assets.json` và các bộ phối người dùng đã lưu.
7. **Nguồn & Lời Nhắn (Sources & Audit)**: Danh mục 10 nguồn bảo tàng (S01–S10), bảng theo dõi thẩm định (Research Queue P0/P1) và bảng 14 mục hiệu đính từ bản thảo cũ (PDF Audit).

---

## 4. DANH SÁCH TÍNH NĂNG ĐỂ FUTURE (GIỚI HẠN DỮ LIỆU)
Các tính năng sau đây được chủ động **không triển khai tại v1** theo đúng chỉ dẫn của tệp nghiên cứu:
1. **Gợi ý theo thời tiết / nhiệt độ (Weather suggestion)**: Dataset không chứa dữ liệu khí tượng, nhiệt độ hay chỉ số thoáng khí của chất liệu dệt.
2. **Preset Lookbook tự tạo**: Không bịa đặt các bộ phối lịch sử hư cấu khi data không cung cấp; Lookbook chỉ hiển thị ảnh đã map trong `assets.json` và bộ phối người dùng tự lưu.
3. **Gợi ý theo sự kiện / occasion tự do**: Chỉ kích hoạt khi record có trường bối cảnh/nghi lễ được chứng thực; không tự suy diễn các dịp đi học, tiệc tùng hiện đại cho trang phục tế lễ cổ đại.
4. **Backend / Auth / Admin CMS**: Phiên bản v1 chạy client-side hoàn toàn, lưu bộ phối cục bộ bằng `localStorage`.
